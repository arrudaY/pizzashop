import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=efc33bbd"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=efc33bbd";
import { DollarSign } from "/node_modules/.vite/deps/lucide-react.js?v=efc33bbd";
import { getMonthCancledOrdersAmount } from "/src/api/get-month-canceled-orders-amount.ts";
import { Card, CardContent, CardHeader, CardTitle } from "/src/components/ui/card.tsx";
import { MetricCardSkeleton } from "/src/pages/app/dashboard/metric-card-skeleton.tsx";
export function MonthCanceledOrdersAmountCard() {
  _s();
  const { data: monthCanceledOrdersAmount } = useQuery({
    queryKey: ["metrics", "month-canceled-orders-amount"],
    queryFn: getMonthCancledOrdersAmount
  });
  return /* @__PURE__ */ jsxDEV(Card, { children: [
    /* @__PURE__ */ jsxDEV(CardHeader, { className: "flex-row items-center justify-between space-y-0 pb-2", children: [
      /* @__PURE__ */ jsxDEV(CardTitle, { className: "text-base font-semibold", children: "Cancelamentos (mês)" }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
        lineNumber: 17,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DollarSign, { className: "h-4 w-4 text-muted-foreground" }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
        lineNumber: 20,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
      lineNumber: 16,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(CardContent, { className: "space-y-1", children: monthCanceledOrdersAmount ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("span", { className: "racking-tight font-mono text-2xl font-bold", children: monthCanceledOrdersAmount.amount.toLocaleString("pt-BR") }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
        lineNumber: 25,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-muted-foreground", children: monthCanceledOrdersAmount.diffFromLastMonth < 0 ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-emerald-500 dark:text-emerald-400", children: [
          monthCanceledOrdersAmount.diffFromLastMonth,
          "%"
        ] }, void 0, true, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
          lineNumber: 31,
          columnNumber: 19
        }, this),
        " ",
        "em relação ao mês anterior"
      ] }, void 0, true, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
        lineNumber: 30,
        columnNumber: 13
      }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-rose-500 dark:text-rose-400", children: [
          "+",
          monthCanceledOrdersAmount.diffFromLastMonth,
          "%"
        ] }, void 0, true, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
          lineNumber: 38,
          columnNumber: 19
        }, this),
        " ",
        "em relação ao mês anterior"
      ] }, void 0, true, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
        lineNumber: 37,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
        lineNumber: 28,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
      lineNumber: 24,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV(MetricCardSkeleton, {}, void 0, false, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
      lineNumber: 47,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
      lineNumber: 22,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
    lineNumber: 15,
    columnNumber: 5
  }, this);
}
_s(MonthCanceledOrdersAmountCard, "8+4OTDJzpazOHlKic+kKfdz2IPM=", false, function() {
  return [useQuery];
});
_c = MonthCanceledOrdersAmountCard;
var _c;
$RefreshReg$(_c, "MonthCanceledOrdersAmountCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JRLFNBYVEsVUFiUjsyQkFoQlI7QUFBaUIsTUFBUSxxQkFBdUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDaEQsU0FBU0Esa0JBQWtCO0FBRTNCLFNBQVNDLG1DQUFtQztBQUM1QyxTQUFTQyxNQUFNQyxhQUFhQyxZQUFZQyxpQkFBaUI7QUFFekQsU0FBU0MsMEJBQTBCO0FBRTVCLGdCQUFTQyxnQ0FBZ0M7QUFBQUMsS0FBQTtBQUM5QyxRQUFNLEVBQUVDLE1BQU1DLDBCQUEwQixJQUFJQyxTQUFTO0FBQUEsSUFDbkRDLFVBQVUsQ0FBQyxXQUFXLDhCQUE4QjtBQUFBLElBQ3BEQyxTQUFTWjtBQUFBQSxFQUNYLENBQUM7QUFDRCxTQUNFLHVCQUFDLFFBQ0M7QUFBQSwyQkFBQyxjQUFXLFdBQVUsd0RBQ3BCO0FBQUEsNkJBQUMsYUFBVSxXQUFVLDJCQUF5QixtQ0FBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxjQUFXLFdBQVUsbUNBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUQ7QUFBQSxTQUp2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxJQUNBLHVCQUFDLGVBQVksV0FBVSxhQUNwQlMsc0NBQ0MsbUNBQ0U7QUFBQSw2QkFBQyxVQUFLLFdBQVUsOENBQ2JBLG9DQUEwQkksT0FBT0MsZUFBZSxPQUFPLEtBRDFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsT0FBRSxXQUFVLGlDQUNWTCxvQ0FBMEJNLG9CQUFvQixJQUM3QyxtQ0FDRTtBQUFBLCtCQUFDLFVBQUssV0FBVSxvREFDYk47QUFBQUEsb0NBQTBCTTtBQUFBQSxVQUFrQjtBQUFBLGFBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQVE7QUFBQSxRQUFHO0FBQUEsV0FIYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0EsSUFFQSxtQ0FDRTtBQUFBLCtCQUFDLFVBQUssV0FBVSw4Q0FBNEM7QUFBQTtBQUFBLFVBQ3hETiwwQkFBMEJNO0FBQUFBLFVBQWtCO0FBQUEsYUFEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFBUTtBQUFBLFFBQUc7QUFBQSxXQUhiO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQSxLQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnQkE7QUFBQSxTQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUJBLElBRUEsdUJBQUMsd0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtQixLQXpCdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJCQTtBQUFBLE9BbENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtQ0E7QUFFSjtBQUFDUixHQTNDZUQsK0JBQTZCO0FBQUEsVUFDQ0ksUUFBUTtBQUFBO0FBQUFNLEtBRHRDVjtBQUE2QixJQUFBVTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiRG9sbGFyU2lnbiIsImdldE1vbnRoQ2FuY2xlZE9yZGVyc0Ftb3VudCIsIkNhcmQiLCJDYXJkQ29udGVudCIsIkNhcmRIZWFkZXIiLCJDYXJkVGl0bGUiLCJNZXRyaWNDYXJkU2tlbGV0b24iLCJNb250aENhbmNlbGVkT3JkZXJzQW1vdW50Q2FyZCIsIl9zIiwiZGF0YSIsIm1vbnRoQ2FuY2VsZWRPcmRlcnNBbW91bnQiLCJ1c2VRdWVyeSIsInF1ZXJ5S2V5IiwicXVlcnlGbiIsImFtb3VudCIsInRvTG9jYWxlU3RyaW5nIiwiZGlmZkZyb21MYXN0TW9udGgiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIm1vbnRoLWNhbmNlbGVkLW9yZGVycy1hbW91bnQtY2FyZC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUXVlcnkgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG5pbXBvcnQgeyBEb2xsYXJTaWduIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuXG5pbXBvcnQgeyBnZXRNb250aENhbmNsZWRPcmRlcnNBbW91bnQgfSBmcm9tICdAL2FwaS9nZXQtbW9udGgtY2FuY2VsZWQtb3JkZXJzLWFtb3VudCdcbmltcG9ydCB7IENhcmQsIENhcmRDb250ZW50LCBDYXJkSGVhZGVyLCBDYXJkVGl0bGUgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvY2FyZCdcblxuaW1wb3J0IHsgTWV0cmljQ2FyZFNrZWxldG9uIH0gZnJvbSAnLi9tZXRyaWMtY2FyZC1za2VsZXRvbidcblxuZXhwb3J0IGZ1bmN0aW9uIE1vbnRoQ2FuY2VsZWRPcmRlcnNBbW91bnRDYXJkKCkge1xuICBjb25zdCB7IGRhdGE6IG1vbnRoQ2FuY2VsZWRPcmRlcnNBbW91bnQgfSA9IHVzZVF1ZXJ5KHtcbiAgICBxdWVyeUtleTogWydtZXRyaWNzJywgJ21vbnRoLWNhbmNlbGVkLW9yZGVycy1hbW91bnQnXSxcbiAgICBxdWVyeUZuOiBnZXRNb250aENhbmNsZWRPcmRlcnNBbW91bnQsXG4gIH0pXG4gIHJldHVybiAoXG4gICAgPENhcmQ+XG4gICAgICA8Q2FyZEhlYWRlciBjbGFzc05hbWU9XCJmbGV4LXJvdyBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXktMCBwYi0yXCI+XG4gICAgICAgIDxDYXJkVGl0bGUgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICBDYW5jZWxhbWVudG9zIChtw6pzKVxuICAgICAgICA8L0NhcmRUaXRsZT5cbiAgICAgICAgPERvbGxhclNpZ24gY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LW11dGVkLWZvcmVncm91bmRcIiAvPlxuICAgICAgPC9DYXJkSGVhZGVyPlxuICAgICAgPENhcmRDb250ZW50IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxuICAgICAgICB7bW9udGhDYW5jZWxlZE9yZGVyc0Ftb3VudCA/IChcbiAgICAgICAgICA8PlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmFja2luZy10aWdodCBmb250LW1vbm8gdGV4dC0yeGwgZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgIHttb250aENhbmNlbGVkT3JkZXJzQW1vdW50LmFtb3VudC50b0xvY2FsZVN0cmluZygncHQtQlInKX1cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgIHttb250aENhbmNlbGVkT3JkZXJzQW1vdW50LmRpZmZGcm9tTGFzdE1vbnRoIDwgMCA/IChcbiAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZW1lcmFsZC01MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIHttb250aENhbmNlbGVkT3JkZXJzQW1vdW50LmRpZmZGcm9tTGFzdE1vbnRofSVcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj57JyAnfVxuICAgICAgICAgICAgICAgICAgZW0gcmVsYcOnw6NvIGFvIG3DqnMgYW50ZXJpb3JcbiAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtcm9zZS01MDAgZGFyazp0ZXh0LXJvc2UtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICt7bW9udGhDYW5jZWxlZE9yZGVyc0Ftb3VudC5kaWZmRnJvbUxhc3RNb250aH0lXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+eycgJ31cbiAgICAgICAgICAgICAgICAgIGVtIHJlbGHDp8OjbyBhbyBtw6pzIGFudGVyaW9yXG4gICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgPC8+XG4gICAgICAgICkgOiAoXG4gICAgICAgICAgPE1ldHJpY0NhcmRTa2VsZXRvbiAvPlxuICAgICAgICApfVxuICAgICAgPC9DYXJkQ29udGVudD5cbiAgICA8L0NhcmQ+XG4gIClcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2FycnVkYXkvR2l0SHViL3Bpenphc2hvcC9zcmMvcGFnZXMvYXBwL2Rhc2hib2FyZC9tb250aC1jYW5jZWxlZC1vcmRlcnMtYW1vdW50LWNhcmQudHN4In0=