import {
  require_react
} from "/node_modules/.vite/deps/chunk-BOFYMYUE.js?v=efc33bbd";
import "/node_modules/.vite/deps/chunk-TXPGJST7.js?v=efc33bbd";
export default require_react();
//# sourceMappingURL=react.js.map
