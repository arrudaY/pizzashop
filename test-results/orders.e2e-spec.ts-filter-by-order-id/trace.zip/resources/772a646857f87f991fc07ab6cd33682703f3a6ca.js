import {
  clsx,
  clsx_default
} from "/node_modules/.vite/deps/chunk-ZHRGLJTE.js?v=efc33bbd";
import "/node_modules/.vite/deps/chunk-TXPGJST7.js?v=efc33bbd";
export {
  clsx,
  clsx_default as default
};
//# sourceMappingURL=clsx.js.map
