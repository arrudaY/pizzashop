import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/order-status.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=efc33bbd"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/arruday/GitHub/pizzashop/src/components/order-status.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const orderStatusMap = {
  pending: "Pendente",
  canceled: "Cancelado",
  processing: "Em preparo",
  delivering: "Em entrega",
  delivered: "Entregue"
};
export function OrderStatus({ status }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
    status === "pending" && /* @__PURE__ */ jsxDEV(
      "span",
      {
        "data-testid": "badge",
        className: "h-2 w-2 rounded-full bg-slate-400"
      },
      void 0,
      false,
      {
        fileName: "/Users/arruday/GitHub/pizzashop/src/components/order-status.tsx",
        lineNumber: 23,
        columnNumber: 7
      },
      this
    ),
    status === "canceled" && /* @__PURE__ */ jsxDEV(
      "span",
      {
        "data-testid": "badge",
        className: "h-2 w-2 rounded-full bg-rose-500"
      },
      void 0,
      false,
      {
        fileName: "/Users/arruday/GitHub/pizzashop/src/components/order-status.tsx",
        lineNumber: 29,
        columnNumber: 7
      },
      this
    ),
    status === "delivered" && /* @__PURE__ */ jsxDEV(
      "span",
      {
        "data-testid": "badge",
        className: "h-2 w-2 rounded-full bg-emerald-500"
      },
      void 0,
      false,
      {
        fileName: "/Users/arruday/GitHub/pizzashop/src/components/order-status.tsx",
        lineNumber: 35,
        columnNumber: 7
      },
      this
    ),
    ["processing", "delivering"].includes(status) && /* @__PURE__ */ jsxDEV(
      "span",
      {
        "data-testid": "badge",
        className: "h-2 w-2 rounded-full bg-amber-500"
      },
      void 0,
      false,
      {
        fileName: "/Users/arruday/GitHub/pizzashop/src/components/order-status.tsx",
        lineNumber: 41,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-muted-foreground", children: orderStatusMap[status] }, void 0, false, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/components/order-status.tsx",
      lineNumber: 47,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/arruday/GitHub/pizzashop/src/components/order-status.tsx",
    lineNumber: 21,
    columnNumber: 5
  }, this);
}
_c = OrderStatus;
var _c;
$RefreshReg$(_c, "OrderStatus");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arruday/GitHub/pizzashop/src/components/order-status.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0JRO0FBdEJSLE9BQU8sb0JBQWdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVd2QixNQUFNQSxpQkFBOEM7QUFBQSxFQUNsREMsU0FBUztBQUFBLEVBQ1RDLFVBQVU7QUFBQSxFQUNWQyxZQUFZO0FBQUEsRUFDWkMsWUFBWTtBQUFBLEVBQ1pDLFdBQVc7QUFDYjtBQUNPLGdCQUFTQyxZQUFZLEVBQUVDLE9BQXlCLEdBQUc7QUFDeEQsU0FDRSx1QkFBQyxTQUFJLFdBQVUsMkJBQ1pBO0FBQUFBLGVBQVcsYUFDVjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsZUFBWTtBQUFBLFFBQ1osV0FBVTtBQUFBO0FBQUEsTUFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFFK0M7QUFBQSxJQUdoREEsV0FBVyxjQUNWO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxlQUFZO0FBQUEsUUFDWixXQUFVO0FBQUE7QUFBQSxNQUZaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUU4QztBQUFBLElBRy9DQSxXQUFXLGVBQ1Y7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLGVBQVk7QUFBQSxRQUNaLFdBQVU7QUFBQTtBQUFBLE1BRlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRWlEO0FBQUEsSUFHbEQsQ0FBQyxjQUFjLFlBQVksRUFBRUMsU0FBU0QsTUFBTSxLQUMzQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsZUFBWTtBQUFBLFFBQ1osV0FBVTtBQUFBO0FBQUEsTUFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFFK0M7QUFBQSxJQUlqRCx1QkFBQyxVQUFLLFdBQVUscUNBQ2JQLHlCQUFlTyxNQUFNLEtBRHhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2QkE7QUFFSjtBQUFDRSxLQWpDZUg7QUFBVyxJQUFBRztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsib3JkZXJTdGF0dXNNYXAiLCJwZW5kaW5nIiwiY2FuY2VsZWQiLCJwcm9jZXNzaW5nIiwiZGVsaXZlcmluZyIsImRlbGl2ZXJlZCIsIk9yZGVyU3RhdHVzIiwic3RhdHVzIiwiaW5jbHVkZXMiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIm9yZGVyLXN0YXR1cy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IHR5cGUgT3JkZXJTdGF0dXMgPVxuICB8ICdwZW5kaW5nJ1xuICB8ICdjYW5jZWxlZCdcbiAgfCAncHJvY2Vzc2luZydcbiAgfCAnZGVsaXZlcmluZydcbiAgfCAnZGVsaXZlcmVkJ1xuXG5pbnRlcmZhY2UgT3JkZXJTdGF0dXNQcm9wcyB7XG4gIHN0YXR1czogT3JkZXJTdGF0dXNcbn1cblxuY29uc3Qgb3JkZXJTdGF0dXNNYXA6IFJlY29yZDxPcmRlclN0YXR1cywgc3RyaW5nPiA9IHtcbiAgcGVuZGluZzogJ1BlbmRlbnRlJyxcbiAgY2FuY2VsZWQ6ICdDYW5jZWxhZG8nLFxuICBwcm9jZXNzaW5nOiAnRW0gcHJlcGFybycsXG4gIGRlbGl2ZXJpbmc6ICdFbSBlbnRyZWdhJyxcbiAgZGVsaXZlcmVkOiAnRW50cmVndWUnLFxufVxuZXhwb3J0IGZ1bmN0aW9uIE9yZGVyU3RhdHVzKHsgc3RhdHVzIH06IE9yZGVyU3RhdHVzUHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICB7c3RhdHVzID09PSAncGVuZGluZycgJiYgKFxuICAgICAgICA8c3BhblxuICAgICAgICAgIGRhdGEtdGVzdGlkPVwiYmFkZ2VcIlxuICAgICAgICAgIGNsYXNzTmFtZT1cImgtMiB3LTIgcm91bmRlZC1mdWxsIGJnLXNsYXRlLTQwMFwiXG4gICAgICAgIC8+XG4gICAgICApfVxuICAgICAge3N0YXR1cyA9PT0gJ2NhbmNlbGVkJyAmJiAoXG4gICAgICAgIDxzcGFuXG4gICAgICAgICAgZGF0YS10ZXN0aWQ9XCJiYWRnZVwiXG4gICAgICAgICAgY2xhc3NOYW1lPVwiaC0yIHctMiByb3VuZGVkLWZ1bGwgYmctcm9zZS01MDBcIlxuICAgICAgICAvPlxuICAgICAgKX1cbiAgICAgIHtzdGF0dXMgPT09ICdkZWxpdmVyZWQnICYmIChcbiAgICAgICAgPHNwYW5cbiAgICAgICAgICBkYXRhLXRlc3RpZD1cImJhZGdlXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJoLTIgdy0yIHJvdW5kZWQtZnVsbCBiZy1lbWVyYWxkLTUwMFwiXG4gICAgICAgIC8+XG4gICAgICApfVxuICAgICAge1sncHJvY2Vzc2luZycsICdkZWxpdmVyaW5nJ10uaW5jbHVkZXMoc3RhdHVzKSAmJiAoXG4gICAgICAgIDxzcGFuXG4gICAgICAgICAgZGF0YS10ZXN0aWQ9XCJiYWRnZVwiXG4gICAgICAgICAgY2xhc3NOYW1lPVwiaC0yIHctMiByb3VuZGVkLWZ1bGwgYmctYW1iZXItNTAwXCJcbiAgICAgICAgLz5cbiAgICAgICl9XG5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICB7b3JkZXJTdGF0dXNNYXBbc3RhdHVzXX1cbiAgICAgIDwvc3Bhbj5cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl0sImZpbGUiOiIvVXNlcnMvYXJydWRheS9HaXRIdWIvcGl6emFzaG9wL3NyYy9jb21wb25lbnRzL29yZGVyLXN0YXR1cy50c3gifQ==