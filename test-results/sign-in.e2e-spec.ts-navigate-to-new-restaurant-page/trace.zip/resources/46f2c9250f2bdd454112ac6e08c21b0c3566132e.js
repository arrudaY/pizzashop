import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/pagination.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=efc33bbd"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/arruday/GitHub/pizzashop/src/components/pagination.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import {
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight
} from "/node_modules/.vite/deps/lucide-react.js?v=efc33bbd";
import { Button } from "/src/components/ui/button.tsx";
export function Pagination({
  pageIndex,
  totalCount,
  perPage,
  onPageChange
}) {
  const pages = Math.ceil(totalCount / perPage) || 1;
  return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
    /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-muted-foreground", children: [
      "Total de ",
      totalCount,
      " ",
      totalCount > 1 ? "itens" : "item"
    ] }, void 0, true, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/components/pagination.tsx",
      lineNumber: 27,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-6 lg:gap-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex text-sm font-medium", children: [
        "Página ",
        pageIndex + 1,
        " de ",
        pages
      ] }, void 0, true, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/components/pagination.tsx",
        lineNumber: 31,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            title: "Primeira página",
            onClick: () => onPageChange(0),
            variant: "outline",
            className: "h-8 w-8 p-0",
            disabled: pageIndex === 0,
            children: [
              /* @__PURE__ */ jsxDEV(ChevronsLeft, { className: "h-4 w-4" }, void 0, false, {
                fileName: "/Users/arruday/GitHub/pizzashop/src/components/pagination.tsx",
                lineNumber: 42,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: "Primeira página" }, void 0, false, {
                fileName: "/Users/arruday/GitHub/pizzashop/src/components/pagination.tsx",
                lineNumber: 43,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/arruday/GitHub/pizzashop/src/components/pagination.tsx",
            lineNumber: 35,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            title: "Página anterior",
            onClick: () => onPageChange(pageIndex - 1),
            variant: "outline",
            className: "h-8 w-8 p-0",
            disabled: pageIndex === 0,
            children: [
              /* @__PURE__ */ jsxDEV(ChevronLeft, { className: "h-4 w-4" }, void 0, false, {
                fileName: "/Users/arruday/GitHub/pizzashop/src/components/pagination.tsx",
                lineNumber: 52,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: "Página anterior" }, void 0, false, {
                fileName: "/Users/arruday/GitHub/pizzashop/src/components/pagination.tsx",
                lineNumber: 53,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/arruday/GitHub/pizzashop/src/components/pagination.tsx",
            lineNumber: 45,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            title: "Próxima página",
            onClick: () => onPageChange(pageIndex + 1),
            variant: "outline",
            className: "h-8 w-8 p-0",
            disabled: pages <= pageIndex + 1,
            children: [
              /* @__PURE__ */ jsxDEV(ChevronRight, { className: "h-4 w-4" }, void 0, false, {
                fileName: "/Users/arruday/GitHub/pizzashop/src/components/pagination.tsx",
                lineNumber: 62,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: "Próxima página" }, void 0, false, {
                fileName: "/Users/arruday/GitHub/pizzashop/src/components/pagination.tsx",
                lineNumber: 63,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/arruday/GitHub/pizzashop/src/components/pagination.tsx",
            lineNumber: 55,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            title: "Última página",
            onClick: () => onPageChange(pages - 1),
            variant: "outline",
            className: "h-8 w-8 p-0",
            disabled: pages <= pageIndex + 1,
            children: [
              /* @__PURE__ */ jsxDEV(ChevronsRight, { className: "h-4 w-4" }, void 0, false, {
                fileName: "/Users/arruday/GitHub/pizzashop/src/components/pagination.tsx",
                lineNumber: 72,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: "Última página" }, void 0, false, {
                fileName: "/Users/arruday/GitHub/pizzashop/src/components/pagination.tsx",
                lineNumber: 73,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/arruday/GitHub/pizzashop/src/components/pagination.tsx",
            lineNumber: 65,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/components/pagination.tsx",
        lineNumber: 34,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/components/pagination.tsx",
      lineNumber: 30,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/arruday/GitHub/pizzashop/src/components/pagination.tsx",
    lineNumber: 26,
    columnNumber: 5
  }, this);
}
_c = Pagination;
var _c;
$RefreshReg$(_c, "Pagination");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arruday/GitHub/pizzashop/src/components/pagination.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEJNO0FBMUJOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFDRUE7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUVQLFNBQVNDLGNBQWM7QUFTaEIsZ0JBQVNDLFdBQVc7QUFBQSxFQUN6QkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDZSxHQUFHO0FBQ2xCLFFBQU1DLFFBQVFDLEtBQUtDLEtBQUtMLGFBQWFDLE9BQU8sS0FBSztBQUVqRCxTQUNFLHVCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLDJCQUFDLFVBQUssV0FBVSxpQ0FBK0I7QUFBQTtBQUFBLE1BQ25DRDtBQUFBQSxNQUFXO0FBQUEsTUFBRUEsYUFBYSxJQUFJLFVBQVU7QUFBQSxTQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBVSxvQ0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSw0QkFBMEI7QUFBQTtBQUFBLFFBQy9CRCxZQUFZO0FBQUEsUUFBRTtBQUFBLFFBQUtJO0FBQUFBLFdBRDdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLFNBQVMsTUFBTUQsYUFBYSxDQUFDO0FBQUEsWUFDN0IsU0FBUTtBQUFBLFlBQ1IsV0FBVTtBQUFBLFlBQ1YsVUFBVUgsY0FBYztBQUFBLFlBRXhCO0FBQUEscUNBQUMsZ0JBQWEsV0FBVSxhQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpQztBQUFBLGNBQ2pDLHVCQUFDLFVBQUssV0FBVSxXQUFVLCtCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5QztBQUFBO0FBQUE7QUFBQSxVQVIzQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFTQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLFNBQVMsTUFBTUcsYUFBYUgsWUFBWSxDQUFDO0FBQUEsWUFDekMsU0FBUTtBQUFBLFlBQ1IsV0FBVTtBQUFBLFlBQ1YsVUFBVUEsY0FBYztBQUFBLFlBRXhCO0FBQUEscUNBQUMsZUFBWSxXQUFVLGFBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdDO0FBQUEsY0FDaEMsdUJBQUMsVUFBSyxXQUFVLFdBQVUsK0JBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlDO0FBQUE7QUFBQTtBQUFBLFVBUjNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVNBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sU0FBUyxNQUFNRyxhQUFhSCxZQUFZLENBQUM7QUFBQSxZQUN6QyxTQUFRO0FBQUEsWUFDUixXQUFVO0FBQUEsWUFDVixVQUFVSSxTQUFTSixZQUFZO0FBQUEsWUFFL0I7QUFBQSxxQ0FBQyxnQkFBYSxXQUFVLGFBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlDO0FBQUEsY0FDakMsdUJBQUMsVUFBSyxXQUFVLFdBQVUsOEJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdDO0FBQUE7QUFBQTtBQUFBLFVBUjFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVNBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sU0FBUyxNQUFNRyxhQUFhQyxRQUFRLENBQUM7QUFBQSxZQUNyQyxTQUFRO0FBQUEsWUFDUixXQUFVO0FBQUEsWUFDVixVQUFVQSxTQUFTSixZQUFZO0FBQUEsWUFFL0I7QUFBQSxxQ0FBQyxpQkFBYyxXQUFVLGFBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtDO0FBQUEsY0FDbEMsdUJBQUMsVUFBSyxXQUFVLFdBQVUsNkJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVDO0FBQUE7QUFBQTtBQUFBLFVBUnpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVNBO0FBQUEsV0F4Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlDQTtBQUFBLFNBN0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4Q0E7QUFBQSxPQWxERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbURBO0FBRUo7QUFBQ08sS0E5RGVSO0FBQVUsSUFBQVE7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkNoZXZyb25MZWZ0IiwiQ2hldnJvblJpZ2h0IiwiQ2hldnJvbnNMZWZ0IiwiQ2hldnJvbnNSaWdodCIsIkJ1dHRvbiIsIlBhZ2luYXRpb24iLCJwYWdlSW5kZXgiLCJ0b3RhbENvdW50IiwicGVyUGFnZSIsIm9uUGFnZUNoYW5nZSIsInBhZ2VzIiwiTWF0aCIsImNlaWwiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbInBhZ2luYXRpb24udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIENoZXZyb25MZWZ0LFxuICBDaGV2cm9uUmlnaHQsXG4gIENoZXZyb25zTGVmdCxcbiAgQ2hldnJvbnNSaWdodCxcbn0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICcuL3VpL2J1dHRvbidcblxuZXhwb3J0IGludGVyZmFjZSBQYWdpbmF0aW9uUHJvcHMge1xuICBwYWdlSW5kZXg6IG51bWJlclxuICB0b3RhbENvdW50OiBudW1iZXJcbiAgcGVyUGFnZTogbnVtYmVyXG4gIG9uUGFnZUNoYW5nZTogKHBhZ2VJbmRleDogbnVtYmVyKSA9PiBQcm9taXNlPHZvaWQ+IHwgdm9pZFxufVxuXG5leHBvcnQgZnVuY3Rpb24gUGFnaW5hdGlvbih7XG4gIHBhZ2VJbmRleCxcbiAgdG90YWxDb3VudCxcbiAgcGVyUGFnZSxcbiAgb25QYWdlQ2hhbmdlLFxufTogUGFnaW5hdGlvblByb3BzKSB7XG4gIGNvbnN0IHBhZ2VzID0gTWF0aC5jZWlsKHRvdGFsQ291bnQgLyBwZXJQYWdlKSB8fCAxXG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgVG90YWwgZGUge3RvdGFsQ291bnR9IHt0b3RhbENvdW50ID4gMSA/ICdpdGVucycgOiAnaXRlbSd9XG4gICAgICA8L3NwYW4+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC02IGxnOmdhcC04XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCB0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgUMOhZ2luYSB7cGFnZUluZGV4ICsgMX0gZGUge3BhZ2VzfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgIHRpdGxlPVwiUHJpbWVpcmEgcMOhZ2luYVwiXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvblBhZ2VDaGFuZ2UoMCl9XG4gICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJoLTggdy04IHAtMFwiXG4gICAgICAgICAgICBkaXNhYmxlZD17cGFnZUluZGV4ID09PSAwfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxDaGV2cm9uc0xlZnQgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzci1vbmx5XCI+UHJpbWVpcmEgcMOhZ2luYTwvc3Bhbj5cbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICB0aXRsZT1cIlDDoWdpbmEgYW50ZXJpb3JcIlxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25QYWdlQ2hhbmdlKHBhZ2VJbmRleCAtIDEpfVxuICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC04IHctOCBwLTBcIlxuICAgICAgICAgICAgZGlzYWJsZWQ9e3BhZ2VJbmRleCA9PT0gMH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8Q2hldnJvbkxlZnQgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzci1vbmx5XCI+UMOhZ2luYSBhbnRlcmlvcjwvc3Bhbj5cbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICB0aXRsZT1cIlByw7N4aW1hIHDDoWdpbmFcIlxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25QYWdlQ2hhbmdlKHBhZ2VJbmRleCArIDEpfVxuICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC04IHctOCBwLTBcIlxuICAgICAgICAgICAgZGlzYWJsZWQ9e3BhZ2VzIDw9IHBhZ2VJbmRleCArIDF9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPENoZXZyb25SaWdodCBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNyLW9ubHlcIj5QcsOzeGltYSBww6FnaW5hPC9zcGFuPlxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgIHRpdGxlPVwiw5psdGltYSBww6FnaW5hXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uUGFnZUNoYW5nZShwYWdlcyAtIDEpfVxuICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC04IHctOCBwLTBcIlxuICAgICAgICAgICAgZGlzYWJsZWQ9e3BhZ2VzIDw9IHBhZ2VJbmRleCArIDF9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPENoZXZyb25zUmlnaHQgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzci1vbmx5XCI+w5psdGltYSBww6FnaW5hPC9zcGFuPlxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApXG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9hcnJ1ZGF5L0dpdEh1Yi9waXp6YXNob3Avc3JjL2NvbXBvbmVudHMvcGFnaW5hdGlvbi50c3gifQ==