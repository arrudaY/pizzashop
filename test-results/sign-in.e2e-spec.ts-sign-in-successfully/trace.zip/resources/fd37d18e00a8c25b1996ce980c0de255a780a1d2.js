import {
  RequestHandler,
  SetupApi,
  devUtils,
  executeHandlers,
  handleRequest,
  invariant,
  store,
  toPublicUrl
} from "/node_modules/.vite/deps/chunk-EAFWXON5.js?v=efc33bbd";
import {
  __publicField
} from "/node_modules/.vite/deps/chunk-TXPGJST7.js?v=efc33bbd";
function checkGlobals() {
  invariant(
    typeof URL !== "undefined",
    devUtils.formatMessage(
      `Global "URL" class is not defined. This likely means that you're running MSW in an environment that doesn't support all Node.js standard API (e.g. React Native). If that's the case, please use an appropriate polyfill for the "URL" class, like "react-native-url-polyfill".`
    )
  );
}
function isStringEqual(actual, expected) {
  return actual.toLowerCase() === expected.toLowerCase();
}
var StatusCodeColor = ((StatusCodeColor2) => {
  StatusCodeColor2["Success"] = "#69AB32";
  StatusCodeColor2["Warning"] = "#F0BB4B";
  StatusCodeColor2["Danger"] = "#E95F5D";
  return StatusCodeColor2;
})(StatusCodeColor || {});
function getStatusCodeColor(status) {
  if (status < 300) {
    return "#69AB32";
  }
  if (status < 400) {
    return "#F0BB4B";
  }
  return "#E95F5D";
}
function getTimestamp() {
  const now = /* @__PURE__ */ new Date();
  return [now.getHours(), now.getMinutes(), now.getSeconds()].map(String).map((chunk) => chunk.slice(0, 2)).map((chunk) => chunk.padStart(2, "0")).join(":");
}
async function serializeRequest(request) {
  const requestClone = request.clone();
  const requestText = await requestClone.text();
  return {
    url: new URL(request.url),
    method: request.method,
    headers: Object.fromEntries(request.headers.entries()),
    body: requestText
  };
}
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var require_codes = __commonJS({
  "node_modules/statuses/codes.json"(exports, module) {
    module.exports = {
      "100": "Continue",
      "101": "Switching Protocols",
      "102": "Processing",
      "103": "Early Hints",
      "200": "OK",
      "201": "Created",
      "202": "Accepted",
      "203": "Non-Authoritative Information",
      "204": "No Content",
      "205": "Reset Content",
      "206": "Partial Content",
      "207": "Multi-Status",
      "208": "Already Reported",
      "226": "IM Used",
      "300": "Multiple Choices",
      "301": "Moved Permanently",
      "302": "Found",
      "303": "See Other",
      "304": "Not Modified",
      "305": "Use Proxy",
      "307": "Temporary Redirect",
      "308": "Permanent Redirect",
      "400": "Bad Request",
      "401": "Unauthorized",
      "402": "Payment Required",
      "403": "Forbidden",
      "404": "Not Found",
      "405": "Method Not Allowed",
      "406": "Not Acceptable",
      "407": "Proxy Authentication Required",
      "408": "Request Timeout",
      "409": "Conflict",
      "410": "Gone",
      "411": "Length Required",
      "412": "Precondition Failed",
      "413": "Payload Too Large",
      "414": "URI Too Long",
      "415": "Unsupported Media Type",
      "416": "Range Not Satisfiable",
      "417": "Expectation Failed",
      "418": "I'm a Teapot",
      "421": "Misdirected Request",
      "422": "Unprocessable Entity",
      "423": "Locked",
      "424": "Failed Dependency",
      "425": "Too Early",
      "426": "Upgrade Required",
      "428": "Precondition Required",
      "429": "Too Many Requests",
      "431": "Request Header Fields Too Large",
      "451": "Unavailable For Legal Reasons",
      "500": "Internal Server Error",
      "501": "Not Implemented",
      "502": "Bad Gateway",
      "503": "Service Unavailable",
      "504": "Gateway Timeout",
      "505": "HTTP Version Not Supported",
      "506": "Variant Also Negotiates",
      "507": "Insufficient Storage",
      "508": "Loop Detected",
      "509": "Bandwidth Limit Exceeded",
      "510": "Not Extended",
      "511": "Network Authentication Required"
    };
  }
});
var require_statuses = __commonJS({
  "node_modules/statuses/index.js"(exports, module) {
    "use strict";
    var codes = require_codes();
    module.exports = status2;
    status2.message = codes;
    status2.code = createMessageToStatusCodeMap(codes);
    status2.codes = createStatusCodeList(codes);
    status2.redirect = {
      300: true,
      301: true,
      302: true,
      303: true,
      305: true,
      307: true,
      308: true
    };
    status2.empty = {
      204: true,
      205: true,
      304: true
    };
    status2.retry = {
      502: true,
      503: true,
      504: true
    };
    function createMessageToStatusCodeMap(codes2) {
      var map = {};
      Object.keys(codes2).forEach(function forEachCode(code) {
        var message3 = codes2[code];
        var status3 = Number(code);
        map[message3.toLowerCase()] = status3;
      });
      return map;
    }
    function createStatusCodeList(codes2) {
      return Object.keys(codes2).map(function mapCode(code) {
        return Number(code);
      });
    }
    function getStatusCode(message3) {
      var msg = message3.toLowerCase();
      if (!Object.prototype.hasOwnProperty.call(status2.code, msg)) {
        throw new Error('invalid status message: "' + message3 + '"');
      }
      return status2.code[msg];
    }
    function getStatusMessage(code) {
      if (!Object.prototype.hasOwnProperty.call(status2.message, code)) {
        throw new Error("invalid status code: " + code);
      }
      return status2.message[code];
    }
    function status2(code) {
      if (typeof code === "number") {
        return getStatusMessage(code);
      }
      if (typeof code !== "string") {
        throw new TypeError("code must be a number or string");
      }
      var n = parseInt(code, 10);
      if (!isNaN(n)) {
        return getStatusMessage(n);
      }
      return getStatusCode(code);
    }
  }
});
var import_statuses = __toESM(require_statuses(), 1);
var source_default = import_statuses.default;
var { message } = source_default;
async function serializeResponse(response) {
  const responseClone = response.clone();
  const responseText = await responseClone.text();
  const responseStatus = responseClone.status || 200;
  const responseStatusText = responseClone.statusText || message[responseStatus] || "OK";
  return {
    status: responseStatus,
    statusText: responseStatusText,
    headers: Object.fromEntries(responseClone.headers.entries()),
    body: responseText
  };
}
function lexer(str) {
  var tokens = [];
  var i = 0;
  while (i < str.length) {
    var char = str[i];
    if (char === "*" || char === "+" || char === "?") {
      tokens.push({ type: "MODIFIER", index: i, value: str[i++] });
      continue;
    }
    if (char === "\\") {
      tokens.push({ type: "ESCAPED_CHAR", index: i++, value: str[i++] });
      continue;
    }
    if (char === "{") {
      tokens.push({ type: "OPEN", index: i, value: str[i++] });
      continue;
    }
    if (char === "}") {
      tokens.push({ type: "CLOSE", index: i, value: str[i++] });
      continue;
    }
    if (char === ":") {
      var name = "";
      var j = i + 1;
      while (j < str.length) {
        var code = str.charCodeAt(j);
        if (
          // `0-9`
          code >= 48 && code <= 57 || // `A-Z`
          code >= 65 && code <= 90 || // `a-z`
          code >= 97 && code <= 122 || // `_`
          code === 95
        ) {
          name += str[j++];
          continue;
        }
        break;
      }
      if (!name)
        throw new TypeError("Missing parameter name at ".concat(i));
      tokens.push({ type: "NAME", index: i, value: name });
      i = j;
      continue;
    }
    if (char === "(") {
      var count = 1;
      var pattern = "";
      var j = i + 1;
      if (str[j] === "?") {
        throw new TypeError('Pattern cannot start with "?" at '.concat(j));
      }
      while (j < str.length) {
        if (str[j] === "\\") {
          pattern += str[j++] + str[j++];
          continue;
        }
        if (str[j] === ")") {
          count--;
          if (count === 0) {
            j++;
            break;
          }
        } else if (str[j] === "(") {
          count++;
          if (str[j + 1] !== "?") {
            throw new TypeError("Capturing groups are not allowed at ".concat(j));
          }
        }
        pattern += str[j++];
      }
      if (count)
        throw new TypeError("Unbalanced pattern at ".concat(i));
      if (!pattern)
        throw new TypeError("Missing pattern at ".concat(i));
      tokens.push({ type: "PATTERN", index: i, value: pattern });
      i = j;
      continue;
    }
    tokens.push({ type: "CHAR", index: i, value: str[i++] });
  }
  tokens.push({ type: "END", index: i, value: "" });
  return tokens;
}
function parse(str, options) {
  if (options === void 0) {
    options = {};
  }
  var tokens = lexer(str);
  var _a2 = options.prefixes, prefixes = _a2 === void 0 ? "./" : _a2;
  var defaultPattern = "[^".concat(escapeString(options.delimiter || "/#?"), "]+?");
  var result = [];
  var key = 0;
  var i = 0;
  var path = "";
  var tryConsume = function(type) {
    if (i < tokens.length && tokens[i].type === type)
      return tokens[i++].value;
  };
  var mustConsume = function(type) {
    var value2 = tryConsume(type);
    if (value2 !== void 0)
      return value2;
    var _a3 = tokens[i], nextType = _a3.type, index = _a3.index;
    throw new TypeError("Unexpected ".concat(nextType, " at ").concat(index, ", expected ").concat(type));
  };
  var consumeText = function() {
    var result2 = "";
    var value2;
    while (value2 = tryConsume("CHAR") || tryConsume("ESCAPED_CHAR")) {
      result2 += value2;
    }
    return result2;
  };
  while (i < tokens.length) {
    var char = tryConsume("CHAR");
    var name = tryConsume("NAME");
    var pattern = tryConsume("PATTERN");
    if (name || pattern) {
      var prefix = char || "";
      if (prefixes.indexOf(prefix) === -1) {
        path += prefix;
        prefix = "";
      }
      if (path) {
        result.push(path);
        path = "";
      }
      result.push({
        name: name || key++,
        prefix,
        suffix: "",
        pattern: pattern || defaultPattern,
        modifier: tryConsume("MODIFIER") || ""
      });
      continue;
    }
    var value = char || tryConsume("ESCAPED_CHAR");
    if (value) {
      path += value;
      continue;
    }
    if (path) {
      result.push(path);
      path = "";
    }
    var open = tryConsume("OPEN");
    if (open) {
      var prefix = consumeText();
      var name_1 = tryConsume("NAME") || "";
      var pattern_1 = tryConsume("PATTERN") || "";
      var suffix = consumeText();
      mustConsume("CLOSE");
      result.push({
        name: name_1 || (pattern_1 ? key++ : ""),
        pattern: name_1 && !pattern_1 ? defaultPattern : pattern_1,
        prefix,
        suffix,
        modifier: tryConsume("MODIFIER") || ""
      });
      continue;
    }
    mustConsume("END");
  }
  return result;
}
function match(str, options) {
  var keys = [];
  var re = pathToRegexp(str, keys, options);
  return regexpToFunction(re, keys, options);
}
function regexpToFunction(re, keys, options) {
  if (options === void 0) {
    options = {};
  }
  var _a2 = options.decode, decode = _a2 === void 0 ? function(x) {
    return x;
  } : _a2;
  return function(pathname) {
    var m = re.exec(pathname);
    if (!m)
      return false;
    var path = m[0], index = m.index;
    var params = /* @__PURE__ */ Object.create(null);
    var _loop_1 = function(i2) {
      if (m[i2] === void 0)
        return "continue";
      var key = keys[i2 - 1];
      if (key.modifier === "*" || key.modifier === "+") {
        params[key.name] = m[i2].split(key.prefix + key.suffix).map(function(value) {
          return decode(value, key);
        });
      } else {
        params[key.name] = decode(m[i2], key);
      }
    };
    for (var i = 1; i < m.length; i++) {
      _loop_1(i);
    }
    return { path, index, params };
  };
}
function escapeString(str) {
  return str.replace(/([.+*?=^!:${}()[\]|/\\])/g, "\\$1");
}
function flags(options) {
  return options && options.sensitive ? "" : "i";
}
function regexpToRegexp(path, keys) {
  if (!keys)
    return path;
  var groupsRegex = /\((?:\?<(.*?)>)?(?!\?)/g;
  var index = 0;
  var execResult = groupsRegex.exec(path.source);
  while (execResult) {
    keys.push({
      // Use parenthesized substring match if available, index otherwise
      name: execResult[1] || index++,
      prefix: "",
      suffix: "",
      modifier: "",
      pattern: ""
    });
    execResult = groupsRegex.exec(path.source);
  }
  return path;
}
function arrayToRegexp(paths, keys, options) {
  var parts = paths.map(function(path) {
    return pathToRegexp(path, keys, options).source;
  });
  return new RegExp("(?:".concat(parts.join("|"), ")"), flags(options));
}
function stringToRegexp(path, keys, options) {
  return tokensToRegexp(parse(path, options), keys, options);
}
function tokensToRegexp(tokens, keys, options) {
  if (options === void 0) {
    options = {};
  }
  var _a2 = options.strict, strict = _a2 === void 0 ? false : _a2, _b2 = options.start, start = _b2 === void 0 ? true : _b2, _c = options.end, end = _c === void 0 ? true : _c, _d = options.encode, encode = _d === void 0 ? function(x) {
    return x;
  } : _d, _e = options.delimiter, delimiter = _e === void 0 ? "/#?" : _e, _f = options.endsWith, endsWith = _f === void 0 ? "" : _f;
  var endsWithRe = "[".concat(escapeString(endsWith), "]|$");
  var delimiterRe = "[".concat(escapeString(delimiter), "]");
  var route = start ? "^" : "";
  for (var _i = 0, tokens_1 = tokens; _i < tokens_1.length; _i++) {
    var token = tokens_1[_i];
    if (typeof token === "string") {
      route += escapeString(encode(token));
    } else {
      var prefix = escapeString(encode(token.prefix));
      var suffix = escapeString(encode(token.suffix));
      if (token.pattern) {
        if (keys)
          keys.push(token);
        if (prefix || suffix) {
          if (token.modifier === "+" || token.modifier === "*") {
            var mod = token.modifier === "*" ? "?" : "";
            route += "(?:".concat(prefix, "((?:").concat(token.pattern, ")(?:").concat(suffix).concat(prefix, "(?:").concat(token.pattern, "))*)").concat(suffix, ")").concat(mod);
          } else {
            route += "(?:".concat(prefix, "(").concat(token.pattern, ")").concat(suffix, ")").concat(token.modifier);
          }
        } else {
          if (token.modifier === "+" || token.modifier === "*") {
            route += "((?:".concat(token.pattern, ")").concat(token.modifier, ")");
          } else {
            route += "(".concat(token.pattern, ")").concat(token.modifier);
          }
        }
      } else {
        route += "(?:".concat(prefix).concat(suffix, ")").concat(token.modifier);
      }
    }
  }
  if (end) {
    if (!strict)
      route += "".concat(delimiterRe, "?");
    route += !options.endsWith ? "$" : "(?=".concat(endsWithRe, ")");
  } else {
    var endToken = tokens[tokens.length - 1];
    var isEndDelimited = typeof endToken === "string" ? delimiterRe.indexOf(endToken[endToken.length - 1]) > -1 : endToken === void 0;
    if (!strict) {
      route += "(?:".concat(delimiterRe, "(?=").concat(endsWithRe, "))?");
    }
    if (!isEndDelimited) {
      route += "(?=".concat(delimiterRe, "|").concat(endsWithRe, ")");
    }
  }
  return new RegExp(route, flags(options));
}
function pathToRegexp(path, keys, options) {
  if (path instanceof RegExp)
    return regexpToRegexp(path, keys);
  if (Array.isArray(path))
    return arrayToRegexp(path, keys, options);
  return stringToRegexp(path, keys, options);
}
var encoder = new TextEncoder();
function isNodeProcess() {
  if (typeof navigator !== "undefined" && navigator.product === "ReactNative") {
    return true;
  }
  if (typeof process !== "undefined") {
    const type = process.type;
    if (type === "renderer" || type === "worker") {
      return false;
    }
    return !!(process.versions && process.versions.node);
  }
  return false;
}
var __defProp2 = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp2(target, name, { get: all[name], enumerable: true });
};
var colors_exports = {};
__export(colors_exports, {
  blue: () => blue,
  gray: () => gray,
  green: () => green,
  red: () => red,
  yellow: () => yellow
});
function yellow(text) {
  return `\x1B[33m${text}\x1B[0m`;
}
function blue(text) {
  return `\x1B[34m${text}\x1B[0m`;
}
function gray(text) {
  return `\x1B[90m${text}\x1B[0m`;
}
function red(text) {
  return `\x1B[31m${text}\x1B[0m`;
}
function green(text) {
  return `\x1B[32m${text}\x1B[0m`;
}
var IS_NODE = isNodeProcess();
var IS_PATCHED_MODULE = Symbol("isPatchedModule");
var InterceptorReadyState = ((InterceptorReadyState2) => {
  InterceptorReadyState2["INACTIVE"] = "INACTIVE";
  InterceptorReadyState2["APPLYING"] = "APPLYING";
  InterceptorReadyState2["APPLIED"] = "APPLIED";
  InterceptorReadyState2["DISPOSING"] = "DISPOSING";
  InterceptorReadyState2["DISPOSED"] = "DISPOSED";
  return InterceptorReadyState2;
})(InterceptorReadyState || {});
function getCleanUrl(url, isAbsolute = true) {
  return [isAbsolute && url.origin, url.pathname].filter(Boolean).join("");
}
var REDUNDANT_CHARACTERS_EXP = /[\?|#].*$/g;
function getSearchParams(path) {
  return new URL(`/${path}`, "http://localhost").searchParams;
}
function cleanUrl(path) {
  return path.replace(REDUNDANT_CHARACTERS_EXP, "");
}
function isAbsoluteUrl(url) {
  return /^([a-z][a-z\d\+\-\.]*:)?\/\//i.test(url);
}
function getAbsoluteUrl(path, baseUrl) {
  if (isAbsoluteUrl(path)) {
    return path;
  }
  if (path.startsWith("*")) {
    return path;
  }
  const origin = baseUrl || typeof document !== "undefined" && document.baseURI;
  return origin ? (
    // Encode and decode the path to preserve escaped characters.
    decodeURI(new URL(encodeURI(path), origin).href)
  ) : path;
}
function normalizePath(path, baseUrl) {
  if (path instanceof RegExp) {
    return path;
  }
  const maybeAbsoluteUrl = getAbsoluteUrl(path, baseUrl);
  return cleanUrl(maybeAbsoluteUrl);
}
function coercePath(path) {
  return path.replace(
    /([:a-zA-Z_-]*)(\*{1,2})+/g,
    (_, parameterName, wildcard) => {
      const expression = "(.*)";
      if (!parameterName) {
        return expression;
      }
      return parameterName.startsWith(":") ? `${parameterName}${wildcard}` : `${parameterName}${expression}`;
    }
  ).replace(/([^\/])(:)(?=\d+)/, "$1\\$2").replace(/^([^\/]+)(:)(?=\/\/)/, "$1\\$2");
}
function matchRequestUrl(url, path, baseUrl) {
  const normalizedPath = normalizePath(path, baseUrl);
  const cleanPath = typeof normalizedPath === "string" ? coercePath(normalizedPath) : normalizedPath;
  const cleanUrl2 = getCleanUrl(url);
  const result = match(cleanPath, { decode: decodeURIComponent })(cleanUrl2);
  const params = result && result.params || {};
  return {
    matches: result !== false,
    params
  };
}
var __create2 = Object.create;
var __defProp3 = Object.defineProperty;
var __getOwnPropDesc2 = Object.getOwnPropertyDescriptor;
var __getOwnPropNames2 = Object.getOwnPropertyNames;
var __getProtoOf2 = Object.getPrototypeOf;
var __hasOwnProp2 = Object.prototype.hasOwnProperty;
var __commonJS2 = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames2(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps2 = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames2(from))
      if (!__hasOwnProp2.call(to, key) && key !== except)
        __defProp3(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc2(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM2 = (mod, isNodeMode, target) => (target = mod != null ? __create2(__getProtoOf2(mod)) : {}, __copyProps2(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp3(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var require_cookie = __commonJS2({
  "node_modules/cookie/index.js"(exports) {
    "use strict";
    exports.parse = parse3;
    exports.serialize = serialize;
    var __toString = Object.prototype.toString;
    var fieldContentRegExp = /^[\u0009\u0020-\u007e\u0080-\u00ff]+$/;
    function parse3(str, options) {
      if (typeof str !== "string") {
        throw new TypeError("argument str must be a string");
      }
      var obj = {};
      var opt = options || {};
      var dec = opt.decode || decode;
      var index = 0;
      while (index < str.length) {
        var eqIdx = str.indexOf("=", index);
        if (eqIdx === -1) {
          break;
        }
        var endIdx = str.indexOf(";", index);
        if (endIdx === -1) {
          endIdx = str.length;
        } else if (endIdx < eqIdx) {
          index = str.lastIndexOf(";", eqIdx - 1) + 1;
          continue;
        }
        var key = str.slice(index, eqIdx).trim();
        if (void 0 === obj[key]) {
          var val = str.slice(eqIdx + 1, endIdx).trim();
          if (val.charCodeAt(0) === 34) {
            val = val.slice(1, -1);
          }
          obj[key] = tryDecode(val, dec);
        }
        index = endIdx + 1;
      }
      return obj;
    }
    function serialize(name, val, options) {
      var opt = options || {};
      var enc = opt.encode || encode;
      if (typeof enc !== "function") {
        throw new TypeError("option encode is invalid");
      }
      if (!fieldContentRegExp.test(name)) {
        throw new TypeError("argument name is invalid");
      }
      var value = enc(val);
      if (value && !fieldContentRegExp.test(value)) {
        throw new TypeError("argument val is invalid");
      }
      var str = name + "=" + value;
      if (null != opt.maxAge) {
        var maxAge = opt.maxAge - 0;
        if (isNaN(maxAge) || !isFinite(maxAge)) {
          throw new TypeError("option maxAge is invalid");
        }
        str += "; Max-Age=" + Math.floor(maxAge);
      }
      if (opt.domain) {
        if (!fieldContentRegExp.test(opt.domain)) {
          throw new TypeError("option domain is invalid");
        }
        str += "; Domain=" + opt.domain;
      }
      if (opt.path) {
        if (!fieldContentRegExp.test(opt.path)) {
          throw new TypeError("option path is invalid");
        }
        str += "; Path=" + opt.path;
      }
      if (opt.expires) {
        var expires = opt.expires;
        if (!isDate(expires) || isNaN(expires.valueOf())) {
          throw new TypeError("option expires is invalid");
        }
        str += "; Expires=" + expires.toUTCString();
      }
      if (opt.httpOnly) {
        str += "; HttpOnly";
      }
      if (opt.secure) {
        str += "; Secure";
      }
      if (opt.priority) {
        var priority = typeof opt.priority === "string" ? opt.priority.toLowerCase() : opt.priority;
        switch (priority) {
          case "low":
            str += "; Priority=Low";
            break;
          case "medium":
            str += "; Priority=Medium";
            break;
          case "high":
            str += "; Priority=High";
            break;
          default:
            throw new TypeError("option priority is invalid");
        }
      }
      if (opt.sameSite) {
        var sameSite = typeof opt.sameSite === "string" ? opt.sameSite.toLowerCase() : opt.sameSite;
        switch (sameSite) {
          case true:
            str += "; SameSite=Strict";
            break;
          case "lax":
            str += "; SameSite=Lax";
            break;
          case "strict":
            str += "; SameSite=Strict";
            break;
          case "none":
            str += "; SameSite=None";
            break;
          default:
            throw new TypeError("option sameSite is invalid");
        }
      }
      return str;
    }
    function decode(str) {
      return str.indexOf("%") !== -1 ? decodeURIComponent(str) : str;
    }
    function encode(val) {
      return encodeURIComponent(val);
    }
    function isDate(val) {
      return __toString.call(val) === "[object Date]" || val instanceof Date;
    }
    function tryDecode(str, decode2) {
      try {
        return decode2(str);
      } catch (e) {
        return str;
      }
    }
  }
});
var import_cookie = __toESM2(require_cookie(), 1);
var source_default2 = import_cookie.default;
function getAllDocumentCookies() {
  return source_default2.parse(document.cookie);
}
function getRequestCookies(request) {
  if (typeof document === "undefined" || typeof location === "undefined") {
    return {};
  }
  switch (request.credentials) {
    case "same-origin": {
      const url = new URL(request.url);
      return location.origin === url.origin ? getAllDocumentCookies() : {};
    }
    case "include": {
      return getAllDocumentCookies();
    }
    default: {
      return {};
    }
  }
}
function getAllRequestCookies(request) {
  var _a2;
  const requestCookiesString = request.headers.get("cookie");
  const cookiesFromHeaders = requestCookiesString ? source_default2.parse(requestCookiesString) : {};
  store.hydrate();
  const cookiesFromStore = Array.from((_a2 = store.get(request)) == null ? void 0 : _a2.entries()).reduce((cookies, [name, { value }]) => {
    return Object.assign(cookies, { [name.trim()]: value });
  }, {});
  const cookiesFromDocument = getRequestCookies(request);
  const forwardedCookies = {
    ...cookiesFromDocument,
    ...cookiesFromStore
  };
  for (const [name, value] of Object.entries(forwardedCookies)) {
    request.headers.append("cookie", source_default2.serialize(name, value));
  }
  return {
    ...forwardedCookies,
    ...cookiesFromHeaders
  };
}
var HttpMethods = ((HttpMethods2) => {
  HttpMethods2["HEAD"] = "HEAD";
  HttpMethods2["GET"] = "GET";
  HttpMethods2["POST"] = "POST";
  HttpMethods2["PUT"] = "PUT";
  HttpMethods2["PATCH"] = "PATCH";
  HttpMethods2["OPTIONS"] = "OPTIONS";
  HttpMethods2["DELETE"] = "DELETE";
  return HttpMethods2;
})(HttpMethods || {});
var HttpHandler = class extends RequestHandler {
  constructor(method, path, resolver, options) {
    super({
      info: {
        header: `${method} ${path}`,
        path,
        method
      },
      resolver,
      options
    });
    this.checkRedundantQueryParameters();
  }
  checkRedundantQueryParameters() {
    const { method, path } = this.info;
    if (path instanceof RegExp) {
      return;
    }
    const url = cleanUrl(path);
    if (url === path) {
      return;
    }
    const searchParams = getSearchParams(path);
    const queryParams = [];
    searchParams.forEach((_, paramName) => {
      queryParams.push(paramName);
    });
    devUtils.warn(
      `Found a redundant usage of query parameters in the request handler URL for "${method} ${path}". Please match against a path instead and access query parameters in the response resolver function using "req.url.searchParams".`
    );
  }
  async parse(args) {
    var _a2;
    const url = new URL(args.request.url);
    const match2 = matchRequestUrl(
      url,
      this.info.path,
      (_a2 = args.resolutionContext) == null ? void 0 : _a2.baseUrl
    );
    const cookies = getAllRequestCookies(args.request);
    return {
      match: match2,
      cookies
    };
  }
  predicate(args) {
    const hasMatchingMethod = this.matchMethod(args.request.method);
    const hasMatchingUrl = args.parsedResult.match.matches;
    return hasMatchingMethod && hasMatchingUrl;
  }
  matchMethod(actualMethod) {
    return this.info.method instanceof RegExp ? this.info.method.test(actualMethod) : isStringEqual(this.info.method, actualMethod);
  }
  extendResolverArgs(args) {
    var _a2;
    return {
      params: ((_a2 = args.parsedResult.match) == null ? void 0 : _a2.params) || {},
      cookies: args.parsedResult.cookies
    };
  }
  async log(args) {
    const publicUrl = toPublicUrl(args.request.url);
    const loggedRequest = await serializeRequest(args.request);
    const loggedResponse = await serializeResponse(args.response);
    const statusColor = getStatusCodeColor(loggedResponse.status);
    console.groupCollapsed(
      devUtils.formatMessage(
        `${getTimestamp()} ${args.request.method} ${publicUrl} (%c${loggedResponse.status} ${loggedResponse.statusText}%c)`
      ),
      `color:${statusColor}`,
      "color:inherit"
    );
    console.log("Request", loggedRequest);
    console.log("Handler:", this);
    console.log("Response", loggedResponse);
    console.groupEnd();
  }
};
function createHttpHandler(method) {
  return (path, resolver, options = {}) => {
    return new HttpHandler(method, path, resolver, options);
  };
}
var http = {
  all: createHttpHandler(/.+/),
  head: createHttpHandler(HttpMethods.HEAD),
  get: createHttpHandler(HttpMethods.GET),
  post: createHttpHandler(HttpMethods.POST),
  put: createHttpHandler(HttpMethods.PUT),
  delete: createHttpHandler(HttpMethods.DELETE),
  patch: createHttpHandler(HttpMethods.PATCH),
  options: createHttpHandler(HttpMethods.OPTIONS)
};
var versionInfo = Object.freeze({
  major: 16,
  minor: 8,
  patch: 1,
  preReleaseTag: null
});
function devAssert(condition, message3) {
  const booleanCondition = Boolean(condition);
  if (!booleanCondition) {
    throw new Error(message3);
  }
}
function isObjectLike(value) {
  return typeof value == "object" && value !== null;
}
function invariant2(condition, message3) {
  const booleanCondition = Boolean(condition);
  if (!booleanCondition) {
    throw new Error(
      message3 != null ? message3 : "Unexpected invariant triggered."
    );
  }
}
var LineRegExp = /\r\n|[\n\r]/g;
function getLocation(source, position) {
  let lastLineStart = 0;
  let line = 1;
  for (const match2 of source.body.matchAll(LineRegExp)) {
    typeof match2.index === "number" || invariant2(false);
    if (match2.index >= position) {
      break;
    }
    lastLineStart = match2.index + match2[0].length;
    line += 1;
  }
  return {
    line,
    column: position + 1 - lastLineStart
  };
}
function printLocation(location2) {
  return printSourceLocation(
    location2.source,
    getLocation(location2.source, location2.start)
  );
}
function printSourceLocation(source, sourceLocation) {
  const firstLineColumnOffset = source.locationOffset.column - 1;
  const body = "".padStart(firstLineColumnOffset) + source.body;
  const lineIndex = sourceLocation.line - 1;
  const lineOffset = source.locationOffset.line - 1;
  const lineNum = sourceLocation.line + lineOffset;
  const columnOffset = sourceLocation.line === 1 ? firstLineColumnOffset : 0;
  const columnNum = sourceLocation.column + columnOffset;
  const locationStr = `${source.name}:${lineNum}:${columnNum}
`;
  const lines = body.split(/\r\n|[\n\r]/g);
  const locationLine = lines[lineIndex];
  if (locationLine.length > 120) {
    const subLineIndex = Math.floor(columnNum / 80);
    const subLineColumnNum = columnNum % 80;
    const subLines = [];
    for (let i = 0; i < locationLine.length; i += 80) {
      subLines.push(locationLine.slice(i, i + 80));
    }
    return locationStr + printPrefixedLines([
      [`${lineNum} |`, subLines[0]],
      ...subLines.slice(1, subLineIndex + 1).map((subLine) => ["|", subLine]),
      ["|", "^".padStart(subLineColumnNum)],
      ["|", subLines[subLineIndex + 1]]
    ]);
  }
  return locationStr + printPrefixedLines([
    // Lines specified like this: ["prefix", "string"],
    [`${lineNum - 1} |`, lines[lineIndex - 1]],
    [`${lineNum} |`, locationLine],
    ["|", "^".padStart(columnNum)],
    [`${lineNum + 1} |`, lines[lineIndex + 1]]
  ]);
}
function printPrefixedLines(lines) {
  const existingLines = lines.filter(([_, line]) => line !== void 0);
  const padLen = Math.max(...existingLines.map(([prefix]) => prefix.length));
  return existingLines.map(([prefix, line]) => prefix.padStart(padLen) + (line ? " " + line : "")).join("\n");
}
function toNormalizedOptions(args) {
  const firstArg = args[0];
  if (firstArg == null || "kind" in firstArg || "length" in firstArg) {
    return {
      nodes: firstArg,
      source: args[1],
      positions: args[2],
      path: args[3],
      originalError: args[4],
      extensions: args[5]
    };
  }
  return firstArg;
}
var GraphQLError = class _GraphQLError extends Error {
  /**
   * An array of `{ line, column }` locations within the source GraphQL document
   * which correspond to this error.
   *
   * Errors during validation often contain multiple locations, for example to
   * point out two things with the same name. Errors during execution include a
   * single location, the field which produced the error.
   *
   * Enumerable, and appears in the result of JSON.stringify().
   */
  /**
   * An array describing the JSON-path into the execution response which
   * corresponds to this error. Only included for errors during execution.
   *
   * Enumerable, and appears in the result of JSON.stringify().
   */
  /**
   * An array of GraphQL AST Nodes corresponding to this error.
   */
  /**
   * The source GraphQL document for the first location of this error.
   *
   * Note that if this Error represents more than one node, the source may not
   * represent nodes after the first node.
   */
  /**
   * An array of character offsets within the source GraphQL document
   * which correspond to this error.
   */
  /**
   * The original error thrown from a field resolver during execution.
   */
  /**
   * Extension fields to add to the formatted error.
   */
  /**
   * @deprecated Please use the `GraphQLErrorOptions` constructor overload instead.
   */
  constructor(message3, ...rawArgs) {
    var _this$nodes, _nodeLocations$, _ref;
    const { nodes, source, positions, path, originalError, extensions } = toNormalizedOptions(rawArgs);
    super(message3);
    this.name = "GraphQLError";
    this.path = path !== null && path !== void 0 ? path : void 0;
    this.originalError = originalError !== null && originalError !== void 0 ? originalError : void 0;
    this.nodes = undefinedIfEmpty(
      Array.isArray(nodes) ? nodes : nodes ? [nodes] : void 0
    );
    const nodeLocations = undefinedIfEmpty(
      (_this$nodes = this.nodes) === null || _this$nodes === void 0 ? void 0 : _this$nodes.map((node) => node.loc).filter((loc) => loc != null)
    );
    this.source = source !== null && source !== void 0 ? source : nodeLocations === null || nodeLocations === void 0 ? void 0 : (_nodeLocations$ = nodeLocations[0]) === null || _nodeLocations$ === void 0 ? void 0 : _nodeLocations$.source;
    this.positions = positions !== null && positions !== void 0 ? positions : nodeLocations === null || nodeLocations === void 0 ? void 0 : nodeLocations.map((loc) => loc.start);
    this.locations = positions && source ? positions.map((pos) => getLocation(source, pos)) : nodeLocations === null || nodeLocations === void 0 ? void 0 : nodeLocations.map((loc) => getLocation(loc.source, loc.start));
    const originalExtensions = isObjectLike(
      originalError === null || originalError === void 0 ? void 0 : originalError.extensions
    ) ? originalError === null || originalError === void 0 ? void 0 : originalError.extensions : void 0;
    this.extensions = (_ref = extensions !== null && extensions !== void 0 ? extensions : originalExtensions) !== null && _ref !== void 0 ? _ref : /* @__PURE__ */ Object.create(null);
    Object.defineProperties(this, {
      message: {
        writable: true,
        enumerable: true
      },
      name: {
        enumerable: false
      },
      nodes: {
        enumerable: false
      },
      source: {
        enumerable: false
      },
      positions: {
        enumerable: false
      },
      originalError: {
        enumerable: false
      }
    });
    if (originalError !== null && originalError !== void 0 && originalError.stack) {
      Object.defineProperty(this, "stack", {
        value: originalError.stack,
        writable: true,
        configurable: true
      });
    } else if (Error.captureStackTrace) {
      Error.captureStackTrace(this, _GraphQLError);
    } else {
      Object.defineProperty(this, "stack", {
        value: Error().stack,
        writable: true,
        configurable: true
      });
    }
  }
  get [Symbol.toStringTag]() {
    return "GraphQLError";
  }
  toString() {
    let output = this.message;
    if (this.nodes) {
      for (const node of this.nodes) {
        if (node.loc) {
          output += "\n\n" + printLocation(node.loc);
        }
      }
    } else if (this.source && this.locations) {
      for (const location2 of this.locations) {
        output += "\n\n" + printSourceLocation(this.source, location2);
      }
    }
    return output;
  }
  toJSON() {
    const formattedError = {
      message: this.message
    };
    if (this.locations != null) {
      formattedError.locations = this.locations;
    }
    if (this.path != null) {
      formattedError.path = this.path;
    }
    if (this.extensions != null && Object.keys(this.extensions).length > 0) {
      formattedError.extensions = this.extensions;
    }
    return formattedError;
  }
};
function undefinedIfEmpty(array) {
  return array === void 0 || array.length === 0 ? void 0 : array;
}
function syntaxError(source, position, description) {
  return new GraphQLError(`Syntax Error: ${description}`, {
    source,
    positions: [position]
  });
}
var Location = class {
  /**
   * The character offset at which this Node begins.
   */
  /**
   * The character offset at which this Node ends.
   */
  /**
   * The Token at which this Node begins.
   */
  /**
   * The Token at which this Node ends.
   */
  /**
   * The Source document the AST represents.
   */
  constructor(startToken, endToken, source) {
    this.start = startToken.start;
    this.end = endToken.end;
    this.startToken = startToken;
    this.endToken = endToken;
    this.source = source;
  }
  get [Symbol.toStringTag]() {
    return "Location";
  }
  toJSON() {
    return {
      start: this.start,
      end: this.end
    };
  }
};
var Token = class {
  /**
   * The kind of Token.
   */
  /**
   * The character offset at which this Node begins.
   */
  /**
   * The character offset at which this Node ends.
   */
  /**
   * The 1-indexed line number on which this Token appears.
   */
  /**
   * The 1-indexed column number at which this Token begins.
   */
  /**
   * For non-punctuation tokens, represents the interpreted value of the token.
   *
   * Note: is undefined for punctuation tokens, but typed as string for
   * convenience in the parser.
   */
  /**
   * Tokens exist as nodes in a double-linked-list amongst all tokens
   * including ignored tokens. <SOF> is always the first node and <EOF>
   * the last.
   */
  constructor(kind, start, end, line, column, value) {
    this.kind = kind;
    this.start = start;
    this.end = end;
    this.line = line;
    this.column = column;
    this.value = value;
    this.prev = null;
    this.next = null;
  }
  get [Symbol.toStringTag]() {
    return "Token";
  }
  toJSON() {
    return {
      kind: this.kind,
      value: this.value,
      line: this.line,
      column: this.column
    };
  }
};
var QueryDocumentKeys = {
  Name: [],
  Document: ["definitions"],
  OperationDefinition: [
    "name",
    "variableDefinitions",
    "directives",
    "selectionSet"
  ],
  VariableDefinition: ["variable", "type", "defaultValue", "directives"],
  Variable: ["name"],
  SelectionSet: ["selections"],
  Field: ["alias", "name", "arguments", "directives", "selectionSet"],
  Argument: ["name", "value"],
  FragmentSpread: ["name", "directives"],
  InlineFragment: ["typeCondition", "directives", "selectionSet"],
  FragmentDefinition: [
    "name",
    // Note: fragment variable definitions are deprecated and will removed in v17.0.0
    "variableDefinitions",
    "typeCondition",
    "directives",
    "selectionSet"
  ],
  IntValue: [],
  FloatValue: [],
  StringValue: [],
  BooleanValue: [],
  NullValue: [],
  EnumValue: [],
  ListValue: ["values"],
  ObjectValue: ["fields"],
  ObjectField: ["name", "value"],
  Directive: ["name", "arguments"],
  NamedType: ["name"],
  ListType: ["type"],
  NonNullType: ["type"],
  SchemaDefinition: ["description", "directives", "operationTypes"],
  OperationTypeDefinition: ["type"],
  ScalarTypeDefinition: ["description", "name", "directives"],
  ObjectTypeDefinition: [
    "description",
    "name",
    "interfaces",
    "directives",
    "fields"
  ],
  FieldDefinition: ["description", "name", "arguments", "type", "directives"],
  InputValueDefinition: [
    "description",
    "name",
    "type",
    "defaultValue",
    "directives"
  ],
  InterfaceTypeDefinition: [
    "description",
    "name",
    "interfaces",
    "directives",
    "fields"
  ],
  UnionTypeDefinition: ["description", "name", "directives", "types"],
  EnumTypeDefinition: ["description", "name", "directives", "values"],
  EnumValueDefinition: ["description", "name", "directives"],
  InputObjectTypeDefinition: ["description", "name", "directives", "fields"],
  DirectiveDefinition: ["description", "name", "arguments", "locations"],
  SchemaExtension: ["directives", "operationTypes"],
  ScalarTypeExtension: ["name", "directives"],
  ObjectTypeExtension: ["name", "interfaces", "directives", "fields"],
  InterfaceTypeExtension: ["name", "interfaces", "directives", "fields"],
  UnionTypeExtension: ["name", "directives", "types"],
  EnumTypeExtension: ["name", "directives", "values"],
  InputObjectTypeExtension: ["name", "directives", "fields"]
};
var kindValues = new Set(Object.keys(QueryDocumentKeys));
function isNode(maybeNode) {
  const maybeKind = maybeNode === null || maybeNode === void 0 ? void 0 : maybeNode.kind;
  return typeof maybeKind === "string" && kindValues.has(maybeKind);
}
var OperationTypeNode;
(function(OperationTypeNode2) {
  OperationTypeNode2["QUERY"] = "query";
  OperationTypeNode2["MUTATION"] = "mutation";
  OperationTypeNode2["SUBSCRIPTION"] = "subscription";
})(OperationTypeNode || (OperationTypeNode = {}));
var DirectiveLocation;
(function(DirectiveLocation2) {
  DirectiveLocation2["QUERY"] = "QUERY";
  DirectiveLocation2["MUTATION"] = "MUTATION";
  DirectiveLocation2["SUBSCRIPTION"] = "SUBSCRIPTION";
  DirectiveLocation2["FIELD"] = "FIELD";
  DirectiveLocation2["FRAGMENT_DEFINITION"] = "FRAGMENT_DEFINITION";
  DirectiveLocation2["FRAGMENT_SPREAD"] = "FRAGMENT_SPREAD";
  DirectiveLocation2["INLINE_FRAGMENT"] = "INLINE_FRAGMENT";
  DirectiveLocation2["VARIABLE_DEFINITION"] = "VARIABLE_DEFINITION";
  DirectiveLocation2["SCHEMA"] = "SCHEMA";
  DirectiveLocation2["SCALAR"] = "SCALAR";
  DirectiveLocation2["OBJECT"] = "OBJECT";
  DirectiveLocation2["FIELD_DEFINITION"] = "FIELD_DEFINITION";
  DirectiveLocation2["ARGUMENT_DEFINITION"] = "ARGUMENT_DEFINITION";
  DirectiveLocation2["INTERFACE"] = "INTERFACE";
  DirectiveLocation2["UNION"] = "UNION";
  DirectiveLocation2["ENUM"] = "ENUM";
  DirectiveLocation2["ENUM_VALUE"] = "ENUM_VALUE";
  DirectiveLocation2["INPUT_OBJECT"] = "INPUT_OBJECT";
  DirectiveLocation2["INPUT_FIELD_DEFINITION"] = "INPUT_FIELD_DEFINITION";
})(DirectiveLocation || (DirectiveLocation = {}));
var Kind;
(function(Kind2) {
  Kind2["NAME"] = "Name";
  Kind2["DOCUMENT"] = "Document";
  Kind2["OPERATION_DEFINITION"] = "OperationDefinition";
  Kind2["VARIABLE_DEFINITION"] = "VariableDefinition";
  Kind2["SELECTION_SET"] = "SelectionSet";
  Kind2["FIELD"] = "Field";
  Kind2["ARGUMENT"] = "Argument";
  Kind2["FRAGMENT_SPREAD"] = "FragmentSpread";
  Kind2["INLINE_FRAGMENT"] = "InlineFragment";
  Kind2["FRAGMENT_DEFINITION"] = "FragmentDefinition";
  Kind2["VARIABLE"] = "Variable";
  Kind2["INT"] = "IntValue";
  Kind2["FLOAT"] = "FloatValue";
  Kind2["STRING"] = "StringValue";
  Kind2["BOOLEAN"] = "BooleanValue";
  Kind2["NULL"] = "NullValue";
  Kind2["ENUM"] = "EnumValue";
  Kind2["LIST"] = "ListValue";
  Kind2["OBJECT"] = "ObjectValue";
  Kind2["OBJECT_FIELD"] = "ObjectField";
  Kind2["DIRECTIVE"] = "Directive";
  Kind2["NAMED_TYPE"] = "NamedType";
  Kind2["LIST_TYPE"] = "ListType";
  Kind2["NON_NULL_TYPE"] = "NonNullType";
  Kind2["SCHEMA_DEFINITION"] = "SchemaDefinition";
  Kind2["OPERATION_TYPE_DEFINITION"] = "OperationTypeDefinition";
  Kind2["SCALAR_TYPE_DEFINITION"] = "ScalarTypeDefinition";
  Kind2["OBJECT_TYPE_DEFINITION"] = "ObjectTypeDefinition";
  Kind2["FIELD_DEFINITION"] = "FieldDefinition";
  Kind2["INPUT_VALUE_DEFINITION"] = "InputValueDefinition";
  Kind2["INTERFACE_TYPE_DEFINITION"] = "InterfaceTypeDefinition";
  Kind2["UNION_TYPE_DEFINITION"] = "UnionTypeDefinition";
  Kind2["ENUM_TYPE_DEFINITION"] = "EnumTypeDefinition";
  Kind2["ENUM_VALUE_DEFINITION"] = "EnumValueDefinition";
  Kind2["INPUT_OBJECT_TYPE_DEFINITION"] = "InputObjectTypeDefinition";
  Kind2["DIRECTIVE_DEFINITION"] = "DirectiveDefinition";
  Kind2["SCHEMA_EXTENSION"] = "SchemaExtension";
  Kind2["SCALAR_TYPE_EXTENSION"] = "ScalarTypeExtension";
  Kind2["OBJECT_TYPE_EXTENSION"] = "ObjectTypeExtension";
  Kind2["INTERFACE_TYPE_EXTENSION"] = "InterfaceTypeExtension";
  Kind2["UNION_TYPE_EXTENSION"] = "UnionTypeExtension";
  Kind2["ENUM_TYPE_EXTENSION"] = "EnumTypeExtension";
  Kind2["INPUT_OBJECT_TYPE_EXTENSION"] = "InputObjectTypeExtension";
})(Kind || (Kind = {}));
function isWhiteSpace(code) {
  return code === 9 || code === 32;
}
function isDigit(code) {
  return code >= 48 && code <= 57;
}
function isLetter(code) {
  return code >= 97 && code <= 122 || // A-Z
  code >= 65 && code <= 90;
}
function isNameStart(code) {
  return isLetter(code) || code === 95;
}
function isNameContinue(code) {
  return isLetter(code) || isDigit(code) || code === 95;
}
function dedentBlockStringLines(lines) {
  var _firstNonEmptyLine2;
  let commonIndent = Number.MAX_SAFE_INTEGER;
  let firstNonEmptyLine = null;
  let lastNonEmptyLine = -1;
  for (let i = 0; i < lines.length; ++i) {
    var _firstNonEmptyLine;
    const line = lines[i];
    const indent2 = leadingWhitespace(line);
    if (indent2 === line.length) {
      continue;
    }
    firstNonEmptyLine = (_firstNonEmptyLine = firstNonEmptyLine) !== null && _firstNonEmptyLine !== void 0 ? _firstNonEmptyLine : i;
    lastNonEmptyLine = i;
    if (i !== 0 && indent2 < commonIndent) {
      commonIndent = indent2;
    }
  }
  return lines.map((line, i) => i === 0 ? line : line.slice(commonIndent)).slice(
    (_firstNonEmptyLine2 = firstNonEmptyLine) !== null && _firstNonEmptyLine2 !== void 0 ? _firstNonEmptyLine2 : 0,
    lastNonEmptyLine + 1
  );
}
function leadingWhitespace(str) {
  let i = 0;
  while (i < str.length && isWhiteSpace(str.charCodeAt(i))) {
    ++i;
  }
  return i;
}
function printBlockString(value, options) {
  const escapedValue = value.replace(/"""/g, '\\"""');
  const lines = escapedValue.split(/\r\n|[\n\r]/g);
  const isSingleLine = lines.length === 1;
  const forceLeadingNewLine = lines.length > 1 && lines.slice(1).every((line) => line.length === 0 || isWhiteSpace(line.charCodeAt(0)));
  const hasTrailingTripleQuotes = escapedValue.endsWith('\\"""');
  const hasTrailingQuote = value.endsWith('"') && !hasTrailingTripleQuotes;
  const hasTrailingSlash = value.endsWith("\\");
  const forceTrailingNewline = hasTrailingQuote || hasTrailingSlash;
  const printAsMultipleLines = !(options !== null && options !== void 0 && options.minimize) && // add leading and trailing new lines only if it improves readability
  (!isSingleLine || value.length > 70 || forceTrailingNewline || forceLeadingNewLine || hasTrailingTripleQuotes);
  let result = "";
  const skipLeadingNewLine = isSingleLine && isWhiteSpace(value.charCodeAt(0));
  if (printAsMultipleLines && !skipLeadingNewLine || forceLeadingNewLine) {
    result += "\n";
  }
  result += escapedValue;
  if (printAsMultipleLines || forceTrailingNewline) {
    result += "\n";
  }
  return '"""' + result + '"""';
}
var TokenKind;
(function(TokenKind2) {
  TokenKind2["SOF"] = "<SOF>";
  TokenKind2["EOF"] = "<EOF>";
  TokenKind2["BANG"] = "!";
  TokenKind2["DOLLAR"] = "$";
  TokenKind2["AMP"] = "&";
  TokenKind2["PAREN_L"] = "(";
  TokenKind2["PAREN_R"] = ")";
  TokenKind2["SPREAD"] = "...";
  TokenKind2["COLON"] = ":";
  TokenKind2["EQUALS"] = "=";
  TokenKind2["AT"] = "@";
  TokenKind2["BRACKET_L"] = "[";
  TokenKind2["BRACKET_R"] = "]";
  TokenKind2["BRACE_L"] = "{";
  TokenKind2["PIPE"] = "|";
  TokenKind2["BRACE_R"] = "}";
  TokenKind2["NAME"] = "Name";
  TokenKind2["INT"] = "Int";
  TokenKind2["FLOAT"] = "Float";
  TokenKind2["STRING"] = "String";
  TokenKind2["BLOCK_STRING"] = "BlockString";
  TokenKind2["COMMENT"] = "Comment";
})(TokenKind || (TokenKind = {}));
var Lexer = class {
  /**
   * The previously focused non-ignored token.
   */
  /**
   * The currently focused non-ignored token.
   */
  /**
   * The (1-indexed) line containing the current token.
   */
  /**
   * The character offset at which the current line begins.
   */
  constructor(source) {
    const startOfFileToken = new Token(TokenKind.SOF, 0, 0, 0, 0);
    this.source = source;
    this.lastToken = startOfFileToken;
    this.token = startOfFileToken;
    this.line = 1;
    this.lineStart = 0;
  }
  get [Symbol.toStringTag]() {
    return "Lexer";
  }
  /**
   * Advances the token stream to the next non-ignored token.
   */
  advance() {
    this.lastToken = this.token;
    const token = this.token = this.lookahead();
    return token;
  }
  /**
   * Looks ahead and returns the next non-ignored token, but does not change
   * the state of Lexer.
   */
  lookahead() {
    let token = this.token;
    if (token.kind !== TokenKind.EOF) {
      do {
        if (token.next) {
          token = token.next;
        } else {
          const nextToken = readNextToken(this, token.end);
          token.next = nextToken;
          nextToken.prev = token;
          token = nextToken;
        }
      } while (token.kind === TokenKind.COMMENT);
    }
    return token;
  }
};
function isPunctuatorTokenKind(kind) {
  return kind === TokenKind.BANG || kind === TokenKind.DOLLAR || kind === TokenKind.AMP || kind === TokenKind.PAREN_L || kind === TokenKind.PAREN_R || kind === TokenKind.SPREAD || kind === TokenKind.COLON || kind === TokenKind.EQUALS || kind === TokenKind.AT || kind === TokenKind.BRACKET_L || kind === TokenKind.BRACKET_R || kind === TokenKind.BRACE_L || kind === TokenKind.PIPE || kind === TokenKind.BRACE_R;
}
function isUnicodeScalarValue(code) {
  return code >= 0 && code <= 55295 || code >= 57344 && code <= 1114111;
}
function isSupplementaryCodePoint(body, location2) {
  return isLeadingSurrogate(body.charCodeAt(location2)) && isTrailingSurrogate(body.charCodeAt(location2 + 1));
}
function isLeadingSurrogate(code) {
  return code >= 55296 && code <= 56319;
}
function isTrailingSurrogate(code) {
  return code >= 56320 && code <= 57343;
}
function printCodePointAt(lexer2, location2) {
  const code = lexer2.source.body.codePointAt(location2);
  if (code === void 0) {
    return TokenKind.EOF;
  } else if (code >= 32 && code <= 126) {
    const char = String.fromCodePoint(code);
    return char === '"' ? `'"'` : `"${char}"`;
  }
  return "U+" + code.toString(16).toUpperCase().padStart(4, "0");
}
function createToken(lexer2, kind, start, end, value) {
  const line = lexer2.line;
  const col = 1 + start - lexer2.lineStart;
  return new Token(kind, start, end, line, col, value);
}
function readNextToken(lexer2, start) {
  const body = lexer2.source.body;
  const bodyLength = body.length;
  let position = start;
  while (position < bodyLength) {
    const code = body.charCodeAt(position);
    switch (code) {
      case 65279:
      case 9:
      case 32:
      case 44:
        ++position;
        continue;
      case 10:
        ++position;
        ++lexer2.line;
        lexer2.lineStart = position;
        continue;
      case 13:
        if (body.charCodeAt(position + 1) === 10) {
          position += 2;
        } else {
          ++position;
        }
        ++lexer2.line;
        lexer2.lineStart = position;
        continue;
      case 35:
        return readComment(lexer2, position);
      case 33:
        return createToken(lexer2, TokenKind.BANG, position, position + 1);
      case 36:
        return createToken(lexer2, TokenKind.DOLLAR, position, position + 1);
      case 38:
        return createToken(lexer2, TokenKind.AMP, position, position + 1);
      case 40:
        return createToken(lexer2, TokenKind.PAREN_L, position, position + 1);
      case 41:
        return createToken(lexer2, TokenKind.PAREN_R, position, position + 1);
      case 46:
        if (body.charCodeAt(position + 1) === 46 && body.charCodeAt(position + 2) === 46) {
          return createToken(lexer2, TokenKind.SPREAD, position, position + 3);
        }
        break;
      case 58:
        return createToken(lexer2, TokenKind.COLON, position, position + 1);
      case 61:
        return createToken(lexer2, TokenKind.EQUALS, position, position + 1);
      case 64:
        return createToken(lexer2, TokenKind.AT, position, position + 1);
      case 91:
        return createToken(lexer2, TokenKind.BRACKET_L, position, position + 1);
      case 93:
        return createToken(lexer2, TokenKind.BRACKET_R, position, position + 1);
      case 123:
        return createToken(lexer2, TokenKind.BRACE_L, position, position + 1);
      case 124:
        return createToken(lexer2, TokenKind.PIPE, position, position + 1);
      case 125:
        return createToken(lexer2, TokenKind.BRACE_R, position, position + 1);
      case 34:
        if (body.charCodeAt(position + 1) === 34 && body.charCodeAt(position + 2) === 34) {
          return readBlockString(lexer2, position);
        }
        return readString(lexer2, position);
    }
    if (isDigit(code) || code === 45) {
      return readNumber(lexer2, position, code);
    }
    if (isNameStart(code)) {
      return readName(lexer2, position);
    }
    throw syntaxError(
      lexer2.source,
      position,
      code === 39 ? `Unexpected single quote character ('), did you mean to use a double quote (")?` : isUnicodeScalarValue(code) || isSupplementaryCodePoint(body, position) ? `Unexpected character: ${printCodePointAt(lexer2, position)}.` : `Invalid character: ${printCodePointAt(lexer2, position)}.`
    );
  }
  return createToken(lexer2, TokenKind.EOF, bodyLength, bodyLength);
}
function readComment(lexer2, start) {
  const body = lexer2.source.body;
  const bodyLength = body.length;
  let position = start + 1;
  while (position < bodyLength) {
    const code = body.charCodeAt(position);
    if (code === 10 || code === 13) {
      break;
    }
    if (isUnicodeScalarValue(code)) {
      ++position;
    } else if (isSupplementaryCodePoint(body, position)) {
      position += 2;
    } else {
      break;
    }
  }
  return createToken(
    lexer2,
    TokenKind.COMMENT,
    start,
    position,
    body.slice(start + 1, position)
  );
}
function readNumber(lexer2, start, firstCode) {
  const body = lexer2.source.body;
  let position = start;
  let code = firstCode;
  let isFloat = false;
  if (code === 45) {
    code = body.charCodeAt(++position);
  }
  if (code === 48) {
    code = body.charCodeAt(++position);
    if (isDigit(code)) {
      throw syntaxError(
        lexer2.source,
        position,
        `Invalid number, unexpected digit after 0: ${printCodePointAt(
          lexer2,
          position
        )}.`
      );
    }
  } else {
    position = readDigits(lexer2, position, code);
    code = body.charCodeAt(position);
  }
  if (code === 46) {
    isFloat = true;
    code = body.charCodeAt(++position);
    position = readDigits(lexer2, position, code);
    code = body.charCodeAt(position);
  }
  if (code === 69 || code === 101) {
    isFloat = true;
    code = body.charCodeAt(++position);
    if (code === 43 || code === 45) {
      code = body.charCodeAt(++position);
    }
    position = readDigits(lexer2, position, code);
    code = body.charCodeAt(position);
  }
  if (code === 46 || isNameStart(code)) {
    throw syntaxError(
      lexer2.source,
      position,
      `Invalid number, expected digit but got: ${printCodePointAt(
        lexer2,
        position
      )}.`
    );
  }
  return createToken(
    lexer2,
    isFloat ? TokenKind.FLOAT : TokenKind.INT,
    start,
    position,
    body.slice(start, position)
  );
}
function readDigits(lexer2, start, firstCode) {
  if (!isDigit(firstCode)) {
    throw syntaxError(
      lexer2.source,
      start,
      `Invalid number, expected digit but got: ${printCodePointAt(
        lexer2,
        start
      )}.`
    );
  }
  const body = lexer2.source.body;
  let position = start + 1;
  while (isDigit(body.charCodeAt(position))) {
    ++position;
  }
  return position;
}
function readString(lexer2, start) {
  const body = lexer2.source.body;
  const bodyLength = body.length;
  let position = start + 1;
  let chunkStart = position;
  let value = "";
  while (position < bodyLength) {
    const code = body.charCodeAt(position);
    if (code === 34) {
      value += body.slice(chunkStart, position);
      return createToken(lexer2, TokenKind.STRING, start, position + 1, value);
    }
    if (code === 92) {
      value += body.slice(chunkStart, position);
      const escape = body.charCodeAt(position + 1) === 117 ? body.charCodeAt(position + 2) === 123 ? readEscapedUnicodeVariableWidth(lexer2, position) : readEscapedUnicodeFixedWidth(lexer2, position) : readEscapedCharacter(lexer2, position);
      value += escape.value;
      position += escape.size;
      chunkStart = position;
      continue;
    }
    if (code === 10 || code === 13) {
      break;
    }
    if (isUnicodeScalarValue(code)) {
      ++position;
    } else if (isSupplementaryCodePoint(body, position)) {
      position += 2;
    } else {
      throw syntaxError(
        lexer2.source,
        position,
        `Invalid character within String: ${printCodePointAt(
          lexer2,
          position
        )}.`
      );
    }
  }
  throw syntaxError(lexer2.source, position, "Unterminated string.");
}
function readEscapedUnicodeVariableWidth(lexer2, position) {
  const body = lexer2.source.body;
  let point = 0;
  let size = 3;
  while (size < 12) {
    const code = body.charCodeAt(position + size++);
    if (code === 125) {
      if (size < 5 || !isUnicodeScalarValue(point)) {
        break;
      }
      return {
        value: String.fromCodePoint(point),
        size
      };
    }
    point = point << 4 | readHexDigit(code);
    if (point < 0) {
      break;
    }
  }
  throw syntaxError(
    lexer2.source,
    position,
    `Invalid Unicode escape sequence: "${body.slice(
      position,
      position + size
    )}".`
  );
}
function readEscapedUnicodeFixedWidth(lexer2, position) {
  const body = lexer2.source.body;
  const code = read16BitHexCode(body, position + 2);
  if (isUnicodeScalarValue(code)) {
    return {
      value: String.fromCodePoint(code),
      size: 6
    };
  }
  if (isLeadingSurrogate(code)) {
    if (body.charCodeAt(position + 6) === 92 && body.charCodeAt(position + 7) === 117) {
      const trailingCode = read16BitHexCode(body, position + 8);
      if (isTrailingSurrogate(trailingCode)) {
        return {
          value: String.fromCodePoint(code, trailingCode),
          size: 12
        };
      }
    }
  }
  throw syntaxError(
    lexer2.source,
    position,
    `Invalid Unicode escape sequence: "${body.slice(position, position + 6)}".`
  );
}
function read16BitHexCode(body, position) {
  return readHexDigit(body.charCodeAt(position)) << 12 | readHexDigit(body.charCodeAt(position + 1)) << 8 | readHexDigit(body.charCodeAt(position + 2)) << 4 | readHexDigit(body.charCodeAt(position + 3));
}
function readHexDigit(code) {
  return code >= 48 && code <= 57 ? code - 48 : code >= 65 && code <= 70 ? code - 55 : code >= 97 && code <= 102 ? code - 87 : -1;
}
function readEscapedCharacter(lexer2, position) {
  const body = lexer2.source.body;
  const code = body.charCodeAt(position + 1);
  switch (code) {
    case 34:
      return {
        value: '"',
        size: 2
      };
    case 92:
      return {
        value: "\\",
        size: 2
      };
    case 47:
      return {
        value: "/",
        size: 2
      };
    case 98:
      return {
        value: "\b",
        size: 2
      };
    case 102:
      return {
        value: "\f",
        size: 2
      };
    case 110:
      return {
        value: "\n",
        size: 2
      };
    case 114:
      return {
        value: "\r",
        size: 2
      };
    case 116:
      return {
        value: "	",
        size: 2
      };
  }
  throw syntaxError(
    lexer2.source,
    position,
    `Invalid character escape sequence: "${body.slice(
      position,
      position + 2
    )}".`
  );
}
function readBlockString(lexer2, start) {
  const body = lexer2.source.body;
  const bodyLength = body.length;
  let lineStart = lexer2.lineStart;
  let position = start + 3;
  let chunkStart = position;
  let currentLine = "";
  const blockLines = [];
  while (position < bodyLength) {
    const code = body.charCodeAt(position);
    if (code === 34 && body.charCodeAt(position + 1) === 34 && body.charCodeAt(position + 2) === 34) {
      currentLine += body.slice(chunkStart, position);
      blockLines.push(currentLine);
      const token = createToken(
        lexer2,
        TokenKind.BLOCK_STRING,
        start,
        position + 3,
        // Return a string of the lines joined with U+000A.
        dedentBlockStringLines(blockLines).join("\n")
      );
      lexer2.line += blockLines.length - 1;
      lexer2.lineStart = lineStart;
      return token;
    }
    if (code === 92 && body.charCodeAt(position + 1) === 34 && body.charCodeAt(position + 2) === 34 && body.charCodeAt(position + 3) === 34) {
      currentLine += body.slice(chunkStart, position);
      chunkStart = position + 1;
      position += 4;
      continue;
    }
    if (code === 10 || code === 13) {
      currentLine += body.slice(chunkStart, position);
      blockLines.push(currentLine);
      if (code === 13 && body.charCodeAt(position + 1) === 10) {
        position += 2;
      } else {
        ++position;
      }
      currentLine = "";
      chunkStart = position;
      lineStart = position;
      continue;
    }
    if (isUnicodeScalarValue(code)) {
      ++position;
    } else if (isSupplementaryCodePoint(body, position)) {
      position += 2;
    } else {
      throw syntaxError(
        lexer2.source,
        position,
        `Invalid character within String: ${printCodePointAt(
          lexer2,
          position
        )}.`
      );
    }
  }
  throw syntaxError(lexer2.source, position, "Unterminated string.");
}
function readName(lexer2, start) {
  const body = lexer2.source.body;
  const bodyLength = body.length;
  let position = start + 1;
  while (position < bodyLength) {
    const code = body.charCodeAt(position);
    if (isNameContinue(code)) {
      ++position;
    } else {
      break;
    }
  }
  return createToken(
    lexer2,
    TokenKind.NAME,
    start,
    position,
    body.slice(start, position)
  );
}
var MAX_ARRAY_LENGTH = 10;
var MAX_RECURSIVE_DEPTH = 2;
function inspect(value) {
  return formatValue(value, []);
}
function formatValue(value, seenValues) {
  switch (typeof value) {
    case "string":
      return JSON.stringify(value);
    case "function":
      return value.name ? `[function ${value.name}]` : "[function]";
    case "object":
      return formatObjectValue(value, seenValues);
    default:
      return String(value);
  }
}
function formatObjectValue(value, previouslySeenValues) {
  if (value === null) {
    return "null";
  }
  if (previouslySeenValues.includes(value)) {
    return "[Circular]";
  }
  const seenValues = [...previouslySeenValues, value];
  if (isJSONable(value)) {
    const jsonValue = value.toJSON();
    if (jsonValue !== value) {
      return typeof jsonValue === "string" ? jsonValue : formatValue(jsonValue, seenValues);
    }
  } else if (Array.isArray(value)) {
    return formatArray(value, seenValues);
  }
  return formatObject(value, seenValues);
}
function isJSONable(value) {
  return typeof value.toJSON === "function";
}
function formatObject(object, seenValues) {
  const entries = Object.entries(object);
  if (entries.length === 0) {
    return "{}";
  }
  if (seenValues.length > MAX_RECURSIVE_DEPTH) {
    return "[" + getObjectTag(object) + "]";
  }
  const properties = entries.map(
    ([key, value]) => key + ": " + formatValue(value, seenValues)
  );
  return "{ " + properties.join(", ") + " }";
}
function formatArray(array, seenValues) {
  if (array.length === 0) {
    return "[]";
  }
  if (seenValues.length > MAX_RECURSIVE_DEPTH) {
    return "[Array]";
  }
  const len = Math.min(MAX_ARRAY_LENGTH, array.length);
  const remaining = array.length - len;
  const items = [];
  for (let i = 0; i < len; ++i) {
    items.push(formatValue(array[i], seenValues));
  }
  if (remaining === 1) {
    items.push("... 1 more item");
  } else if (remaining > 1) {
    items.push(`... ${remaining} more items`);
  }
  return "[" + items.join(", ") + "]";
}
function getObjectTag(object) {
  const tag = Object.prototype.toString.call(object).replace(/^\[object /, "").replace(/]$/, "");
  if (tag === "Object" && typeof object.constructor === "function") {
    const name = object.constructor.name;
    if (typeof name === "string" && name !== "") {
      return name;
    }
  }
  return tag;
}
var instanceOf = (
  /* c8 ignore next 6 */
  // FIXME: https://github.com/graphql/graphql-js/issues/2317
  globalThis.process && false ? function instanceOf2(value, constructor) {
    return value instanceof constructor;
  } : function instanceOf3(value, constructor) {
    if (value instanceof constructor) {
      return true;
    }
    if (typeof value === "object" && value !== null) {
      var _value$constructor;
      const className = constructor.prototype[Symbol.toStringTag];
      const valueClassName = (
        // We still need to support constructor's name to detect conflicts with older versions of this library.
        Symbol.toStringTag in value ? value[Symbol.toStringTag] : (_value$constructor = value.constructor) === null || _value$constructor === void 0 ? void 0 : _value$constructor.name
      );
      if (className === valueClassName) {
        const stringifiedValue = inspect(value);
        throw new Error(`Cannot use ${className} "${stringifiedValue}" from another module or realm.

Ensure that there is only one instance of "graphql" in the node_modules
directory. If different versions of "graphql" are the dependencies of other
relied on modules, use "resolutions" to ensure only one version is installed.

https://yarnpkg.com/en/docs/selective-version-resolutions

Duplicate "graphql" modules cannot be used at the same time since different
versions may have different capabilities and behavior. The data from one
version used in the function from another could produce confusing and
spurious results.`);
      }
    }
    return false;
  }
);
var Source = class {
  constructor(body, name = "GraphQL request", locationOffset = {
    line: 1,
    column: 1
  }) {
    typeof body === "string" || devAssert(false, `Body must be a string. Received: ${inspect(body)}.`);
    this.body = body;
    this.name = name;
    this.locationOffset = locationOffset;
    this.locationOffset.line > 0 || devAssert(
      false,
      "line in locationOffset is 1-indexed and must be positive."
    );
    this.locationOffset.column > 0 || devAssert(
      false,
      "column in locationOffset is 1-indexed and must be positive."
    );
  }
  get [Symbol.toStringTag]() {
    return "Source";
  }
};
function isSource(source) {
  return instanceOf(source, Source);
}
function parse2(source, options) {
  const parser = new Parser(source, options);
  return parser.parseDocument();
}
var Parser = class {
  constructor(source, options = {}) {
    const sourceObj = isSource(source) ? source : new Source(source);
    this._lexer = new Lexer(sourceObj);
    this._options = options;
    this._tokenCounter = 0;
  }
  /**
   * Converts a name lex token into a name parse node.
   */
  parseName() {
    const token = this.expectToken(TokenKind.NAME);
    return this.node(token, {
      kind: Kind.NAME,
      value: token.value
    });
  }
  // Implements the parsing rules in the Document section.
  /**
   * Document : Definition+
   */
  parseDocument() {
    return this.node(this._lexer.token, {
      kind: Kind.DOCUMENT,
      definitions: this.many(
        TokenKind.SOF,
        this.parseDefinition,
        TokenKind.EOF
      )
    });
  }
  /**
   * Definition :
   *   - ExecutableDefinition
   *   - TypeSystemDefinition
   *   - TypeSystemExtension
   *
   * ExecutableDefinition :
   *   - OperationDefinition
   *   - FragmentDefinition
   *
   * TypeSystemDefinition :
   *   - SchemaDefinition
   *   - TypeDefinition
   *   - DirectiveDefinition
   *
   * TypeDefinition :
   *   - ScalarTypeDefinition
   *   - ObjectTypeDefinition
   *   - InterfaceTypeDefinition
   *   - UnionTypeDefinition
   *   - EnumTypeDefinition
   *   - InputObjectTypeDefinition
   */
  parseDefinition() {
    if (this.peek(TokenKind.BRACE_L)) {
      return this.parseOperationDefinition();
    }
    const hasDescription = this.peekDescription();
    const keywordToken = hasDescription ? this._lexer.lookahead() : this._lexer.token;
    if (keywordToken.kind === TokenKind.NAME) {
      switch (keywordToken.value) {
        case "schema":
          return this.parseSchemaDefinition();
        case "scalar":
          return this.parseScalarTypeDefinition();
        case "type":
          return this.parseObjectTypeDefinition();
        case "interface":
          return this.parseInterfaceTypeDefinition();
        case "union":
          return this.parseUnionTypeDefinition();
        case "enum":
          return this.parseEnumTypeDefinition();
        case "input":
          return this.parseInputObjectTypeDefinition();
        case "directive":
          return this.parseDirectiveDefinition();
      }
      if (hasDescription) {
        throw syntaxError(
          this._lexer.source,
          this._lexer.token.start,
          "Unexpected description, descriptions are supported only on type definitions."
        );
      }
      switch (keywordToken.value) {
        case "query":
        case "mutation":
        case "subscription":
          return this.parseOperationDefinition();
        case "fragment":
          return this.parseFragmentDefinition();
        case "extend":
          return this.parseTypeSystemExtension();
      }
    }
    throw this.unexpected(keywordToken);
  }
  // Implements the parsing rules in the Operations section.
  /**
   * OperationDefinition :
   *  - SelectionSet
   *  - OperationType Name? VariableDefinitions? Directives? SelectionSet
   */
  parseOperationDefinition() {
    const start = this._lexer.token;
    if (this.peek(TokenKind.BRACE_L)) {
      return this.node(start, {
        kind: Kind.OPERATION_DEFINITION,
        operation: OperationTypeNode.QUERY,
        name: void 0,
        variableDefinitions: [],
        directives: [],
        selectionSet: this.parseSelectionSet()
      });
    }
    const operation = this.parseOperationType();
    let name;
    if (this.peek(TokenKind.NAME)) {
      name = this.parseName();
    }
    return this.node(start, {
      kind: Kind.OPERATION_DEFINITION,
      operation,
      name,
      variableDefinitions: this.parseVariableDefinitions(),
      directives: this.parseDirectives(false),
      selectionSet: this.parseSelectionSet()
    });
  }
  /**
   * OperationType : one of query mutation subscription
   */
  parseOperationType() {
    const operationToken = this.expectToken(TokenKind.NAME);
    switch (operationToken.value) {
      case "query":
        return OperationTypeNode.QUERY;
      case "mutation":
        return OperationTypeNode.MUTATION;
      case "subscription":
        return OperationTypeNode.SUBSCRIPTION;
    }
    throw this.unexpected(operationToken);
  }
  /**
   * VariableDefinitions : ( VariableDefinition+ )
   */
  parseVariableDefinitions() {
    return this.optionalMany(
      TokenKind.PAREN_L,
      this.parseVariableDefinition,
      TokenKind.PAREN_R
    );
  }
  /**
   * VariableDefinition : Variable : Type DefaultValue? Directives[Const]?
   */
  parseVariableDefinition() {
    return this.node(this._lexer.token, {
      kind: Kind.VARIABLE_DEFINITION,
      variable: this.parseVariable(),
      type: (this.expectToken(TokenKind.COLON), this.parseTypeReference()),
      defaultValue: this.expectOptionalToken(TokenKind.EQUALS) ? this.parseConstValueLiteral() : void 0,
      directives: this.parseConstDirectives()
    });
  }
  /**
   * Variable : $ Name
   */
  parseVariable() {
    const start = this._lexer.token;
    this.expectToken(TokenKind.DOLLAR);
    return this.node(start, {
      kind: Kind.VARIABLE,
      name: this.parseName()
    });
  }
  /**
   * ```
   * SelectionSet : { Selection+ }
   * ```
   */
  parseSelectionSet() {
    return this.node(this._lexer.token, {
      kind: Kind.SELECTION_SET,
      selections: this.many(
        TokenKind.BRACE_L,
        this.parseSelection,
        TokenKind.BRACE_R
      )
    });
  }
  /**
   * Selection :
   *   - Field
   *   - FragmentSpread
   *   - InlineFragment
   */
  parseSelection() {
    return this.peek(TokenKind.SPREAD) ? this.parseFragment() : this.parseField();
  }
  /**
   * Field : Alias? Name Arguments? Directives? SelectionSet?
   *
   * Alias : Name :
   */
  parseField() {
    const start = this._lexer.token;
    const nameOrAlias = this.parseName();
    let alias;
    let name;
    if (this.expectOptionalToken(TokenKind.COLON)) {
      alias = nameOrAlias;
      name = this.parseName();
    } else {
      name = nameOrAlias;
    }
    return this.node(start, {
      kind: Kind.FIELD,
      alias,
      name,
      arguments: this.parseArguments(false),
      directives: this.parseDirectives(false),
      selectionSet: this.peek(TokenKind.BRACE_L) ? this.parseSelectionSet() : void 0
    });
  }
  /**
   * Arguments[Const] : ( Argument[?Const]+ )
   */
  parseArguments(isConst) {
    const item = isConst ? this.parseConstArgument : this.parseArgument;
    return this.optionalMany(TokenKind.PAREN_L, item, TokenKind.PAREN_R);
  }
  /**
   * Argument[Const] : Name : Value[?Const]
   */
  parseArgument(isConst = false) {
    const start = this._lexer.token;
    const name = this.parseName();
    this.expectToken(TokenKind.COLON);
    return this.node(start, {
      kind: Kind.ARGUMENT,
      name,
      value: this.parseValueLiteral(isConst)
    });
  }
  parseConstArgument() {
    return this.parseArgument(true);
  }
  // Implements the parsing rules in the Fragments section.
  /**
   * Corresponds to both FragmentSpread and InlineFragment in the spec.
   *
   * FragmentSpread : ... FragmentName Directives?
   *
   * InlineFragment : ... TypeCondition? Directives? SelectionSet
   */
  parseFragment() {
    const start = this._lexer.token;
    this.expectToken(TokenKind.SPREAD);
    const hasTypeCondition = this.expectOptionalKeyword("on");
    if (!hasTypeCondition && this.peek(TokenKind.NAME)) {
      return this.node(start, {
        kind: Kind.FRAGMENT_SPREAD,
        name: this.parseFragmentName(),
        directives: this.parseDirectives(false)
      });
    }
    return this.node(start, {
      kind: Kind.INLINE_FRAGMENT,
      typeCondition: hasTypeCondition ? this.parseNamedType() : void 0,
      directives: this.parseDirectives(false),
      selectionSet: this.parseSelectionSet()
    });
  }
  /**
   * FragmentDefinition :
   *   - fragment FragmentName on TypeCondition Directives? SelectionSet
   *
   * TypeCondition : NamedType
   */
  parseFragmentDefinition() {
    const start = this._lexer.token;
    this.expectKeyword("fragment");
    if (this._options.allowLegacyFragmentVariables === true) {
      return this.node(start, {
        kind: Kind.FRAGMENT_DEFINITION,
        name: this.parseFragmentName(),
        variableDefinitions: this.parseVariableDefinitions(),
        typeCondition: (this.expectKeyword("on"), this.parseNamedType()),
        directives: this.parseDirectives(false),
        selectionSet: this.parseSelectionSet()
      });
    }
    return this.node(start, {
      kind: Kind.FRAGMENT_DEFINITION,
      name: this.parseFragmentName(),
      typeCondition: (this.expectKeyword("on"), this.parseNamedType()),
      directives: this.parseDirectives(false),
      selectionSet: this.parseSelectionSet()
    });
  }
  /**
   * FragmentName : Name but not `on`
   */
  parseFragmentName() {
    if (this._lexer.token.value === "on") {
      throw this.unexpected();
    }
    return this.parseName();
  }
  // Implements the parsing rules in the Values section.
  /**
   * Value[Const] :
   *   - [~Const] Variable
   *   - IntValue
   *   - FloatValue
   *   - StringValue
   *   - BooleanValue
   *   - NullValue
   *   - EnumValue
   *   - ListValue[?Const]
   *   - ObjectValue[?Const]
   *
   * BooleanValue : one of `true` `false`
   *
   * NullValue : `null`
   *
   * EnumValue : Name but not `true`, `false` or `null`
   */
  parseValueLiteral(isConst) {
    const token = this._lexer.token;
    switch (token.kind) {
      case TokenKind.BRACKET_L:
        return this.parseList(isConst);
      case TokenKind.BRACE_L:
        return this.parseObject(isConst);
      case TokenKind.INT:
        this.advanceLexer();
        return this.node(token, {
          kind: Kind.INT,
          value: token.value
        });
      case TokenKind.FLOAT:
        this.advanceLexer();
        return this.node(token, {
          kind: Kind.FLOAT,
          value: token.value
        });
      case TokenKind.STRING:
      case TokenKind.BLOCK_STRING:
        return this.parseStringLiteral();
      case TokenKind.NAME:
        this.advanceLexer();
        switch (token.value) {
          case "true":
            return this.node(token, {
              kind: Kind.BOOLEAN,
              value: true
            });
          case "false":
            return this.node(token, {
              kind: Kind.BOOLEAN,
              value: false
            });
          case "null":
            return this.node(token, {
              kind: Kind.NULL
            });
          default:
            return this.node(token, {
              kind: Kind.ENUM,
              value: token.value
            });
        }
      case TokenKind.DOLLAR:
        if (isConst) {
          this.expectToken(TokenKind.DOLLAR);
          if (this._lexer.token.kind === TokenKind.NAME) {
            const varName = this._lexer.token.value;
            throw syntaxError(
              this._lexer.source,
              token.start,
              `Unexpected variable "$${varName}" in constant value.`
            );
          } else {
            throw this.unexpected(token);
          }
        }
        return this.parseVariable();
      default:
        throw this.unexpected();
    }
  }
  parseConstValueLiteral() {
    return this.parseValueLiteral(true);
  }
  parseStringLiteral() {
    const token = this._lexer.token;
    this.advanceLexer();
    return this.node(token, {
      kind: Kind.STRING,
      value: token.value,
      block: token.kind === TokenKind.BLOCK_STRING
    });
  }
  /**
   * ListValue[Const] :
   *   - [ ]
   *   - [ Value[?Const]+ ]
   */
  parseList(isConst) {
    const item = () => this.parseValueLiteral(isConst);
    return this.node(this._lexer.token, {
      kind: Kind.LIST,
      values: this.any(TokenKind.BRACKET_L, item, TokenKind.BRACKET_R)
    });
  }
  /**
   * ```
   * ObjectValue[Const] :
   *   - { }
   *   - { ObjectField[?Const]+ }
   * ```
   */
  parseObject(isConst) {
    const item = () => this.parseObjectField(isConst);
    return this.node(this._lexer.token, {
      kind: Kind.OBJECT,
      fields: this.any(TokenKind.BRACE_L, item, TokenKind.BRACE_R)
    });
  }
  /**
   * ObjectField[Const] : Name : Value[?Const]
   */
  parseObjectField(isConst) {
    const start = this._lexer.token;
    const name = this.parseName();
    this.expectToken(TokenKind.COLON);
    return this.node(start, {
      kind: Kind.OBJECT_FIELD,
      name,
      value: this.parseValueLiteral(isConst)
    });
  }
  // Implements the parsing rules in the Directives section.
  /**
   * Directives[Const] : Directive[?Const]+
   */
  parseDirectives(isConst) {
    const directives = [];
    while (this.peek(TokenKind.AT)) {
      directives.push(this.parseDirective(isConst));
    }
    return directives;
  }
  parseConstDirectives() {
    return this.parseDirectives(true);
  }
  /**
   * ```
   * Directive[Const] : @ Name Arguments[?Const]?
   * ```
   */
  parseDirective(isConst) {
    const start = this._lexer.token;
    this.expectToken(TokenKind.AT);
    return this.node(start, {
      kind: Kind.DIRECTIVE,
      name: this.parseName(),
      arguments: this.parseArguments(isConst)
    });
  }
  // Implements the parsing rules in the Types section.
  /**
   * Type :
   *   - NamedType
   *   - ListType
   *   - NonNullType
   */
  parseTypeReference() {
    const start = this._lexer.token;
    let type;
    if (this.expectOptionalToken(TokenKind.BRACKET_L)) {
      const innerType = this.parseTypeReference();
      this.expectToken(TokenKind.BRACKET_R);
      type = this.node(start, {
        kind: Kind.LIST_TYPE,
        type: innerType
      });
    } else {
      type = this.parseNamedType();
    }
    if (this.expectOptionalToken(TokenKind.BANG)) {
      return this.node(start, {
        kind: Kind.NON_NULL_TYPE,
        type
      });
    }
    return type;
  }
  /**
   * NamedType : Name
   */
  parseNamedType() {
    return this.node(this._lexer.token, {
      kind: Kind.NAMED_TYPE,
      name: this.parseName()
    });
  }
  // Implements the parsing rules in the Type Definition section.
  peekDescription() {
    return this.peek(TokenKind.STRING) || this.peek(TokenKind.BLOCK_STRING);
  }
  /**
   * Description : StringValue
   */
  parseDescription() {
    if (this.peekDescription()) {
      return this.parseStringLiteral();
    }
  }
  /**
   * ```
   * SchemaDefinition : Description? schema Directives[Const]? { OperationTypeDefinition+ }
   * ```
   */
  parseSchemaDefinition() {
    const start = this._lexer.token;
    const description = this.parseDescription();
    this.expectKeyword("schema");
    const directives = this.parseConstDirectives();
    const operationTypes = this.many(
      TokenKind.BRACE_L,
      this.parseOperationTypeDefinition,
      TokenKind.BRACE_R
    );
    return this.node(start, {
      kind: Kind.SCHEMA_DEFINITION,
      description,
      directives,
      operationTypes
    });
  }
  /**
   * OperationTypeDefinition : OperationType : NamedType
   */
  parseOperationTypeDefinition() {
    const start = this._lexer.token;
    const operation = this.parseOperationType();
    this.expectToken(TokenKind.COLON);
    const type = this.parseNamedType();
    return this.node(start, {
      kind: Kind.OPERATION_TYPE_DEFINITION,
      operation,
      type
    });
  }
  /**
   * ScalarTypeDefinition : Description? scalar Name Directives[Const]?
   */
  parseScalarTypeDefinition() {
    const start = this._lexer.token;
    const description = this.parseDescription();
    this.expectKeyword("scalar");
    const name = this.parseName();
    const directives = this.parseConstDirectives();
    return this.node(start, {
      kind: Kind.SCALAR_TYPE_DEFINITION,
      description,
      name,
      directives
    });
  }
  /**
   * ObjectTypeDefinition :
   *   Description?
   *   type Name ImplementsInterfaces? Directives[Const]? FieldsDefinition?
   */
  parseObjectTypeDefinition() {
    const start = this._lexer.token;
    const description = this.parseDescription();
    this.expectKeyword("type");
    const name = this.parseName();
    const interfaces = this.parseImplementsInterfaces();
    const directives = this.parseConstDirectives();
    const fields = this.parseFieldsDefinition();
    return this.node(start, {
      kind: Kind.OBJECT_TYPE_DEFINITION,
      description,
      name,
      interfaces,
      directives,
      fields
    });
  }
  /**
   * ImplementsInterfaces :
   *   - implements `&`? NamedType
   *   - ImplementsInterfaces & NamedType
   */
  parseImplementsInterfaces() {
    return this.expectOptionalKeyword("implements") ? this.delimitedMany(TokenKind.AMP, this.parseNamedType) : [];
  }
  /**
   * ```
   * FieldsDefinition : { FieldDefinition+ }
   * ```
   */
  parseFieldsDefinition() {
    return this.optionalMany(
      TokenKind.BRACE_L,
      this.parseFieldDefinition,
      TokenKind.BRACE_R
    );
  }
  /**
   * FieldDefinition :
   *   - Description? Name ArgumentsDefinition? : Type Directives[Const]?
   */
  parseFieldDefinition() {
    const start = this._lexer.token;
    const description = this.parseDescription();
    const name = this.parseName();
    const args = this.parseArgumentDefs();
    this.expectToken(TokenKind.COLON);
    const type = this.parseTypeReference();
    const directives = this.parseConstDirectives();
    return this.node(start, {
      kind: Kind.FIELD_DEFINITION,
      description,
      name,
      arguments: args,
      type,
      directives
    });
  }
  /**
   * ArgumentsDefinition : ( InputValueDefinition+ )
   */
  parseArgumentDefs() {
    return this.optionalMany(
      TokenKind.PAREN_L,
      this.parseInputValueDef,
      TokenKind.PAREN_R
    );
  }
  /**
   * InputValueDefinition :
   *   - Description? Name : Type DefaultValue? Directives[Const]?
   */
  parseInputValueDef() {
    const start = this._lexer.token;
    const description = this.parseDescription();
    const name = this.parseName();
    this.expectToken(TokenKind.COLON);
    const type = this.parseTypeReference();
    let defaultValue;
    if (this.expectOptionalToken(TokenKind.EQUALS)) {
      defaultValue = this.parseConstValueLiteral();
    }
    const directives = this.parseConstDirectives();
    return this.node(start, {
      kind: Kind.INPUT_VALUE_DEFINITION,
      description,
      name,
      type,
      defaultValue,
      directives
    });
  }
  /**
   * InterfaceTypeDefinition :
   *   - Description? interface Name Directives[Const]? FieldsDefinition?
   */
  parseInterfaceTypeDefinition() {
    const start = this._lexer.token;
    const description = this.parseDescription();
    this.expectKeyword("interface");
    const name = this.parseName();
    const interfaces = this.parseImplementsInterfaces();
    const directives = this.parseConstDirectives();
    const fields = this.parseFieldsDefinition();
    return this.node(start, {
      kind: Kind.INTERFACE_TYPE_DEFINITION,
      description,
      name,
      interfaces,
      directives,
      fields
    });
  }
  /**
   * UnionTypeDefinition :
   *   - Description? union Name Directives[Const]? UnionMemberTypes?
   */
  parseUnionTypeDefinition() {
    const start = this._lexer.token;
    const description = this.parseDescription();
    this.expectKeyword("union");
    const name = this.parseName();
    const directives = this.parseConstDirectives();
    const types = this.parseUnionMemberTypes();
    return this.node(start, {
      kind: Kind.UNION_TYPE_DEFINITION,
      description,
      name,
      directives,
      types
    });
  }
  /**
   * UnionMemberTypes :
   *   - = `|`? NamedType
   *   - UnionMemberTypes | NamedType
   */
  parseUnionMemberTypes() {
    return this.expectOptionalToken(TokenKind.EQUALS) ? this.delimitedMany(TokenKind.PIPE, this.parseNamedType) : [];
  }
  /**
   * EnumTypeDefinition :
   *   - Description? enum Name Directives[Const]? EnumValuesDefinition?
   */
  parseEnumTypeDefinition() {
    const start = this._lexer.token;
    const description = this.parseDescription();
    this.expectKeyword("enum");
    const name = this.parseName();
    const directives = this.parseConstDirectives();
    const values = this.parseEnumValuesDefinition();
    return this.node(start, {
      kind: Kind.ENUM_TYPE_DEFINITION,
      description,
      name,
      directives,
      values
    });
  }
  /**
   * ```
   * EnumValuesDefinition : { EnumValueDefinition+ }
   * ```
   */
  parseEnumValuesDefinition() {
    return this.optionalMany(
      TokenKind.BRACE_L,
      this.parseEnumValueDefinition,
      TokenKind.BRACE_R
    );
  }
  /**
   * EnumValueDefinition : Description? EnumValue Directives[Const]?
   */
  parseEnumValueDefinition() {
    const start = this._lexer.token;
    const description = this.parseDescription();
    const name = this.parseEnumValueName();
    const directives = this.parseConstDirectives();
    return this.node(start, {
      kind: Kind.ENUM_VALUE_DEFINITION,
      description,
      name,
      directives
    });
  }
  /**
   * EnumValue : Name but not `true`, `false` or `null`
   */
  parseEnumValueName() {
    if (this._lexer.token.value === "true" || this._lexer.token.value === "false" || this._lexer.token.value === "null") {
      throw syntaxError(
        this._lexer.source,
        this._lexer.token.start,
        `${getTokenDesc(
          this._lexer.token
        )} is reserved and cannot be used for an enum value.`
      );
    }
    return this.parseName();
  }
  /**
   * InputObjectTypeDefinition :
   *   - Description? input Name Directives[Const]? InputFieldsDefinition?
   */
  parseInputObjectTypeDefinition() {
    const start = this._lexer.token;
    const description = this.parseDescription();
    this.expectKeyword("input");
    const name = this.parseName();
    const directives = this.parseConstDirectives();
    const fields = this.parseInputFieldsDefinition();
    return this.node(start, {
      kind: Kind.INPUT_OBJECT_TYPE_DEFINITION,
      description,
      name,
      directives,
      fields
    });
  }
  /**
   * ```
   * InputFieldsDefinition : { InputValueDefinition+ }
   * ```
   */
  parseInputFieldsDefinition() {
    return this.optionalMany(
      TokenKind.BRACE_L,
      this.parseInputValueDef,
      TokenKind.BRACE_R
    );
  }
  /**
   * TypeSystemExtension :
   *   - SchemaExtension
   *   - TypeExtension
   *
   * TypeExtension :
   *   - ScalarTypeExtension
   *   - ObjectTypeExtension
   *   - InterfaceTypeExtension
   *   - UnionTypeExtension
   *   - EnumTypeExtension
   *   - InputObjectTypeDefinition
   */
  parseTypeSystemExtension() {
    const keywordToken = this._lexer.lookahead();
    if (keywordToken.kind === TokenKind.NAME) {
      switch (keywordToken.value) {
        case "schema":
          return this.parseSchemaExtension();
        case "scalar":
          return this.parseScalarTypeExtension();
        case "type":
          return this.parseObjectTypeExtension();
        case "interface":
          return this.parseInterfaceTypeExtension();
        case "union":
          return this.parseUnionTypeExtension();
        case "enum":
          return this.parseEnumTypeExtension();
        case "input":
          return this.parseInputObjectTypeExtension();
      }
    }
    throw this.unexpected(keywordToken);
  }
  /**
   * ```
   * SchemaExtension :
   *  - extend schema Directives[Const]? { OperationTypeDefinition+ }
   *  - extend schema Directives[Const]
   * ```
   */
  parseSchemaExtension() {
    const start = this._lexer.token;
    this.expectKeyword("extend");
    this.expectKeyword("schema");
    const directives = this.parseConstDirectives();
    const operationTypes = this.optionalMany(
      TokenKind.BRACE_L,
      this.parseOperationTypeDefinition,
      TokenKind.BRACE_R
    );
    if (directives.length === 0 && operationTypes.length === 0) {
      throw this.unexpected();
    }
    return this.node(start, {
      kind: Kind.SCHEMA_EXTENSION,
      directives,
      operationTypes
    });
  }
  /**
   * ScalarTypeExtension :
   *   - extend scalar Name Directives[Const]
   */
  parseScalarTypeExtension() {
    const start = this._lexer.token;
    this.expectKeyword("extend");
    this.expectKeyword("scalar");
    const name = this.parseName();
    const directives = this.parseConstDirectives();
    if (directives.length === 0) {
      throw this.unexpected();
    }
    return this.node(start, {
      kind: Kind.SCALAR_TYPE_EXTENSION,
      name,
      directives
    });
  }
  /**
   * ObjectTypeExtension :
   *  - extend type Name ImplementsInterfaces? Directives[Const]? FieldsDefinition
   *  - extend type Name ImplementsInterfaces? Directives[Const]
   *  - extend type Name ImplementsInterfaces
   */
  parseObjectTypeExtension() {
    const start = this._lexer.token;
    this.expectKeyword("extend");
    this.expectKeyword("type");
    const name = this.parseName();
    const interfaces = this.parseImplementsInterfaces();
    const directives = this.parseConstDirectives();
    const fields = this.parseFieldsDefinition();
    if (interfaces.length === 0 && directives.length === 0 && fields.length === 0) {
      throw this.unexpected();
    }
    return this.node(start, {
      kind: Kind.OBJECT_TYPE_EXTENSION,
      name,
      interfaces,
      directives,
      fields
    });
  }
  /**
   * InterfaceTypeExtension :
   *  - extend interface Name ImplementsInterfaces? Directives[Const]? FieldsDefinition
   *  - extend interface Name ImplementsInterfaces? Directives[Const]
   *  - extend interface Name ImplementsInterfaces
   */
  parseInterfaceTypeExtension() {
    const start = this._lexer.token;
    this.expectKeyword("extend");
    this.expectKeyword("interface");
    const name = this.parseName();
    const interfaces = this.parseImplementsInterfaces();
    const directives = this.parseConstDirectives();
    const fields = this.parseFieldsDefinition();
    if (interfaces.length === 0 && directives.length === 0 && fields.length === 0) {
      throw this.unexpected();
    }
    return this.node(start, {
      kind: Kind.INTERFACE_TYPE_EXTENSION,
      name,
      interfaces,
      directives,
      fields
    });
  }
  /**
   * UnionTypeExtension :
   *   - extend union Name Directives[Const]? UnionMemberTypes
   *   - extend union Name Directives[Const]
   */
  parseUnionTypeExtension() {
    const start = this._lexer.token;
    this.expectKeyword("extend");
    this.expectKeyword("union");
    const name = this.parseName();
    const directives = this.parseConstDirectives();
    const types = this.parseUnionMemberTypes();
    if (directives.length === 0 && types.length === 0) {
      throw this.unexpected();
    }
    return this.node(start, {
      kind: Kind.UNION_TYPE_EXTENSION,
      name,
      directives,
      types
    });
  }
  /**
   * EnumTypeExtension :
   *   - extend enum Name Directives[Const]? EnumValuesDefinition
   *   - extend enum Name Directives[Const]
   */
  parseEnumTypeExtension() {
    const start = this._lexer.token;
    this.expectKeyword("extend");
    this.expectKeyword("enum");
    const name = this.parseName();
    const directives = this.parseConstDirectives();
    const values = this.parseEnumValuesDefinition();
    if (directives.length === 0 && values.length === 0) {
      throw this.unexpected();
    }
    return this.node(start, {
      kind: Kind.ENUM_TYPE_EXTENSION,
      name,
      directives,
      values
    });
  }
  /**
   * InputObjectTypeExtension :
   *   - extend input Name Directives[Const]? InputFieldsDefinition
   *   - extend input Name Directives[Const]
   */
  parseInputObjectTypeExtension() {
    const start = this._lexer.token;
    this.expectKeyword("extend");
    this.expectKeyword("input");
    const name = this.parseName();
    const directives = this.parseConstDirectives();
    const fields = this.parseInputFieldsDefinition();
    if (directives.length === 0 && fields.length === 0) {
      throw this.unexpected();
    }
    return this.node(start, {
      kind: Kind.INPUT_OBJECT_TYPE_EXTENSION,
      name,
      directives,
      fields
    });
  }
  /**
   * ```
   * DirectiveDefinition :
   *   - Description? directive @ Name ArgumentsDefinition? `repeatable`? on DirectiveLocations
   * ```
   */
  parseDirectiveDefinition() {
    const start = this._lexer.token;
    const description = this.parseDescription();
    this.expectKeyword("directive");
    this.expectToken(TokenKind.AT);
    const name = this.parseName();
    const args = this.parseArgumentDefs();
    const repeatable = this.expectOptionalKeyword("repeatable");
    this.expectKeyword("on");
    const locations = this.parseDirectiveLocations();
    return this.node(start, {
      kind: Kind.DIRECTIVE_DEFINITION,
      description,
      name,
      arguments: args,
      repeatable,
      locations
    });
  }
  /**
   * DirectiveLocations :
   *   - `|`? DirectiveLocation
   *   - DirectiveLocations | DirectiveLocation
   */
  parseDirectiveLocations() {
    return this.delimitedMany(TokenKind.PIPE, this.parseDirectiveLocation);
  }
  /*
   * DirectiveLocation :
   *   - ExecutableDirectiveLocation
   *   - TypeSystemDirectiveLocation
   *
   * ExecutableDirectiveLocation : one of
   *   `QUERY`
   *   `MUTATION`
   *   `SUBSCRIPTION`
   *   `FIELD`
   *   `FRAGMENT_DEFINITION`
   *   `FRAGMENT_SPREAD`
   *   `INLINE_FRAGMENT`
   *
   * TypeSystemDirectiveLocation : one of
   *   `SCHEMA`
   *   `SCALAR`
   *   `OBJECT`
   *   `FIELD_DEFINITION`
   *   `ARGUMENT_DEFINITION`
   *   `INTERFACE`
   *   `UNION`
   *   `ENUM`
   *   `ENUM_VALUE`
   *   `INPUT_OBJECT`
   *   `INPUT_FIELD_DEFINITION`
   */
  parseDirectiveLocation() {
    const start = this._lexer.token;
    const name = this.parseName();
    if (Object.prototype.hasOwnProperty.call(DirectiveLocation, name.value)) {
      return name;
    }
    throw this.unexpected(start);
  }
  // Core parsing utility functions
  /**
   * Returns a node that, if configured to do so, sets a "loc" field as a
   * location object, used to identify the place in the source that created a
   * given parsed object.
   */
  node(startToken, node) {
    if (this._options.noLocation !== true) {
      node.loc = new Location(
        startToken,
        this._lexer.lastToken,
        this._lexer.source
      );
    }
    return node;
  }
  /**
   * Determines if the next token is of a given kind
   */
  peek(kind) {
    return this._lexer.token.kind === kind;
  }
  /**
   * If the next token is of the given kind, return that token after advancing the lexer.
   * Otherwise, do not change the parser state and throw an error.
   */
  expectToken(kind) {
    const token = this._lexer.token;
    if (token.kind === kind) {
      this.advanceLexer();
      return token;
    }
    throw syntaxError(
      this._lexer.source,
      token.start,
      `Expected ${getTokenKindDesc(kind)}, found ${getTokenDesc(token)}.`
    );
  }
  /**
   * If the next token is of the given kind, return "true" after advancing the lexer.
   * Otherwise, do not change the parser state and return "false".
   */
  expectOptionalToken(kind) {
    const token = this._lexer.token;
    if (token.kind === kind) {
      this.advanceLexer();
      return true;
    }
    return false;
  }
  /**
   * If the next token is a given keyword, advance the lexer.
   * Otherwise, do not change the parser state and throw an error.
   */
  expectKeyword(value) {
    const token = this._lexer.token;
    if (token.kind === TokenKind.NAME && token.value === value) {
      this.advanceLexer();
    } else {
      throw syntaxError(
        this._lexer.source,
        token.start,
        `Expected "${value}", found ${getTokenDesc(token)}.`
      );
    }
  }
  /**
   * If the next token is a given keyword, return "true" after advancing the lexer.
   * Otherwise, do not change the parser state and return "false".
   */
  expectOptionalKeyword(value) {
    const token = this._lexer.token;
    if (token.kind === TokenKind.NAME && token.value === value) {
      this.advanceLexer();
      return true;
    }
    return false;
  }
  /**
   * Helper function for creating an error when an unexpected lexed token is encountered.
   */
  unexpected(atToken) {
    const token = atToken !== null && atToken !== void 0 ? atToken : this._lexer.token;
    return syntaxError(
      this._lexer.source,
      token.start,
      `Unexpected ${getTokenDesc(token)}.`
    );
  }
  /**
   * Returns a possibly empty list of parse nodes, determined by the parseFn.
   * This list begins with a lex token of openKind and ends with a lex token of closeKind.
   * Advances the parser to the next lex token after the closing token.
   */
  any(openKind, parseFn, closeKind) {
    this.expectToken(openKind);
    const nodes = [];
    while (!this.expectOptionalToken(closeKind)) {
      nodes.push(parseFn.call(this));
    }
    return nodes;
  }
  /**
   * Returns a list of parse nodes, determined by the parseFn.
   * It can be empty only if open token is missing otherwise it will always return non-empty list
   * that begins with a lex token of openKind and ends with a lex token of closeKind.
   * Advances the parser to the next lex token after the closing token.
   */
  optionalMany(openKind, parseFn, closeKind) {
    if (this.expectOptionalToken(openKind)) {
      const nodes = [];
      do {
        nodes.push(parseFn.call(this));
      } while (!this.expectOptionalToken(closeKind));
      return nodes;
    }
    return [];
  }
  /**
   * Returns a non-empty list of parse nodes, determined by the parseFn.
   * This list begins with a lex token of openKind and ends with a lex token of closeKind.
   * Advances the parser to the next lex token after the closing token.
   */
  many(openKind, parseFn, closeKind) {
    this.expectToken(openKind);
    const nodes = [];
    do {
      nodes.push(parseFn.call(this));
    } while (!this.expectOptionalToken(closeKind));
    return nodes;
  }
  /**
   * Returns a non-empty list of parse nodes, determined by the parseFn.
   * This list may begin with a lex token of delimiterKind followed by items separated by lex tokens of tokenKind.
   * Advances the parser to the next lex token after last item in the list.
   */
  delimitedMany(delimiterKind, parseFn) {
    this.expectOptionalToken(delimiterKind);
    const nodes = [];
    do {
      nodes.push(parseFn.call(this));
    } while (this.expectOptionalToken(delimiterKind));
    return nodes;
  }
  advanceLexer() {
    const { maxTokens } = this._options;
    const token = this._lexer.advance();
    if (maxTokens !== void 0 && token.kind !== TokenKind.EOF) {
      ++this._tokenCounter;
      if (this._tokenCounter > maxTokens) {
        throw syntaxError(
          this._lexer.source,
          token.start,
          `Document contains more that ${maxTokens} tokens. Parsing aborted.`
        );
      }
    }
  }
};
function getTokenDesc(token) {
  const value = token.value;
  return getTokenKindDesc(token.kind) + (value != null ? ` "${value}"` : "");
}
function getTokenKindDesc(kind) {
  return isPunctuatorTokenKind(kind) ? `"${kind}"` : kind;
}
var MAX_SUGGESTIONS = 5;
function didYouMean(firstArg, secondArg) {
  const [subMessage, suggestionsArg] = secondArg ? [firstArg, secondArg] : [void 0, firstArg];
  let message3 = " Did you mean ";
  if (subMessage) {
    message3 += subMessage + " ";
  }
  const suggestions = suggestionsArg.map((x) => `"${x}"`);
  switch (suggestions.length) {
    case 0:
      return "";
    case 1:
      return message3 + suggestions[0] + "?";
    case 2:
      return message3 + suggestions[0] + " or " + suggestions[1] + "?";
  }
  const selected = suggestions.slice(0, MAX_SUGGESTIONS);
  const lastItem = selected.pop();
  return message3 + selected.join(", ") + ", or " + lastItem + "?";
}
function identityFunc(x) {
  return x;
}
function keyMap(list, keyFn) {
  const result = /* @__PURE__ */ Object.create(null);
  for (const item of list) {
    result[keyFn(item)] = item;
  }
  return result;
}
function keyValMap(list, keyFn, valFn) {
  const result = /* @__PURE__ */ Object.create(null);
  for (const item of list) {
    result[keyFn(item)] = valFn(item);
  }
  return result;
}
function mapValue(map, fn) {
  const result = /* @__PURE__ */ Object.create(null);
  for (const key of Object.keys(map)) {
    result[key] = fn(map[key], key);
  }
  return result;
}
function naturalCompare(aStr, bStr) {
  let aIndex = 0;
  let bIndex = 0;
  while (aIndex < aStr.length && bIndex < bStr.length) {
    let aChar = aStr.charCodeAt(aIndex);
    let bChar = bStr.charCodeAt(bIndex);
    if (isDigit2(aChar) && isDigit2(bChar)) {
      let aNum = 0;
      do {
        ++aIndex;
        aNum = aNum * 10 + aChar - DIGIT_0;
        aChar = aStr.charCodeAt(aIndex);
      } while (isDigit2(aChar) && aNum > 0);
      let bNum = 0;
      do {
        ++bIndex;
        bNum = bNum * 10 + bChar - DIGIT_0;
        bChar = bStr.charCodeAt(bIndex);
      } while (isDigit2(bChar) && bNum > 0);
      if (aNum < bNum) {
        return -1;
      }
      if (aNum > bNum) {
        return 1;
      }
    } else {
      if (aChar < bChar) {
        return -1;
      }
      if (aChar > bChar) {
        return 1;
      }
      ++aIndex;
      ++bIndex;
    }
  }
  return aStr.length - bStr.length;
}
var DIGIT_0 = 48;
var DIGIT_9 = 57;
function isDigit2(code) {
  return !isNaN(code) && DIGIT_0 <= code && code <= DIGIT_9;
}
function suggestionList(input, options) {
  const optionsByDistance = /* @__PURE__ */ Object.create(null);
  const lexicalDistance = new LexicalDistance(input);
  const threshold = Math.floor(input.length * 0.4) + 1;
  for (const option of options) {
    const distance = lexicalDistance.measure(option, threshold);
    if (distance !== void 0) {
      optionsByDistance[option] = distance;
    }
  }
  return Object.keys(optionsByDistance).sort((a, b) => {
    const distanceDiff = optionsByDistance[a] - optionsByDistance[b];
    return distanceDiff !== 0 ? distanceDiff : naturalCompare(a, b);
  });
}
var LexicalDistance = class {
  constructor(input) {
    this._input = input;
    this._inputLowerCase = input.toLowerCase();
    this._inputArray = stringToArray(this._inputLowerCase);
    this._rows = [
      new Array(input.length + 1).fill(0),
      new Array(input.length + 1).fill(0),
      new Array(input.length + 1).fill(0)
    ];
  }
  measure(option, threshold) {
    if (this._input === option) {
      return 0;
    }
    const optionLowerCase = option.toLowerCase();
    if (this._inputLowerCase === optionLowerCase) {
      return 1;
    }
    let a = stringToArray(optionLowerCase);
    let b = this._inputArray;
    if (a.length < b.length) {
      const tmp = a;
      a = b;
      b = tmp;
    }
    const aLength = a.length;
    const bLength = b.length;
    if (aLength - bLength > threshold) {
      return void 0;
    }
    const rows = this._rows;
    for (let j = 0; j <= bLength; j++) {
      rows[0][j] = j;
    }
    for (let i = 1; i <= aLength; i++) {
      const upRow = rows[(i - 1) % 3];
      const currentRow = rows[i % 3];
      let smallestCell = currentRow[0] = i;
      for (let j = 1; j <= bLength; j++) {
        const cost = a[i - 1] === b[j - 1] ? 0 : 1;
        let currentCell = Math.min(
          upRow[j] + 1,
          // delete
          currentRow[j - 1] + 1,
          // insert
          upRow[j - 1] + cost
          // substitute
        );
        if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) {
          const doubleDiagonalCell = rows[(i - 2) % 3][j - 2];
          currentCell = Math.min(currentCell, doubleDiagonalCell + 1);
        }
        if (currentCell < smallestCell) {
          smallestCell = currentCell;
        }
        currentRow[j] = currentCell;
      }
      if (smallestCell > threshold) {
        return void 0;
      }
    }
    const distance = rows[aLength % 3][bLength];
    return distance <= threshold ? distance : void 0;
  }
};
function stringToArray(str) {
  const strLength = str.length;
  const array = new Array(strLength);
  for (let i = 0; i < strLength; ++i) {
    array[i] = str.charCodeAt(i);
  }
  return array;
}
function toObjMap(obj) {
  if (obj == null) {
    return /* @__PURE__ */ Object.create(null);
  }
  if (Object.getPrototypeOf(obj) === null) {
    return obj;
  }
  const map = /* @__PURE__ */ Object.create(null);
  for (const [key, value] of Object.entries(obj)) {
    map[key] = value;
  }
  return map;
}
function printString(str) {
  return `"${str.replace(escapedRegExp, escapedReplacer)}"`;
}
var escapedRegExp = /[\x00-\x1f\x22\x5c\x7f-\x9f]/g;
function escapedReplacer(str) {
  return escapeSequences[str.charCodeAt(0)];
}
var escapeSequences = [
  "\\u0000",
  "\\u0001",
  "\\u0002",
  "\\u0003",
  "\\u0004",
  "\\u0005",
  "\\u0006",
  "\\u0007",
  "\\b",
  "\\t",
  "\\n",
  "\\u000B",
  "\\f",
  "\\r",
  "\\u000E",
  "\\u000F",
  "\\u0010",
  "\\u0011",
  "\\u0012",
  "\\u0013",
  "\\u0014",
  "\\u0015",
  "\\u0016",
  "\\u0017",
  "\\u0018",
  "\\u0019",
  "\\u001A",
  "\\u001B",
  "\\u001C",
  "\\u001D",
  "\\u001E",
  "\\u001F",
  "",
  "",
  '\\"',
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  // 2F
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  // 3F
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  // 4F
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "\\\\",
  "",
  "",
  "",
  // 5F
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  // 6F
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "\\u007F",
  "\\u0080",
  "\\u0081",
  "\\u0082",
  "\\u0083",
  "\\u0084",
  "\\u0085",
  "\\u0086",
  "\\u0087",
  "\\u0088",
  "\\u0089",
  "\\u008A",
  "\\u008B",
  "\\u008C",
  "\\u008D",
  "\\u008E",
  "\\u008F",
  "\\u0090",
  "\\u0091",
  "\\u0092",
  "\\u0093",
  "\\u0094",
  "\\u0095",
  "\\u0096",
  "\\u0097",
  "\\u0098",
  "\\u0099",
  "\\u009A",
  "\\u009B",
  "\\u009C",
  "\\u009D",
  "\\u009E",
  "\\u009F"
];
var BREAK = Object.freeze({});
function visit(root, visitor, visitorKeys = QueryDocumentKeys) {
  const enterLeaveMap = /* @__PURE__ */ new Map();
  for (const kind of Object.values(Kind)) {
    enterLeaveMap.set(kind, getEnterLeaveForKind(visitor, kind));
  }
  let stack = void 0;
  let inArray = Array.isArray(root);
  let keys = [root];
  let index = -1;
  let edits = [];
  let node = root;
  let key = void 0;
  let parent = void 0;
  const path = [];
  const ancestors = [];
  do {
    index++;
    const isLeaving = index === keys.length;
    const isEdited = isLeaving && edits.length !== 0;
    if (isLeaving) {
      key = ancestors.length === 0 ? void 0 : path[path.length - 1];
      node = parent;
      parent = ancestors.pop();
      if (isEdited) {
        if (inArray) {
          node = node.slice();
          let editOffset = 0;
          for (const [editKey, editValue] of edits) {
            const arrayKey = editKey - editOffset;
            if (editValue === null) {
              node.splice(arrayKey, 1);
              editOffset++;
            } else {
              node[arrayKey] = editValue;
            }
          }
        } else {
          node = Object.defineProperties(
            {},
            Object.getOwnPropertyDescriptors(node)
          );
          for (const [editKey, editValue] of edits) {
            node[editKey] = editValue;
          }
        }
      }
      index = stack.index;
      keys = stack.keys;
      edits = stack.edits;
      inArray = stack.inArray;
      stack = stack.prev;
    } else if (parent) {
      key = inArray ? index : keys[index];
      node = parent[key];
      if (node === null || node === void 0) {
        continue;
      }
      path.push(key);
    }
    let result;
    if (!Array.isArray(node)) {
      var _enterLeaveMap$get, _enterLeaveMap$get2;
      isNode(node) || devAssert(false, `Invalid AST Node: ${inspect(node)}.`);
      const visitFn = isLeaving ? (_enterLeaveMap$get = enterLeaveMap.get(node.kind)) === null || _enterLeaveMap$get === void 0 ? void 0 : _enterLeaveMap$get.leave : (_enterLeaveMap$get2 = enterLeaveMap.get(node.kind)) === null || _enterLeaveMap$get2 === void 0 ? void 0 : _enterLeaveMap$get2.enter;
      result = visitFn === null || visitFn === void 0 ? void 0 : visitFn.call(visitor, node, key, parent, path, ancestors);
      if (result === BREAK) {
        break;
      }
      if (result === false) {
        if (!isLeaving) {
          path.pop();
          continue;
        }
      } else if (result !== void 0) {
        edits.push([key, result]);
        if (!isLeaving) {
          if (isNode(result)) {
            node = result;
          } else {
            path.pop();
            continue;
          }
        }
      }
    }
    if (result === void 0 && isEdited) {
      edits.push([key, node]);
    }
    if (isLeaving) {
      path.pop();
    } else {
      var _node$kind;
      stack = {
        inArray,
        index,
        keys,
        edits,
        prev: stack
      };
      inArray = Array.isArray(node);
      keys = inArray ? node : (_node$kind = visitorKeys[node.kind]) !== null && _node$kind !== void 0 ? _node$kind : [];
      index = -1;
      edits = [];
      if (parent) {
        ancestors.push(parent);
      }
      parent = node;
    }
  } while (stack !== void 0);
  if (edits.length !== 0) {
    return edits[edits.length - 1][1];
  }
  return root;
}
function getEnterLeaveForKind(visitor, kind) {
  const kindVisitor = visitor[kind];
  if (typeof kindVisitor === "object") {
    return kindVisitor;
  } else if (typeof kindVisitor === "function") {
    return {
      enter: kindVisitor,
      leave: void 0
    };
  }
  return {
    enter: visitor.enter,
    leave: visitor.leave
  };
}
function print(ast) {
  return visit(ast, printDocASTReducer);
}
var MAX_LINE_LENGTH = 80;
var printDocASTReducer = {
  Name: {
    leave: (node) => node.value
  },
  Variable: {
    leave: (node) => "$" + node.name
  },
  // Document
  Document: {
    leave: (node) => join(node.definitions, "\n\n")
  },
  OperationDefinition: {
    leave(node) {
      const varDefs = wrap("(", join(node.variableDefinitions, ", "), ")");
      const prefix = join(
        [
          node.operation,
          join([node.name, varDefs]),
          join(node.directives, " ")
        ],
        " "
      );
      return (prefix === "query" ? "" : prefix + " ") + node.selectionSet;
    }
  },
  VariableDefinition: {
    leave: ({ variable, type, defaultValue, directives }) => variable + ": " + type + wrap(" = ", defaultValue) + wrap(" ", join(directives, " "))
  },
  SelectionSet: {
    leave: ({ selections }) => block(selections)
  },
  Field: {
    leave({ alias, name, arguments: args, directives, selectionSet }) {
      const prefix = wrap("", alias, ": ") + name;
      let argsLine = prefix + wrap("(", join(args, ", "), ")");
      if (argsLine.length > MAX_LINE_LENGTH) {
        argsLine = prefix + wrap("(\n", indent(join(args, "\n")), "\n)");
      }
      return join([argsLine, join(directives, " "), selectionSet], " ");
    }
  },
  Argument: {
    leave: ({ name, value }) => name + ": " + value
  },
  // Fragments
  FragmentSpread: {
    leave: ({ name, directives }) => "..." + name + wrap(" ", join(directives, " "))
  },
  InlineFragment: {
    leave: ({ typeCondition, directives, selectionSet }) => join(
      [
        "...",
        wrap("on ", typeCondition),
        join(directives, " "),
        selectionSet
      ],
      " "
    )
  },
  FragmentDefinition: {
    leave: ({ name, typeCondition, variableDefinitions, directives, selectionSet }) => (
      // or removed in the future.
      `fragment ${name}${wrap("(", join(variableDefinitions, ", "), ")")} on ${typeCondition} ${wrap("", join(directives, " "), " ")}` + selectionSet
    )
  },
  // Value
  IntValue: {
    leave: ({ value }) => value
  },
  FloatValue: {
    leave: ({ value }) => value
  },
  StringValue: {
    leave: ({ value, block: isBlockString }) => isBlockString ? printBlockString(value) : printString(value)
  },
  BooleanValue: {
    leave: ({ value }) => value ? "true" : "false"
  },
  NullValue: {
    leave: () => "null"
  },
  EnumValue: {
    leave: ({ value }) => value
  },
  ListValue: {
    leave: ({ values }) => "[" + join(values, ", ") + "]"
  },
  ObjectValue: {
    leave: ({ fields }) => "{" + join(fields, ", ") + "}"
  },
  ObjectField: {
    leave: ({ name, value }) => name + ": " + value
  },
  // Directive
  Directive: {
    leave: ({ name, arguments: args }) => "@" + name + wrap("(", join(args, ", "), ")")
  },
  // Type
  NamedType: {
    leave: ({ name }) => name
  },
  ListType: {
    leave: ({ type }) => "[" + type + "]"
  },
  NonNullType: {
    leave: ({ type }) => type + "!"
  },
  // Type System Definitions
  SchemaDefinition: {
    leave: ({ description, directives, operationTypes }) => wrap("", description, "\n") + join(["schema", join(directives, " "), block(operationTypes)], " ")
  },
  OperationTypeDefinition: {
    leave: ({ operation, type }) => operation + ": " + type
  },
  ScalarTypeDefinition: {
    leave: ({ description, name, directives }) => wrap("", description, "\n") + join(["scalar", name, join(directives, " ")], " ")
  },
  ObjectTypeDefinition: {
    leave: ({ description, name, interfaces, directives, fields }) => wrap("", description, "\n") + join(
      [
        "type",
        name,
        wrap("implements ", join(interfaces, " & ")),
        join(directives, " "),
        block(fields)
      ],
      " "
    )
  },
  FieldDefinition: {
    leave: ({ description, name, arguments: args, type, directives }) => wrap("", description, "\n") + name + (hasMultilineItems(args) ? wrap("(\n", indent(join(args, "\n")), "\n)") : wrap("(", join(args, ", "), ")")) + ": " + type + wrap(" ", join(directives, " "))
  },
  InputValueDefinition: {
    leave: ({ description, name, type, defaultValue, directives }) => wrap("", description, "\n") + join(
      [name + ": " + type, wrap("= ", defaultValue), join(directives, " ")],
      " "
    )
  },
  InterfaceTypeDefinition: {
    leave: ({ description, name, interfaces, directives, fields }) => wrap("", description, "\n") + join(
      [
        "interface",
        name,
        wrap("implements ", join(interfaces, " & ")),
        join(directives, " "),
        block(fields)
      ],
      " "
    )
  },
  UnionTypeDefinition: {
    leave: ({ description, name, directives, types }) => wrap("", description, "\n") + join(
      ["union", name, join(directives, " "), wrap("= ", join(types, " | "))],
      " "
    )
  },
  EnumTypeDefinition: {
    leave: ({ description, name, directives, values }) => wrap("", description, "\n") + join(["enum", name, join(directives, " "), block(values)], " ")
  },
  EnumValueDefinition: {
    leave: ({ description, name, directives }) => wrap("", description, "\n") + join([name, join(directives, " ")], " ")
  },
  InputObjectTypeDefinition: {
    leave: ({ description, name, directives, fields }) => wrap("", description, "\n") + join(["input", name, join(directives, " "), block(fields)], " ")
  },
  DirectiveDefinition: {
    leave: ({ description, name, arguments: args, repeatable, locations }) => wrap("", description, "\n") + "directive @" + name + (hasMultilineItems(args) ? wrap("(\n", indent(join(args, "\n")), "\n)") : wrap("(", join(args, ", "), ")")) + (repeatable ? " repeatable" : "") + " on " + join(locations, " | ")
  },
  SchemaExtension: {
    leave: ({ directives, operationTypes }) => join(
      ["extend schema", join(directives, " "), block(operationTypes)],
      " "
    )
  },
  ScalarTypeExtension: {
    leave: ({ name, directives }) => join(["extend scalar", name, join(directives, " ")], " ")
  },
  ObjectTypeExtension: {
    leave: ({ name, interfaces, directives, fields }) => join(
      [
        "extend type",
        name,
        wrap("implements ", join(interfaces, " & ")),
        join(directives, " "),
        block(fields)
      ],
      " "
    )
  },
  InterfaceTypeExtension: {
    leave: ({ name, interfaces, directives, fields }) => join(
      [
        "extend interface",
        name,
        wrap("implements ", join(interfaces, " & ")),
        join(directives, " "),
        block(fields)
      ],
      " "
    )
  },
  UnionTypeExtension: {
    leave: ({ name, directives, types }) => join(
      [
        "extend union",
        name,
        join(directives, " "),
        wrap("= ", join(types, " | "))
      ],
      " "
    )
  },
  EnumTypeExtension: {
    leave: ({ name, directives, values }) => join(["extend enum", name, join(directives, " "), block(values)], " ")
  },
  InputObjectTypeExtension: {
    leave: ({ name, directives, fields }) => join(["extend input", name, join(directives, " "), block(fields)], " ")
  }
};
function join(maybeArray, separator = "") {
  var _maybeArray$filter$jo;
  return (_maybeArray$filter$jo = maybeArray === null || maybeArray === void 0 ? void 0 : maybeArray.filter((x) => x).join(separator)) !== null && _maybeArray$filter$jo !== void 0 ? _maybeArray$filter$jo : "";
}
function block(array) {
  return wrap("{\n", indent(join(array, "\n")), "\n}");
}
function wrap(start, maybeString, end = "") {
  return maybeString != null && maybeString !== "" ? start + maybeString + end : "";
}
function indent(str) {
  return wrap("  ", str.replace(/\n/g, "\n  "));
}
function hasMultilineItems(maybeArray) {
  var _maybeArray$some;
  return (_maybeArray$some = maybeArray === null || maybeArray === void 0 ? void 0 : maybeArray.some((str) => str.includes("\n"))) !== null && _maybeArray$some !== void 0 ? _maybeArray$some : false;
}
function valueFromASTUntyped(valueNode, variables) {
  switch (valueNode.kind) {
    case Kind.NULL:
      return null;
    case Kind.INT:
      return parseInt(valueNode.value, 10);
    case Kind.FLOAT:
      return parseFloat(valueNode.value);
    case Kind.STRING:
    case Kind.ENUM:
    case Kind.BOOLEAN:
      return valueNode.value;
    case Kind.LIST:
      return valueNode.values.map(
        (node) => valueFromASTUntyped(node, variables)
      );
    case Kind.OBJECT:
      return keyValMap(
        valueNode.fields,
        (field) => field.name.value,
        (field) => valueFromASTUntyped(field.value, variables)
      );
    case Kind.VARIABLE:
      return variables === null || variables === void 0 ? void 0 : variables[valueNode.name.value];
  }
}
function assertName(name) {
  name != null || devAssert(false, "Must provide name.");
  typeof name === "string" || devAssert(false, "Expected name to be a string.");
  if (name.length === 0) {
    throw new GraphQLError("Expected name to be a non-empty string.");
  }
  for (let i = 1; i < name.length; ++i) {
    if (!isNameContinue(name.charCodeAt(i))) {
      throw new GraphQLError(
        `Names must only contain [_a-zA-Z0-9] but "${name}" does not.`
      );
    }
  }
  if (!isNameStart(name.charCodeAt(0))) {
    throw new GraphQLError(
      `Names must start with [_a-zA-Z] but "${name}" does not.`
    );
  }
  return name;
}
function assertEnumValueName(name) {
  if (name === "true" || name === "false" || name === "null") {
    throw new GraphQLError(`Enum values cannot be named: ${name}`);
  }
  return assertName(name);
}
function isType(type) {
  return isScalarType(type) || isObjectType(type) || isInterfaceType(type) || isUnionType(type) || isEnumType(type) || isInputObjectType(type) || isListType(type) || isNonNullType(type);
}
function isScalarType(type) {
  return instanceOf(type, GraphQLScalarType);
}
function isObjectType(type) {
  return instanceOf(type, GraphQLObjectType);
}
function isInterfaceType(type) {
  return instanceOf(type, GraphQLInterfaceType);
}
function isUnionType(type) {
  return instanceOf(type, GraphQLUnionType);
}
function isEnumType(type) {
  return instanceOf(type, GraphQLEnumType);
}
function isInputObjectType(type) {
  return instanceOf(type, GraphQLInputObjectType);
}
function isListType(type) {
  return instanceOf(type, GraphQLList);
}
function isNonNullType(type) {
  return instanceOf(type, GraphQLNonNull);
}
function isInputType(type) {
  return isScalarType(type) || isEnumType(type) || isInputObjectType(type) || isWrappingType(type) && isInputType(type.ofType);
}
function isLeafType(type) {
  return isScalarType(type) || isEnumType(type);
}
function isCompositeType(type) {
  return isObjectType(type) || isInterfaceType(type) || isUnionType(type);
}
function isAbstractType(type) {
  return isInterfaceType(type) || isUnionType(type);
}
var GraphQLList = class {
  constructor(ofType) {
    isType(ofType) || devAssert(false, `Expected ${inspect(ofType)} to be a GraphQL type.`);
    this.ofType = ofType;
  }
  get [Symbol.toStringTag]() {
    return "GraphQLList";
  }
  toString() {
    return "[" + String(this.ofType) + "]";
  }
  toJSON() {
    return this.toString();
  }
};
var GraphQLNonNull = class {
  constructor(ofType) {
    isNullableType(ofType) || devAssert(
      false,
      `Expected ${inspect(ofType)} to be a GraphQL nullable type.`
    );
    this.ofType = ofType;
  }
  get [Symbol.toStringTag]() {
    return "GraphQLNonNull";
  }
  toString() {
    return String(this.ofType) + "!";
  }
  toJSON() {
    return this.toString();
  }
};
function isWrappingType(type) {
  return isListType(type) || isNonNullType(type);
}
function isNullableType(type) {
  return isType(type) && !isNonNullType(type);
}
function getNullableType(type) {
  if (type) {
    return isNonNullType(type) ? type.ofType : type;
  }
}
function getNamedType(type) {
  if (type) {
    let unwrappedType = type;
    while (isWrappingType(unwrappedType)) {
      unwrappedType = unwrappedType.ofType;
    }
    return unwrappedType;
  }
}
function resolveReadonlyArrayThunk(thunk) {
  return typeof thunk === "function" ? thunk() : thunk;
}
function resolveObjMapThunk(thunk) {
  return typeof thunk === "function" ? thunk() : thunk;
}
var GraphQLScalarType = class {
  constructor(config) {
    var _config$parseValue, _config$serialize, _config$parseLiteral, _config$extensionASTN;
    const parseValue2 = (_config$parseValue = config.parseValue) !== null && _config$parseValue !== void 0 ? _config$parseValue : identityFunc;
    this.name = assertName(config.name);
    this.description = config.description;
    this.specifiedByURL = config.specifiedByURL;
    this.serialize = (_config$serialize = config.serialize) !== null && _config$serialize !== void 0 ? _config$serialize : identityFunc;
    this.parseValue = parseValue2;
    this.parseLiteral = (_config$parseLiteral = config.parseLiteral) !== null && _config$parseLiteral !== void 0 ? _config$parseLiteral : (node, variables) => parseValue2(valueFromASTUntyped(node, variables));
    this.extensions = toObjMap(config.extensions);
    this.astNode = config.astNode;
    this.extensionASTNodes = (_config$extensionASTN = config.extensionASTNodes) !== null && _config$extensionASTN !== void 0 ? _config$extensionASTN : [];
    config.specifiedByURL == null || typeof config.specifiedByURL === "string" || devAssert(
      false,
      `${this.name} must provide "specifiedByURL" as a string, but got: ${inspect(config.specifiedByURL)}.`
    );
    config.serialize == null || typeof config.serialize === "function" || devAssert(
      false,
      `${this.name} must provide "serialize" function. If this custom Scalar is also used as an input type, ensure "parseValue" and "parseLiteral" functions are also provided.`
    );
    if (config.parseLiteral) {
      typeof config.parseValue === "function" && typeof config.parseLiteral === "function" || devAssert(
        false,
        `${this.name} must provide both "parseValue" and "parseLiteral" functions.`
      );
    }
  }
  get [Symbol.toStringTag]() {
    return "GraphQLScalarType";
  }
  toConfig() {
    return {
      name: this.name,
      description: this.description,
      specifiedByURL: this.specifiedByURL,
      serialize: this.serialize,
      parseValue: this.parseValue,
      parseLiteral: this.parseLiteral,
      extensions: this.extensions,
      astNode: this.astNode,
      extensionASTNodes: this.extensionASTNodes
    };
  }
  toString() {
    return this.name;
  }
  toJSON() {
    return this.toString();
  }
};
var GraphQLObjectType = class {
  constructor(config) {
    var _config$extensionASTN2;
    this.name = assertName(config.name);
    this.description = config.description;
    this.isTypeOf = config.isTypeOf;
    this.extensions = toObjMap(config.extensions);
    this.astNode = config.astNode;
    this.extensionASTNodes = (_config$extensionASTN2 = config.extensionASTNodes) !== null && _config$extensionASTN2 !== void 0 ? _config$extensionASTN2 : [];
    this._fields = () => defineFieldMap(config);
    this._interfaces = () => defineInterfaces(config);
    config.isTypeOf == null || typeof config.isTypeOf === "function" || devAssert(
      false,
      `${this.name} must provide "isTypeOf" as a function, but got: ${inspect(config.isTypeOf)}.`
    );
  }
  get [Symbol.toStringTag]() {
    return "GraphQLObjectType";
  }
  getFields() {
    if (typeof this._fields === "function") {
      this._fields = this._fields();
    }
    return this._fields;
  }
  getInterfaces() {
    if (typeof this._interfaces === "function") {
      this._interfaces = this._interfaces();
    }
    return this._interfaces;
  }
  toConfig() {
    return {
      name: this.name,
      description: this.description,
      interfaces: this.getInterfaces(),
      fields: fieldsToFieldsConfig(this.getFields()),
      isTypeOf: this.isTypeOf,
      extensions: this.extensions,
      astNode: this.astNode,
      extensionASTNodes: this.extensionASTNodes
    };
  }
  toString() {
    return this.name;
  }
  toJSON() {
    return this.toString();
  }
};
function defineInterfaces(config) {
  var _config$interfaces;
  const interfaces = resolveReadonlyArrayThunk(
    (_config$interfaces = config.interfaces) !== null && _config$interfaces !== void 0 ? _config$interfaces : []
  );
  Array.isArray(interfaces) || devAssert(
    false,
    `${config.name} interfaces must be an Array or a function which returns an Array.`
  );
  return interfaces;
}
function defineFieldMap(config) {
  const fieldMap = resolveObjMapThunk(config.fields);
  isPlainObj(fieldMap) || devAssert(
    false,
    `${config.name} fields must be an object with field names as keys or a function which returns such an object.`
  );
  return mapValue(fieldMap, (fieldConfig, fieldName) => {
    var _fieldConfig$args;
    isPlainObj(fieldConfig) || devAssert(
      false,
      `${config.name}.${fieldName} field config must be an object.`
    );
    fieldConfig.resolve == null || typeof fieldConfig.resolve === "function" || devAssert(
      false,
      `${config.name}.${fieldName} field resolver must be a function if provided, but got: ${inspect(fieldConfig.resolve)}.`
    );
    const argsConfig = (_fieldConfig$args = fieldConfig.args) !== null && _fieldConfig$args !== void 0 ? _fieldConfig$args : {};
    isPlainObj(argsConfig) || devAssert(
      false,
      `${config.name}.${fieldName} args must be an object with argument names as keys.`
    );
    return {
      name: assertName(fieldName),
      description: fieldConfig.description,
      type: fieldConfig.type,
      args: defineArguments(argsConfig),
      resolve: fieldConfig.resolve,
      subscribe: fieldConfig.subscribe,
      deprecationReason: fieldConfig.deprecationReason,
      extensions: toObjMap(fieldConfig.extensions),
      astNode: fieldConfig.astNode
    };
  });
}
function defineArguments(config) {
  return Object.entries(config).map(([argName, argConfig]) => ({
    name: assertName(argName),
    description: argConfig.description,
    type: argConfig.type,
    defaultValue: argConfig.defaultValue,
    deprecationReason: argConfig.deprecationReason,
    extensions: toObjMap(argConfig.extensions),
    astNode: argConfig.astNode
  }));
}
function isPlainObj(obj) {
  return isObjectLike(obj) && !Array.isArray(obj);
}
function fieldsToFieldsConfig(fields) {
  return mapValue(fields, (field) => ({
    description: field.description,
    type: field.type,
    args: argsToArgsConfig(field.args),
    resolve: field.resolve,
    subscribe: field.subscribe,
    deprecationReason: field.deprecationReason,
    extensions: field.extensions,
    astNode: field.astNode
  }));
}
function argsToArgsConfig(args) {
  return keyValMap(
    args,
    (arg) => arg.name,
    (arg) => ({
      description: arg.description,
      type: arg.type,
      defaultValue: arg.defaultValue,
      deprecationReason: arg.deprecationReason,
      extensions: arg.extensions,
      astNode: arg.astNode
    })
  );
}
function isRequiredArgument(arg) {
  return isNonNullType(arg.type) && arg.defaultValue === void 0;
}
var GraphQLInterfaceType = class {
  constructor(config) {
    var _config$extensionASTN3;
    this.name = assertName(config.name);
    this.description = config.description;
    this.resolveType = config.resolveType;
    this.extensions = toObjMap(config.extensions);
    this.astNode = config.astNode;
    this.extensionASTNodes = (_config$extensionASTN3 = config.extensionASTNodes) !== null && _config$extensionASTN3 !== void 0 ? _config$extensionASTN3 : [];
    this._fields = defineFieldMap.bind(void 0, config);
    this._interfaces = defineInterfaces.bind(void 0, config);
    config.resolveType == null || typeof config.resolveType === "function" || devAssert(
      false,
      `${this.name} must provide "resolveType" as a function, but got: ${inspect(config.resolveType)}.`
    );
  }
  get [Symbol.toStringTag]() {
    return "GraphQLInterfaceType";
  }
  getFields() {
    if (typeof this._fields === "function") {
      this._fields = this._fields();
    }
    return this._fields;
  }
  getInterfaces() {
    if (typeof this._interfaces === "function") {
      this._interfaces = this._interfaces();
    }
    return this._interfaces;
  }
  toConfig() {
    return {
      name: this.name,
      description: this.description,
      interfaces: this.getInterfaces(),
      fields: fieldsToFieldsConfig(this.getFields()),
      resolveType: this.resolveType,
      extensions: this.extensions,
      astNode: this.astNode,
      extensionASTNodes: this.extensionASTNodes
    };
  }
  toString() {
    return this.name;
  }
  toJSON() {
    return this.toString();
  }
};
var GraphQLUnionType = class {
  constructor(config) {
    var _config$extensionASTN4;
    this.name = assertName(config.name);
    this.description = config.description;
    this.resolveType = config.resolveType;
    this.extensions = toObjMap(config.extensions);
    this.astNode = config.astNode;
    this.extensionASTNodes = (_config$extensionASTN4 = config.extensionASTNodes) !== null && _config$extensionASTN4 !== void 0 ? _config$extensionASTN4 : [];
    this._types = defineTypes.bind(void 0, config);
    config.resolveType == null || typeof config.resolveType === "function" || devAssert(
      false,
      `${this.name} must provide "resolveType" as a function, but got: ${inspect(config.resolveType)}.`
    );
  }
  get [Symbol.toStringTag]() {
    return "GraphQLUnionType";
  }
  getTypes() {
    if (typeof this._types === "function") {
      this._types = this._types();
    }
    return this._types;
  }
  toConfig() {
    return {
      name: this.name,
      description: this.description,
      types: this.getTypes(),
      resolveType: this.resolveType,
      extensions: this.extensions,
      astNode: this.astNode,
      extensionASTNodes: this.extensionASTNodes
    };
  }
  toString() {
    return this.name;
  }
  toJSON() {
    return this.toString();
  }
};
function defineTypes(config) {
  const types = resolveReadonlyArrayThunk(config.types);
  Array.isArray(types) || devAssert(
    false,
    `Must provide Array of types or a function which returns such an array for Union ${config.name}.`
  );
  return types;
}
var GraphQLEnumType = class {
  /* <T> */
  constructor(config) {
    var _config$extensionASTN5;
    this.name = assertName(config.name);
    this.description = config.description;
    this.extensions = toObjMap(config.extensions);
    this.astNode = config.astNode;
    this.extensionASTNodes = (_config$extensionASTN5 = config.extensionASTNodes) !== null && _config$extensionASTN5 !== void 0 ? _config$extensionASTN5 : [];
    this._values = defineEnumValues(this.name, config.values);
    this._valueLookup = new Map(
      this._values.map((enumValue) => [enumValue.value, enumValue])
    );
    this._nameLookup = keyMap(this._values, (value) => value.name);
  }
  get [Symbol.toStringTag]() {
    return "GraphQLEnumType";
  }
  getValues() {
    return this._values;
  }
  getValue(name) {
    return this._nameLookup[name];
  }
  serialize(outputValue) {
    const enumValue = this._valueLookup.get(outputValue);
    if (enumValue === void 0) {
      throw new GraphQLError(
        `Enum "${this.name}" cannot represent value: ${inspect(outputValue)}`
      );
    }
    return enumValue.name;
  }
  parseValue(inputValue) {
    if (typeof inputValue !== "string") {
      const valueStr = inspect(inputValue);
      throw new GraphQLError(
        `Enum "${this.name}" cannot represent non-string value: ${valueStr}.` + didYouMeanEnumValue(this, valueStr)
      );
    }
    const enumValue = this.getValue(inputValue);
    if (enumValue == null) {
      throw new GraphQLError(
        `Value "${inputValue}" does not exist in "${this.name}" enum.` + didYouMeanEnumValue(this, inputValue)
      );
    }
    return enumValue.value;
  }
  parseLiteral(valueNode, _variables) {
    if (valueNode.kind !== Kind.ENUM) {
      const valueStr = print(valueNode);
      throw new GraphQLError(
        `Enum "${this.name}" cannot represent non-enum value: ${valueStr}.` + didYouMeanEnumValue(this, valueStr),
        {
          nodes: valueNode
        }
      );
    }
    const enumValue = this.getValue(valueNode.value);
    if (enumValue == null) {
      const valueStr = print(valueNode);
      throw new GraphQLError(
        `Value "${valueStr}" does not exist in "${this.name}" enum.` + didYouMeanEnumValue(this, valueStr),
        {
          nodes: valueNode
        }
      );
    }
    return enumValue.value;
  }
  toConfig() {
    const values = keyValMap(
      this.getValues(),
      (value) => value.name,
      (value) => ({
        description: value.description,
        value: value.value,
        deprecationReason: value.deprecationReason,
        extensions: value.extensions,
        astNode: value.astNode
      })
    );
    return {
      name: this.name,
      description: this.description,
      values,
      extensions: this.extensions,
      astNode: this.astNode,
      extensionASTNodes: this.extensionASTNodes
    };
  }
  toString() {
    return this.name;
  }
  toJSON() {
    return this.toString();
  }
};
function didYouMeanEnumValue(enumType, unknownValueStr) {
  const allNames = enumType.getValues().map((value) => value.name);
  const suggestedValues = suggestionList(unknownValueStr, allNames);
  return didYouMean("the enum value", suggestedValues);
}
function defineEnumValues(typeName, valueMap) {
  isPlainObj(valueMap) || devAssert(
    false,
    `${typeName} values must be an object with value names as keys.`
  );
  return Object.entries(valueMap).map(([valueName, valueConfig]) => {
    isPlainObj(valueConfig) || devAssert(
      false,
      `${typeName}.${valueName} must refer to an object with a "value" key representing an internal value but got: ${inspect(valueConfig)}.`
    );
    return {
      name: assertEnumValueName(valueName),
      description: valueConfig.description,
      value: valueConfig.value !== void 0 ? valueConfig.value : valueName,
      deprecationReason: valueConfig.deprecationReason,
      extensions: toObjMap(valueConfig.extensions),
      astNode: valueConfig.astNode
    };
  });
}
var GraphQLInputObjectType = class {
  constructor(config) {
    var _config$extensionASTN6;
    this.name = assertName(config.name);
    this.description = config.description;
    this.extensions = toObjMap(config.extensions);
    this.astNode = config.astNode;
    this.extensionASTNodes = (_config$extensionASTN6 = config.extensionASTNodes) !== null && _config$extensionASTN6 !== void 0 ? _config$extensionASTN6 : [];
    this._fields = defineInputFieldMap.bind(void 0, config);
  }
  get [Symbol.toStringTag]() {
    return "GraphQLInputObjectType";
  }
  getFields() {
    if (typeof this._fields === "function") {
      this._fields = this._fields();
    }
    return this._fields;
  }
  toConfig() {
    const fields = mapValue(this.getFields(), (field) => ({
      description: field.description,
      type: field.type,
      defaultValue: field.defaultValue,
      deprecationReason: field.deprecationReason,
      extensions: field.extensions,
      astNode: field.astNode
    }));
    return {
      name: this.name,
      description: this.description,
      fields,
      extensions: this.extensions,
      astNode: this.astNode,
      extensionASTNodes: this.extensionASTNodes
    };
  }
  toString() {
    return this.name;
  }
  toJSON() {
    return this.toString();
  }
};
function defineInputFieldMap(config) {
  const fieldMap = resolveObjMapThunk(config.fields);
  isPlainObj(fieldMap) || devAssert(
    false,
    `${config.name} fields must be an object with field names as keys or a function which returns such an object.`
  );
  return mapValue(fieldMap, (fieldConfig, fieldName) => {
    !("resolve" in fieldConfig) || devAssert(
      false,
      `${config.name}.${fieldName} field has a resolve property, but Input Types cannot define resolvers.`
    );
    return {
      name: assertName(fieldName),
      description: fieldConfig.description,
      type: fieldConfig.type,
      defaultValue: fieldConfig.defaultValue,
      deprecationReason: fieldConfig.deprecationReason,
      extensions: toObjMap(fieldConfig.extensions),
      astNode: fieldConfig.astNode
    };
  });
}
function isRequiredInputField(field) {
  return isNonNullType(field.type) && field.defaultValue === void 0;
}
function isTypeSubTypeOf(schema, maybeSubType, superType) {
  if (maybeSubType === superType) {
    return true;
  }
  if (isNonNullType(superType)) {
    if (isNonNullType(maybeSubType)) {
      return isTypeSubTypeOf(schema, maybeSubType.ofType, superType.ofType);
    }
    return false;
  }
  if (isNonNullType(maybeSubType)) {
    return isTypeSubTypeOf(schema, maybeSubType.ofType, superType);
  }
  if (isListType(superType)) {
    if (isListType(maybeSubType)) {
      return isTypeSubTypeOf(schema, maybeSubType.ofType, superType.ofType);
    }
    return false;
  }
  if (isListType(maybeSubType)) {
    return false;
  }
  return isAbstractType(superType) && (isInterfaceType(maybeSubType) || isObjectType(maybeSubType)) && schema.isSubType(superType, maybeSubType);
}
function doTypesOverlap(schema, typeA, typeB) {
  if (typeA === typeB) {
    return true;
  }
  if (isAbstractType(typeA)) {
    if (isAbstractType(typeB)) {
      return schema.getPossibleTypes(typeA).some((type) => schema.isSubType(typeB, type));
    }
    return schema.isSubType(typeA, typeB);
  }
  if (isAbstractType(typeB)) {
    return schema.isSubType(typeB, typeA);
  }
  return false;
}
var GRAPHQL_MAX_INT = 2147483647;
var GRAPHQL_MIN_INT = -2147483648;
var GraphQLInt = new GraphQLScalarType({
  name: "Int",
  description: "The `Int` scalar type represents non-fractional signed whole numeric values. Int can represent values between -(2^31) and 2^31 - 1.",
  serialize(outputValue) {
    const coercedValue = serializeObject(outputValue);
    if (typeof coercedValue === "boolean") {
      return coercedValue ? 1 : 0;
    }
    let num = coercedValue;
    if (typeof coercedValue === "string" && coercedValue !== "") {
      num = Number(coercedValue);
    }
    if (typeof num !== "number" || !Number.isInteger(num)) {
      throw new GraphQLError(
        `Int cannot represent non-integer value: ${inspect(coercedValue)}`
      );
    }
    if (num > GRAPHQL_MAX_INT || num < GRAPHQL_MIN_INT) {
      throw new GraphQLError(
        "Int cannot represent non 32-bit signed integer value: " + inspect(coercedValue)
      );
    }
    return num;
  },
  parseValue(inputValue) {
    if (typeof inputValue !== "number" || !Number.isInteger(inputValue)) {
      throw new GraphQLError(
        `Int cannot represent non-integer value: ${inspect(inputValue)}`
      );
    }
    if (inputValue > GRAPHQL_MAX_INT || inputValue < GRAPHQL_MIN_INT) {
      throw new GraphQLError(
        `Int cannot represent non 32-bit signed integer value: ${inputValue}`
      );
    }
    return inputValue;
  },
  parseLiteral(valueNode) {
    if (valueNode.kind !== Kind.INT) {
      throw new GraphQLError(
        `Int cannot represent non-integer value: ${print(valueNode)}`,
        {
          nodes: valueNode
        }
      );
    }
    const num = parseInt(valueNode.value, 10);
    if (num > GRAPHQL_MAX_INT || num < GRAPHQL_MIN_INT) {
      throw new GraphQLError(
        `Int cannot represent non 32-bit signed integer value: ${valueNode.value}`,
        {
          nodes: valueNode
        }
      );
    }
    return num;
  }
});
var GraphQLFloat = new GraphQLScalarType({
  name: "Float",
  description: "The `Float` scalar type represents signed double-precision fractional values as specified by [IEEE 754](https://en.wikipedia.org/wiki/IEEE_floating_point).",
  serialize(outputValue) {
    const coercedValue = serializeObject(outputValue);
    if (typeof coercedValue === "boolean") {
      return coercedValue ? 1 : 0;
    }
    let num = coercedValue;
    if (typeof coercedValue === "string" && coercedValue !== "") {
      num = Number(coercedValue);
    }
    if (typeof num !== "number" || !Number.isFinite(num)) {
      throw new GraphQLError(
        `Float cannot represent non numeric value: ${inspect(coercedValue)}`
      );
    }
    return num;
  },
  parseValue(inputValue) {
    if (typeof inputValue !== "number" || !Number.isFinite(inputValue)) {
      throw new GraphQLError(
        `Float cannot represent non numeric value: ${inspect(inputValue)}`
      );
    }
    return inputValue;
  },
  parseLiteral(valueNode) {
    if (valueNode.kind !== Kind.FLOAT && valueNode.kind !== Kind.INT) {
      throw new GraphQLError(
        `Float cannot represent non numeric value: ${print(valueNode)}`,
        valueNode
      );
    }
    return parseFloat(valueNode.value);
  }
});
var GraphQLString = new GraphQLScalarType({
  name: "String",
  description: "The `String` scalar type represents textual data, represented as UTF-8 character sequences. The String type is most often used by GraphQL to represent free-form human-readable text.",
  serialize(outputValue) {
    const coercedValue = serializeObject(outputValue);
    if (typeof coercedValue === "string") {
      return coercedValue;
    }
    if (typeof coercedValue === "boolean") {
      return coercedValue ? "true" : "false";
    }
    if (typeof coercedValue === "number" && Number.isFinite(coercedValue)) {
      return coercedValue.toString();
    }
    throw new GraphQLError(
      `String cannot represent value: ${inspect(outputValue)}`
    );
  },
  parseValue(inputValue) {
    if (typeof inputValue !== "string") {
      throw new GraphQLError(
        `String cannot represent a non string value: ${inspect(inputValue)}`
      );
    }
    return inputValue;
  },
  parseLiteral(valueNode) {
    if (valueNode.kind !== Kind.STRING) {
      throw new GraphQLError(
        `String cannot represent a non string value: ${print(valueNode)}`,
        {
          nodes: valueNode
        }
      );
    }
    return valueNode.value;
  }
});
var GraphQLBoolean = new GraphQLScalarType({
  name: "Boolean",
  description: "The `Boolean` scalar type represents `true` or `false`.",
  serialize(outputValue) {
    const coercedValue = serializeObject(outputValue);
    if (typeof coercedValue === "boolean") {
      return coercedValue;
    }
    if (Number.isFinite(coercedValue)) {
      return coercedValue !== 0;
    }
    throw new GraphQLError(
      `Boolean cannot represent a non boolean value: ${inspect(coercedValue)}`
    );
  },
  parseValue(inputValue) {
    if (typeof inputValue !== "boolean") {
      throw new GraphQLError(
        `Boolean cannot represent a non boolean value: ${inspect(inputValue)}`
      );
    }
    return inputValue;
  },
  parseLiteral(valueNode) {
    if (valueNode.kind !== Kind.BOOLEAN) {
      throw new GraphQLError(
        `Boolean cannot represent a non boolean value: ${print(valueNode)}`,
        {
          nodes: valueNode
        }
      );
    }
    return valueNode.value;
  }
});
var GraphQLID = new GraphQLScalarType({
  name: "ID",
  description: 'The `ID` scalar type represents a unique identifier, often used to refetch an object or as key for a cache. The ID type appears in a JSON response as a String; however, it is not intended to be human-readable. When expected as an input type, any string (such as `"4"`) or integer (such as `4`) input value will be accepted as an ID.',
  serialize(outputValue) {
    const coercedValue = serializeObject(outputValue);
    if (typeof coercedValue === "string") {
      return coercedValue;
    }
    if (Number.isInteger(coercedValue)) {
      return String(coercedValue);
    }
    throw new GraphQLError(
      `ID cannot represent value: ${inspect(outputValue)}`
    );
  },
  parseValue(inputValue) {
    if (typeof inputValue === "string") {
      return inputValue;
    }
    if (typeof inputValue === "number" && Number.isInteger(inputValue)) {
      return inputValue.toString();
    }
    throw new GraphQLError(`ID cannot represent value: ${inspect(inputValue)}`);
  },
  parseLiteral(valueNode) {
    if (valueNode.kind !== Kind.STRING && valueNode.kind !== Kind.INT) {
      throw new GraphQLError(
        "ID cannot represent a non-string and non-integer value: " + print(valueNode),
        {
          nodes: valueNode
        }
      );
    }
    return valueNode.value;
  }
});
var specifiedScalarTypes = Object.freeze([
  GraphQLString,
  GraphQLInt,
  GraphQLFloat,
  GraphQLBoolean,
  GraphQLID
]);
function serializeObject(outputValue) {
  if (isObjectLike(outputValue)) {
    if (typeof outputValue.valueOf === "function") {
      const valueOfResult = outputValue.valueOf();
      if (!isObjectLike(valueOfResult)) {
        return valueOfResult;
      }
    }
    if (typeof outputValue.toJSON === "function") {
      return outputValue.toJSON();
    }
  }
  return outputValue;
}
var GraphQLDirective = class {
  constructor(config) {
    var _config$isRepeatable, _config$args;
    this.name = assertName(config.name);
    this.description = config.description;
    this.locations = config.locations;
    this.isRepeatable = (_config$isRepeatable = config.isRepeatable) !== null && _config$isRepeatable !== void 0 ? _config$isRepeatable : false;
    this.extensions = toObjMap(config.extensions);
    this.astNode = config.astNode;
    Array.isArray(config.locations) || devAssert(false, `@${config.name} locations must be an Array.`);
    const args = (_config$args = config.args) !== null && _config$args !== void 0 ? _config$args : {};
    isObjectLike(args) && !Array.isArray(args) || devAssert(
      false,
      `@${config.name} args must be an object with argument names as keys.`
    );
    this.args = defineArguments(args);
  }
  get [Symbol.toStringTag]() {
    return "GraphQLDirective";
  }
  toConfig() {
    return {
      name: this.name,
      description: this.description,
      locations: this.locations,
      args: argsToArgsConfig(this.args),
      isRepeatable: this.isRepeatable,
      extensions: this.extensions,
      astNode: this.astNode
    };
  }
  toString() {
    return "@" + this.name;
  }
  toJSON() {
    return this.toString();
  }
};
var GraphQLIncludeDirective = new GraphQLDirective({
  name: "include",
  description: "Directs the executor to include this field or fragment only when the `if` argument is true.",
  locations: [
    DirectiveLocation.FIELD,
    DirectiveLocation.FRAGMENT_SPREAD,
    DirectiveLocation.INLINE_FRAGMENT
  ],
  args: {
    if: {
      type: new GraphQLNonNull(GraphQLBoolean),
      description: "Included when true."
    }
  }
});
var GraphQLSkipDirective = new GraphQLDirective({
  name: "skip",
  description: "Directs the executor to skip this field or fragment when the `if` argument is true.",
  locations: [
    DirectiveLocation.FIELD,
    DirectiveLocation.FRAGMENT_SPREAD,
    DirectiveLocation.INLINE_FRAGMENT
  ],
  args: {
    if: {
      type: new GraphQLNonNull(GraphQLBoolean),
      description: "Skipped when true."
    }
  }
});
var DEFAULT_DEPRECATION_REASON = "No longer supported";
var GraphQLDeprecatedDirective = new GraphQLDirective({
  name: "deprecated",
  description: "Marks an element of a GraphQL schema as no longer supported.",
  locations: [
    DirectiveLocation.FIELD_DEFINITION,
    DirectiveLocation.ARGUMENT_DEFINITION,
    DirectiveLocation.INPUT_FIELD_DEFINITION,
    DirectiveLocation.ENUM_VALUE
  ],
  args: {
    reason: {
      type: GraphQLString,
      description: "Explains why this element was deprecated, usually also including a suggestion for how to access supported similar data. Formatted using the Markdown syntax, as specified by [CommonMark](https://commonmark.org/).",
      defaultValue: DEFAULT_DEPRECATION_REASON
    }
  }
});
var GraphQLSpecifiedByDirective = new GraphQLDirective({
  name: "specifiedBy",
  description: "Exposes a URL that specifies the behavior of this scalar.",
  locations: [DirectiveLocation.SCALAR],
  args: {
    url: {
      type: new GraphQLNonNull(GraphQLString),
      description: "The URL that specifies the behavior of this scalar."
    }
  }
});
var specifiedDirectives = Object.freeze([
  GraphQLIncludeDirective,
  GraphQLSkipDirective,
  GraphQLDeprecatedDirective,
  GraphQLSpecifiedByDirective
]);
function isIterableObject(maybeIterable) {
  return typeof maybeIterable === "object" && typeof (maybeIterable === null || maybeIterable === void 0 ? void 0 : maybeIterable[Symbol.iterator]) === "function";
}
function astFromValue(value, type) {
  if (isNonNullType(type)) {
    const astValue = astFromValue(value, type.ofType);
    if ((astValue === null || astValue === void 0 ? void 0 : astValue.kind) === Kind.NULL) {
      return null;
    }
    return astValue;
  }
  if (value === null) {
    return {
      kind: Kind.NULL
    };
  }
  if (value === void 0) {
    return null;
  }
  if (isListType(type)) {
    const itemType = type.ofType;
    if (isIterableObject(value)) {
      const valuesNodes = [];
      for (const item of value) {
        const itemNode = astFromValue(item, itemType);
        if (itemNode != null) {
          valuesNodes.push(itemNode);
        }
      }
      return {
        kind: Kind.LIST,
        values: valuesNodes
      };
    }
    return astFromValue(value, itemType);
  }
  if (isInputObjectType(type)) {
    if (!isObjectLike(value)) {
      return null;
    }
    const fieldNodes = [];
    for (const field of Object.values(type.getFields())) {
      const fieldValue = astFromValue(value[field.name], field.type);
      if (fieldValue) {
        fieldNodes.push({
          kind: Kind.OBJECT_FIELD,
          name: {
            kind: Kind.NAME,
            value: field.name
          },
          value: fieldValue
        });
      }
    }
    return {
      kind: Kind.OBJECT,
      fields: fieldNodes
    };
  }
  if (isLeafType(type)) {
    const serialized = type.serialize(value);
    if (serialized == null) {
      return null;
    }
    if (typeof serialized === "boolean") {
      return {
        kind: Kind.BOOLEAN,
        value: serialized
      };
    }
    if (typeof serialized === "number" && Number.isFinite(serialized)) {
      const stringNum = String(serialized);
      return integerStringRegExp.test(stringNum) ? {
        kind: Kind.INT,
        value: stringNum
      } : {
        kind: Kind.FLOAT,
        value: stringNum
      };
    }
    if (typeof serialized === "string") {
      if (isEnumType(type)) {
        return {
          kind: Kind.ENUM,
          value: serialized
        };
      }
      if (type === GraphQLID && integerStringRegExp.test(serialized)) {
        return {
          kind: Kind.INT,
          value: serialized
        };
      }
      return {
        kind: Kind.STRING,
        value: serialized
      };
    }
    throw new TypeError(`Cannot convert value to AST: ${inspect(serialized)}.`);
  }
  invariant2(false, "Unexpected input type: " + inspect(type));
}
var integerStringRegExp = /^-?(?:0|[1-9][0-9]*)$/;
var __Schema = new GraphQLObjectType({
  name: "__Schema",
  description: "A GraphQL Schema defines the capabilities of a GraphQL server. It exposes all available types and directives on the server, as well as the entry points for query, mutation, and subscription operations.",
  fields: () => ({
    description: {
      type: GraphQLString,
      resolve: (schema) => schema.description
    },
    types: {
      description: "A list of all types supported by this server.",
      type: new GraphQLNonNull(new GraphQLList(new GraphQLNonNull(__Type))),
      resolve(schema) {
        return Object.values(schema.getTypeMap());
      }
    },
    queryType: {
      description: "The type that query operations will be rooted at.",
      type: new GraphQLNonNull(__Type),
      resolve: (schema) => schema.getQueryType()
    },
    mutationType: {
      description: "If this server supports mutation, the type that mutation operations will be rooted at.",
      type: __Type,
      resolve: (schema) => schema.getMutationType()
    },
    subscriptionType: {
      description: "If this server support subscription, the type that subscription operations will be rooted at.",
      type: __Type,
      resolve: (schema) => schema.getSubscriptionType()
    },
    directives: {
      description: "A list of all directives supported by this server.",
      type: new GraphQLNonNull(
        new GraphQLList(new GraphQLNonNull(__Directive))
      ),
      resolve: (schema) => schema.getDirectives()
    }
  })
});
var __Directive = new GraphQLObjectType({
  name: "__Directive",
  description: "A Directive provides a way to describe alternate runtime execution and type validation behavior in a GraphQL document.\n\nIn some cases, you need to provide options to alter GraphQL's execution behavior in ways field arguments will not suffice, such as conditionally including or skipping a field. Directives provide this by describing additional information to the executor.",
  fields: () => ({
    name: {
      type: new GraphQLNonNull(GraphQLString),
      resolve: (directive) => directive.name
    },
    description: {
      type: GraphQLString,
      resolve: (directive) => directive.description
    },
    isRepeatable: {
      type: new GraphQLNonNull(GraphQLBoolean),
      resolve: (directive) => directive.isRepeatable
    },
    locations: {
      type: new GraphQLNonNull(
        new GraphQLList(new GraphQLNonNull(__DirectiveLocation))
      ),
      resolve: (directive) => directive.locations
    },
    args: {
      type: new GraphQLNonNull(
        new GraphQLList(new GraphQLNonNull(__InputValue))
      ),
      args: {
        includeDeprecated: {
          type: GraphQLBoolean,
          defaultValue: false
        }
      },
      resolve(field, { includeDeprecated }) {
        return includeDeprecated ? field.args : field.args.filter((arg) => arg.deprecationReason == null);
      }
    }
  })
});
var __DirectiveLocation = new GraphQLEnumType({
  name: "__DirectiveLocation",
  description: "A Directive can be adjacent to many parts of the GraphQL language, a __DirectiveLocation describes one such possible adjacencies.",
  values: {
    QUERY: {
      value: DirectiveLocation.QUERY,
      description: "Location adjacent to a query operation."
    },
    MUTATION: {
      value: DirectiveLocation.MUTATION,
      description: "Location adjacent to a mutation operation."
    },
    SUBSCRIPTION: {
      value: DirectiveLocation.SUBSCRIPTION,
      description: "Location adjacent to a subscription operation."
    },
    FIELD: {
      value: DirectiveLocation.FIELD,
      description: "Location adjacent to a field."
    },
    FRAGMENT_DEFINITION: {
      value: DirectiveLocation.FRAGMENT_DEFINITION,
      description: "Location adjacent to a fragment definition."
    },
    FRAGMENT_SPREAD: {
      value: DirectiveLocation.FRAGMENT_SPREAD,
      description: "Location adjacent to a fragment spread."
    },
    INLINE_FRAGMENT: {
      value: DirectiveLocation.INLINE_FRAGMENT,
      description: "Location adjacent to an inline fragment."
    },
    VARIABLE_DEFINITION: {
      value: DirectiveLocation.VARIABLE_DEFINITION,
      description: "Location adjacent to a variable definition."
    },
    SCHEMA: {
      value: DirectiveLocation.SCHEMA,
      description: "Location adjacent to a schema definition."
    },
    SCALAR: {
      value: DirectiveLocation.SCALAR,
      description: "Location adjacent to a scalar definition."
    },
    OBJECT: {
      value: DirectiveLocation.OBJECT,
      description: "Location adjacent to an object type definition."
    },
    FIELD_DEFINITION: {
      value: DirectiveLocation.FIELD_DEFINITION,
      description: "Location adjacent to a field definition."
    },
    ARGUMENT_DEFINITION: {
      value: DirectiveLocation.ARGUMENT_DEFINITION,
      description: "Location adjacent to an argument definition."
    },
    INTERFACE: {
      value: DirectiveLocation.INTERFACE,
      description: "Location adjacent to an interface definition."
    },
    UNION: {
      value: DirectiveLocation.UNION,
      description: "Location adjacent to a union definition."
    },
    ENUM: {
      value: DirectiveLocation.ENUM,
      description: "Location adjacent to an enum definition."
    },
    ENUM_VALUE: {
      value: DirectiveLocation.ENUM_VALUE,
      description: "Location adjacent to an enum value definition."
    },
    INPUT_OBJECT: {
      value: DirectiveLocation.INPUT_OBJECT,
      description: "Location adjacent to an input object type definition."
    },
    INPUT_FIELD_DEFINITION: {
      value: DirectiveLocation.INPUT_FIELD_DEFINITION,
      description: "Location adjacent to an input object field definition."
    }
  }
});
var __Type = new GraphQLObjectType({
  name: "__Type",
  description: "The fundamental unit of any GraphQL Schema is the type. There are many kinds of types in GraphQL as represented by the `__TypeKind` enum.\n\nDepending on the kind of a type, certain fields describe information about that type. Scalar types provide no information beyond a name, description and optional `specifiedByURL`, while Enum types provide their values. Object and Interface types provide the fields they describe. Abstract types, Union and Interface, provide the Object types possible at runtime. List and NonNull types compose other types.",
  fields: () => ({
    kind: {
      type: new GraphQLNonNull(__TypeKind),
      resolve(type) {
        if (isScalarType(type)) {
          return TypeKind.SCALAR;
        }
        if (isObjectType(type)) {
          return TypeKind.OBJECT;
        }
        if (isInterfaceType(type)) {
          return TypeKind.INTERFACE;
        }
        if (isUnionType(type)) {
          return TypeKind.UNION;
        }
        if (isEnumType(type)) {
          return TypeKind.ENUM;
        }
        if (isInputObjectType(type)) {
          return TypeKind.INPUT_OBJECT;
        }
        if (isListType(type)) {
          return TypeKind.LIST;
        }
        if (isNonNullType(type)) {
          return TypeKind.NON_NULL;
        }
        invariant2(false, `Unexpected type: "${inspect(type)}".`);
      }
    },
    name: {
      type: GraphQLString,
      resolve: (type) => "name" in type ? type.name : void 0
    },
    description: {
      type: GraphQLString,
      resolve: (type) => (
        /* c8 ignore next */
        "description" in type ? type.description : void 0
      )
    },
    specifiedByURL: {
      type: GraphQLString,
      resolve: (obj) => "specifiedByURL" in obj ? obj.specifiedByURL : void 0
    },
    fields: {
      type: new GraphQLList(new GraphQLNonNull(__Field)),
      args: {
        includeDeprecated: {
          type: GraphQLBoolean,
          defaultValue: false
        }
      },
      resolve(type, { includeDeprecated }) {
        if (isObjectType(type) || isInterfaceType(type)) {
          const fields = Object.values(type.getFields());
          return includeDeprecated ? fields : fields.filter((field) => field.deprecationReason == null);
        }
      }
    },
    interfaces: {
      type: new GraphQLList(new GraphQLNonNull(__Type)),
      resolve(type) {
        if (isObjectType(type) || isInterfaceType(type)) {
          return type.getInterfaces();
        }
      }
    },
    possibleTypes: {
      type: new GraphQLList(new GraphQLNonNull(__Type)),
      resolve(type, _args, _context, { schema }) {
        if (isAbstractType(type)) {
          return schema.getPossibleTypes(type);
        }
      }
    },
    enumValues: {
      type: new GraphQLList(new GraphQLNonNull(__EnumValue)),
      args: {
        includeDeprecated: {
          type: GraphQLBoolean,
          defaultValue: false
        }
      },
      resolve(type, { includeDeprecated }) {
        if (isEnumType(type)) {
          const values = type.getValues();
          return includeDeprecated ? values : values.filter((field) => field.deprecationReason == null);
        }
      }
    },
    inputFields: {
      type: new GraphQLList(new GraphQLNonNull(__InputValue)),
      args: {
        includeDeprecated: {
          type: GraphQLBoolean,
          defaultValue: false
        }
      },
      resolve(type, { includeDeprecated }) {
        if (isInputObjectType(type)) {
          const values = Object.values(type.getFields());
          return includeDeprecated ? values : values.filter((field) => field.deprecationReason == null);
        }
      }
    },
    ofType: {
      type: __Type,
      resolve: (type) => "ofType" in type ? type.ofType : void 0
    }
  })
});
var __Field = new GraphQLObjectType({
  name: "__Field",
  description: "Object and Interface types are described by a list of Fields, each of which has a name, potentially a list of arguments, and a return type.",
  fields: () => ({
    name: {
      type: new GraphQLNonNull(GraphQLString),
      resolve: (field) => field.name
    },
    description: {
      type: GraphQLString,
      resolve: (field) => field.description
    },
    args: {
      type: new GraphQLNonNull(
        new GraphQLList(new GraphQLNonNull(__InputValue))
      ),
      args: {
        includeDeprecated: {
          type: GraphQLBoolean,
          defaultValue: false
        }
      },
      resolve(field, { includeDeprecated }) {
        return includeDeprecated ? field.args : field.args.filter((arg) => arg.deprecationReason == null);
      }
    },
    type: {
      type: new GraphQLNonNull(__Type),
      resolve: (field) => field.type
    },
    isDeprecated: {
      type: new GraphQLNonNull(GraphQLBoolean),
      resolve: (field) => field.deprecationReason != null
    },
    deprecationReason: {
      type: GraphQLString,
      resolve: (field) => field.deprecationReason
    }
  })
});
var __InputValue = new GraphQLObjectType({
  name: "__InputValue",
  description: "Arguments provided to Fields or Directives and the input fields of an InputObject are represented as Input Values which describe their type and optionally a default value.",
  fields: () => ({
    name: {
      type: new GraphQLNonNull(GraphQLString),
      resolve: (inputValue) => inputValue.name
    },
    description: {
      type: GraphQLString,
      resolve: (inputValue) => inputValue.description
    },
    type: {
      type: new GraphQLNonNull(__Type),
      resolve: (inputValue) => inputValue.type
    },
    defaultValue: {
      type: GraphQLString,
      description: "A GraphQL-formatted string representing the default value for this input value.",
      resolve(inputValue) {
        const { type, defaultValue } = inputValue;
        const valueAST = astFromValue(defaultValue, type);
        return valueAST ? print(valueAST) : null;
      }
    },
    isDeprecated: {
      type: new GraphQLNonNull(GraphQLBoolean),
      resolve: (field) => field.deprecationReason != null
    },
    deprecationReason: {
      type: GraphQLString,
      resolve: (obj) => obj.deprecationReason
    }
  })
});
var __EnumValue = new GraphQLObjectType({
  name: "__EnumValue",
  description: "One possible value for a given Enum. Enum values are unique values, not a placeholder for a string or numeric value. However an Enum value is returned in a JSON response as a string.",
  fields: () => ({
    name: {
      type: new GraphQLNonNull(GraphQLString),
      resolve: (enumValue) => enumValue.name
    },
    description: {
      type: GraphQLString,
      resolve: (enumValue) => enumValue.description
    },
    isDeprecated: {
      type: new GraphQLNonNull(GraphQLBoolean),
      resolve: (enumValue) => enumValue.deprecationReason != null
    },
    deprecationReason: {
      type: GraphQLString,
      resolve: (enumValue) => enumValue.deprecationReason
    }
  })
});
var TypeKind;
(function(TypeKind2) {
  TypeKind2["SCALAR"] = "SCALAR";
  TypeKind2["OBJECT"] = "OBJECT";
  TypeKind2["INTERFACE"] = "INTERFACE";
  TypeKind2["UNION"] = "UNION";
  TypeKind2["ENUM"] = "ENUM";
  TypeKind2["INPUT_OBJECT"] = "INPUT_OBJECT";
  TypeKind2["LIST"] = "LIST";
  TypeKind2["NON_NULL"] = "NON_NULL";
})(TypeKind || (TypeKind = {}));
var __TypeKind = new GraphQLEnumType({
  name: "__TypeKind",
  description: "An enum describing what kind of type a given `__Type` is.",
  values: {
    SCALAR: {
      value: TypeKind.SCALAR,
      description: "Indicates this type is a scalar."
    },
    OBJECT: {
      value: TypeKind.OBJECT,
      description: "Indicates this type is an object. `fields` and `interfaces` are valid fields."
    },
    INTERFACE: {
      value: TypeKind.INTERFACE,
      description: "Indicates this type is an interface. `fields`, `interfaces`, and `possibleTypes` are valid fields."
    },
    UNION: {
      value: TypeKind.UNION,
      description: "Indicates this type is a union. `possibleTypes` is a valid field."
    },
    ENUM: {
      value: TypeKind.ENUM,
      description: "Indicates this type is an enum. `enumValues` is a valid field."
    },
    INPUT_OBJECT: {
      value: TypeKind.INPUT_OBJECT,
      description: "Indicates this type is an input object. `inputFields` is a valid field."
    },
    LIST: {
      value: TypeKind.LIST,
      description: "Indicates this type is a list. `ofType` is a valid field."
    },
    NON_NULL: {
      value: TypeKind.NON_NULL,
      description: "Indicates this type is a non-null. `ofType` is a valid field."
    }
  }
});
var SchemaMetaFieldDef = {
  name: "__schema",
  type: new GraphQLNonNull(__Schema),
  description: "Access the current type schema of this server.",
  args: [],
  resolve: (_source, _args, _context, { schema }) => schema,
  deprecationReason: void 0,
  extensions: /* @__PURE__ */ Object.create(null),
  astNode: void 0
};
var TypeMetaFieldDef = {
  name: "__type",
  type: __Type,
  description: "Request the type information of a single type.",
  args: [
    {
      name: "name",
      description: void 0,
      type: new GraphQLNonNull(GraphQLString),
      defaultValue: void 0,
      deprecationReason: void 0,
      extensions: /* @__PURE__ */ Object.create(null),
      astNode: void 0
    }
  ],
  resolve: (_source, { name }, _context, { schema }) => schema.getType(name),
  deprecationReason: void 0,
  extensions: /* @__PURE__ */ Object.create(null),
  astNode: void 0
};
var TypeNameMetaFieldDef = {
  name: "__typename",
  type: new GraphQLNonNull(GraphQLString),
  description: "The name of the current Object type at runtime.",
  args: [],
  resolve: (_source, _args, _context, { parentType }) => parentType.name,
  deprecationReason: void 0,
  extensions: /* @__PURE__ */ Object.create(null),
  astNode: void 0
};
var introspectionTypes = Object.freeze([
  __Schema,
  __Directive,
  __DirectiveLocation,
  __Type,
  __Field,
  __InputValue,
  __EnumValue,
  __TypeKind
]);
function typeFromAST(schema, typeNode) {
  switch (typeNode.kind) {
    case Kind.LIST_TYPE: {
      const innerType = typeFromAST(schema, typeNode.type);
      return innerType && new GraphQLList(innerType);
    }
    case Kind.NON_NULL_TYPE: {
      const innerType = typeFromAST(schema, typeNode.type);
      return innerType && new GraphQLNonNull(innerType);
    }
    case Kind.NAMED_TYPE:
      return schema.getType(typeNode.name.value);
  }
}
function isExecutableDefinitionNode(node) {
  return node.kind === Kind.OPERATION_DEFINITION || node.kind === Kind.FRAGMENT_DEFINITION;
}
function isTypeSystemDefinitionNode(node) {
  return node.kind === Kind.SCHEMA_DEFINITION || isTypeDefinitionNode(node) || node.kind === Kind.DIRECTIVE_DEFINITION;
}
function isTypeDefinitionNode(node) {
  return node.kind === Kind.SCALAR_TYPE_DEFINITION || node.kind === Kind.OBJECT_TYPE_DEFINITION || node.kind === Kind.INTERFACE_TYPE_DEFINITION || node.kind === Kind.UNION_TYPE_DEFINITION || node.kind === Kind.ENUM_TYPE_DEFINITION || node.kind === Kind.INPUT_OBJECT_TYPE_DEFINITION;
}
function isTypeSystemExtensionNode(node) {
  return node.kind === Kind.SCHEMA_EXTENSION || isTypeExtensionNode(node);
}
function isTypeExtensionNode(node) {
  return node.kind === Kind.SCALAR_TYPE_EXTENSION || node.kind === Kind.OBJECT_TYPE_EXTENSION || node.kind === Kind.INTERFACE_TYPE_EXTENSION || node.kind === Kind.UNION_TYPE_EXTENSION || node.kind === Kind.ENUM_TYPE_EXTENSION || node.kind === Kind.INPUT_OBJECT_TYPE_EXTENSION;
}
function ExecutableDefinitionsRule(context) {
  return {
    Document(node) {
      for (const definition of node.definitions) {
        if (!isExecutableDefinitionNode(definition)) {
          const defName = definition.kind === Kind.SCHEMA_DEFINITION || definition.kind === Kind.SCHEMA_EXTENSION ? "schema" : '"' + definition.name.value + '"';
          context.reportError(
            new GraphQLError(`The ${defName} definition is not executable.`, {
              nodes: definition
            })
          );
        }
      }
      return false;
    }
  };
}
function FieldsOnCorrectTypeRule(context) {
  return {
    Field(node) {
      const type = context.getParentType();
      if (type) {
        const fieldDef = context.getFieldDef();
        if (!fieldDef) {
          const schema = context.getSchema();
          const fieldName = node.name.value;
          let suggestion = didYouMean(
            "to use an inline fragment on",
            getSuggestedTypeNames(schema, type, fieldName)
          );
          if (suggestion === "") {
            suggestion = didYouMean(getSuggestedFieldNames(type, fieldName));
          }
          context.reportError(
            new GraphQLError(
              `Cannot query field "${fieldName}" on type "${type.name}".` + suggestion,
              {
                nodes: node
              }
            )
          );
        }
      }
    }
  };
}
function getSuggestedTypeNames(schema, type, fieldName) {
  if (!isAbstractType(type)) {
    return [];
  }
  const suggestedTypes = /* @__PURE__ */ new Set();
  const usageCount = /* @__PURE__ */ Object.create(null);
  for (const possibleType of schema.getPossibleTypes(type)) {
    if (!possibleType.getFields()[fieldName]) {
      continue;
    }
    suggestedTypes.add(possibleType);
    usageCount[possibleType.name] = 1;
    for (const possibleInterface of possibleType.getInterfaces()) {
      var _usageCount$possibleI;
      if (!possibleInterface.getFields()[fieldName]) {
        continue;
      }
      suggestedTypes.add(possibleInterface);
      usageCount[possibleInterface.name] = ((_usageCount$possibleI = usageCount[possibleInterface.name]) !== null && _usageCount$possibleI !== void 0 ? _usageCount$possibleI : 0) + 1;
    }
  }
  return [...suggestedTypes].sort((typeA, typeB) => {
    const usageCountDiff = usageCount[typeB.name] - usageCount[typeA.name];
    if (usageCountDiff !== 0) {
      return usageCountDiff;
    }
    if (isInterfaceType(typeA) && schema.isSubType(typeA, typeB)) {
      return -1;
    }
    if (isInterfaceType(typeB) && schema.isSubType(typeB, typeA)) {
      return 1;
    }
    return naturalCompare(typeA.name, typeB.name);
  }).map((x) => x.name);
}
function getSuggestedFieldNames(type, fieldName) {
  if (isObjectType(type) || isInterfaceType(type)) {
    const possibleFieldNames = Object.keys(type.getFields());
    return suggestionList(fieldName, possibleFieldNames);
  }
  return [];
}
function FragmentsOnCompositeTypesRule(context) {
  return {
    InlineFragment(node) {
      const typeCondition = node.typeCondition;
      if (typeCondition) {
        const type = typeFromAST(context.getSchema(), typeCondition);
        if (type && !isCompositeType(type)) {
          const typeStr = print(typeCondition);
          context.reportError(
            new GraphQLError(
              `Fragment cannot condition on non composite type "${typeStr}".`,
              {
                nodes: typeCondition
              }
            )
          );
        }
      }
    },
    FragmentDefinition(node) {
      const type = typeFromAST(context.getSchema(), node.typeCondition);
      if (type && !isCompositeType(type)) {
        const typeStr = print(node.typeCondition);
        context.reportError(
          new GraphQLError(
            `Fragment "${node.name.value}" cannot condition on non composite type "${typeStr}".`,
            {
              nodes: node.typeCondition
            }
          )
        );
      }
    }
  };
}
function KnownArgumentNamesRule(context) {
  return {
    // eslint-disable-next-line new-cap
    ...KnownArgumentNamesOnDirectivesRule(context),
    Argument(argNode) {
      const argDef = context.getArgument();
      const fieldDef = context.getFieldDef();
      const parentType = context.getParentType();
      if (!argDef && fieldDef && parentType) {
        const argName = argNode.name.value;
        const knownArgsNames = fieldDef.args.map((arg) => arg.name);
        const suggestions = suggestionList(argName, knownArgsNames);
        context.reportError(
          new GraphQLError(
            `Unknown argument "${argName}" on field "${parentType.name}.${fieldDef.name}".` + didYouMean(suggestions),
            {
              nodes: argNode
            }
          )
        );
      }
    }
  };
}
function KnownArgumentNamesOnDirectivesRule(context) {
  const directiveArgs = /* @__PURE__ */ Object.create(null);
  const schema = context.getSchema();
  const definedDirectives = schema ? schema.getDirectives() : specifiedDirectives;
  for (const directive of definedDirectives) {
    directiveArgs[directive.name] = directive.args.map((arg) => arg.name);
  }
  const astDefinitions = context.getDocument().definitions;
  for (const def of astDefinitions) {
    if (def.kind === Kind.DIRECTIVE_DEFINITION) {
      var _def$arguments;
      const argsNodes = (_def$arguments = def.arguments) !== null && _def$arguments !== void 0 ? _def$arguments : [];
      directiveArgs[def.name.value] = argsNodes.map((arg) => arg.name.value);
    }
  }
  return {
    Directive(directiveNode) {
      const directiveName = directiveNode.name.value;
      const knownArgs = directiveArgs[directiveName];
      if (directiveNode.arguments && knownArgs) {
        for (const argNode of directiveNode.arguments) {
          const argName = argNode.name.value;
          if (!knownArgs.includes(argName)) {
            const suggestions = suggestionList(argName, knownArgs);
            context.reportError(
              new GraphQLError(
                `Unknown argument "${argName}" on directive "@${directiveName}".` + didYouMean(suggestions),
                {
                  nodes: argNode
                }
              )
            );
          }
        }
      }
      return false;
    }
  };
}
function KnownDirectivesRule(context) {
  const locationsMap = /* @__PURE__ */ Object.create(null);
  const schema = context.getSchema();
  const definedDirectives = schema ? schema.getDirectives() : specifiedDirectives;
  for (const directive of definedDirectives) {
    locationsMap[directive.name] = directive.locations;
  }
  const astDefinitions = context.getDocument().definitions;
  for (const def of astDefinitions) {
    if (def.kind === Kind.DIRECTIVE_DEFINITION) {
      locationsMap[def.name.value] = def.locations.map((name) => name.value);
    }
  }
  return {
    Directive(node, _key, _parent, _path, ancestors) {
      const name = node.name.value;
      const locations = locationsMap[name];
      if (!locations) {
        context.reportError(
          new GraphQLError(`Unknown directive "@${name}".`, {
            nodes: node
          })
        );
        return;
      }
      const candidateLocation = getDirectiveLocationForASTPath(ancestors);
      if (candidateLocation && !locations.includes(candidateLocation)) {
        context.reportError(
          new GraphQLError(
            `Directive "@${name}" may not be used on ${candidateLocation}.`,
            {
              nodes: node
            }
          )
        );
      }
    }
  };
}
function getDirectiveLocationForASTPath(ancestors) {
  const appliedTo = ancestors[ancestors.length - 1];
  "kind" in appliedTo || invariant2(false);
  switch (appliedTo.kind) {
    case Kind.OPERATION_DEFINITION:
      return getDirectiveLocationForOperation(appliedTo.operation);
    case Kind.FIELD:
      return DirectiveLocation.FIELD;
    case Kind.FRAGMENT_SPREAD:
      return DirectiveLocation.FRAGMENT_SPREAD;
    case Kind.INLINE_FRAGMENT:
      return DirectiveLocation.INLINE_FRAGMENT;
    case Kind.FRAGMENT_DEFINITION:
      return DirectiveLocation.FRAGMENT_DEFINITION;
    case Kind.VARIABLE_DEFINITION:
      return DirectiveLocation.VARIABLE_DEFINITION;
    case Kind.SCHEMA_DEFINITION:
    case Kind.SCHEMA_EXTENSION:
      return DirectiveLocation.SCHEMA;
    case Kind.SCALAR_TYPE_DEFINITION:
    case Kind.SCALAR_TYPE_EXTENSION:
      return DirectiveLocation.SCALAR;
    case Kind.OBJECT_TYPE_DEFINITION:
    case Kind.OBJECT_TYPE_EXTENSION:
      return DirectiveLocation.OBJECT;
    case Kind.FIELD_DEFINITION:
      return DirectiveLocation.FIELD_DEFINITION;
    case Kind.INTERFACE_TYPE_DEFINITION:
    case Kind.INTERFACE_TYPE_EXTENSION:
      return DirectiveLocation.INTERFACE;
    case Kind.UNION_TYPE_DEFINITION:
    case Kind.UNION_TYPE_EXTENSION:
      return DirectiveLocation.UNION;
    case Kind.ENUM_TYPE_DEFINITION:
    case Kind.ENUM_TYPE_EXTENSION:
      return DirectiveLocation.ENUM;
    case Kind.ENUM_VALUE_DEFINITION:
      return DirectiveLocation.ENUM_VALUE;
    case Kind.INPUT_OBJECT_TYPE_DEFINITION:
    case Kind.INPUT_OBJECT_TYPE_EXTENSION:
      return DirectiveLocation.INPUT_OBJECT;
    case Kind.INPUT_VALUE_DEFINITION: {
      const parentNode = ancestors[ancestors.length - 3];
      "kind" in parentNode || invariant2(false);
      return parentNode.kind === Kind.INPUT_OBJECT_TYPE_DEFINITION ? DirectiveLocation.INPUT_FIELD_DEFINITION : DirectiveLocation.ARGUMENT_DEFINITION;
    }
    default:
      invariant2(false, "Unexpected kind: " + inspect(appliedTo.kind));
  }
}
function getDirectiveLocationForOperation(operation) {
  switch (operation) {
    case OperationTypeNode.QUERY:
      return DirectiveLocation.QUERY;
    case OperationTypeNode.MUTATION:
      return DirectiveLocation.MUTATION;
    case OperationTypeNode.SUBSCRIPTION:
      return DirectiveLocation.SUBSCRIPTION;
  }
}
function KnownFragmentNamesRule(context) {
  return {
    FragmentSpread(node) {
      const fragmentName = node.name.value;
      const fragment = context.getFragment(fragmentName);
      if (!fragment) {
        context.reportError(
          new GraphQLError(`Unknown fragment "${fragmentName}".`, {
            nodes: node.name
          })
        );
      }
    }
  };
}
function KnownTypeNamesRule(context) {
  const schema = context.getSchema();
  const existingTypesMap = schema ? schema.getTypeMap() : /* @__PURE__ */ Object.create(null);
  const definedTypes = /* @__PURE__ */ Object.create(null);
  for (const def of context.getDocument().definitions) {
    if (isTypeDefinitionNode(def)) {
      definedTypes[def.name.value] = true;
    }
  }
  const typeNames = [
    ...Object.keys(existingTypesMap),
    ...Object.keys(definedTypes)
  ];
  return {
    NamedType(node, _1, parent, _2, ancestors) {
      const typeName = node.name.value;
      if (!existingTypesMap[typeName] && !definedTypes[typeName]) {
        var _ancestors$;
        const definitionNode = (_ancestors$ = ancestors[2]) !== null && _ancestors$ !== void 0 ? _ancestors$ : parent;
        const isSDL = definitionNode != null && isSDLNode(definitionNode);
        if (isSDL && standardTypeNames.includes(typeName)) {
          return;
        }
        const suggestedTypes = suggestionList(
          typeName,
          isSDL ? standardTypeNames.concat(typeNames) : typeNames
        );
        context.reportError(
          new GraphQLError(
            `Unknown type "${typeName}".` + didYouMean(suggestedTypes),
            {
              nodes: node
            }
          )
        );
      }
    }
  };
}
var standardTypeNames = [...specifiedScalarTypes, ...introspectionTypes].map(
  (type) => type.name
);
function isSDLNode(value) {
  return "kind" in value && (isTypeSystemDefinitionNode(value) || isTypeSystemExtensionNode(value));
}
function LoneAnonymousOperationRule(context) {
  let operationCount = 0;
  return {
    Document(node) {
      operationCount = node.definitions.filter(
        (definition) => definition.kind === Kind.OPERATION_DEFINITION
      ).length;
    },
    OperationDefinition(node) {
      if (!node.name && operationCount > 1) {
        context.reportError(
          new GraphQLError(
            "This anonymous operation must be the only defined operation.",
            {
              nodes: node
            }
          )
        );
      }
    }
  };
}
function LoneSchemaDefinitionRule(context) {
  var _ref, _ref2, _oldSchema$astNode;
  const oldSchema = context.getSchema();
  const alreadyDefined = (_ref = (_ref2 = (_oldSchema$astNode = oldSchema === null || oldSchema === void 0 ? void 0 : oldSchema.astNode) !== null && _oldSchema$astNode !== void 0 ? _oldSchema$astNode : oldSchema === null || oldSchema === void 0 ? void 0 : oldSchema.getQueryType()) !== null && _ref2 !== void 0 ? _ref2 : oldSchema === null || oldSchema === void 0 ? void 0 : oldSchema.getMutationType()) !== null && _ref !== void 0 ? _ref : oldSchema === null || oldSchema === void 0 ? void 0 : oldSchema.getSubscriptionType();
  let schemaDefinitionsCount = 0;
  return {
    SchemaDefinition(node) {
      if (alreadyDefined) {
        context.reportError(
          new GraphQLError(
            "Cannot define a new schema within a schema extension.",
            {
              nodes: node
            }
          )
        );
        return;
      }
      if (schemaDefinitionsCount > 0) {
        context.reportError(
          new GraphQLError("Must provide only one schema definition.", {
            nodes: node
          })
        );
      }
      ++schemaDefinitionsCount;
    }
  };
}
function NoFragmentCyclesRule(context) {
  const visitedFrags = /* @__PURE__ */ Object.create(null);
  const spreadPath = [];
  const spreadPathIndexByName = /* @__PURE__ */ Object.create(null);
  return {
    OperationDefinition: () => false,
    FragmentDefinition(node) {
      detectCycleRecursive(node);
      return false;
    }
  };
  function detectCycleRecursive(fragment) {
    if (visitedFrags[fragment.name.value]) {
      return;
    }
    const fragmentName = fragment.name.value;
    visitedFrags[fragmentName] = true;
    const spreadNodes = context.getFragmentSpreads(fragment.selectionSet);
    if (spreadNodes.length === 0) {
      return;
    }
    spreadPathIndexByName[fragmentName] = spreadPath.length;
    for (const spreadNode of spreadNodes) {
      const spreadName = spreadNode.name.value;
      const cycleIndex = spreadPathIndexByName[spreadName];
      spreadPath.push(spreadNode);
      if (cycleIndex === void 0) {
        const spreadFragment = context.getFragment(spreadName);
        if (spreadFragment) {
          detectCycleRecursive(spreadFragment);
        }
      } else {
        const cyclePath = spreadPath.slice(cycleIndex);
        const viaPath = cyclePath.slice(0, -1).map((s) => '"' + s.name.value + '"').join(", ");
        context.reportError(
          new GraphQLError(
            `Cannot spread fragment "${spreadName}" within itself` + (viaPath !== "" ? ` via ${viaPath}.` : "."),
            {
              nodes: cyclePath
            }
          )
        );
      }
      spreadPath.pop();
    }
    spreadPathIndexByName[fragmentName] = void 0;
  }
}
function NoUndefinedVariablesRule(context) {
  let variableNameDefined = /* @__PURE__ */ Object.create(null);
  return {
    OperationDefinition: {
      enter() {
        variableNameDefined = /* @__PURE__ */ Object.create(null);
      },
      leave(operation) {
        const usages = context.getRecursiveVariableUsages(operation);
        for (const { node } of usages) {
          const varName = node.name.value;
          if (variableNameDefined[varName] !== true) {
            context.reportError(
              new GraphQLError(
                operation.name ? `Variable "$${varName}" is not defined by operation "${operation.name.value}".` : `Variable "$${varName}" is not defined.`,
                {
                  nodes: [node, operation]
                }
              )
            );
          }
        }
      }
    },
    VariableDefinition(node) {
      variableNameDefined[node.variable.name.value] = true;
    }
  };
}
function NoUnusedFragmentsRule(context) {
  const operationDefs = [];
  const fragmentDefs = [];
  return {
    OperationDefinition(node) {
      operationDefs.push(node);
      return false;
    },
    FragmentDefinition(node) {
      fragmentDefs.push(node);
      return false;
    },
    Document: {
      leave() {
        const fragmentNameUsed = /* @__PURE__ */ Object.create(null);
        for (const operation of operationDefs) {
          for (const fragment of context.getRecursivelyReferencedFragments(
            operation
          )) {
            fragmentNameUsed[fragment.name.value] = true;
          }
        }
        for (const fragmentDef of fragmentDefs) {
          const fragName = fragmentDef.name.value;
          if (fragmentNameUsed[fragName] !== true) {
            context.reportError(
              new GraphQLError(`Fragment "${fragName}" is never used.`, {
                nodes: fragmentDef
              })
            );
          }
        }
      }
    }
  };
}
function NoUnusedVariablesRule(context) {
  let variableDefs = [];
  return {
    OperationDefinition: {
      enter() {
        variableDefs = [];
      },
      leave(operation) {
        const variableNameUsed = /* @__PURE__ */ Object.create(null);
        const usages = context.getRecursiveVariableUsages(operation);
        for (const { node } of usages) {
          variableNameUsed[node.name.value] = true;
        }
        for (const variableDef of variableDefs) {
          const variableName = variableDef.variable.name.value;
          if (variableNameUsed[variableName] !== true) {
            context.reportError(
              new GraphQLError(
                operation.name ? `Variable "$${variableName}" is never used in operation "${operation.name.value}".` : `Variable "$${variableName}" is never used.`,
                {
                  nodes: variableDef
                }
              )
            );
          }
        }
      }
    },
    VariableDefinition(def) {
      variableDefs.push(def);
    }
  };
}
function sortValueNode(valueNode) {
  switch (valueNode.kind) {
    case Kind.OBJECT:
      return { ...valueNode, fields: sortFields(valueNode.fields) };
    case Kind.LIST:
      return { ...valueNode, values: valueNode.values.map(sortValueNode) };
    case Kind.INT:
    case Kind.FLOAT:
    case Kind.STRING:
    case Kind.BOOLEAN:
    case Kind.NULL:
    case Kind.ENUM:
    case Kind.VARIABLE:
      return valueNode;
  }
}
function sortFields(fields) {
  return fields.map((fieldNode) => ({
    ...fieldNode,
    value: sortValueNode(fieldNode.value)
  })).sort(
    (fieldA, fieldB) => naturalCompare(fieldA.name.value, fieldB.name.value)
  );
}
function reasonMessage(reason) {
  if (Array.isArray(reason)) {
    return reason.map(
      ([responseName, subReason]) => `subfields "${responseName}" conflict because ` + reasonMessage(subReason)
    ).join(" and ");
  }
  return reason;
}
function OverlappingFieldsCanBeMergedRule(context) {
  const comparedFragmentPairs = new PairSet();
  const cachedFieldsAndFragmentNames = /* @__PURE__ */ new Map();
  return {
    SelectionSet(selectionSet) {
      const conflicts = findConflictsWithinSelectionSet(
        context,
        cachedFieldsAndFragmentNames,
        comparedFragmentPairs,
        context.getParentType(),
        selectionSet
      );
      for (const [[responseName, reason], fields1, fields2] of conflicts) {
        const reasonMsg = reasonMessage(reason);
        context.reportError(
          new GraphQLError(
            `Fields "${responseName}" conflict because ${reasonMsg}. Use different aliases on the fields to fetch both if this was intentional.`,
            {
              nodes: fields1.concat(fields2)
            }
          )
        );
      }
    }
  };
}
function findConflictsWithinSelectionSet(context, cachedFieldsAndFragmentNames, comparedFragmentPairs, parentType, selectionSet) {
  const conflicts = [];
  const [fieldMap, fragmentNames] = getFieldsAndFragmentNames(
    context,
    cachedFieldsAndFragmentNames,
    parentType,
    selectionSet
  );
  collectConflictsWithin(
    context,
    conflicts,
    cachedFieldsAndFragmentNames,
    comparedFragmentPairs,
    fieldMap
  );
  if (fragmentNames.length !== 0) {
    for (let i = 0; i < fragmentNames.length; i++) {
      collectConflictsBetweenFieldsAndFragment(
        context,
        conflicts,
        cachedFieldsAndFragmentNames,
        comparedFragmentPairs,
        false,
        fieldMap,
        fragmentNames[i]
      );
      for (let j = i + 1; j < fragmentNames.length; j++) {
        collectConflictsBetweenFragments(
          context,
          conflicts,
          cachedFieldsAndFragmentNames,
          comparedFragmentPairs,
          false,
          fragmentNames[i],
          fragmentNames[j]
        );
      }
    }
  }
  return conflicts;
}
function collectConflictsBetweenFieldsAndFragment(context, conflicts, cachedFieldsAndFragmentNames, comparedFragmentPairs, areMutuallyExclusive, fieldMap, fragmentName) {
  const fragment = context.getFragment(fragmentName);
  if (!fragment) {
    return;
  }
  const [fieldMap2, referencedFragmentNames] = getReferencedFieldsAndFragmentNames(
    context,
    cachedFieldsAndFragmentNames,
    fragment
  );
  if (fieldMap === fieldMap2) {
    return;
  }
  collectConflictsBetween(
    context,
    conflicts,
    cachedFieldsAndFragmentNames,
    comparedFragmentPairs,
    areMutuallyExclusive,
    fieldMap,
    fieldMap2
  );
  for (const referencedFragmentName of referencedFragmentNames) {
    if (comparedFragmentPairs.has(
      referencedFragmentName,
      fragmentName,
      areMutuallyExclusive
    )) {
      continue;
    }
    comparedFragmentPairs.add(
      referencedFragmentName,
      fragmentName,
      areMutuallyExclusive
    );
    collectConflictsBetweenFieldsAndFragment(
      context,
      conflicts,
      cachedFieldsAndFragmentNames,
      comparedFragmentPairs,
      areMutuallyExclusive,
      fieldMap,
      referencedFragmentName
    );
  }
}
function collectConflictsBetweenFragments(context, conflicts, cachedFieldsAndFragmentNames, comparedFragmentPairs, areMutuallyExclusive, fragmentName1, fragmentName2) {
  if (fragmentName1 === fragmentName2) {
    return;
  }
  if (comparedFragmentPairs.has(
    fragmentName1,
    fragmentName2,
    areMutuallyExclusive
  )) {
    return;
  }
  comparedFragmentPairs.add(fragmentName1, fragmentName2, areMutuallyExclusive);
  const fragment1 = context.getFragment(fragmentName1);
  const fragment2 = context.getFragment(fragmentName2);
  if (!fragment1 || !fragment2) {
    return;
  }
  const [fieldMap1, referencedFragmentNames1] = getReferencedFieldsAndFragmentNames(
    context,
    cachedFieldsAndFragmentNames,
    fragment1
  );
  const [fieldMap2, referencedFragmentNames2] = getReferencedFieldsAndFragmentNames(
    context,
    cachedFieldsAndFragmentNames,
    fragment2
  );
  collectConflictsBetween(
    context,
    conflicts,
    cachedFieldsAndFragmentNames,
    comparedFragmentPairs,
    areMutuallyExclusive,
    fieldMap1,
    fieldMap2
  );
  for (const referencedFragmentName2 of referencedFragmentNames2) {
    collectConflictsBetweenFragments(
      context,
      conflicts,
      cachedFieldsAndFragmentNames,
      comparedFragmentPairs,
      areMutuallyExclusive,
      fragmentName1,
      referencedFragmentName2
    );
  }
  for (const referencedFragmentName1 of referencedFragmentNames1) {
    collectConflictsBetweenFragments(
      context,
      conflicts,
      cachedFieldsAndFragmentNames,
      comparedFragmentPairs,
      areMutuallyExclusive,
      referencedFragmentName1,
      fragmentName2
    );
  }
}
function findConflictsBetweenSubSelectionSets(context, cachedFieldsAndFragmentNames, comparedFragmentPairs, areMutuallyExclusive, parentType1, selectionSet1, parentType2, selectionSet2) {
  const conflicts = [];
  const [fieldMap1, fragmentNames1] = getFieldsAndFragmentNames(
    context,
    cachedFieldsAndFragmentNames,
    parentType1,
    selectionSet1
  );
  const [fieldMap2, fragmentNames2] = getFieldsAndFragmentNames(
    context,
    cachedFieldsAndFragmentNames,
    parentType2,
    selectionSet2
  );
  collectConflictsBetween(
    context,
    conflicts,
    cachedFieldsAndFragmentNames,
    comparedFragmentPairs,
    areMutuallyExclusive,
    fieldMap1,
    fieldMap2
  );
  for (const fragmentName2 of fragmentNames2) {
    collectConflictsBetweenFieldsAndFragment(
      context,
      conflicts,
      cachedFieldsAndFragmentNames,
      comparedFragmentPairs,
      areMutuallyExclusive,
      fieldMap1,
      fragmentName2
    );
  }
  for (const fragmentName1 of fragmentNames1) {
    collectConflictsBetweenFieldsAndFragment(
      context,
      conflicts,
      cachedFieldsAndFragmentNames,
      comparedFragmentPairs,
      areMutuallyExclusive,
      fieldMap2,
      fragmentName1
    );
  }
  for (const fragmentName1 of fragmentNames1) {
    for (const fragmentName2 of fragmentNames2) {
      collectConflictsBetweenFragments(
        context,
        conflicts,
        cachedFieldsAndFragmentNames,
        comparedFragmentPairs,
        areMutuallyExclusive,
        fragmentName1,
        fragmentName2
      );
    }
  }
  return conflicts;
}
function collectConflictsWithin(context, conflicts, cachedFieldsAndFragmentNames, comparedFragmentPairs, fieldMap) {
  for (const [responseName, fields] of Object.entries(fieldMap)) {
    if (fields.length > 1) {
      for (let i = 0; i < fields.length; i++) {
        for (let j = i + 1; j < fields.length; j++) {
          const conflict = findConflict(
            context,
            cachedFieldsAndFragmentNames,
            comparedFragmentPairs,
            false,
            // within one collection is never mutually exclusive
            responseName,
            fields[i],
            fields[j]
          );
          if (conflict) {
            conflicts.push(conflict);
          }
        }
      }
    }
  }
}
function collectConflictsBetween(context, conflicts, cachedFieldsAndFragmentNames, comparedFragmentPairs, parentFieldsAreMutuallyExclusive, fieldMap1, fieldMap2) {
  for (const [responseName, fields1] of Object.entries(fieldMap1)) {
    const fields2 = fieldMap2[responseName];
    if (fields2) {
      for (const field1 of fields1) {
        for (const field2 of fields2) {
          const conflict = findConflict(
            context,
            cachedFieldsAndFragmentNames,
            comparedFragmentPairs,
            parentFieldsAreMutuallyExclusive,
            responseName,
            field1,
            field2
          );
          if (conflict) {
            conflicts.push(conflict);
          }
        }
      }
    }
  }
}
function findConflict(context, cachedFieldsAndFragmentNames, comparedFragmentPairs, parentFieldsAreMutuallyExclusive, responseName, field1, field2) {
  const [parentType1, node1, def1] = field1;
  const [parentType2, node2, def2] = field2;
  const areMutuallyExclusive = parentFieldsAreMutuallyExclusive || parentType1 !== parentType2 && isObjectType(parentType1) && isObjectType(parentType2);
  if (!areMutuallyExclusive) {
    const name1 = node1.name.value;
    const name2 = node2.name.value;
    if (name1 !== name2) {
      return [
        [responseName, `"${name1}" and "${name2}" are different fields`],
        [node1],
        [node2]
      ];
    }
    if (!sameArguments(node1, node2)) {
      return [
        [responseName, "they have differing arguments"],
        [node1],
        [node2]
      ];
    }
  }
  const type1 = def1 === null || def1 === void 0 ? void 0 : def1.type;
  const type2 = def2 === null || def2 === void 0 ? void 0 : def2.type;
  if (type1 && type2 && doTypesConflict(type1, type2)) {
    return [
      [
        responseName,
        `they return conflicting types "${inspect(type1)}" and "${inspect(
          type2
        )}"`
      ],
      [node1],
      [node2]
    ];
  }
  const selectionSet1 = node1.selectionSet;
  const selectionSet2 = node2.selectionSet;
  if (selectionSet1 && selectionSet2) {
    const conflicts = findConflictsBetweenSubSelectionSets(
      context,
      cachedFieldsAndFragmentNames,
      comparedFragmentPairs,
      areMutuallyExclusive,
      getNamedType(type1),
      selectionSet1,
      getNamedType(type2),
      selectionSet2
    );
    return subfieldConflicts(conflicts, responseName, node1, node2);
  }
}
function sameArguments(node1, node2) {
  const args1 = node1.arguments;
  const args2 = node2.arguments;
  if (args1 === void 0 || args1.length === 0) {
    return args2 === void 0 || args2.length === 0;
  }
  if (args2 === void 0 || args2.length === 0) {
    return false;
  }
  if (args1.length !== args2.length) {
    return false;
  }
  const values2 = new Map(args2.map(({ name, value }) => [name.value, value]));
  return args1.every((arg1) => {
    const value1 = arg1.value;
    const value2 = values2.get(arg1.name.value);
    if (value2 === void 0) {
      return false;
    }
    return stringifyValue(value1) === stringifyValue(value2);
  });
}
function stringifyValue(value) {
  return print(sortValueNode(value));
}
function doTypesConflict(type1, type2) {
  if (isListType(type1)) {
    return isListType(type2) ? doTypesConflict(type1.ofType, type2.ofType) : true;
  }
  if (isListType(type2)) {
    return true;
  }
  if (isNonNullType(type1)) {
    return isNonNullType(type2) ? doTypesConflict(type1.ofType, type2.ofType) : true;
  }
  if (isNonNullType(type2)) {
    return true;
  }
  if (isLeafType(type1) || isLeafType(type2)) {
    return type1 !== type2;
  }
  return false;
}
function getFieldsAndFragmentNames(context, cachedFieldsAndFragmentNames, parentType, selectionSet) {
  const cached = cachedFieldsAndFragmentNames.get(selectionSet);
  if (cached) {
    return cached;
  }
  const nodeAndDefs = /* @__PURE__ */ Object.create(null);
  const fragmentNames = /* @__PURE__ */ Object.create(null);
  _collectFieldsAndFragmentNames(
    context,
    parentType,
    selectionSet,
    nodeAndDefs,
    fragmentNames
  );
  const result = [nodeAndDefs, Object.keys(fragmentNames)];
  cachedFieldsAndFragmentNames.set(selectionSet, result);
  return result;
}
function getReferencedFieldsAndFragmentNames(context, cachedFieldsAndFragmentNames, fragment) {
  const cached = cachedFieldsAndFragmentNames.get(fragment.selectionSet);
  if (cached) {
    return cached;
  }
  const fragmentType = typeFromAST(context.getSchema(), fragment.typeCondition);
  return getFieldsAndFragmentNames(
    context,
    cachedFieldsAndFragmentNames,
    fragmentType,
    fragment.selectionSet
  );
}
function _collectFieldsAndFragmentNames(context, parentType, selectionSet, nodeAndDefs, fragmentNames) {
  for (const selection of selectionSet.selections) {
    switch (selection.kind) {
      case Kind.FIELD: {
        const fieldName = selection.name.value;
        let fieldDef;
        if (isObjectType(parentType) || isInterfaceType(parentType)) {
          fieldDef = parentType.getFields()[fieldName];
        }
        const responseName = selection.alias ? selection.alias.value : fieldName;
        if (!nodeAndDefs[responseName]) {
          nodeAndDefs[responseName] = [];
        }
        nodeAndDefs[responseName].push([parentType, selection, fieldDef]);
        break;
      }
      case Kind.FRAGMENT_SPREAD:
        fragmentNames[selection.name.value] = true;
        break;
      case Kind.INLINE_FRAGMENT: {
        const typeCondition = selection.typeCondition;
        const inlineFragmentType = typeCondition ? typeFromAST(context.getSchema(), typeCondition) : parentType;
        _collectFieldsAndFragmentNames(
          context,
          inlineFragmentType,
          selection.selectionSet,
          nodeAndDefs,
          fragmentNames
        );
        break;
      }
    }
  }
}
function subfieldConflicts(conflicts, responseName, node1, node2) {
  if (conflicts.length > 0) {
    return [
      [responseName, conflicts.map(([reason]) => reason)],
      [node1, ...conflicts.map(([, fields1]) => fields1).flat()],
      [node2, ...conflicts.map(([, , fields2]) => fields2).flat()]
    ];
  }
}
var PairSet = class {
  constructor() {
    this._data = /* @__PURE__ */ new Map();
  }
  has(a, b, areMutuallyExclusive) {
    var _this$_data$get;
    const [key1, key2] = a < b ? [a, b] : [b, a];
    const result = (_this$_data$get = this._data.get(key1)) === null || _this$_data$get === void 0 ? void 0 : _this$_data$get.get(key2);
    if (result === void 0) {
      return false;
    }
    return areMutuallyExclusive ? true : areMutuallyExclusive === result;
  }
  add(a, b, areMutuallyExclusive) {
    const [key1, key2] = a < b ? [a, b] : [b, a];
    const map = this._data.get(key1);
    if (map === void 0) {
      this._data.set(key1, /* @__PURE__ */ new Map([[key2, areMutuallyExclusive]]));
    } else {
      map.set(key2, areMutuallyExclusive);
    }
  }
};
function PossibleFragmentSpreadsRule(context) {
  return {
    InlineFragment(node) {
      const fragType = context.getType();
      const parentType = context.getParentType();
      if (isCompositeType(fragType) && isCompositeType(parentType) && !doTypesOverlap(context.getSchema(), fragType, parentType)) {
        const parentTypeStr = inspect(parentType);
        const fragTypeStr = inspect(fragType);
        context.reportError(
          new GraphQLError(
            `Fragment cannot be spread here as objects of type "${parentTypeStr}" can never be of type "${fragTypeStr}".`,
            {
              nodes: node
            }
          )
        );
      }
    },
    FragmentSpread(node) {
      const fragName = node.name.value;
      const fragType = getFragmentType(context, fragName);
      const parentType = context.getParentType();
      if (fragType && parentType && !doTypesOverlap(context.getSchema(), fragType, parentType)) {
        const parentTypeStr = inspect(parentType);
        const fragTypeStr = inspect(fragType);
        context.reportError(
          new GraphQLError(
            `Fragment "${fragName}" cannot be spread here as objects of type "${parentTypeStr}" can never be of type "${fragTypeStr}".`,
            {
              nodes: node
            }
          )
        );
      }
    }
  };
}
function getFragmentType(context, name) {
  const frag = context.getFragment(name);
  if (frag) {
    const type = typeFromAST(context.getSchema(), frag.typeCondition);
    if (isCompositeType(type)) {
      return type;
    }
  }
}
function PossibleTypeExtensionsRule(context) {
  const schema = context.getSchema();
  const definedTypes = /* @__PURE__ */ Object.create(null);
  for (const def of context.getDocument().definitions) {
    if (isTypeDefinitionNode(def)) {
      definedTypes[def.name.value] = def;
    }
  }
  return {
    ScalarTypeExtension: checkExtension,
    ObjectTypeExtension: checkExtension,
    InterfaceTypeExtension: checkExtension,
    UnionTypeExtension: checkExtension,
    EnumTypeExtension: checkExtension,
    InputObjectTypeExtension: checkExtension
  };
  function checkExtension(node) {
    const typeName = node.name.value;
    const defNode = definedTypes[typeName];
    const existingType = schema === null || schema === void 0 ? void 0 : schema.getType(typeName);
    let expectedKind;
    if (defNode) {
      expectedKind = defKindToExtKind[defNode.kind];
    } else if (existingType) {
      expectedKind = typeToExtKind(existingType);
    }
    if (expectedKind) {
      if (expectedKind !== node.kind) {
        const kindStr = extensionKindToTypeName(node.kind);
        context.reportError(
          new GraphQLError(`Cannot extend non-${kindStr} type "${typeName}".`, {
            nodes: defNode ? [defNode, node] : node
          })
        );
      }
    } else {
      const allTypeNames = Object.keys({
        ...definedTypes,
        ...schema === null || schema === void 0 ? void 0 : schema.getTypeMap()
      });
      const suggestedTypes = suggestionList(typeName, allTypeNames);
      context.reportError(
        new GraphQLError(
          `Cannot extend type "${typeName}" because it is not defined.` + didYouMean(suggestedTypes),
          {
            nodes: node.name
          }
        )
      );
    }
  }
}
var defKindToExtKind = {
  [Kind.SCALAR_TYPE_DEFINITION]: Kind.SCALAR_TYPE_EXTENSION,
  [Kind.OBJECT_TYPE_DEFINITION]: Kind.OBJECT_TYPE_EXTENSION,
  [Kind.INTERFACE_TYPE_DEFINITION]: Kind.INTERFACE_TYPE_EXTENSION,
  [Kind.UNION_TYPE_DEFINITION]: Kind.UNION_TYPE_EXTENSION,
  [Kind.ENUM_TYPE_DEFINITION]: Kind.ENUM_TYPE_EXTENSION,
  [Kind.INPUT_OBJECT_TYPE_DEFINITION]: Kind.INPUT_OBJECT_TYPE_EXTENSION
};
function typeToExtKind(type) {
  if (isScalarType(type)) {
    return Kind.SCALAR_TYPE_EXTENSION;
  }
  if (isObjectType(type)) {
    return Kind.OBJECT_TYPE_EXTENSION;
  }
  if (isInterfaceType(type)) {
    return Kind.INTERFACE_TYPE_EXTENSION;
  }
  if (isUnionType(type)) {
    return Kind.UNION_TYPE_EXTENSION;
  }
  if (isEnumType(type)) {
    return Kind.ENUM_TYPE_EXTENSION;
  }
  if (isInputObjectType(type)) {
    return Kind.INPUT_OBJECT_TYPE_EXTENSION;
  }
  invariant2(false, "Unexpected type: " + inspect(type));
}
function extensionKindToTypeName(kind) {
  switch (kind) {
    case Kind.SCALAR_TYPE_EXTENSION:
      return "scalar";
    case Kind.OBJECT_TYPE_EXTENSION:
      return "object";
    case Kind.INTERFACE_TYPE_EXTENSION:
      return "interface";
    case Kind.UNION_TYPE_EXTENSION:
      return "union";
    case Kind.ENUM_TYPE_EXTENSION:
      return "enum";
    case Kind.INPUT_OBJECT_TYPE_EXTENSION:
      return "input object";
    default:
      invariant2(false, "Unexpected kind: " + inspect(kind));
  }
}
function ProvidedRequiredArgumentsRule(context) {
  return {
    // eslint-disable-next-line new-cap
    ...ProvidedRequiredArgumentsOnDirectivesRule(context),
    Field: {
      // Validate on leave to allow for deeper errors to appear first.
      leave(fieldNode) {
        var _fieldNode$arguments;
        const fieldDef = context.getFieldDef();
        if (!fieldDef) {
          return false;
        }
        const providedArgs = new Set(
          // FIXME: https://github.com/graphql/graphql-js/issues/2203
          /* c8 ignore next */
          (_fieldNode$arguments = fieldNode.arguments) === null || _fieldNode$arguments === void 0 ? void 0 : _fieldNode$arguments.map((arg) => arg.name.value)
        );
        for (const argDef of fieldDef.args) {
          if (!providedArgs.has(argDef.name) && isRequiredArgument(argDef)) {
            const argTypeStr = inspect(argDef.type);
            context.reportError(
              new GraphQLError(
                `Field "${fieldDef.name}" argument "${argDef.name}" of type "${argTypeStr}" is required, but it was not provided.`,
                {
                  nodes: fieldNode
                }
              )
            );
          }
        }
      }
    }
  };
}
function ProvidedRequiredArgumentsOnDirectivesRule(context) {
  var _schema$getDirectives;
  const requiredArgsMap = /* @__PURE__ */ Object.create(null);
  const schema = context.getSchema();
  const definedDirectives = (_schema$getDirectives = schema === null || schema === void 0 ? void 0 : schema.getDirectives()) !== null && _schema$getDirectives !== void 0 ? _schema$getDirectives : specifiedDirectives;
  for (const directive of definedDirectives) {
    requiredArgsMap[directive.name] = keyMap(
      directive.args.filter(isRequiredArgument),
      (arg) => arg.name
    );
  }
  const astDefinitions = context.getDocument().definitions;
  for (const def of astDefinitions) {
    if (def.kind === Kind.DIRECTIVE_DEFINITION) {
      var _def$arguments;
      const argNodes = (_def$arguments = def.arguments) !== null && _def$arguments !== void 0 ? _def$arguments : [];
      requiredArgsMap[def.name.value] = keyMap(
        argNodes.filter(isRequiredArgumentNode),
        (arg) => arg.name.value
      );
    }
  }
  return {
    Directive: {
      // Validate on leave to allow for deeper errors to appear first.
      leave(directiveNode) {
        const directiveName = directiveNode.name.value;
        const requiredArgs = requiredArgsMap[directiveName];
        if (requiredArgs) {
          var _directiveNode$argume;
          const argNodes = (_directiveNode$argume = directiveNode.arguments) !== null && _directiveNode$argume !== void 0 ? _directiveNode$argume : [];
          const argNodeMap = new Set(argNodes.map((arg) => arg.name.value));
          for (const [argName, argDef] of Object.entries(requiredArgs)) {
            if (!argNodeMap.has(argName)) {
              const argType = isType(argDef.type) ? inspect(argDef.type) : print(argDef.type);
              context.reportError(
                new GraphQLError(
                  `Directive "@${directiveName}" argument "${argName}" of type "${argType}" is required, but it was not provided.`,
                  {
                    nodes: directiveNode
                  }
                )
              );
            }
          }
        }
      }
    }
  };
}
function isRequiredArgumentNode(arg) {
  return arg.type.kind === Kind.NON_NULL_TYPE && arg.defaultValue == null;
}
function ScalarLeafsRule(context) {
  return {
    Field(node) {
      const type = context.getType();
      const selectionSet = node.selectionSet;
      if (type) {
        if (isLeafType(getNamedType(type))) {
          if (selectionSet) {
            const fieldName = node.name.value;
            const typeStr = inspect(type);
            context.reportError(
              new GraphQLError(
                `Field "${fieldName}" must not have a selection since type "${typeStr}" has no subfields.`,
                {
                  nodes: selectionSet
                }
              )
            );
          }
        } else if (!selectionSet) {
          const fieldName = node.name.value;
          const typeStr = inspect(type);
          context.reportError(
            new GraphQLError(
              `Field "${fieldName}" of type "${typeStr}" must have a selection of subfields. Did you mean "${fieldName} { ... }"?`,
              {
                nodes: node
              }
            )
          );
        }
      }
    }
  };
}
function valueFromAST(valueNode, type, variables) {
  if (!valueNode) {
    return;
  }
  if (valueNode.kind === Kind.VARIABLE) {
    const variableName = valueNode.name.value;
    if (variables == null || variables[variableName] === void 0) {
      return;
    }
    const variableValue = variables[variableName];
    if (variableValue === null && isNonNullType(type)) {
      return;
    }
    return variableValue;
  }
  if (isNonNullType(type)) {
    if (valueNode.kind === Kind.NULL) {
      return;
    }
    return valueFromAST(valueNode, type.ofType, variables);
  }
  if (valueNode.kind === Kind.NULL) {
    return null;
  }
  if (isListType(type)) {
    const itemType = type.ofType;
    if (valueNode.kind === Kind.LIST) {
      const coercedValues = [];
      for (const itemNode of valueNode.values) {
        if (isMissingVariable(itemNode, variables)) {
          if (isNonNullType(itemType)) {
            return;
          }
          coercedValues.push(null);
        } else {
          const itemValue = valueFromAST(itemNode, itemType, variables);
          if (itemValue === void 0) {
            return;
          }
          coercedValues.push(itemValue);
        }
      }
      return coercedValues;
    }
    const coercedValue = valueFromAST(valueNode, itemType, variables);
    if (coercedValue === void 0) {
      return;
    }
    return [coercedValue];
  }
  if (isInputObjectType(type)) {
    if (valueNode.kind !== Kind.OBJECT) {
      return;
    }
    const coercedObj = /* @__PURE__ */ Object.create(null);
    const fieldNodes = keyMap(valueNode.fields, (field) => field.name.value);
    for (const field of Object.values(type.getFields())) {
      const fieldNode = fieldNodes[field.name];
      if (!fieldNode || isMissingVariable(fieldNode.value, variables)) {
        if (field.defaultValue !== void 0) {
          coercedObj[field.name] = field.defaultValue;
        } else if (isNonNullType(field.type)) {
          return;
        }
        continue;
      }
      const fieldValue = valueFromAST(fieldNode.value, field.type, variables);
      if (fieldValue === void 0) {
        return;
      }
      coercedObj[field.name] = fieldValue;
    }
    return coercedObj;
  }
  if (isLeafType(type)) {
    let result;
    try {
      result = type.parseLiteral(valueNode, variables);
    } catch (_error) {
      return;
    }
    if (result === void 0) {
      return;
    }
    return result;
  }
  invariant2(false, "Unexpected input type: " + inspect(type));
}
function isMissingVariable(valueNode, variables) {
  return valueNode.kind === Kind.VARIABLE && (variables == null || variables[valueNode.name.value] === void 0);
}
function getArgumentValues(def, node, variableValues) {
  var _node$arguments;
  const coercedValues = {};
  const argumentNodes = (_node$arguments = node.arguments) !== null && _node$arguments !== void 0 ? _node$arguments : [];
  const argNodeMap = keyMap(argumentNodes, (arg) => arg.name.value);
  for (const argDef of def.args) {
    const name = argDef.name;
    const argType = argDef.type;
    const argumentNode = argNodeMap[name];
    if (!argumentNode) {
      if (argDef.defaultValue !== void 0) {
        coercedValues[name] = argDef.defaultValue;
      } else if (isNonNullType(argType)) {
        throw new GraphQLError(
          `Argument "${name}" of required type "${inspect(argType)}" was not provided.`,
          {
            nodes: node
          }
        );
      }
      continue;
    }
    const valueNode = argumentNode.value;
    let isNull = valueNode.kind === Kind.NULL;
    if (valueNode.kind === Kind.VARIABLE) {
      const variableName = valueNode.name.value;
      if (variableValues == null || !hasOwnProperty(variableValues, variableName)) {
        if (argDef.defaultValue !== void 0) {
          coercedValues[name] = argDef.defaultValue;
        } else if (isNonNullType(argType)) {
          throw new GraphQLError(
            `Argument "${name}" of required type "${inspect(argType)}" was provided the variable "$${variableName}" which was not provided a runtime value.`,
            {
              nodes: valueNode
            }
          );
        }
        continue;
      }
      isNull = variableValues[variableName] == null;
    }
    if (isNull && isNonNullType(argType)) {
      throw new GraphQLError(
        `Argument "${name}" of non-null type "${inspect(argType)}" must not be null.`,
        {
          nodes: valueNode
        }
      );
    }
    const coercedValue = valueFromAST(valueNode, argType, variableValues);
    if (coercedValue === void 0) {
      throw new GraphQLError(
        `Argument "${name}" has invalid value ${print(valueNode)}.`,
        {
          nodes: valueNode
        }
      );
    }
    coercedValues[name] = coercedValue;
  }
  return coercedValues;
}
function getDirectiveValues(directiveDef, node, variableValues) {
  var _node$directives;
  const directiveNode = (_node$directives = node.directives) === null || _node$directives === void 0 ? void 0 : _node$directives.find(
    (directive) => directive.name.value === directiveDef.name
  );
  if (directiveNode) {
    return getArgumentValues(directiveDef, directiveNode, variableValues);
  }
}
function hasOwnProperty(obj, prop) {
  return Object.prototype.hasOwnProperty.call(obj, prop);
}
function collectFields(schema, fragments, variableValues, runtimeType, selectionSet) {
  const fields = /* @__PURE__ */ new Map();
  collectFieldsImpl(
    schema,
    fragments,
    variableValues,
    runtimeType,
    selectionSet,
    fields,
    /* @__PURE__ */ new Set()
  );
  return fields;
}
function collectSubfields(schema, fragments, variableValues, returnType, fieldNodes) {
  const subFieldNodes = /* @__PURE__ */ new Map();
  const visitedFragmentNames = /* @__PURE__ */ new Set();
  for (const node of fieldNodes) {
    if (node.selectionSet) {
      collectFieldsImpl(
        schema,
        fragments,
        variableValues,
        returnType,
        node.selectionSet,
        subFieldNodes,
        visitedFragmentNames
      );
    }
  }
  return subFieldNodes;
}
function collectFieldsImpl(schema, fragments, variableValues, runtimeType, selectionSet, fields, visitedFragmentNames) {
  for (const selection of selectionSet.selections) {
    switch (selection.kind) {
      case Kind.FIELD: {
        if (!shouldIncludeNode(variableValues, selection)) {
          continue;
        }
        const name = getFieldEntryKey(selection);
        const fieldList = fields.get(name);
        if (fieldList !== void 0) {
          fieldList.push(selection);
        } else {
          fields.set(name, [selection]);
        }
        break;
      }
      case Kind.INLINE_FRAGMENT: {
        if (!shouldIncludeNode(variableValues, selection) || !doesFragmentConditionMatch(schema, selection, runtimeType)) {
          continue;
        }
        collectFieldsImpl(
          schema,
          fragments,
          variableValues,
          runtimeType,
          selection.selectionSet,
          fields,
          visitedFragmentNames
        );
        break;
      }
      case Kind.FRAGMENT_SPREAD: {
        const fragName = selection.name.value;
        if (visitedFragmentNames.has(fragName) || !shouldIncludeNode(variableValues, selection)) {
          continue;
        }
        visitedFragmentNames.add(fragName);
        const fragment = fragments[fragName];
        if (!fragment || !doesFragmentConditionMatch(schema, fragment, runtimeType)) {
          continue;
        }
        collectFieldsImpl(
          schema,
          fragments,
          variableValues,
          runtimeType,
          fragment.selectionSet,
          fields,
          visitedFragmentNames
        );
        break;
      }
    }
  }
}
function shouldIncludeNode(variableValues, node) {
  const skip = getDirectiveValues(GraphQLSkipDirective, node, variableValues);
  if ((skip === null || skip === void 0 ? void 0 : skip.if) === true) {
    return false;
  }
  const include = getDirectiveValues(
    GraphQLIncludeDirective,
    node,
    variableValues
  );
  if ((include === null || include === void 0 ? void 0 : include.if) === false) {
    return false;
  }
  return true;
}
function doesFragmentConditionMatch(schema, fragment, type) {
  const typeConditionNode = fragment.typeCondition;
  if (!typeConditionNode) {
    return true;
  }
  const conditionalType = typeFromAST(schema, typeConditionNode);
  if (conditionalType === type) {
    return true;
  }
  if (isAbstractType(conditionalType)) {
    return schema.isSubType(conditionalType, type);
  }
  return false;
}
function getFieldEntryKey(node) {
  return node.alias ? node.alias.value : node.name.value;
}
function SingleFieldSubscriptionsRule(context) {
  return {
    OperationDefinition(node) {
      if (node.operation === "subscription") {
        const schema = context.getSchema();
        const subscriptionType = schema.getSubscriptionType();
        if (subscriptionType) {
          const operationName = node.name ? node.name.value : null;
          const variableValues = /* @__PURE__ */ Object.create(null);
          const document2 = context.getDocument();
          const fragments = /* @__PURE__ */ Object.create(null);
          for (const definition of document2.definitions) {
            if (definition.kind === Kind.FRAGMENT_DEFINITION) {
              fragments[definition.name.value] = definition;
            }
          }
          const fields = collectFields(
            schema,
            fragments,
            variableValues,
            subscriptionType,
            node.selectionSet
          );
          if (fields.size > 1) {
            const fieldSelectionLists = [...fields.values()];
            const extraFieldSelectionLists = fieldSelectionLists.slice(1);
            const extraFieldSelections = extraFieldSelectionLists.flat();
            context.reportError(
              new GraphQLError(
                operationName != null ? `Subscription "${operationName}" must select only one top level field.` : "Anonymous Subscription must select only one top level field.",
                {
                  nodes: extraFieldSelections
                }
              )
            );
          }
          for (const fieldNodes of fields.values()) {
            const field = fieldNodes[0];
            const fieldName = field.name.value;
            if (fieldName.startsWith("__")) {
              context.reportError(
                new GraphQLError(
                  operationName != null ? `Subscription "${operationName}" must not select an introspection top level field.` : "Anonymous Subscription must not select an introspection top level field.",
                  {
                    nodes: fieldNodes
                  }
                )
              );
            }
          }
        }
      }
    }
  };
}
function groupBy(list, keyFn) {
  const result = /* @__PURE__ */ new Map();
  for (const item of list) {
    const key = keyFn(item);
    const group = result.get(key);
    if (group === void 0) {
      result.set(key, [item]);
    } else {
      group.push(item);
    }
  }
  return result;
}
function UniqueArgumentDefinitionNamesRule(context) {
  return {
    DirectiveDefinition(directiveNode) {
      var _directiveNode$argume;
      const argumentNodes = (_directiveNode$argume = directiveNode.arguments) !== null && _directiveNode$argume !== void 0 ? _directiveNode$argume : [];
      return checkArgUniqueness(`@${directiveNode.name.value}`, argumentNodes);
    },
    InterfaceTypeDefinition: checkArgUniquenessPerField,
    InterfaceTypeExtension: checkArgUniquenessPerField,
    ObjectTypeDefinition: checkArgUniquenessPerField,
    ObjectTypeExtension: checkArgUniquenessPerField
  };
  function checkArgUniquenessPerField(typeNode) {
    var _typeNode$fields;
    const typeName = typeNode.name.value;
    const fieldNodes = (_typeNode$fields = typeNode.fields) !== null && _typeNode$fields !== void 0 ? _typeNode$fields : [];
    for (const fieldDef of fieldNodes) {
      var _fieldDef$arguments;
      const fieldName = fieldDef.name.value;
      const argumentNodes = (_fieldDef$arguments = fieldDef.arguments) !== null && _fieldDef$arguments !== void 0 ? _fieldDef$arguments : [];
      checkArgUniqueness(`${typeName}.${fieldName}`, argumentNodes);
    }
    return false;
  }
  function checkArgUniqueness(parentName, argumentNodes) {
    const seenArgs = groupBy(argumentNodes, (arg) => arg.name.value);
    for (const [argName, argNodes] of seenArgs) {
      if (argNodes.length > 1) {
        context.reportError(
          new GraphQLError(
            `Argument "${parentName}(${argName}:)" can only be defined once.`,
            {
              nodes: argNodes.map((node) => node.name)
            }
          )
        );
      }
    }
    return false;
  }
}
function UniqueArgumentNamesRule(context) {
  return {
    Field: checkArgUniqueness,
    Directive: checkArgUniqueness
  };
  function checkArgUniqueness(parentNode) {
    var _parentNode$arguments;
    const argumentNodes = (_parentNode$arguments = parentNode.arguments) !== null && _parentNode$arguments !== void 0 ? _parentNode$arguments : [];
    const seenArgs = groupBy(argumentNodes, (arg) => arg.name.value);
    for (const [argName, argNodes] of seenArgs) {
      if (argNodes.length > 1) {
        context.reportError(
          new GraphQLError(
            `There can be only one argument named "${argName}".`,
            {
              nodes: argNodes.map((node) => node.name)
            }
          )
        );
      }
    }
  }
}
function UniqueDirectiveNamesRule(context) {
  const knownDirectiveNames = /* @__PURE__ */ Object.create(null);
  const schema = context.getSchema();
  return {
    DirectiveDefinition(node) {
      const directiveName = node.name.value;
      if (schema !== null && schema !== void 0 && schema.getDirective(directiveName)) {
        context.reportError(
          new GraphQLError(
            `Directive "@${directiveName}" already exists in the schema. It cannot be redefined.`,
            {
              nodes: node.name
            }
          )
        );
        return;
      }
      if (knownDirectiveNames[directiveName]) {
        context.reportError(
          new GraphQLError(
            `There can be only one directive named "@${directiveName}".`,
            {
              nodes: [knownDirectiveNames[directiveName], node.name]
            }
          )
        );
      } else {
        knownDirectiveNames[directiveName] = node.name;
      }
      return false;
    }
  };
}
function UniqueDirectivesPerLocationRule(context) {
  const uniqueDirectiveMap = /* @__PURE__ */ Object.create(null);
  const schema = context.getSchema();
  const definedDirectives = schema ? schema.getDirectives() : specifiedDirectives;
  for (const directive of definedDirectives) {
    uniqueDirectiveMap[directive.name] = !directive.isRepeatable;
  }
  const astDefinitions = context.getDocument().definitions;
  for (const def of astDefinitions) {
    if (def.kind === Kind.DIRECTIVE_DEFINITION) {
      uniqueDirectiveMap[def.name.value] = !def.repeatable;
    }
  }
  const schemaDirectives = /* @__PURE__ */ Object.create(null);
  const typeDirectivesMap = /* @__PURE__ */ Object.create(null);
  return {
    // Many different AST nodes may contain directives. Rather than listing
    // them all, just listen for entering any node, and check to see if it
    // defines any directives.
    enter(node) {
      if (!("directives" in node) || !node.directives) {
        return;
      }
      let seenDirectives;
      if (node.kind === Kind.SCHEMA_DEFINITION || node.kind === Kind.SCHEMA_EXTENSION) {
        seenDirectives = schemaDirectives;
      } else if (isTypeDefinitionNode(node) || isTypeExtensionNode(node)) {
        const typeName = node.name.value;
        seenDirectives = typeDirectivesMap[typeName];
        if (seenDirectives === void 0) {
          typeDirectivesMap[typeName] = seenDirectives = /* @__PURE__ */ Object.create(null);
        }
      } else {
        seenDirectives = /* @__PURE__ */ Object.create(null);
      }
      for (const directive of node.directives) {
        const directiveName = directive.name.value;
        if (uniqueDirectiveMap[directiveName]) {
          if (seenDirectives[directiveName]) {
            context.reportError(
              new GraphQLError(
                `The directive "@${directiveName}" can only be used once at this location.`,
                {
                  nodes: [seenDirectives[directiveName], directive]
                }
              )
            );
          } else {
            seenDirectives[directiveName] = directive;
          }
        }
      }
    }
  };
}
function UniqueEnumValueNamesRule(context) {
  const schema = context.getSchema();
  const existingTypeMap = schema ? schema.getTypeMap() : /* @__PURE__ */ Object.create(null);
  const knownValueNames = /* @__PURE__ */ Object.create(null);
  return {
    EnumTypeDefinition: checkValueUniqueness,
    EnumTypeExtension: checkValueUniqueness
  };
  function checkValueUniqueness(node) {
    var _node$values;
    const typeName = node.name.value;
    if (!knownValueNames[typeName]) {
      knownValueNames[typeName] = /* @__PURE__ */ Object.create(null);
    }
    const valueNodes = (_node$values = node.values) !== null && _node$values !== void 0 ? _node$values : [];
    const valueNames = knownValueNames[typeName];
    for (const valueDef of valueNodes) {
      const valueName = valueDef.name.value;
      const existingType = existingTypeMap[typeName];
      if (isEnumType(existingType) && existingType.getValue(valueName)) {
        context.reportError(
          new GraphQLError(
            `Enum value "${typeName}.${valueName}" already exists in the schema. It cannot also be defined in this type extension.`,
            {
              nodes: valueDef.name
            }
          )
        );
      } else if (valueNames[valueName]) {
        context.reportError(
          new GraphQLError(
            `Enum value "${typeName}.${valueName}" can only be defined once.`,
            {
              nodes: [valueNames[valueName], valueDef.name]
            }
          )
        );
      } else {
        valueNames[valueName] = valueDef.name;
      }
    }
    return false;
  }
}
function UniqueFieldDefinitionNamesRule(context) {
  const schema = context.getSchema();
  const existingTypeMap = schema ? schema.getTypeMap() : /* @__PURE__ */ Object.create(null);
  const knownFieldNames = /* @__PURE__ */ Object.create(null);
  return {
    InputObjectTypeDefinition: checkFieldUniqueness,
    InputObjectTypeExtension: checkFieldUniqueness,
    InterfaceTypeDefinition: checkFieldUniqueness,
    InterfaceTypeExtension: checkFieldUniqueness,
    ObjectTypeDefinition: checkFieldUniqueness,
    ObjectTypeExtension: checkFieldUniqueness
  };
  function checkFieldUniqueness(node) {
    var _node$fields;
    const typeName = node.name.value;
    if (!knownFieldNames[typeName]) {
      knownFieldNames[typeName] = /* @__PURE__ */ Object.create(null);
    }
    const fieldNodes = (_node$fields = node.fields) !== null && _node$fields !== void 0 ? _node$fields : [];
    const fieldNames = knownFieldNames[typeName];
    for (const fieldDef of fieldNodes) {
      const fieldName = fieldDef.name.value;
      if (hasField(existingTypeMap[typeName], fieldName)) {
        context.reportError(
          new GraphQLError(
            `Field "${typeName}.${fieldName}" already exists in the schema. It cannot also be defined in this type extension.`,
            {
              nodes: fieldDef.name
            }
          )
        );
      } else if (fieldNames[fieldName]) {
        context.reportError(
          new GraphQLError(
            `Field "${typeName}.${fieldName}" can only be defined once.`,
            {
              nodes: [fieldNames[fieldName], fieldDef.name]
            }
          )
        );
      } else {
        fieldNames[fieldName] = fieldDef.name;
      }
    }
    return false;
  }
}
function hasField(type, fieldName) {
  if (isObjectType(type) || isInterfaceType(type) || isInputObjectType(type)) {
    return type.getFields()[fieldName] != null;
  }
  return false;
}
function UniqueFragmentNamesRule(context) {
  const knownFragmentNames = /* @__PURE__ */ Object.create(null);
  return {
    OperationDefinition: () => false,
    FragmentDefinition(node) {
      const fragmentName = node.name.value;
      if (knownFragmentNames[fragmentName]) {
        context.reportError(
          new GraphQLError(
            `There can be only one fragment named "${fragmentName}".`,
            {
              nodes: [knownFragmentNames[fragmentName], node.name]
            }
          )
        );
      } else {
        knownFragmentNames[fragmentName] = node.name;
      }
      return false;
    }
  };
}
function UniqueInputFieldNamesRule(context) {
  const knownNameStack = [];
  let knownNames = /* @__PURE__ */ Object.create(null);
  return {
    ObjectValue: {
      enter() {
        knownNameStack.push(knownNames);
        knownNames = /* @__PURE__ */ Object.create(null);
      },
      leave() {
        const prevKnownNames = knownNameStack.pop();
        prevKnownNames || invariant2(false);
        knownNames = prevKnownNames;
      }
    },
    ObjectField(node) {
      const fieldName = node.name.value;
      if (knownNames[fieldName]) {
        context.reportError(
          new GraphQLError(
            `There can be only one input field named "${fieldName}".`,
            {
              nodes: [knownNames[fieldName], node.name]
            }
          )
        );
      } else {
        knownNames[fieldName] = node.name;
      }
    }
  };
}
function UniqueOperationNamesRule(context) {
  const knownOperationNames = /* @__PURE__ */ Object.create(null);
  return {
    OperationDefinition(node) {
      const operationName = node.name;
      if (operationName) {
        if (knownOperationNames[operationName.value]) {
          context.reportError(
            new GraphQLError(
              `There can be only one operation named "${operationName.value}".`,
              {
                nodes: [
                  knownOperationNames[operationName.value],
                  operationName
                ]
              }
            )
          );
        } else {
          knownOperationNames[operationName.value] = operationName;
        }
      }
      return false;
    },
    FragmentDefinition: () => false
  };
}
function UniqueOperationTypesRule(context) {
  const schema = context.getSchema();
  const definedOperationTypes = /* @__PURE__ */ Object.create(null);
  const existingOperationTypes = schema ? {
    query: schema.getQueryType(),
    mutation: schema.getMutationType(),
    subscription: schema.getSubscriptionType()
  } : {};
  return {
    SchemaDefinition: checkOperationTypes,
    SchemaExtension: checkOperationTypes
  };
  function checkOperationTypes(node) {
    var _node$operationTypes;
    const operationTypesNodes = (_node$operationTypes = node.operationTypes) !== null && _node$operationTypes !== void 0 ? _node$operationTypes : [];
    for (const operationType of operationTypesNodes) {
      const operation = operationType.operation;
      const alreadyDefinedOperationType = definedOperationTypes[operation];
      if (existingOperationTypes[operation]) {
        context.reportError(
          new GraphQLError(
            `Type for ${operation} already defined in the schema. It cannot be redefined.`,
            {
              nodes: operationType
            }
          )
        );
      } else if (alreadyDefinedOperationType) {
        context.reportError(
          new GraphQLError(
            `There can be only one ${operation} type in schema.`,
            {
              nodes: [alreadyDefinedOperationType, operationType]
            }
          )
        );
      } else {
        definedOperationTypes[operation] = operationType;
      }
    }
    return false;
  }
}
function UniqueTypeNamesRule(context) {
  const knownTypeNames = /* @__PURE__ */ Object.create(null);
  const schema = context.getSchema();
  return {
    ScalarTypeDefinition: checkTypeName,
    ObjectTypeDefinition: checkTypeName,
    InterfaceTypeDefinition: checkTypeName,
    UnionTypeDefinition: checkTypeName,
    EnumTypeDefinition: checkTypeName,
    InputObjectTypeDefinition: checkTypeName
  };
  function checkTypeName(node) {
    const typeName = node.name.value;
    if (schema !== null && schema !== void 0 && schema.getType(typeName)) {
      context.reportError(
        new GraphQLError(
          `Type "${typeName}" already exists in the schema. It cannot also be defined in this type definition.`,
          {
            nodes: node.name
          }
        )
      );
      return;
    }
    if (knownTypeNames[typeName]) {
      context.reportError(
        new GraphQLError(`There can be only one type named "${typeName}".`, {
          nodes: [knownTypeNames[typeName], node.name]
        })
      );
    } else {
      knownTypeNames[typeName] = node.name;
    }
    return false;
  }
}
function UniqueVariableNamesRule(context) {
  return {
    OperationDefinition(operationNode) {
      var _operationNode$variab;
      const variableDefinitions = (_operationNode$variab = operationNode.variableDefinitions) !== null && _operationNode$variab !== void 0 ? _operationNode$variab : [];
      const seenVariableDefinitions = groupBy(
        variableDefinitions,
        (node) => node.variable.name.value
      );
      for (const [variableName, variableNodes] of seenVariableDefinitions) {
        if (variableNodes.length > 1) {
          context.reportError(
            new GraphQLError(
              `There can be only one variable named "$${variableName}".`,
              {
                nodes: variableNodes.map((node) => node.variable.name)
              }
            )
          );
        }
      }
    }
  };
}
function ValuesOfCorrectTypeRule(context) {
  return {
    ListValue(node) {
      const type = getNullableType(context.getParentInputType());
      if (!isListType(type)) {
        isValidValueNode(context, node);
        return false;
      }
    },
    ObjectValue(node) {
      const type = getNamedType(context.getInputType());
      if (!isInputObjectType(type)) {
        isValidValueNode(context, node);
        return false;
      }
      const fieldNodeMap = keyMap(node.fields, (field) => field.name.value);
      for (const fieldDef of Object.values(type.getFields())) {
        const fieldNode = fieldNodeMap[fieldDef.name];
        if (!fieldNode && isRequiredInputField(fieldDef)) {
          const typeStr = inspect(fieldDef.type);
          context.reportError(
            new GraphQLError(
              `Field "${type.name}.${fieldDef.name}" of required type "${typeStr}" was not provided.`,
              {
                nodes: node
              }
            )
          );
        }
      }
    },
    ObjectField(node) {
      const parentType = getNamedType(context.getParentInputType());
      const fieldType = context.getInputType();
      if (!fieldType && isInputObjectType(parentType)) {
        const suggestions = suggestionList(
          node.name.value,
          Object.keys(parentType.getFields())
        );
        context.reportError(
          new GraphQLError(
            `Field "${node.name.value}" is not defined by type "${parentType.name}".` + didYouMean(suggestions),
            {
              nodes: node
            }
          )
        );
      }
    },
    NullValue(node) {
      const type = context.getInputType();
      if (isNonNullType(type)) {
        context.reportError(
          new GraphQLError(
            `Expected value of type "${inspect(type)}", found ${print(node)}.`,
            {
              nodes: node
            }
          )
        );
      }
    },
    EnumValue: (node) => isValidValueNode(context, node),
    IntValue: (node) => isValidValueNode(context, node),
    FloatValue: (node) => isValidValueNode(context, node),
    StringValue: (node) => isValidValueNode(context, node),
    BooleanValue: (node) => isValidValueNode(context, node)
  };
}
function isValidValueNode(context, node) {
  const locationType = context.getInputType();
  if (!locationType) {
    return;
  }
  const type = getNamedType(locationType);
  if (!isLeafType(type)) {
    const typeStr = inspect(locationType);
    context.reportError(
      new GraphQLError(
        `Expected value of type "${typeStr}", found ${print(node)}.`,
        {
          nodes: node
        }
      )
    );
    return;
  }
  try {
    const parseResult = type.parseLiteral(
      node,
      void 0
      /* variables */
    );
    if (parseResult === void 0) {
      const typeStr = inspect(locationType);
      context.reportError(
        new GraphQLError(
          `Expected value of type "${typeStr}", found ${print(node)}.`,
          {
            nodes: node
          }
        )
      );
    }
  } catch (error) {
    const typeStr = inspect(locationType);
    if (error instanceof GraphQLError) {
      context.reportError(error);
    } else {
      context.reportError(
        new GraphQLError(
          `Expected value of type "${typeStr}", found ${print(node)}; ` + error.message,
          {
            nodes: node,
            originalError: error
          }
        )
      );
    }
  }
}
function VariablesAreInputTypesRule(context) {
  return {
    VariableDefinition(node) {
      const type = typeFromAST(context.getSchema(), node.type);
      if (type !== void 0 && !isInputType(type)) {
        const variableName = node.variable.name.value;
        const typeName = print(node.type);
        context.reportError(
          new GraphQLError(
            `Variable "$${variableName}" cannot be non-input type "${typeName}".`,
            {
              nodes: node.type
            }
          )
        );
      }
    }
  };
}
function VariablesInAllowedPositionRule(context) {
  let varDefMap = /* @__PURE__ */ Object.create(null);
  return {
    OperationDefinition: {
      enter() {
        varDefMap = /* @__PURE__ */ Object.create(null);
      },
      leave(operation) {
        const usages = context.getRecursiveVariableUsages(operation);
        for (const { node, type, defaultValue } of usages) {
          const varName = node.name.value;
          const varDef = varDefMap[varName];
          if (varDef && type) {
            const schema = context.getSchema();
            const varType = typeFromAST(schema, varDef.type);
            if (varType && !allowedVariableUsage(
              schema,
              varType,
              varDef.defaultValue,
              type,
              defaultValue
            )) {
              const varTypeStr = inspect(varType);
              const typeStr = inspect(type);
              context.reportError(
                new GraphQLError(
                  `Variable "$${varName}" of type "${varTypeStr}" used in position expecting type "${typeStr}".`,
                  {
                    nodes: [varDef, node]
                  }
                )
              );
            }
          }
        }
      }
    },
    VariableDefinition(node) {
      varDefMap[node.variable.name.value] = node;
    }
  };
}
function allowedVariableUsage(schema, varType, varDefaultValue, locationType, locationDefaultValue) {
  if (isNonNullType(locationType) && !isNonNullType(varType)) {
    const hasNonNullVariableDefaultValue = varDefaultValue != null && varDefaultValue.kind !== Kind.NULL;
    const hasLocationDefaultValue = locationDefaultValue !== void 0;
    if (!hasNonNullVariableDefaultValue && !hasLocationDefaultValue) {
      return false;
    }
    const nullableLocationType = locationType.ofType;
    return isTypeSubTypeOf(schema, varType, nullableLocationType);
  }
  return isTypeSubTypeOf(schema, varType, locationType);
}
var specifiedRules = Object.freeze([
  ExecutableDefinitionsRule,
  UniqueOperationNamesRule,
  LoneAnonymousOperationRule,
  SingleFieldSubscriptionsRule,
  KnownTypeNamesRule,
  FragmentsOnCompositeTypesRule,
  VariablesAreInputTypesRule,
  ScalarLeafsRule,
  FieldsOnCorrectTypeRule,
  UniqueFragmentNamesRule,
  KnownFragmentNamesRule,
  NoUnusedFragmentsRule,
  PossibleFragmentSpreadsRule,
  NoFragmentCyclesRule,
  UniqueVariableNamesRule,
  NoUndefinedVariablesRule,
  NoUnusedVariablesRule,
  KnownDirectivesRule,
  UniqueDirectivesPerLocationRule,
  KnownArgumentNamesRule,
  UniqueArgumentNamesRule,
  ValuesOfCorrectTypeRule,
  ProvidedRequiredArgumentsRule,
  VariablesInAllowedPositionRule,
  OverlappingFieldsCanBeMergedRule,
  UniqueInputFieldNamesRule
]);
var specifiedSDLRules = Object.freeze([
  LoneSchemaDefinitionRule,
  UniqueOperationTypesRule,
  UniqueTypeNamesRule,
  UniqueEnumValueNamesRule,
  UniqueFieldDefinitionNamesRule,
  UniqueArgumentDefinitionNamesRule,
  UniqueDirectiveNamesRule,
  KnownTypeNamesRule,
  KnownDirectivesRule,
  UniqueDirectivesPerLocationRule,
  PossibleTypeExtensionsRule,
  KnownArgumentNamesOnDirectivesRule,
  UniqueArgumentNamesRule,
  UniqueInputFieldNamesRule,
  ProvidedRequiredArgumentsOnDirectivesRule
]);
function memoize3(fn) {
  let cache0;
  return function memoized(a1, a2, a3) {
    if (cache0 === void 0) {
      cache0 = /* @__PURE__ */ new WeakMap();
    }
    let cache1 = cache0.get(a1);
    if (cache1 === void 0) {
      cache1 = /* @__PURE__ */ new WeakMap();
      cache0.set(a1, cache1);
    }
    let cache2 = cache1.get(a2);
    if (cache2 === void 0) {
      cache2 = /* @__PURE__ */ new WeakMap();
      cache1.set(a2, cache2);
    }
    let fnResult = cache2.get(a3);
    if (fnResult === void 0) {
      fnResult = fn(a1, a2, a3);
      cache2.set(a3, fnResult);
    }
    return fnResult;
  };
}
var collectSubfields2 = memoize3(
  (exeContext, returnType, fieldNodes) => collectSubfields(
    exeContext.schema,
    exeContext.fragments,
    exeContext.variableValues,
    returnType,
    fieldNodes
  )
);
var stdTypeMap = keyMap(
  [...specifiedScalarTypes, ...introspectionTypes],
  (type) => type.name
);
var BreakingChangeType;
(function(BreakingChangeType2) {
  BreakingChangeType2["TYPE_REMOVED"] = "TYPE_REMOVED";
  BreakingChangeType2["TYPE_CHANGED_KIND"] = "TYPE_CHANGED_KIND";
  BreakingChangeType2["TYPE_REMOVED_FROM_UNION"] = "TYPE_REMOVED_FROM_UNION";
  BreakingChangeType2["VALUE_REMOVED_FROM_ENUM"] = "VALUE_REMOVED_FROM_ENUM";
  BreakingChangeType2["REQUIRED_INPUT_FIELD_ADDED"] = "REQUIRED_INPUT_FIELD_ADDED";
  BreakingChangeType2["IMPLEMENTED_INTERFACE_REMOVED"] = "IMPLEMENTED_INTERFACE_REMOVED";
  BreakingChangeType2["FIELD_REMOVED"] = "FIELD_REMOVED";
  BreakingChangeType2["FIELD_CHANGED_KIND"] = "FIELD_CHANGED_KIND";
  BreakingChangeType2["REQUIRED_ARG_ADDED"] = "REQUIRED_ARG_ADDED";
  BreakingChangeType2["ARG_REMOVED"] = "ARG_REMOVED";
  BreakingChangeType2["ARG_CHANGED_KIND"] = "ARG_CHANGED_KIND";
  BreakingChangeType2["DIRECTIVE_REMOVED"] = "DIRECTIVE_REMOVED";
  BreakingChangeType2["DIRECTIVE_ARG_REMOVED"] = "DIRECTIVE_ARG_REMOVED";
  BreakingChangeType2["REQUIRED_DIRECTIVE_ARG_ADDED"] = "REQUIRED_DIRECTIVE_ARG_ADDED";
  BreakingChangeType2["DIRECTIVE_REPEATABLE_REMOVED"] = "DIRECTIVE_REPEATABLE_REMOVED";
  BreakingChangeType2["DIRECTIVE_LOCATION_REMOVED"] = "DIRECTIVE_LOCATION_REMOVED";
})(BreakingChangeType || (BreakingChangeType = {}));
var DangerousChangeType;
(function(DangerousChangeType2) {
  DangerousChangeType2["VALUE_ADDED_TO_ENUM"] = "VALUE_ADDED_TO_ENUM";
  DangerousChangeType2["TYPE_ADDED_TO_UNION"] = "TYPE_ADDED_TO_UNION";
  DangerousChangeType2["OPTIONAL_INPUT_FIELD_ADDED"] = "OPTIONAL_INPUT_FIELD_ADDED";
  DangerousChangeType2["OPTIONAL_ARG_ADDED"] = "OPTIONAL_ARG_ADDED";
  DangerousChangeType2["IMPLEMENTED_INTERFACE_ADDED"] = "IMPLEMENTED_INTERFACE_ADDED";
  DangerousChangeType2["ARG_DEFAULT_VALUE_CHANGE"] = "ARG_DEFAULT_VALUE_CHANGE";
})(DangerousChangeType || (DangerousChangeType = {}));
function jsonParse(value) {
  try {
    return JSON.parse(value);
  } catch (error) {
    return void 0;
  }
}
var __create3 = Object.create;
var __defProp4 = Object.defineProperty;
var __getOwnPropDesc3 = Object.getOwnPropertyDescriptor;
var __getOwnPropNames3 = Object.getOwnPropertyNames;
var __getProtoOf3 = Object.getPrototypeOf;
var __hasOwnProp3 = Object.prototype.hasOwnProperty;
var __commonJS3 = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames3(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps3 = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames3(from))
      if (!__hasOwnProp3.call(to, key) && key !== except)
        __defProp4(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc3(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM3 = (mod, isNodeMode, target) => (target = mod != null ? __create3(__getProtoOf3(mod)) : {}, __copyProps3(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp4(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var require_set_cookie = __commonJS3({
  "node_modules/set-cookie-parser/lib/set-cookie.js"(exports, module) {
    "use strict";
    var defaultParseOptions = {
      decodeValues: true,
      map: false,
      silent: false
    };
    function isNonEmptyString(str) {
      return typeof str === "string" && !!str.trim();
    }
    function parseString(setCookieValue, options) {
      var parts = setCookieValue.split(";").filter(isNonEmptyString);
      var nameValuePairStr = parts.shift();
      var parsed = parseNameValuePair(nameValuePairStr);
      var name = parsed.name;
      var value = parsed.value;
      options = options ? Object.assign({}, defaultParseOptions, options) : defaultParseOptions;
      try {
        value = options.decodeValues ? decodeURIComponent(value) : value;
      } catch (e) {
        console.error(
          "set-cookie-parser encountered an error while decoding a cookie with value '" + value + "'. Set options.decodeValues to false to disable this feature.",
          e
        );
      }
      var cookie = {
        name,
        value
      };
      parts.forEach(function(part) {
        var sides = part.split("=");
        var key = sides.shift().trimLeft().toLowerCase();
        var value2 = sides.join("=");
        if (key === "expires") {
          cookie.expires = new Date(value2);
        } else if (key === "max-age") {
          cookie.maxAge = parseInt(value2, 10);
        } else if (key === "secure") {
          cookie.secure = true;
        } else if (key === "httponly") {
          cookie.httpOnly = true;
        } else if (key === "samesite") {
          cookie.sameSite = value2;
        } else {
          cookie[key] = value2;
        }
      });
      return cookie;
    }
    function parseNameValuePair(nameValuePairStr) {
      var name = "";
      var value = "";
      var nameValueArr = nameValuePairStr.split("=");
      if (nameValueArr.length > 1) {
        name = nameValueArr.shift();
        value = nameValueArr.join("=");
      } else {
        value = nameValuePairStr;
      }
      return { name, value };
    }
    function parse3(input, options) {
      options = options ? Object.assign({}, defaultParseOptions, options) : defaultParseOptions;
      if (!input) {
        if (!options.map) {
          return [];
        } else {
          return {};
        }
      }
      if (input.headers) {
        if (typeof input.headers.getSetCookie === "function") {
          input = input.headers.getSetCookie();
        } else if (input.headers["set-cookie"]) {
          input = input.headers["set-cookie"];
        } else {
          var sch = input.headers[Object.keys(input.headers).find(function(key) {
            return key.toLowerCase() === "set-cookie";
          })];
          if (!sch && input.headers.cookie && !options.silent) {
            console.warn(
              "Warning: set-cookie-parser appears to have been called on a request object. It is designed to parse Set-Cookie headers from responses, not Cookie headers from requests. Set the option {silent: true} to suppress this warning."
            );
          }
          input = sch;
        }
      }
      if (!Array.isArray(input)) {
        input = [input];
      }
      options = options ? Object.assign({}, defaultParseOptions, options) : defaultParseOptions;
      if (!options.map) {
        return input.filter(isNonEmptyString).map(function(str) {
          return parseString(str, options);
        });
      } else {
        var cookies = {};
        return input.filter(isNonEmptyString).reduce(function(cookies2, str) {
          var cookie = parseString(str, options);
          cookies2[cookie.name] = cookie;
          return cookies2;
        }, cookies);
      }
    }
    function splitCookiesString2(cookiesString) {
      if (Array.isArray(cookiesString)) {
        return cookiesString;
      }
      if (typeof cookiesString !== "string") {
        return [];
      }
      var cookiesStrings = [];
      var pos = 0;
      var start;
      var ch;
      var lastComma;
      var nextStart;
      var cookiesSeparatorFound;
      function skipWhitespace() {
        while (pos < cookiesString.length && /\s/.test(cookiesString.charAt(pos))) {
          pos += 1;
        }
        return pos < cookiesString.length;
      }
      function notSpecialChar() {
        ch = cookiesString.charAt(pos);
        return ch !== "=" && ch !== ";" && ch !== ",";
      }
      while (pos < cookiesString.length) {
        start = pos;
        cookiesSeparatorFound = false;
        while (skipWhitespace()) {
          ch = cookiesString.charAt(pos);
          if (ch === ",") {
            lastComma = pos;
            pos += 1;
            skipWhitespace();
            nextStart = pos;
            while (pos < cookiesString.length && notSpecialChar()) {
              pos += 1;
            }
            if (pos < cookiesString.length && cookiesString.charAt(pos) === "=") {
              cookiesSeparatorFound = true;
              pos = nextStart;
              cookiesStrings.push(cookiesString.substring(start, lastComma));
              start = pos;
            } else {
              pos = lastComma + 1;
            }
          } else {
            pos += 1;
          }
        }
        if (!cookiesSeparatorFound || pos >= cookiesString.length) {
          cookiesStrings.push(cookiesString.substring(start, cookiesString.length));
        }
      }
      return cookiesStrings;
    }
    module.exports = parse3;
    module.exports.parse = parse3;
    module.exports.parseString = parseString;
    module.exports.splitCookiesString = splitCookiesString2;
  }
});
var import_set_cookie_parser = __toESM3(require_set_cookie());
var HEADERS_INVALID_CHARACTERS = /[^a-z0-9\-#$%&'*+.^_`|~]/i;
function normalizeHeaderName(name) {
  if (HEADERS_INVALID_CHARACTERS.test(name) || name.trim() === "") {
    throw new TypeError("Invalid character in header field name");
  }
  return name.trim().toLowerCase();
}
var charCodesToRemove = [
  String.fromCharCode(10),
  String.fromCharCode(13),
  String.fromCharCode(9),
  String.fromCharCode(32)
];
var HEADER_VALUE_REMOVE_REGEXP = new RegExp(
  `(^[${charCodesToRemove.join("")}]|$[${charCodesToRemove.join("")}])`,
  "g"
);
function normalizeHeaderValue(value) {
  const nextValue = value.replace(HEADER_VALUE_REMOVE_REGEXP, "");
  return nextValue;
}
function isValidHeaderName(value) {
  if (typeof value !== "string") {
    return false;
  }
  if (value.length === 0) {
    return false;
  }
  for (let i = 0; i < value.length; i++) {
    const character = value.charCodeAt(i);
    if (character > 127 || !isToken(character)) {
      return false;
    }
  }
  return true;
}
function isToken(value) {
  return ![
    127,
    32,
    "(",
    ")",
    "<",
    ">",
    "@",
    ",",
    ";",
    ":",
    "\\",
    '"',
    "/",
    "[",
    "]",
    "?",
    "=",
    "{",
    "}"
  ].includes(value);
}
function isValidHeaderValue(value) {
  if (typeof value !== "string") {
    return false;
  }
  if (value.trim() !== value) {
    return false;
  }
  for (let i = 0; i < value.length; i++) {
    const character = value.charCodeAt(i);
    if (
      // NUL.
      character === 0 || // HTTP newline bytes.
      character === 10 || character === 13
    ) {
      return false;
    }
  }
  return true;
}
var NORMALIZED_HEADERS = Symbol("normalizedHeaders");
var RAW_HEADER_NAMES = Symbol("rawHeaderNames");
var HEADER_VALUE_DELIMITER = ", ";
var _a;
var _b;
var Headers2 = class _Headers {
  constructor(init) {
    this[_a] = {};
    this[_b] = /* @__PURE__ */ new Map();
    if (["Headers", "HeadersPolyfill"].includes(init == null ? void 0 : init.constructor.name) || init instanceof _Headers || typeof globalThis.Headers !== "undefined" && init instanceof globalThis.Headers) {
      const initialHeaders = init;
      initialHeaders.forEach((value, name) => {
        this.append(name, value);
      }, this);
    } else if (Array.isArray(init)) {
      init.forEach(([name, value]) => {
        this.append(
          name,
          Array.isArray(value) ? value.join(HEADER_VALUE_DELIMITER) : value
        );
      });
    } else if (init) {
      Object.getOwnPropertyNames(init).forEach((name) => {
        const value = init[name];
        this.append(
          name,
          Array.isArray(value) ? value.join(HEADER_VALUE_DELIMITER) : value
        );
      });
    }
  }
  [(_a = NORMALIZED_HEADERS, _b = RAW_HEADER_NAMES, Symbol.iterator)]() {
    return this.entries();
  }
  *keys() {
    for (const [name] of this.entries()) {
      yield name;
    }
  }
  *values() {
    for (const [, value] of this.entries()) {
      yield value;
    }
  }
  *entries() {
    let sortedKeys = Object.keys(this[NORMALIZED_HEADERS]).sort(
      (a, b) => a.localeCompare(b)
    );
    for (const name of sortedKeys) {
      if (name === "set-cookie") {
        for (const value of this.getSetCookie()) {
          yield [name, value];
        }
      } else {
        yield [name, this.get(name)];
      }
    }
  }
  /**
   * Returns a boolean stating whether a `Headers` object contains a certain header.
   */
  has(name) {
    if (!isValidHeaderName(name)) {
      throw new TypeError(`Invalid header name "${name}"`);
    }
    return this[NORMALIZED_HEADERS].hasOwnProperty(normalizeHeaderName(name));
  }
  /**
   * Returns a `ByteString` sequence of all the values of a header with a given name.
   */
  get(name) {
    if (!isValidHeaderName(name)) {
      throw TypeError(`Invalid header name "${name}"`);
    }
    return this[NORMALIZED_HEADERS][normalizeHeaderName(name)] ?? null;
  }
  /**
   * Sets a new value for an existing header inside a `Headers` object, or adds the header if it does not already exist.
   */
  set(name, value) {
    if (!isValidHeaderName(name) || !isValidHeaderValue(value)) {
      return;
    }
    const normalizedName = normalizeHeaderName(name);
    const normalizedValue = normalizeHeaderValue(value);
    this[NORMALIZED_HEADERS][normalizedName] = normalizeHeaderValue(normalizedValue);
    this[RAW_HEADER_NAMES].set(normalizedName, name);
  }
  /**
   * Appends a new value onto an existing header inside a `Headers` object, or adds the header if it does not already exist.
   */
  append(name, value) {
    if (!isValidHeaderName(name) || !isValidHeaderValue(value)) {
      return;
    }
    const normalizedName = normalizeHeaderName(name);
    const normalizedValue = normalizeHeaderValue(value);
    let resolvedValue = this.has(normalizedName) ? `${this.get(normalizedName)}, ${normalizedValue}` : normalizedValue;
    this.set(name, resolvedValue);
  }
  /**
   * Deletes a header from the `Headers` object.
   */
  delete(name) {
    if (!isValidHeaderName(name)) {
      return;
    }
    if (!this.has(name)) {
      return;
    }
    const normalizedName = normalizeHeaderName(name);
    delete this[NORMALIZED_HEADERS][normalizedName];
    this[RAW_HEADER_NAMES].delete(normalizedName);
  }
  /**
   * Traverses the `Headers` object,
   * calling the given callback for each header.
   */
  forEach(callback, thisArg) {
    for (const [name, value] of this.entries()) {
      callback.call(thisArg, value, name, this);
    }
  }
  /**
   * Returns an array containing the values
   * of all Set-Cookie headers associated
   * with a response
   */
  getSetCookie() {
    const setCookieHeader = this.get("set-cookie");
    if (setCookieHeader === null) {
      return [];
    }
    if (setCookieHeader === "") {
      return [""];
    }
    return (0, import_set_cookie_parser.splitCookiesString)(setCookieHeader);
  }
};
function stringToHeaders(str) {
  const lines = str.trim().split(/[\r\n]+/);
  return lines.reduce((headers, line) => {
    if (line.trim() === "") {
      return headers;
    }
    const parts = line.split(": ");
    const name = parts.shift();
    const value = parts.join(": ");
    headers.append(name, value);
    return headers;
  }, new Headers2());
}
function parseContentHeaders(headersString) {
  var _a2, _b2;
  const headers = stringToHeaders(headersString);
  const contentType = headers.get("content-type") || "text/plain";
  const disposition = headers.get("content-disposition");
  if (!disposition) {
    throw new Error('"Content-Disposition" header is required.');
  }
  const directives = disposition.split(";").reduce((acc, chunk) => {
    const [name2, ...rest] = chunk.trim().split("=");
    acc[name2] = rest.join("=");
    return acc;
  }, {});
  const name = (_a2 = directives.name) == null ? void 0 : _a2.slice(1, -1);
  const filename = (_b2 = directives.filename) == null ? void 0 : _b2.slice(1, -1);
  return {
    name,
    filename,
    contentType
  };
}
function parseMultipartData(data, headers) {
  const contentType = headers == null ? void 0 : headers.get("content-type");
  if (!contentType) {
    return void 0;
  }
  const [, ...directives] = contentType.split(/; */);
  const boundary = directives.filter((d) => d.startsWith("boundary=")).map((s) => s.replace(/^boundary=/, ""))[0];
  if (!boundary) {
    return void 0;
  }
  const boundaryRegExp = new RegExp(`--+${boundary}`);
  const fields = data.split(boundaryRegExp).filter((chunk) => chunk.startsWith("\r\n") && chunk.endsWith("\r\n")).map((chunk) => chunk.trimStart().replace(/\r\n$/, ""));
  if (!fields.length) {
    return void 0;
  }
  const parsedBody = {};
  try {
    for (const field of fields) {
      const [contentHeaders, ...rest] = field.split("\r\n\r\n");
      const contentBody = rest.join("\r\n\r\n");
      const { contentType: contentType2, filename, name } = parseContentHeaders(contentHeaders);
      const value = filename === void 0 ? contentBody : new File([contentBody], filename, { type: contentType2 });
      const parsedValue = parsedBody[name];
      if (parsedValue === void 0) {
        parsedBody[name] = value;
      } else if (Array.isArray(parsedValue)) {
        parsedBody[name] = [...parsedValue, value];
      } else {
        parsedBody[name] = [parsedValue, value];
      }
    }
    return parsedBody;
  } catch (error) {
    return void 0;
  }
}
function parseDocumentNode(node) {
  var _a2;
  const operationDef = node.definitions.find((definition) => {
    return definition.kind === "OperationDefinition";
  });
  return {
    operationType: operationDef == null ? void 0 : operationDef.operation,
    operationName: (_a2 = operationDef == null ? void 0 : operationDef.name) == null ? void 0 : _a2.value
  };
}
function parseQuery(query) {
  try {
    const ast = parse2(query);
    return parseDocumentNode(ast);
  } catch (error) {
    return error;
  }
}
function extractMultipartVariables(variables, map, files) {
  const operations = { variables };
  for (const [key, pathArray] of Object.entries(map)) {
    if (!(key in files)) {
      throw new Error(`Given files do not have a key '${key}' .`);
    }
    for (const dotPath of pathArray) {
      const [lastPath, ...reversedPaths] = dotPath.split(".").reverse();
      const paths = reversedPaths.reverse();
      let target = operations;
      for (const path of paths) {
        if (!(path in target)) {
          throw new Error(`Property '${paths}' is not in operations.`);
        }
        target = target[path];
      }
      target[lastPath] = files[key];
    }
  }
  return operations.variables;
}
async function getGraphQLInput(request) {
  var _a2;
  switch (request.method) {
    case "GET": {
      const url = new URL(request.url);
      const query = url.searchParams.get("query");
      const variables = url.searchParams.get("variables") || "";
      return {
        query,
        variables: jsonParse(variables)
      };
    }
    case "POST": {
      const requestClone = request.clone();
      if ((_a2 = request.headers.get("content-type")) == null ? void 0 : _a2.includes("multipart/form-data")) {
        const responseJson = parseMultipartData(
          await requestClone.text(),
          request.headers
        );
        if (!responseJson) {
          return null;
        }
        const { operations, map, ...files } = responseJson;
        const parsedOperations = jsonParse(
          operations
        ) || {};
        if (!parsedOperations.query) {
          return null;
        }
        const parsedMap = jsonParse(map || "") || {};
        const variables = parsedOperations.variables ? extractMultipartVariables(
          parsedOperations.variables,
          parsedMap,
          files
        ) : {};
        return {
          query: parsedOperations.query,
          variables
        };
      }
      const requestJson = await requestClone.json().catch(() => null);
      if (requestJson == null ? void 0 : requestJson.query) {
        const { query, variables } = requestJson;
        return {
          query,
          variables
        };
      }
    }
    default:
      return null;
  }
}
async function parseGraphQLRequest(request) {
  const input = await getGraphQLInput(request);
  if (!input || !input.query) {
    return;
  }
  const { query, variables } = input;
  const parsedResult = parseQuery(query);
  if (parsedResult instanceof Error) {
    const requestPublicUrl = toPublicUrl(request.url);
    throw new Error(
      devUtils.formatMessage(
        'Failed to intercept a GraphQL request to "%s %s": cannot parse query. See the error message from the parser below.\n\n%s',
        request.method,
        requestPublicUrl,
        parsedResult.message
      )
    );
  }
  return {
    query: input.query,
    operationType: parsedResult.operationType,
    operationName: parsedResult.operationName,
    variables
  };
}
function isDocumentNode(value) {
  if (value == null) {
    return false;
  }
  return typeof value === "object" && "kind" in value && "definitions" in value;
}
var _GraphQLHandler = class _GraphQLHandler2 extends RequestHandler {
  constructor(operationType, operationName, endpoint, resolver, options) {
    let resolvedOperationName = operationName;
    if (isDocumentNode(operationName)) {
      const parsedNode = parseDocumentNode(operationName);
      if (parsedNode.operationType !== operationType) {
        throw new Error(
          `Failed to create a GraphQL handler: provided a DocumentNode with a mismatched operation type (expected "${operationType}", but got "${parsedNode.operationType}").`
        );
      }
      if (!parsedNode.operationName) {
        throw new Error(
          `Failed to create a GraphQL handler: provided a DocumentNode with no operation name.`
        );
      }
      resolvedOperationName = parsedNode.operationName;
    }
    const header = operationType === "all" ? `${operationType} (origin: ${endpoint.toString()})` : `${operationType} ${resolvedOperationName} (origin: ${endpoint.toString()})`;
    super({
      info: {
        header,
        operationType,
        operationName: resolvedOperationName
      },
      resolver,
      options
    });
    __publicField(this, "endpoint");
    this.endpoint = endpoint;
  }
  /**
   * Parses the request body, once per request, cached across all
   * GraphQL handlers. This is done to avoid multiple parsing of the
   * request body, which each requires a clone of the request.
   */
  async parseGraphQLRequestOrGetFromCache(request) {
    if (!_GraphQLHandler2.parsedRequestCache.has(request)) {
      _GraphQLHandler2.parsedRequestCache.set(
        request,
        await parseGraphQLRequest(request).catch((error) => {
          console.error(error);
          return void 0;
        })
      );
    }
    return _GraphQLHandler2.parsedRequestCache.get(request);
  }
  async parse(args) {
    const match2 = matchRequestUrl(new URL(args.request.url), this.endpoint);
    const cookies = getAllRequestCookies(args.request);
    if (!match2.matches) {
      return { match: match2, cookies };
    }
    const parsedResult = await this.parseGraphQLRequestOrGetFromCache(
      args.request
    );
    if (typeof parsedResult === "undefined") {
      return { match: match2, cookies };
    }
    return {
      match: match2,
      cookies,
      query: parsedResult.query,
      operationType: parsedResult.operationType,
      operationName: parsedResult.operationName,
      variables: parsedResult.variables
    };
  }
  predicate(args) {
    if (args.parsedResult.operationType === void 0) {
      return false;
    }
    if (!args.parsedResult.operationName && this.info.operationType !== "all") {
      const publicUrl = toPublicUrl(args.request.url);
      devUtils.warn(`Failed to intercept a GraphQL request at "${args.request.method} ${publicUrl}": anonymous GraphQL operations are not supported.

Consider naming this operation or using "graphql.operation()" request handler to intercept GraphQL requests regardless of their operation name/type. Read more: https://mswjs.io/docs/api/graphql/#graphqloperationresolver`);
      return false;
    }
    const hasMatchingOperationType = this.info.operationType === "all" || args.parsedResult.operationType === this.info.operationType;
    const hasMatchingOperationName = this.info.operationName instanceof RegExp ? this.info.operationName.test(args.parsedResult.operationName || "") : args.parsedResult.operationName === this.info.operationName;
    return args.parsedResult.match.matches && hasMatchingOperationType && hasMatchingOperationName;
  }
  extendResolverArgs(args) {
    return {
      query: args.parsedResult.query || "",
      operationName: args.parsedResult.operationName || "",
      variables: args.parsedResult.variables || {},
      cookies: args.parsedResult.cookies
    };
  }
  async log(args) {
    const loggedRequest = await serializeRequest(args.request);
    const loggedResponse = await serializeResponse(args.response);
    const statusColor = getStatusCodeColor(loggedResponse.status);
    const requestInfo = args.parsedResult.operationName ? `${args.parsedResult.operationType} ${args.parsedResult.operationName}` : `anonymous ${args.parsedResult.operationType}`;
    console.groupCollapsed(
      devUtils.formatMessage(
        `${getTimestamp()} ${requestInfo} (%c${loggedResponse.status} ${loggedResponse.statusText}%c)`
      ),
      `color:${statusColor}`,
      "color:inherit"
    );
    console.log("Request:", loggedRequest);
    console.log("Handler:", this);
    console.log("Response:", loggedResponse);
    console.groupEnd();
  }
};
__publicField(_GraphQLHandler, "parsedRequestCache", /* @__PURE__ */ new WeakMap());
var GraphQLHandler = _GraphQLHandler;
function createScopedGraphQLHandler(operationType, url) {
  return (operationName, resolver, options = {}) => {
    return new GraphQLHandler(
      operationType,
      operationName,
      url,
      resolver,
      options
    );
  };
}
function createGraphQLOperationHandler(url) {
  return (resolver) => {
    return new GraphQLHandler("all", new RegExp(".*"), url, resolver);
  };
}
var standardGraphQLHandlers = {
  /**
   * Intercepts a GraphQL query by a given name.
   *
   * @example
   * graphql.query('GetUser', () => {
   *   return HttpResponse.json({ data: { user: { name: 'John' } } })
   * })
   *
   * @see {@link https://mswjs.io/docs/api/graphql#graphqlqueryqueryname-resolver `graphql.query()` API reference}
   */
  query: createScopedGraphQLHandler("query", "*"),
  /**
   * Intercepts a GraphQL mutation by its name.
   *
   * @example
   * graphql.mutation('SavePost', () => {
   *   return HttpResponse.json({ data: { post: { id: 'abc-123 } } })
   * })
   *
   * @see {@link https://mswjs.io/docs/api/graphql#graphqlmutationmutationname-resolver `graphql.query()` API reference}
   *
   */
  mutation: createScopedGraphQLHandler("mutation", "*"),
  /**
   * Intercepts any GraphQL operation, regardless of its type or name.
   *
   * @example
   * graphql.operation(() => {
   *   return HttpResponse.json({ data: { name: 'John' } })
   * })
   *
   * @see {@link https://mswjs.io/docs/api/graphql#graphloperationresolver `graphql.operation()` API reference}
   */
  operation: createGraphQLOperationHandler("*")
};
function createGraphQLLink(url) {
  return {
    operation: createGraphQLOperationHandler(url),
    query: createScopedGraphQLHandler("query", url),
    mutation: createScopedGraphQLHandler("mutation", url)
  };
}
var graphql2 = {
  ...standardGraphQLHandlers,
  /**
   * Intercepts GraphQL operations scoped by the given URL.
   *
   * @example
   * const github = graphql.link('https://api.github.com/graphql')
   * github.query('GetRepo', resolver)
   *
   * @see {@link https://mswjs.io/docs/api/graphql#graphqllinkurl `graphql.link()` API reference}
   */
  link: createGraphQLLink
};
function randomId() {
  return Math.random().toString(16).slice(2);
}
var getResponse = async (handlers, request) => {
  const result = await executeHandlers({
    request,
    requestId: randomId(),
    handlers
  });
  return result == null ? void 0 : result.response;
};
var { message: message2 } = source_default;
function normalizeResponseInit(init = {}) {
  const status = (init == null ? void 0 : init.status) || 200;
  const statusText = (init == null ? void 0 : init.statusText) || message2[status] || "";
  const headers = new Headers(init == null ? void 0 : init.headers);
  return {
    ...init,
    headers,
    status,
    statusText
  };
}
function decorateResponse(response, init) {
  var _a2;
  if (init.type) {
    Object.defineProperty(response, "type", {
      value: init.type,
      enumerable: true,
      writable: false
    });
  }
  if (typeof document !== "undefined") {
    const responseCookies = ((_a2 = init.headers.get("Set-Cookie")) == null ? void 0 : _a2.split(",")) || [];
    for (const cookieString of responseCookies) {
      document.cookie = cookieString;
    }
  }
  return response;
}
var HttpResponse = class _HttpResponse extends Response {
  constructor(body, init) {
    const responseInit = normalizeResponseInit(init);
    super(body, responseInit);
    decorateResponse(this, responseInit);
  }
  /**
   * Create a `Response` with a `Content-Type: "text/plain"` body.
   * @example
   * HttpResponse.text('hello world')
   * HttpResponse.text('Error', { status: 500 })
   */
  static text(body, init) {
    const responseInit = normalizeResponseInit(init);
    if (!responseInit.headers.has("Content-Type")) {
      responseInit.headers.set("Content-Type", "text/plain");
    }
    if (!responseInit.headers.has("Content-Length")) {
      responseInit.headers.set(
        "Content-Length",
        body ? body.length.toString() : "0"
      );
    }
    return new _HttpResponse(body, responseInit);
  }
  /**
   * Create a `Response` with a `Content-Type: "application/json"` body.
   * @example
   * HttpResponse.json({ firstName: 'John' })
   * HttpResponse.json({ error: 'Not Authorized' }, { status: 401 })
   */
  static json(body, init) {
    const responseInit = normalizeResponseInit(init);
    if (!responseInit.headers.has("Content-Type")) {
      responseInit.headers.set("Content-Type", "application/json");
    }
    const responseText = JSON.stringify(body);
    if (!responseInit.headers.has("Content-Length")) {
      responseInit.headers.set(
        "Content-Length",
        responseText ? responseText.length.toString() : "0"
      );
    }
    return new _HttpResponse(
      responseText,
      responseInit
    );
  }
  /**
   * Create a `Response` with a `Content-Type: "application/xml"` body.
   * @example
   * HttpResponse.xml(`<user name="John" />`)
   * HttpResponse.xml(`<article id="abc-123" />`, { status: 201 })
   */
  static xml(body, init) {
    const responseInit = normalizeResponseInit(init);
    if (!responseInit.headers.has("Content-Type")) {
      responseInit.headers.set("Content-Type", "text/xml");
    }
    return new _HttpResponse(body, responseInit);
  }
  /**
   * Create a `Response` with an `ArrayBuffer` body.
   * @example
   * const buffer = new ArrayBuffer(3)
   * const view = new Uint8Array(buffer)
   * view.set([1, 2, 3])
   *
   * HttpResponse.arrayBuffer(buffer)
   */
  static arrayBuffer(body, init) {
    const responseInit = normalizeResponseInit(init);
    if (body) {
      responseInit.headers.set("Content-Length", body.byteLength.toString());
    }
    return new _HttpResponse(body, responseInit);
  }
  /**
   * Create a `Response` with a `FormData` body.
   * @example
   * const data = new FormData()
   * data.set('name', 'Alice')
   *
   * HttpResponse.formData(data)
   */
  static formData(body, init) {
    return new _HttpResponse(body, normalizeResponseInit(init));
  }
};
var SET_TIMEOUT_MAX_ALLOWED_INT = 2147483647;
var MIN_SERVER_RESPONSE_TIME = 100;
var MAX_SERVER_RESPONSE_TIME = 400;
var NODE_SERVER_RESPONSE_TIME = 5;
function getRealisticResponseTime() {
  if (isNodeProcess()) {
    return NODE_SERVER_RESPONSE_TIME;
  }
  return Math.floor(
    Math.random() * (MAX_SERVER_RESPONSE_TIME - MIN_SERVER_RESPONSE_TIME) + MIN_SERVER_RESPONSE_TIME
  );
}
async function delay(durationOrMode) {
  let delayTime;
  if (typeof durationOrMode === "string") {
    switch (durationOrMode) {
      case "infinite": {
        delayTime = SET_TIMEOUT_MAX_ALLOWED_INT;
        break;
      }
      case "real": {
        delayTime = getRealisticResponseTime();
        break;
      }
      default: {
        throw new Error(
          `Failed to delay a response: unknown delay mode "${durationOrMode}". Please make sure you provide one of the supported modes ("real", "infinite") or a number.`
        );
      }
    }
  } else if (typeof durationOrMode === "undefined") {
    delayTime = getRealisticResponseTime();
  } else {
    if (durationOrMode > SET_TIMEOUT_MAX_ALLOWED_INT) {
      throw new Error(
        `Failed to delay a response: provided delay duration (${durationOrMode}) exceeds the maximum allowed duration for "setTimeout" (${SET_TIMEOUT_MAX_ALLOWED_INT}). This will cause the response to be returned immediately. Please use a number within the allowed range to delay the response by exact duration, or consider the "infinite" delay mode to delay the response indefinitely.`
      );
    }
    delayTime = durationOrMode;
  }
  return new Promise((resolve) => setTimeout(resolve, delayTime));
}
function bypass(input, init) {
  const request = input instanceof Request ? input : new Request(input, init);
  invariant(
    !request.bodyUsed,
    'Failed to create a bypassed request to "%s %s": given request instance already has its body read. Make sure to clone the intercepted request if you wish to read its body before bypassing it.',
    request.method,
    request.url
  );
  const requestClone = request.clone();
  requestClone.headers.set("x-msw-intention", "bypass");
  return requestClone;
}
function passthrough() {
  return new Response(null, {
    status: 302,
    statusText: "Passthrough",
    headers: {
      "x-msw-intention": "passthrough"
    }
  });
}
checkGlobals();
export {
  GraphQLHandler,
  HttpHandler,
  HttpMethods,
  HttpResponse,
  MAX_SERVER_RESPONSE_TIME,
  MIN_SERVER_RESPONSE_TIME,
  NODE_SERVER_RESPONSE_TIME,
  RequestHandler,
  SET_TIMEOUT_MAX_ALLOWED_INT,
  SetupApi,
  bypass,
  cleanUrl,
  delay,
  getResponse,
  graphql2 as graphql,
  handleRequest,
  http,
  matchRequestUrl,
  passthrough
};
/*! Bundled license information:

@bundled-es-modules/statuses/index-esm.js:
  (*! Bundled license information:
  
  statuses/index.js:
    (*!
     * statuses
     * Copyright(c) 2014 Jonathan Ong
     * Copyright(c) 2016 Douglas Christopher Wilson
     * MIT Licensed
     *)
  *)

@bundled-es-modules/cookie/index-esm.js:
  (*! Bundled license information:
  
  cookie/index.js:
    (*!
     * cookie
     * Copyright(c) 2012-2014 Roman Shtylman
     * Copyright(c) 2015 Douglas Christopher Wilson
     * MIT Licensed
     *)
  *)
*/

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1zdy5qcz92PWVmYzMzYmJkIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIFJlcXVlc3RIYW5kbGVyLFxuICBTZXR1cEFwaSxcbiAgZGV2VXRpbHMsXG4gIGV4ZWN1dGVIYW5kbGVycyxcbiAgaGFuZGxlUmVxdWVzdCxcbiAgaW52YXJpYW50LFxuICBzdG9yZSxcbiAgdG9QdWJsaWNVcmxcbn0gZnJvbSBcIi4vY2h1bmstRUFGV1hPTjUuanNcIjtcbmltcG9ydCB7XG4gIF9fcHVibGljRmllbGRcbn0gZnJvbSBcIi4vY2h1bmstVFhQR0pTVDcuanNcIjtcblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL21zd0AyLjIuMV90eXBlc2NyaXB0QDUuMy4zL25vZGVfbW9kdWxlcy9tc3cvbGliL2NvcmUvdXRpbHMvaW50ZXJuYWwvY2hlY2tHbG9iYWxzLm1qc1xuZnVuY3Rpb24gY2hlY2tHbG9iYWxzKCkge1xuICBpbnZhcmlhbnQoXG4gICAgdHlwZW9mIFVSTCAhPT0gXCJ1bmRlZmluZWRcIixcbiAgICBkZXZVdGlscy5mb3JtYXRNZXNzYWdlKFxuICAgICAgYEdsb2JhbCBcIlVSTFwiIGNsYXNzIGlzIG5vdCBkZWZpbmVkLiBUaGlzIGxpa2VseSBtZWFucyB0aGF0IHlvdSdyZSBydW5uaW5nIE1TVyBpbiBhbiBlbnZpcm9ubWVudCB0aGF0IGRvZXNuJ3Qgc3VwcG9ydCBhbGwgTm9kZS5qcyBzdGFuZGFyZCBBUEkgKGUuZy4gUmVhY3QgTmF0aXZlKS4gSWYgdGhhdCdzIHRoZSBjYXNlLCBwbGVhc2UgdXNlIGFuIGFwcHJvcHJpYXRlIHBvbHlmaWxsIGZvciB0aGUgXCJVUkxcIiBjbGFzcywgbGlrZSBcInJlYWN0LW5hdGl2ZS11cmwtcG9seWZpbGxcIi5gXG4gICAgKVxuICApO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vbXN3QDIuMi4xX3R5cGVzY3JpcHRANS4zLjMvbm9kZV9tb2R1bGVzL21zdy9saWIvY29yZS91dGlscy9pbnRlcm5hbC9pc1N0cmluZ0VxdWFsLm1qc1xuZnVuY3Rpb24gaXNTdHJpbmdFcXVhbChhY3R1YWwsIGV4cGVjdGVkKSB7XG4gIHJldHVybiBhY3R1YWwudG9Mb3dlckNhc2UoKSA9PT0gZXhwZWN0ZWQudG9Mb3dlckNhc2UoKTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL21zd0AyLjIuMV90eXBlc2NyaXB0QDUuMy4zL25vZGVfbW9kdWxlcy9tc3cvbGliL2NvcmUvdXRpbHMvbG9nZ2luZy9nZXRTdGF0dXNDb2RlQ29sb3IubWpzXG52YXIgU3RhdHVzQ29kZUNvbG9yID0gKChTdGF0dXNDb2RlQ29sb3IyKSA9PiB7XG4gIFN0YXR1c0NvZGVDb2xvcjJbXCJTdWNjZXNzXCJdID0gXCIjNjlBQjMyXCI7XG4gIFN0YXR1c0NvZGVDb2xvcjJbXCJXYXJuaW5nXCJdID0gXCIjRjBCQjRCXCI7XG4gIFN0YXR1c0NvZGVDb2xvcjJbXCJEYW5nZXJcIl0gPSBcIiNFOTVGNURcIjtcbiAgcmV0dXJuIFN0YXR1c0NvZGVDb2xvcjI7XG59KShTdGF0dXNDb2RlQ29sb3IgfHwge30pO1xuZnVuY3Rpb24gZ2V0U3RhdHVzQ29kZUNvbG9yKHN0YXR1cykge1xuICBpZiAoc3RhdHVzIDwgMzAwKSB7XG4gICAgcmV0dXJuIFwiIzY5QUIzMlwiO1xuICB9XG4gIGlmIChzdGF0dXMgPCA0MDApIHtcbiAgICByZXR1cm4gXCIjRjBCQjRCXCI7XG4gIH1cbiAgcmV0dXJuIFwiI0U5NUY1RFwiO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vbXN3QDIuMi4xX3R5cGVzY3JpcHRANS4zLjMvbm9kZV9tb2R1bGVzL21zdy9saWIvY29yZS91dGlscy9sb2dnaW5nL2dldFRpbWVzdGFtcC5tanNcbmZ1bmN0aW9uIGdldFRpbWVzdGFtcCgpIHtcbiAgY29uc3Qgbm93ID0gLyogQF9fUFVSRV9fICovIG5ldyBEYXRlKCk7XG4gIHJldHVybiBbbm93LmdldEhvdXJzKCksIG5vdy5nZXRNaW51dGVzKCksIG5vdy5nZXRTZWNvbmRzKCldLm1hcChTdHJpbmcpLm1hcCgoY2h1bmspID0+IGNodW5rLnNsaWNlKDAsIDIpKS5tYXAoKGNodW5rKSA9PiBjaHVuay5wYWRTdGFydCgyLCBcIjBcIikpLmpvaW4oXCI6XCIpO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vbXN3QDIuMi4xX3R5cGVzY3JpcHRANS4zLjMvbm9kZV9tb2R1bGVzL21zdy9saWIvY29yZS91dGlscy9sb2dnaW5nL3NlcmlhbGl6ZVJlcXVlc3QubWpzXG5hc3luYyBmdW5jdGlvbiBzZXJpYWxpemVSZXF1ZXN0KHJlcXVlc3QpIHtcbiAgY29uc3QgcmVxdWVzdENsb25lID0gcmVxdWVzdC5jbG9uZSgpO1xuICBjb25zdCByZXF1ZXN0VGV4dCA9IGF3YWl0IHJlcXVlc3RDbG9uZS50ZXh0KCk7XG4gIHJldHVybiB7XG4gICAgdXJsOiBuZXcgVVJMKHJlcXVlc3QudXJsKSxcbiAgICBtZXRob2Q6IHJlcXVlc3QubWV0aG9kLFxuICAgIGhlYWRlcnM6IE9iamVjdC5mcm9tRW50cmllcyhyZXF1ZXN0LmhlYWRlcnMuZW50cmllcygpKSxcbiAgICBib2R5OiByZXF1ZXN0VGV4dFxuICB9O1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vQGJ1bmRsZWQtZXMtbW9kdWxlcytzdGF0dXNlc0AxLjAuMS9ub2RlX21vZHVsZXMvQGJ1bmRsZWQtZXMtbW9kdWxlcy9zdGF0dXNlcy9pbmRleC1lc20uanNcbnZhciBfX2NyZWF0ZSA9IE9iamVjdC5jcmVhdGU7XG52YXIgX19kZWZQcm9wID0gT2JqZWN0LmRlZmluZVByb3BlcnR5O1xudmFyIF9fZ2V0T3duUHJvcERlc2MgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yO1xudmFyIF9fZ2V0T3duUHJvcE5hbWVzID0gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXM7XG52YXIgX19nZXRQcm90b09mID0gT2JqZWN0LmdldFByb3RvdHlwZU9mO1xudmFyIF9faGFzT3duUHJvcCA9IE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHk7XG52YXIgX19jb21tb25KUyA9IChjYiwgbW9kKSA9PiBmdW5jdGlvbiBfX3JlcXVpcmUoKSB7XG4gIHJldHVybiBtb2QgfHwgKDAsIGNiW19fZ2V0T3duUHJvcE5hbWVzKGNiKVswXV0pKChtb2QgPSB7IGV4cG9ydHM6IHt9IH0pLmV4cG9ydHMsIG1vZCksIG1vZC5leHBvcnRzO1xufTtcbnZhciBfX2NvcHlQcm9wcyA9ICh0bywgZnJvbSwgZXhjZXB0LCBkZXNjKSA9PiB7XG4gIGlmIChmcm9tICYmIHR5cGVvZiBmcm9tID09PSBcIm9iamVjdFwiIHx8IHR5cGVvZiBmcm9tID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICBmb3IgKGxldCBrZXkgb2YgX19nZXRPd25Qcm9wTmFtZXMoZnJvbSkpXG4gICAgICBpZiAoIV9faGFzT3duUHJvcC5jYWxsKHRvLCBrZXkpICYmIGtleSAhPT0gZXhjZXB0KVxuICAgICAgICBfX2RlZlByb3AodG8sIGtleSwgeyBnZXQ6ICgpID0+IGZyb21ba2V5XSwgZW51bWVyYWJsZTogIShkZXNjID0gX19nZXRPd25Qcm9wRGVzYyhmcm9tLCBrZXkpKSB8fCBkZXNjLmVudW1lcmFibGUgfSk7XG4gIH1cbiAgcmV0dXJuIHRvO1xufTtcbnZhciBfX3RvRVNNID0gKG1vZCwgaXNOb2RlTW9kZSwgdGFyZ2V0KSA9PiAodGFyZ2V0ID0gbW9kICE9IG51bGwgPyBfX2NyZWF0ZShfX2dldFByb3RvT2YobW9kKSkgOiB7fSwgX19jb3B5UHJvcHMoXG4gIC8vIElmIHRoZSBpbXBvcnRlciBpcyBpbiBub2RlIGNvbXBhdGliaWxpdHkgbW9kZSBvciB0aGlzIGlzIG5vdCBhbiBFU01cbiAgLy8gZmlsZSB0aGF0IGhhcyBiZWVuIGNvbnZlcnRlZCB0byBhIENvbW1vbkpTIGZpbGUgdXNpbmcgYSBCYWJlbC1cbiAgLy8gY29tcGF0aWJsZSB0cmFuc2Zvcm0gKGkuZS4gXCJfX2VzTW9kdWxlXCIgaGFzIG5vdCBiZWVuIHNldCksIHRoZW4gc2V0XG4gIC8vIFwiZGVmYXVsdFwiIHRvIHRoZSBDb21tb25KUyBcIm1vZHVsZS5leHBvcnRzXCIgZm9yIG5vZGUgY29tcGF0aWJpbGl0eS5cbiAgaXNOb2RlTW9kZSB8fCAhbW9kIHx8ICFtb2QuX19lc01vZHVsZSA/IF9fZGVmUHJvcCh0YXJnZXQsIFwiZGVmYXVsdFwiLCB7IHZhbHVlOiBtb2QsIGVudW1lcmFibGU6IHRydWUgfSkgOiB0YXJnZXQsXG4gIG1vZFxuKSk7XG52YXIgcmVxdWlyZV9jb2RlcyA9IF9fY29tbW9uSlMoe1xuICBcIm5vZGVfbW9kdWxlcy9zdGF0dXNlcy9jb2Rlcy5qc29uXCIoZXhwb3J0cywgbW9kdWxlKSB7XG4gICAgbW9kdWxlLmV4cG9ydHMgPSB7XG4gICAgICBcIjEwMFwiOiBcIkNvbnRpbnVlXCIsXG4gICAgICBcIjEwMVwiOiBcIlN3aXRjaGluZyBQcm90b2NvbHNcIixcbiAgICAgIFwiMTAyXCI6IFwiUHJvY2Vzc2luZ1wiLFxuICAgICAgXCIxMDNcIjogXCJFYXJseSBIaW50c1wiLFxuICAgICAgXCIyMDBcIjogXCJPS1wiLFxuICAgICAgXCIyMDFcIjogXCJDcmVhdGVkXCIsXG4gICAgICBcIjIwMlwiOiBcIkFjY2VwdGVkXCIsXG4gICAgICBcIjIwM1wiOiBcIk5vbi1BdXRob3JpdGF0aXZlIEluZm9ybWF0aW9uXCIsXG4gICAgICBcIjIwNFwiOiBcIk5vIENvbnRlbnRcIixcbiAgICAgIFwiMjA1XCI6IFwiUmVzZXQgQ29udGVudFwiLFxuICAgICAgXCIyMDZcIjogXCJQYXJ0aWFsIENvbnRlbnRcIixcbiAgICAgIFwiMjA3XCI6IFwiTXVsdGktU3RhdHVzXCIsXG4gICAgICBcIjIwOFwiOiBcIkFscmVhZHkgUmVwb3J0ZWRcIixcbiAgICAgIFwiMjI2XCI6IFwiSU0gVXNlZFwiLFxuICAgICAgXCIzMDBcIjogXCJNdWx0aXBsZSBDaG9pY2VzXCIsXG4gICAgICBcIjMwMVwiOiBcIk1vdmVkIFBlcm1hbmVudGx5XCIsXG4gICAgICBcIjMwMlwiOiBcIkZvdW5kXCIsXG4gICAgICBcIjMwM1wiOiBcIlNlZSBPdGhlclwiLFxuICAgICAgXCIzMDRcIjogXCJOb3QgTW9kaWZpZWRcIixcbiAgICAgIFwiMzA1XCI6IFwiVXNlIFByb3h5XCIsXG4gICAgICBcIjMwN1wiOiBcIlRlbXBvcmFyeSBSZWRpcmVjdFwiLFxuICAgICAgXCIzMDhcIjogXCJQZXJtYW5lbnQgUmVkaXJlY3RcIixcbiAgICAgIFwiNDAwXCI6IFwiQmFkIFJlcXVlc3RcIixcbiAgICAgIFwiNDAxXCI6IFwiVW5hdXRob3JpemVkXCIsXG4gICAgICBcIjQwMlwiOiBcIlBheW1lbnQgUmVxdWlyZWRcIixcbiAgICAgIFwiNDAzXCI6IFwiRm9yYmlkZGVuXCIsXG4gICAgICBcIjQwNFwiOiBcIk5vdCBGb3VuZFwiLFxuICAgICAgXCI0MDVcIjogXCJNZXRob2QgTm90IEFsbG93ZWRcIixcbiAgICAgIFwiNDA2XCI6IFwiTm90IEFjY2VwdGFibGVcIixcbiAgICAgIFwiNDA3XCI6IFwiUHJveHkgQXV0aGVudGljYXRpb24gUmVxdWlyZWRcIixcbiAgICAgIFwiNDA4XCI6IFwiUmVxdWVzdCBUaW1lb3V0XCIsXG4gICAgICBcIjQwOVwiOiBcIkNvbmZsaWN0XCIsXG4gICAgICBcIjQxMFwiOiBcIkdvbmVcIixcbiAgICAgIFwiNDExXCI6IFwiTGVuZ3RoIFJlcXVpcmVkXCIsXG4gICAgICBcIjQxMlwiOiBcIlByZWNvbmRpdGlvbiBGYWlsZWRcIixcbiAgICAgIFwiNDEzXCI6IFwiUGF5bG9hZCBUb28gTGFyZ2VcIixcbiAgICAgIFwiNDE0XCI6IFwiVVJJIFRvbyBMb25nXCIsXG4gICAgICBcIjQxNVwiOiBcIlVuc3VwcG9ydGVkIE1lZGlhIFR5cGVcIixcbiAgICAgIFwiNDE2XCI6IFwiUmFuZ2UgTm90IFNhdGlzZmlhYmxlXCIsXG4gICAgICBcIjQxN1wiOiBcIkV4cGVjdGF0aW9uIEZhaWxlZFwiLFxuICAgICAgXCI0MThcIjogXCJJJ20gYSBUZWFwb3RcIixcbiAgICAgIFwiNDIxXCI6IFwiTWlzZGlyZWN0ZWQgUmVxdWVzdFwiLFxuICAgICAgXCI0MjJcIjogXCJVbnByb2Nlc3NhYmxlIEVudGl0eVwiLFxuICAgICAgXCI0MjNcIjogXCJMb2NrZWRcIixcbiAgICAgIFwiNDI0XCI6IFwiRmFpbGVkIERlcGVuZGVuY3lcIixcbiAgICAgIFwiNDI1XCI6IFwiVG9vIEVhcmx5XCIsXG4gICAgICBcIjQyNlwiOiBcIlVwZ3JhZGUgUmVxdWlyZWRcIixcbiAgICAgIFwiNDI4XCI6IFwiUHJlY29uZGl0aW9uIFJlcXVpcmVkXCIsXG4gICAgICBcIjQyOVwiOiBcIlRvbyBNYW55IFJlcXVlc3RzXCIsXG4gICAgICBcIjQzMVwiOiBcIlJlcXVlc3QgSGVhZGVyIEZpZWxkcyBUb28gTGFyZ2VcIixcbiAgICAgIFwiNDUxXCI6IFwiVW5hdmFpbGFibGUgRm9yIExlZ2FsIFJlYXNvbnNcIixcbiAgICAgIFwiNTAwXCI6IFwiSW50ZXJuYWwgU2VydmVyIEVycm9yXCIsXG4gICAgICBcIjUwMVwiOiBcIk5vdCBJbXBsZW1lbnRlZFwiLFxuICAgICAgXCI1MDJcIjogXCJCYWQgR2F0ZXdheVwiLFxuICAgICAgXCI1MDNcIjogXCJTZXJ2aWNlIFVuYXZhaWxhYmxlXCIsXG4gICAgICBcIjUwNFwiOiBcIkdhdGV3YXkgVGltZW91dFwiLFxuICAgICAgXCI1MDVcIjogXCJIVFRQIFZlcnNpb24gTm90IFN1cHBvcnRlZFwiLFxuICAgICAgXCI1MDZcIjogXCJWYXJpYW50IEFsc28gTmVnb3RpYXRlc1wiLFxuICAgICAgXCI1MDdcIjogXCJJbnN1ZmZpY2llbnQgU3RvcmFnZVwiLFxuICAgICAgXCI1MDhcIjogXCJMb29wIERldGVjdGVkXCIsXG4gICAgICBcIjUwOVwiOiBcIkJhbmR3aWR0aCBMaW1pdCBFeGNlZWRlZFwiLFxuICAgICAgXCI1MTBcIjogXCJOb3QgRXh0ZW5kZWRcIixcbiAgICAgIFwiNTExXCI6IFwiTmV0d29yayBBdXRoZW50aWNhdGlvbiBSZXF1aXJlZFwiXG4gICAgfTtcbiAgfVxufSk7XG52YXIgcmVxdWlyZV9zdGF0dXNlcyA9IF9fY29tbW9uSlMoe1xuICBcIm5vZGVfbW9kdWxlcy9zdGF0dXNlcy9pbmRleC5qc1wiKGV4cG9ydHMsIG1vZHVsZSkge1xuICAgIFwidXNlIHN0cmljdFwiO1xuICAgIHZhciBjb2RlcyA9IHJlcXVpcmVfY29kZXMoKTtcbiAgICBtb2R1bGUuZXhwb3J0cyA9IHN0YXR1czI7XG4gICAgc3RhdHVzMi5tZXNzYWdlID0gY29kZXM7XG4gICAgc3RhdHVzMi5jb2RlID0gY3JlYXRlTWVzc2FnZVRvU3RhdHVzQ29kZU1hcChjb2Rlcyk7XG4gICAgc3RhdHVzMi5jb2RlcyA9IGNyZWF0ZVN0YXR1c0NvZGVMaXN0KGNvZGVzKTtcbiAgICBzdGF0dXMyLnJlZGlyZWN0ID0ge1xuICAgICAgMzAwOiB0cnVlLFxuICAgICAgMzAxOiB0cnVlLFxuICAgICAgMzAyOiB0cnVlLFxuICAgICAgMzAzOiB0cnVlLFxuICAgICAgMzA1OiB0cnVlLFxuICAgICAgMzA3OiB0cnVlLFxuICAgICAgMzA4OiB0cnVlXG4gICAgfTtcbiAgICBzdGF0dXMyLmVtcHR5ID0ge1xuICAgICAgMjA0OiB0cnVlLFxuICAgICAgMjA1OiB0cnVlLFxuICAgICAgMzA0OiB0cnVlXG4gICAgfTtcbiAgICBzdGF0dXMyLnJldHJ5ID0ge1xuICAgICAgNTAyOiB0cnVlLFxuICAgICAgNTAzOiB0cnVlLFxuICAgICAgNTA0OiB0cnVlXG4gICAgfTtcbiAgICBmdW5jdGlvbiBjcmVhdGVNZXNzYWdlVG9TdGF0dXNDb2RlTWFwKGNvZGVzMikge1xuICAgICAgdmFyIG1hcCA9IHt9O1xuICAgICAgT2JqZWN0LmtleXMoY29kZXMyKS5mb3JFYWNoKGZ1bmN0aW9uIGZvckVhY2hDb2RlKGNvZGUpIHtcbiAgICAgICAgdmFyIG1lc3NhZ2UzID0gY29kZXMyW2NvZGVdO1xuICAgICAgICB2YXIgc3RhdHVzMyA9IE51bWJlcihjb2RlKTtcbiAgICAgICAgbWFwW21lc3NhZ2UzLnRvTG93ZXJDYXNlKCldID0gc3RhdHVzMztcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIG1hcDtcbiAgICB9XG4gICAgZnVuY3Rpb24gY3JlYXRlU3RhdHVzQ29kZUxpc3QoY29kZXMyKSB7XG4gICAgICByZXR1cm4gT2JqZWN0LmtleXMoY29kZXMyKS5tYXAoZnVuY3Rpb24gbWFwQ29kZShjb2RlKSB7XG4gICAgICAgIHJldHVybiBOdW1iZXIoY29kZSk7XG4gICAgICB9KTtcbiAgICB9XG4gICAgZnVuY3Rpb24gZ2V0U3RhdHVzQ29kZShtZXNzYWdlMykge1xuICAgICAgdmFyIG1zZyA9IG1lc3NhZ2UzLnRvTG93ZXJDYXNlKCk7XG4gICAgICBpZiAoIU9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChzdGF0dXMyLmNvZGUsIG1zZykpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdpbnZhbGlkIHN0YXR1cyBtZXNzYWdlOiBcIicgKyBtZXNzYWdlMyArICdcIicpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHN0YXR1czIuY29kZVttc2ddO1xuICAgIH1cbiAgICBmdW5jdGlvbiBnZXRTdGF0dXNNZXNzYWdlKGNvZGUpIHtcbiAgICAgIGlmICghT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHN0YXR1czIubWVzc2FnZSwgY29kZSkpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiaW52YWxpZCBzdGF0dXMgY29kZTogXCIgKyBjb2RlKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBzdGF0dXMyLm1lc3NhZ2VbY29kZV07XG4gICAgfVxuICAgIGZ1bmN0aW9uIHN0YXR1czIoY29kZSkge1xuICAgICAgaWYgKHR5cGVvZiBjb2RlID09PSBcIm51bWJlclwiKSB7XG4gICAgICAgIHJldHVybiBnZXRTdGF0dXNNZXNzYWdlKGNvZGUpO1xuICAgICAgfVxuICAgICAgaWYgKHR5cGVvZiBjb2RlICE9PSBcInN0cmluZ1wiKSB7XG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJjb2RlIG11c3QgYmUgYSBudW1iZXIgb3Igc3RyaW5nXCIpO1xuICAgICAgfVxuICAgICAgdmFyIG4gPSBwYXJzZUludChjb2RlLCAxMCk7XG4gICAgICBpZiAoIWlzTmFOKG4pKSB7XG4gICAgICAgIHJldHVybiBnZXRTdGF0dXNNZXNzYWdlKG4pO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGdldFN0YXR1c0NvZGUoY29kZSk7XG4gICAgfVxuICB9XG59KTtcbnZhciBpbXBvcnRfc3RhdHVzZXMgPSBfX3RvRVNNKHJlcXVpcmVfc3RhdHVzZXMoKSwgMSk7XG52YXIgc291cmNlX2RlZmF1bHQgPSBpbXBvcnRfc3RhdHVzZXMuZGVmYXVsdDtcblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL21zd0AyLjIuMV90eXBlc2NyaXB0QDUuMy4zL25vZGVfbW9kdWxlcy9tc3cvbGliL2NvcmUvdXRpbHMvbG9nZ2luZy9zZXJpYWxpemVSZXNwb25zZS5tanNcbnZhciB7IG1lc3NhZ2UgfSA9IHNvdXJjZV9kZWZhdWx0O1xuYXN5bmMgZnVuY3Rpb24gc2VyaWFsaXplUmVzcG9uc2UocmVzcG9uc2UpIHtcbiAgY29uc3QgcmVzcG9uc2VDbG9uZSA9IHJlc3BvbnNlLmNsb25lKCk7XG4gIGNvbnN0IHJlc3BvbnNlVGV4dCA9IGF3YWl0IHJlc3BvbnNlQ2xvbmUudGV4dCgpO1xuICBjb25zdCByZXNwb25zZVN0YXR1cyA9IHJlc3BvbnNlQ2xvbmUuc3RhdHVzIHx8IDIwMDtcbiAgY29uc3QgcmVzcG9uc2VTdGF0dXNUZXh0ID0gcmVzcG9uc2VDbG9uZS5zdGF0dXNUZXh0IHx8IG1lc3NhZ2VbcmVzcG9uc2VTdGF0dXNdIHx8IFwiT0tcIjtcbiAgcmV0dXJuIHtcbiAgICBzdGF0dXM6IHJlc3BvbnNlU3RhdHVzLFxuICAgIHN0YXR1c1RleHQ6IHJlc3BvbnNlU3RhdHVzVGV4dCxcbiAgICBoZWFkZXJzOiBPYmplY3QuZnJvbUVudHJpZXMocmVzcG9uc2VDbG9uZS5oZWFkZXJzLmVudHJpZXMoKSksXG4gICAgYm9keTogcmVzcG9uc2VUZXh0XG4gIH07XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9wYXRoLXRvLXJlZ2V4cEA2LjIuMS9ub2RlX21vZHVsZXMvcGF0aC10by1yZWdleHAvZGlzdC5lczIwMTUvaW5kZXguanNcbmZ1bmN0aW9uIGxleGVyKHN0cikge1xuICB2YXIgdG9rZW5zID0gW107XG4gIHZhciBpID0gMDtcbiAgd2hpbGUgKGkgPCBzdHIubGVuZ3RoKSB7XG4gICAgdmFyIGNoYXIgPSBzdHJbaV07XG4gICAgaWYgKGNoYXIgPT09IFwiKlwiIHx8IGNoYXIgPT09IFwiK1wiIHx8IGNoYXIgPT09IFwiP1wiKSB7XG4gICAgICB0b2tlbnMucHVzaCh7IHR5cGU6IFwiTU9ESUZJRVJcIiwgaW5kZXg6IGksIHZhbHVlOiBzdHJbaSsrXSB9KTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpZiAoY2hhciA9PT0gXCJcXFxcXCIpIHtcbiAgICAgIHRva2Vucy5wdXNoKHsgdHlwZTogXCJFU0NBUEVEX0NIQVJcIiwgaW5kZXg6IGkrKywgdmFsdWU6IHN0cltpKytdIH0pO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmIChjaGFyID09PSBcIntcIikge1xuICAgICAgdG9rZW5zLnB1c2goeyB0eXBlOiBcIk9QRU5cIiwgaW5kZXg6IGksIHZhbHVlOiBzdHJbaSsrXSB9KTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpZiAoY2hhciA9PT0gXCJ9XCIpIHtcbiAgICAgIHRva2Vucy5wdXNoKHsgdHlwZTogXCJDTE9TRVwiLCBpbmRleDogaSwgdmFsdWU6IHN0cltpKytdIH0pO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmIChjaGFyID09PSBcIjpcIikge1xuICAgICAgdmFyIG5hbWUgPSBcIlwiO1xuICAgICAgdmFyIGogPSBpICsgMTtcbiAgICAgIHdoaWxlIChqIDwgc3RyLmxlbmd0aCkge1xuICAgICAgICB2YXIgY29kZSA9IHN0ci5jaGFyQ29kZUF0KGopO1xuICAgICAgICBpZiAoXG4gICAgICAgICAgLy8gYDAtOWBcbiAgICAgICAgICBjb2RlID49IDQ4ICYmIGNvZGUgPD0gNTcgfHwgLy8gYEEtWmBcbiAgICAgICAgICBjb2RlID49IDY1ICYmIGNvZGUgPD0gOTAgfHwgLy8gYGEtemBcbiAgICAgICAgICBjb2RlID49IDk3ICYmIGNvZGUgPD0gMTIyIHx8IC8vIGBfYFxuICAgICAgICAgIGNvZGUgPT09IDk1XG4gICAgICAgICkge1xuICAgICAgICAgIG5hbWUgKz0gc3RyW2orK107XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBpZiAoIW5hbWUpXG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJNaXNzaW5nIHBhcmFtZXRlciBuYW1lIGF0IFwiLmNvbmNhdChpKSk7XG4gICAgICB0b2tlbnMucHVzaCh7IHR5cGU6IFwiTkFNRVwiLCBpbmRleDogaSwgdmFsdWU6IG5hbWUgfSk7XG4gICAgICBpID0gajtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpZiAoY2hhciA9PT0gXCIoXCIpIHtcbiAgICAgIHZhciBjb3VudCA9IDE7XG4gICAgICB2YXIgcGF0dGVybiA9IFwiXCI7XG4gICAgICB2YXIgaiA9IGkgKyAxO1xuICAgICAgaWYgKHN0cltqXSA9PT0gXCI/XCIpIHtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignUGF0dGVybiBjYW5ub3Qgc3RhcnQgd2l0aCBcIj9cIiBhdCAnLmNvbmNhdChqKSk7XG4gICAgICB9XG4gICAgICB3aGlsZSAoaiA8IHN0ci5sZW5ndGgpIHtcbiAgICAgICAgaWYgKHN0cltqXSA9PT0gXCJcXFxcXCIpIHtcbiAgICAgICAgICBwYXR0ZXJuICs9IHN0cltqKytdICsgc3RyW2orK107XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHN0cltqXSA9PT0gXCIpXCIpIHtcbiAgICAgICAgICBjb3VudC0tO1xuICAgICAgICAgIGlmIChjb3VudCA9PT0gMCkge1xuICAgICAgICAgICAgaisrO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2UgaWYgKHN0cltqXSA9PT0gXCIoXCIpIHtcbiAgICAgICAgICBjb3VudCsrO1xuICAgICAgICAgIGlmIChzdHJbaiArIDFdICE9PSBcIj9cIikge1xuICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkNhcHR1cmluZyBncm91cHMgYXJlIG5vdCBhbGxvd2VkIGF0IFwiLmNvbmNhdChqKSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHBhdHRlcm4gKz0gc3RyW2orK107XG4gICAgICB9XG4gICAgICBpZiAoY291bnQpXG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJVbmJhbGFuY2VkIHBhdHRlcm4gYXQgXCIuY29uY2F0KGkpKTtcbiAgICAgIGlmICghcGF0dGVybilcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIk1pc3NpbmcgcGF0dGVybiBhdCBcIi5jb25jYXQoaSkpO1xuICAgICAgdG9rZW5zLnB1c2goeyB0eXBlOiBcIlBBVFRFUk5cIiwgaW5kZXg6IGksIHZhbHVlOiBwYXR0ZXJuIH0pO1xuICAgICAgaSA9IGo7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgdG9rZW5zLnB1c2goeyB0eXBlOiBcIkNIQVJcIiwgaW5kZXg6IGksIHZhbHVlOiBzdHJbaSsrXSB9KTtcbiAgfVxuICB0b2tlbnMucHVzaCh7IHR5cGU6IFwiRU5EXCIsIGluZGV4OiBpLCB2YWx1ZTogXCJcIiB9KTtcbiAgcmV0dXJuIHRva2Vucztcbn1cbmZ1bmN0aW9uIHBhcnNlKHN0ciwgb3B0aW9ucykge1xuICBpZiAob3B0aW9ucyA9PT0gdm9pZCAwKSB7XG4gICAgb3B0aW9ucyA9IHt9O1xuICB9XG4gIHZhciB0b2tlbnMgPSBsZXhlcihzdHIpO1xuICB2YXIgX2EyID0gb3B0aW9ucy5wcmVmaXhlcywgcHJlZml4ZXMgPSBfYTIgPT09IHZvaWQgMCA/IFwiLi9cIiA6IF9hMjtcbiAgdmFyIGRlZmF1bHRQYXR0ZXJuID0gXCJbXlwiLmNvbmNhdChlc2NhcGVTdHJpbmcob3B0aW9ucy5kZWxpbWl0ZXIgfHwgXCIvIz9cIiksIFwiXSs/XCIpO1xuICB2YXIgcmVzdWx0ID0gW107XG4gIHZhciBrZXkgPSAwO1xuICB2YXIgaSA9IDA7XG4gIHZhciBwYXRoID0gXCJcIjtcbiAgdmFyIHRyeUNvbnN1bWUgPSBmdW5jdGlvbih0eXBlKSB7XG4gICAgaWYgKGkgPCB0b2tlbnMubGVuZ3RoICYmIHRva2Vuc1tpXS50eXBlID09PSB0eXBlKVxuICAgICAgcmV0dXJuIHRva2Vuc1tpKytdLnZhbHVlO1xuICB9O1xuICB2YXIgbXVzdENvbnN1bWUgPSBmdW5jdGlvbih0eXBlKSB7XG4gICAgdmFyIHZhbHVlMiA9IHRyeUNvbnN1bWUodHlwZSk7XG4gICAgaWYgKHZhbHVlMiAhPT0gdm9pZCAwKVxuICAgICAgcmV0dXJuIHZhbHVlMjtcbiAgICB2YXIgX2EzID0gdG9rZW5zW2ldLCBuZXh0VHlwZSA9IF9hMy50eXBlLCBpbmRleCA9IF9hMy5pbmRleDtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiVW5leHBlY3RlZCBcIi5jb25jYXQobmV4dFR5cGUsIFwiIGF0IFwiKS5jb25jYXQoaW5kZXgsIFwiLCBleHBlY3RlZCBcIikuY29uY2F0KHR5cGUpKTtcbiAgfTtcbiAgdmFyIGNvbnN1bWVUZXh0ID0gZnVuY3Rpb24oKSB7XG4gICAgdmFyIHJlc3VsdDIgPSBcIlwiO1xuICAgIHZhciB2YWx1ZTI7XG4gICAgd2hpbGUgKHZhbHVlMiA9IHRyeUNvbnN1bWUoXCJDSEFSXCIpIHx8IHRyeUNvbnN1bWUoXCJFU0NBUEVEX0NIQVJcIikpIHtcbiAgICAgIHJlc3VsdDIgKz0gdmFsdWUyO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0MjtcbiAgfTtcbiAgd2hpbGUgKGkgPCB0b2tlbnMubGVuZ3RoKSB7XG4gICAgdmFyIGNoYXIgPSB0cnlDb25zdW1lKFwiQ0hBUlwiKTtcbiAgICB2YXIgbmFtZSA9IHRyeUNvbnN1bWUoXCJOQU1FXCIpO1xuICAgIHZhciBwYXR0ZXJuID0gdHJ5Q29uc3VtZShcIlBBVFRFUk5cIik7XG4gICAgaWYgKG5hbWUgfHwgcGF0dGVybikge1xuICAgICAgdmFyIHByZWZpeCA9IGNoYXIgfHwgXCJcIjtcbiAgICAgIGlmIChwcmVmaXhlcy5pbmRleE9mKHByZWZpeCkgPT09IC0xKSB7XG4gICAgICAgIHBhdGggKz0gcHJlZml4O1xuICAgICAgICBwcmVmaXggPSBcIlwiO1xuICAgICAgfVxuICAgICAgaWYgKHBhdGgpIHtcbiAgICAgICAgcmVzdWx0LnB1c2gocGF0aCk7XG4gICAgICAgIHBhdGggPSBcIlwiO1xuICAgICAgfVxuICAgICAgcmVzdWx0LnB1c2goe1xuICAgICAgICBuYW1lOiBuYW1lIHx8IGtleSsrLFxuICAgICAgICBwcmVmaXgsXG4gICAgICAgIHN1ZmZpeDogXCJcIixcbiAgICAgICAgcGF0dGVybjogcGF0dGVybiB8fCBkZWZhdWx0UGF0dGVybixcbiAgICAgICAgbW9kaWZpZXI6IHRyeUNvbnN1bWUoXCJNT0RJRklFUlwiKSB8fCBcIlwiXG4gICAgICB9KTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICB2YXIgdmFsdWUgPSBjaGFyIHx8IHRyeUNvbnN1bWUoXCJFU0NBUEVEX0NIQVJcIik7XG4gICAgaWYgKHZhbHVlKSB7XG4gICAgICBwYXRoICs9IHZhbHVlO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmIChwYXRoKSB7XG4gICAgICByZXN1bHQucHVzaChwYXRoKTtcbiAgICAgIHBhdGggPSBcIlwiO1xuICAgIH1cbiAgICB2YXIgb3BlbiA9IHRyeUNvbnN1bWUoXCJPUEVOXCIpO1xuICAgIGlmIChvcGVuKSB7XG4gICAgICB2YXIgcHJlZml4ID0gY29uc3VtZVRleHQoKTtcbiAgICAgIHZhciBuYW1lXzEgPSB0cnlDb25zdW1lKFwiTkFNRVwiKSB8fCBcIlwiO1xuICAgICAgdmFyIHBhdHRlcm5fMSA9IHRyeUNvbnN1bWUoXCJQQVRURVJOXCIpIHx8IFwiXCI7XG4gICAgICB2YXIgc3VmZml4ID0gY29uc3VtZVRleHQoKTtcbiAgICAgIG11c3RDb25zdW1lKFwiQ0xPU0VcIik7XG4gICAgICByZXN1bHQucHVzaCh7XG4gICAgICAgIG5hbWU6IG5hbWVfMSB8fCAocGF0dGVybl8xID8ga2V5KysgOiBcIlwiKSxcbiAgICAgICAgcGF0dGVybjogbmFtZV8xICYmICFwYXR0ZXJuXzEgPyBkZWZhdWx0UGF0dGVybiA6IHBhdHRlcm5fMSxcbiAgICAgICAgcHJlZml4LFxuICAgICAgICBzdWZmaXgsXG4gICAgICAgIG1vZGlmaWVyOiB0cnlDb25zdW1lKFwiTU9ESUZJRVJcIikgfHwgXCJcIlxuICAgICAgfSk7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgbXVzdENvbnN1bWUoXCJFTkRcIik7XG4gIH1cbiAgcmV0dXJuIHJlc3VsdDtcbn1cbmZ1bmN0aW9uIG1hdGNoKHN0ciwgb3B0aW9ucykge1xuICB2YXIga2V5cyA9IFtdO1xuICB2YXIgcmUgPSBwYXRoVG9SZWdleHAoc3RyLCBrZXlzLCBvcHRpb25zKTtcbiAgcmV0dXJuIHJlZ2V4cFRvRnVuY3Rpb24ocmUsIGtleXMsIG9wdGlvbnMpO1xufVxuZnVuY3Rpb24gcmVnZXhwVG9GdW5jdGlvbihyZSwga2V5cywgb3B0aW9ucykge1xuICBpZiAob3B0aW9ucyA9PT0gdm9pZCAwKSB7XG4gICAgb3B0aW9ucyA9IHt9O1xuICB9XG4gIHZhciBfYTIgPSBvcHRpb25zLmRlY29kZSwgZGVjb2RlID0gX2EyID09PSB2b2lkIDAgPyBmdW5jdGlvbih4KSB7XG4gICAgcmV0dXJuIHg7XG4gIH0gOiBfYTI7XG4gIHJldHVybiBmdW5jdGlvbihwYXRobmFtZSkge1xuICAgIHZhciBtID0gcmUuZXhlYyhwYXRobmFtZSk7XG4gICAgaWYgKCFtKVxuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIHZhciBwYXRoID0gbVswXSwgaW5kZXggPSBtLmluZGV4O1xuICAgIHZhciBwYXJhbXMgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICB2YXIgX2xvb3BfMSA9IGZ1bmN0aW9uKGkyKSB7XG4gICAgICBpZiAobVtpMl0gPT09IHZvaWQgMClcbiAgICAgICAgcmV0dXJuIFwiY29udGludWVcIjtcbiAgICAgIHZhciBrZXkgPSBrZXlzW2kyIC0gMV07XG4gICAgICBpZiAoa2V5Lm1vZGlmaWVyID09PSBcIipcIiB8fCBrZXkubW9kaWZpZXIgPT09IFwiK1wiKSB7XG4gICAgICAgIHBhcmFtc1trZXkubmFtZV0gPSBtW2kyXS5zcGxpdChrZXkucHJlZml4ICsga2V5LnN1ZmZpeCkubWFwKGZ1bmN0aW9uKHZhbHVlKSB7XG4gICAgICAgICAgcmV0dXJuIGRlY29kZSh2YWx1ZSwga2V5KTtcbiAgICAgICAgfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBwYXJhbXNba2V5Lm5hbWVdID0gZGVjb2RlKG1baTJdLCBrZXkpO1xuICAgICAgfVxuICAgIH07XG4gICAgZm9yICh2YXIgaSA9IDE7IGkgPCBtLmxlbmd0aDsgaSsrKSB7XG4gICAgICBfbG9vcF8xKGkpO1xuICAgIH1cbiAgICByZXR1cm4geyBwYXRoLCBpbmRleCwgcGFyYW1zIH07XG4gIH07XG59XG5mdW5jdGlvbiBlc2NhcGVTdHJpbmcoc3RyKSB7XG4gIHJldHVybiBzdHIucmVwbGFjZSgvKFsuKyo/PV4hOiR7fSgpW1xcXXwvXFxcXF0pL2csIFwiXFxcXCQxXCIpO1xufVxuZnVuY3Rpb24gZmxhZ3Mob3B0aW9ucykge1xuICByZXR1cm4gb3B0aW9ucyAmJiBvcHRpb25zLnNlbnNpdGl2ZSA/IFwiXCIgOiBcImlcIjtcbn1cbmZ1bmN0aW9uIHJlZ2V4cFRvUmVnZXhwKHBhdGgsIGtleXMpIHtcbiAgaWYgKCFrZXlzKVxuICAgIHJldHVybiBwYXRoO1xuICB2YXIgZ3JvdXBzUmVnZXggPSAvXFwoKD86XFw/PCguKj8pPik/KD8hXFw/KS9nO1xuICB2YXIgaW5kZXggPSAwO1xuICB2YXIgZXhlY1Jlc3VsdCA9IGdyb3Vwc1JlZ2V4LmV4ZWMocGF0aC5zb3VyY2UpO1xuICB3aGlsZSAoZXhlY1Jlc3VsdCkge1xuICAgIGtleXMucHVzaCh7XG4gICAgICAvLyBVc2UgcGFyZW50aGVzaXplZCBzdWJzdHJpbmcgbWF0Y2ggaWYgYXZhaWxhYmxlLCBpbmRleCBvdGhlcndpc2VcbiAgICAgIG5hbWU6IGV4ZWNSZXN1bHRbMV0gfHwgaW5kZXgrKyxcbiAgICAgIHByZWZpeDogXCJcIixcbiAgICAgIHN1ZmZpeDogXCJcIixcbiAgICAgIG1vZGlmaWVyOiBcIlwiLFxuICAgICAgcGF0dGVybjogXCJcIlxuICAgIH0pO1xuICAgIGV4ZWNSZXN1bHQgPSBncm91cHNSZWdleC5leGVjKHBhdGguc291cmNlKTtcbiAgfVxuICByZXR1cm4gcGF0aDtcbn1cbmZ1bmN0aW9uIGFycmF5VG9SZWdleHAocGF0aHMsIGtleXMsIG9wdGlvbnMpIHtcbiAgdmFyIHBhcnRzID0gcGF0aHMubWFwKGZ1bmN0aW9uKHBhdGgpIHtcbiAgICByZXR1cm4gcGF0aFRvUmVnZXhwKHBhdGgsIGtleXMsIG9wdGlvbnMpLnNvdXJjZTtcbiAgfSk7XG4gIHJldHVybiBuZXcgUmVnRXhwKFwiKD86XCIuY29uY2F0KHBhcnRzLmpvaW4oXCJ8XCIpLCBcIilcIiksIGZsYWdzKG9wdGlvbnMpKTtcbn1cbmZ1bmN0aW9uIHN0cmluZ1RvUmVnZXhwKHBhdGgsIGtleXMsIG9wdGlvbnMpIHtcbiAgcmV0dXJuIHRva2Vuc1RvUmVnZXhwKHBhcnNlKHBhdGgsIG9wdGlvbnMpLCBrZXlzLCBvcHRpb25zKTtcbn1cbmZ1bmN0aW9uIHRva2Vuc1RvUmVnZXhwKHRva2Vucywga2V5cywgb3B0aW9ucykge1xuICBpZiAob3B0aW9ucyA9PT0gdm9pZCAwKSB7XG4gICAgb3B0aW9ucyA9IHt9O1xuICB9XG4gIHZhciBfYTIgPSBvcHRpb25zLnN0cmljdCwgc3RyaWN0ID0gX2EyID09PSB2b2lkIDAgPyBmYWxzZSA6IF9hMiwgX2IyID0gb3B0aW9ucy5zdGFydCwgc3RhcnQgPSBfYjIgPT09IHZvaWQgMCA/IHRydWUgOiBfYjIsIF9jID0gb3B0aW9ucy5lbmQsIGVuZCA9IF9jID09PSB2b2lkIDAgPyB0cnVlIDogX2MsIF9kID0gb3B0aW9ucy5lbmNvZGUsIGVuY29kZSA9IF9kID09PSB2b2lkIDAgPyBmdW5jdGlvbih4KSB7XG4gICAgcmV0dXJuIHg7XG4gIH0gOiBfZCwgX2UgPSBvcHRpb25zLmRlbGltaXRlciwgZGVsaW1pdGVyID0gX2UgPT09IHZvaWQgMCA/IFwiLyM/XCIgOiBfZSwgX2YgPSBvcHRpb25zLmVuZHNXaXRoLCBlbmRzV2l0aCA9IF9mID09PSB2b2lkIDAgPyBcIlwiIDogX2Y7XG4gIHZhciBlbmRzV2l0aFJlID0gXCJbXCIuY29uY2F0KGVzY2FwZVN0cmluZyhlbmRzV2l0aCksIFwiXXwkXCIpO1xuICB2YXIgZGVsaW1pdGVyUmUgPSBcIltcIi5jb25jYXQoZXNjYXBlU3RyaW5nKGRlbGltaXRlciksIFwiXVwiKTtcbiAgdmFyIHJvdXRlID0gc3RhcnQgPyBcIl5cIiA6IFwiXCI7XG4gIGZvciAodmFyIF9pID0gMCwgdG9rZW5zXzEgPSB0b2tlbnM7IF9pIDwgdG9rZW5zXzEubGVuZ3RoOyBfaSsrKSB7XG4gICAgdmFyIHRva2VuID0gdG9rZW5zXzFbX2ldO1xuICAgIGlmICh0eXBlb2YgdG9rZW4gPT09IFwic3RyaW5nXCIpIHtcbiAgICAgIHJvdXRlICs9IGVzY2FwZVN0cmluZyhlbmNvZGUodG9rZW4pKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdmFyIHByZWZpeCA9IGVzY2FwZVN0cmluZyhlbmNvZGUodG9rZW4ucHJlZml4KSk7XG4gICAgICB2YXIgc3VmZml4ID0gZXNjYXBlU3RyaW5nKGVuY29kZSh0b2tlbi5zdWZmaXgpKTtcbiAgICAgIGlmICh0b2tlbi5wYXR0ZXJuKSB7XG4gICAgICAgIGlmIChrZXlzKVxuICAgICAgICAgIGtleXMucHVzaCh0b2tlbik7XG4gICAgICAgIGlmIChwcmVmaXggfHwgc3VmZml4KSB7XG4gICAgICAgICAgaWYgKHRva2VuLm1vZGlmaWVyID09PSBcIitcIiB8fCB0b2tlbi5tb2RpZmllciA9PT0gXCIqXCIpIHtcbiAgICAgICAgICAgIHZhciBtb2QgPSB0b2tlbi5tb2RpZmllciA9PT0gXCIqXCIgPyBcIj9cIiA6IFwiXCI7XG4gICAgICAgICAgICByb3V0ZSArPSBcIig/OlwiLmNvbmNhdChwcmVmaXgsIFwiKCg/OlwiKS5jb25jYXQodG9rZW4ucGF0dGVybiwgXCIpKD86XCIpLmNvbmNhdChzdWZmaXgpLmNvbmNhdChwcmVmaXgsIFwiKD86XCIpLmNvbmNhdCh0b2tlbi5wYXR0ZXJuLCBcIikpKilcIikuY29uY2F0KHN1ZmZpeCwgXCIpXCIpLmNvbmNhdChtb2QpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByb3V0ZSArPSBcIig/OlwiLmNvbmNhdChwcmVmaXgsIFwiKFwiKS5jb25jYXQodG9rZW4ucGF0dGVybiwgXCIpXCIpLmNvbmNhdChzdWZmaXgsIFwiKVwiKS5jb25jYXQodG9rZW4ubW9kaWZpZXIpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBpZiAodG9rZW4ubW9kaWZpZXIgPT09IFwiK1wiIHx8IHRva2VuLm1vZGlmaWVyID09PSBcIipcIikge1xuICAgICAgICAgICAgcm91dGUgKz0gXCIoKD86XCIuY29uY2F0KHRva2VuLnBhdHRlcm4sIFwiKVwiKS5jb25jYXQodG9rZW4ubW9kaWZpZXIsIFwiKVwiKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcm91dGUgKz0gXCIoXCIuY29uY2F0KHRva2VuLnBhdHRlcm4sIFwiKVwiKS5jb25jYXQodG9rZW4ubW9kaWZpZXIpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcm91dGUgKz0gXCIoPzpcIi5jb25jYXQocHJlZml4KS5jb25jYXQoc3VmZml4LCBcIilcIikuY29uY2F0KHRva2VuLm1vZGlmaWVyKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgaWYgKGVuZCkge1xuICAgIGlmICghc3RyaWN0KVxuICAgICAgcm91dGUgKz0gXCJcIi5jb25jYXQoZGVsaW1pdGVyUmUsIFwiP1wiKTtcbiAgICByb3V0ZSArPSAhb3B0aW9ucy5lbmRzV2l0aCA/IFwiJFwiIDogXCIoPz1cIi5jb25jYXQoZW5kc1dpdGhSZSwgXCIpXCIpO1xuICB9IGVsc2Uge1xuICAgIHZhciBlbmRUb2tlbiA9IHRva2Vuc1t0b2tlbnMubGVuZ3RoIC0gMV07XG4gICAgdmFyIGlzRW5kRGVsaW1pdGVkID0gdHlwZW9mIGVuZFRva2VuID09PSBcInN0cmluZ1wiID8gZGVsaW1pdGVyUmUuaW5kZXhPZihlbmRUb2tlbltlbmRUb2tlbi5sZW5ndGggLSAxXSkgPiAtMSA6IGVuZFRva2VuID09PSB2b2lkIDA7XG4gICAgaWYgKCFzdHJpY3QpIHtcbiAgICAgIHJvdXRlICs9IFwiKD86XCIuY29uY2F0KGRlbGltaXRlclJlLCBcIig/PVwiKS5jb25jYXQoZW5kc1dpdGhSZSwgXCIpKT9cIik7XG4gICAgfVxuICAgIGlmICghaXNFbmREZWxpbWl0ZWQpIHtcbiAgICAgIHJvdXRlICs9IFwiKD89XCIuY29uY2F0KGRlbGltaXRlclJlLCBcInxcIikuY29uY2F0KGVuZHNXaXRoUmUsIFwiKVwiKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG5ldyBSZWdFeHAocm91dGUsIGZsYWdzKG9wdGlvbnMpKTtcbn1cbmZ1bmN0aW9uIHBhdGhUb1JlZ2V4cChwYXRoLCBrZXlzLCBvcHRpb25zKSB7XG4gIGlmIChwYXRoIGluc3RhbmNlb2YgUmVnRXhwKVxuICAgIHJldHVybiByZWdleHBUb1JlZ2V4cChwYXRoLCBrZXlzKTtcbiAgaWYgKEFycmF5LmlzQXJyYXkocGF0aCkpXG4gICAgcmV0dXJuIGFycmF5VG9SZWdleHAocGF0aCwga2V5cywgb3B0aW9ucyk7XG4gIHJldHVybiBzdHJpbmdUb1JlZ2V4cChwYXRoLCBrZXlzLCBvcHRpb25zKTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL0Btc3dqcytpbnRlcmNlcHRvcnNAMC4yNS4xNi9ub2RlX21vZHVsZXMvQG1zd2pzL2ludGVyY2VwdG9ycy9saWIvYnJvd3Nlci9jaHVuay1VSlpPSlNNUC5tanNcbnZhciBlbmNvZGVyID0gbmV3IFRleHRFbmNvZGVyKCk7XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9pcy1ub2RlLXByb2Nlc3NAMS4yLjAvbm9kZV9tb2R1bGVzL2lzLW5vZGUtcHJvY2Vzcy9saWIvaW5kZXgubWpzXG5mdW5jdGlvbiBpc05vZGVQcm9jZXNzKCkge1xuICBpZiAodHlwZW9mIG5hdmlnYXRvciAhPT0gXCJ1bmRlZmluZWRcIiAmJiBuYXZpZ2F0b3IucHJvZHVjdCA9PT0gXCJSZWFjdE5hdGl2ZVwiKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgaWYgKHR5cGVvZiBwcm9jZXNzICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgY29uc3QgdHlwZSA9IHByb2Nlc3MudHlwZTtcbiAgICBpZiAodHlwZSA9PT0gXCJyZW5kZXJlclwiIHx8IHR5cGUgPT09IFwid29ya2VyXCIpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgcmV0dXJuICEhKHByb2Nlc3MudmVyc2lvbnMgJiYgcHJvY2Vzcy52ZXJzaW9ucy5ub2RlKTtcbiAgfVxuICByZXR1cm4gZmFsc2U7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9Ab3Blbi1kcmFmdCtsb2dnZXJAMC4zLjAvbm9kZV9tb2R1bGVzL0BvcGVuLWRyYWZ0L2xvZ2dlci9saWIvaW5kZXgubWpzXG52YXIgX19kZWZQcm9wMiA9IE9iamVjdC5kZWZpbmVQcm9wZXJ0eTtcbnZhciBfX2V4cG9ydCA9ICh0YXJnZXQsIGFsbCkgPT4ge1xuICBmb3IgKHZhciBuYW1lIGluIGFsbClcbiAgICBfX2RlZlByb3AyKHRhcmdldCwgbmFtZSwgeyBnZXQ6IGFsbFtuYW1lXSwgZW51bWVyYWJsZTogdHJ1ZSB9KTtcbn07XG52YXIgY29sb3JzX2V4cG9ydHMgPSB7fTtcbl9fZXhwb3J0KGNvbG9yc19leHBvcnRzLCB7XG4gIGJsdWU6ICgpID0+IGJsdWUsXG4gIGdyYXk6ICgpID0+IGdyYXksXG4gIGdyZWVuOiAoKSA9PiBncmVlbixcbiAgcmVkOiAoKSA9PiByZWQsXG4gIHllbGxvdzogKCkgPT4geWVsbG93XG59KTtcbmZ1bmN0aW9uIHllbGxvdyh0ZXh0KSB7XG4gIHJldHVybiBgXFx4MUJbMzNtJHt0ZXh0fVxceDFCWzBtYDtcbn1cbmZ1bmN0aW9uIGJsdWUodGV4dCkge1xuICByZXR1cm4gYFxceDFCWzM0bSR7dGV4dH1cXHgxQlswbWA7XG59XG5mdW5jdGlvbiBncmF5KHRleHQpIHtcbiAgcmV0dXJuIGBcXHgxQls5MG0ke3RleHR9XFx4MUJbMG1gO1xufVxuZnVuY3Rpb24gcmVkKHRleHQpIHtcbiAgcmV0dXJuIGBcXHgxQlszMW0ke3RleHR9XFx4MUJbMG1gO1xufVxuZnVuY3Rpb24gZ3JlZW4odGV4dCkge1xuICByZXR1cm4gYFxceDFCWzMybSR7dGV4dH1cXHgxQlswbWA7XG59XG52YXIgSVNfTk9ERSA9IGlzTm9kZVByb2Nlc3MoKTtcblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL0Btc3dqcytpbnRlcmNlcHRvcnNAMC4yNS4xNi9ub2RlX21vZHVsZXMvQG1zd2pzL2ludGVyY2VwdG9ycy9saWIvYnJvd3Nlci9jaHVuay1XWlFOM0ZNWS5tanNcbnZhciBJU19QQVRDSEVEX01PRFVMRSA9IFN5bWJvbChcImlzUGF0Y2hlZE1vZHVsZVwiKTtcbnZhciBJbnRlcmNlcHRvclJlYWR5U3RhdGUgPSAoKEludGVyY2VwdG9yUmVhZHlTdGF0ZTIpID0+IHtcbiAgSW50ZXJjZXB0b3JSZWFkeVN0YXRlMltcIklOQUNUSVZFXCJdID0gXCJJTkFDVElWRVwiO1xuICBJbnRlcmNlcHRvclJlYWR5U3RhdGUyW1wiQVBQTFlJTkdcIl0gPSBcIkFQUExZSU5HXCI7XG4gIEludGVyY2VwdG9yUmVhZHlTdGF0ZTJbXCJBUFBMSUVEXCJdID0gXCJBUFBMSUVEXCI7XG4gIEludGVyY2VwdG9yUmVhZHlTdGF0ZTJbXCJESVNQT1NJTkdcIl0gPSBcIkRJU1BPU0lOR1wiO1xuICBJbnRlcmNlcHRvclJlYWR5U3RhdGUyW1wiRElTUE9TRURcIl0gPSBcIkRJU1BPU0VEXCI7XG4gIHJldHVybiBJbnRlcmNlcHRvclJlYWR5U3RhdGUyO1xufSkoSW50ZXJjZXB0b3JSZWFkeVN0YXRlIHx8IHt9KTtcblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL0Btc3dqcytpbnRlcmNlcHRvcnNAMC4yNS4xNi9ub2RlX21vZHVsZXMvQG1zd2pzL2ludGVyY2VwdG9ycy9saWIvYnJvd3Nlci9pbmRleC5tanNcbmZ1bmN0aW9uIGdldENsZWFuVXJsKHVybCwgaXNBYnNvbHV0ZSA9IHRydWUpIHtcbiAgcmV0dXJuIFtpc0Fic29sdXRlICYmIHVybC5vcmlnaW4sIHVybC5wYXRobmFtZV0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCJcIik7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9tc3dAMi4yLjFfdHlwZXNjcmlwdEA1LjMuMy9ub2RlX21vZHVsZXMvbXN3L2xpYi9jb3JlL3V0aWxzL3VybC9jbGVhblVybC5tanNcbnZhciBSRURVTkRBTlRfQ0hBUkFDVEVSU19FWFAgPSAvW1xcP3wjXS4qJC9nO1xuZnVuY3Rpb24gZ2V0U2VhcmNoUGFyYW1zKHBhdGgpIHtcbiAgcmV0dXJuIG5ldyBVUkwoYC8ke3BhdGh9YCwgXCJodHRwOi8vbG9jYWxob3N0XCIpLnNlYXJjaFBhcmFtcztcbn1cbmZ1bmN0aW9uIGNsZWFuVXJsKHBhdGgpIHtcbiAgcmV0dXJuIHBhdGgucmVwbGFjZShSRURVTkRBTlRfQ0hBUkFDVEVSU19FWFAsIFwiXCIpO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vbXN3QDIuMi4xX3R5cGVzY3JpcHRANS4zLjMvbm9kZV9tb2R1bGVzL21zdy9saWIvY29yZS91dGlscy91cmwvaXNBYnNvbHV0ZVVybC5tanNcbmZ1bmN0aW9uIGlzQWJzb2x1dGVVcmwodXJsKSB7XG4gIHJldHVybiAvXihbYS16XVthLXpcXGRcXCtcXC1cXC5dKjopP1xcL1xcLy9pLnRlc3QodXJsKTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL21zd0AyLjIuMV90eXBlc2NyaXB0QDUuMy4zL25vZGVfbW9kdWxlcy9tc3cvbGliL2NvcmUvdXRpbHMvdXJsL2dldEFic29sdXRlVXJsLm1qc1xuZnVuY3Rpb24gZ2V0QWJzb2x1dGVVcmwocGF0aCwgYmFzZVVybCkge1xuICBpZiAoaXNBYnNvbHV0ZVVybChwYXRoKSkge1xuICAgIHJldHVybiBwYXRoO1xuICB9XG4gIGlmIChwYXRoLnN0YXJ0c1dpdGgoXCIqXCIpKSB7XG4gICAgcmV0dXJuIHBhdGg7XG4gIH1cbiAgY29uc3Qgb3JpZ2luID0gYmFzZVVybCB8fCB0eXBlb2YgZG9jdW1lbnQgIT09IFwidW5kZWZpbmVkXCIgJiYgZG9jdW1lbnQuYmFzZVVSSTtcbiAgcmV0dXJuIG9yaWdpbiA/IChcbiAgICAvLyBFbmNvZGUgYW5kIGRlY29kZSB0aGUgcGF0aCB0byBwcmVzZXJ2ZSBlc2NhcGVkIGNoYXJhY3RlcnMuXG4gICAgZGVjb2RlVVJJKG5ldyBVUkwoZW5jb2RlVVJJKHBhdGgpLCBvcmlnaW4pLmhyZWYpXG4gICkgOiBwYXRoO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vbXN3QDIuMi4xX3R5cGVzY3JpcHRANS4zLjMvbm9kZV9tb2R1bGVzL21zdy9saWIvY29yZS91dGlscy9tYXRjaGluZy9ub3JtYWxpemVQYXRoLm1qc1xuZnVuY3Rpb24gbm9ybWFsaXplUGF0aChwYXRoLCBiYXNlVXJsKSB7XG4gIGlmIChwYXRoIGluc3RhbmNlb2YgUmVnRXhwKSB7XG4gICAgcmV0dXJuIHBhdGg7XG4gIH1cbiAgY29uc3QgbWF5YmVBYnNvbHV0ZVVybCA9IGdldEFic29sdXRlVXJsKHBhdGgsIGJhc2VVcmwpO1xuICByZXR1cm4gY2xlYW5VcmwobWF5YmVBYnNvbHV0ZVVybCk7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9tc3dAMi4yLjFfdHlwZXNjcmlwdEA1LjMuMy9ub2RlX21vZHVsZXMvbXN3L2xpYi9jb3JlL3V0aWxzL21hdGNoaW5nL21hdGNoUmVxdWVzdFVybC5tanNcbmZ1bmN0aW9uIGNvZXJjZVBhdGgocGF0aCkge1xuICByZXR1cm4gcGF0aC5yZXBsYWNlKFxuICAgIC8oWzphLXpBLVpfLV0qKShcXCp7MSwyfSkrL2csXG4gICAgKF8sIHBhcmFtZXRlck5hbWUsIHdpbGRjYXJkKSA9PiB7XG4gICAgICBjb25zdCBleHByZXNzaW9uID0gXCIoLiopXCI7XG4gICAgICBpZiAoIXBhcmFtZXRlck5hbWUpIHtcbiAgICAgICAgcmV0dXJuIGV4cHJlc3Npb247XG4gICAgICB9XG4gICAgICByZXR1cm4gcGFyYW1ldGVyTmFtZS5zdGFydHNXaXRoKFwiOlwiKSA/IGAke3BhcmFtZXRlck5hbWV9JHt3aWxkY2FyZH1gIDogYCR7cGFyYW1ldGVyTmFtZX0ke2V4cHJlc3Npb259YDtcbiAgICB9XG4gICkucmVwbGFjZSgvKFteXFwvXSkoOikoPz1cXGQrKS8sIFwiJDFcXFxcJDJcIikucmVwbGFjZSgvXihbXlxcL10rKSg6KSg/PVxcL1xcLykvLCBcIiQxXFxcXCQyXCIpO1xufVxuZnVuY3Rpb24gbWF0Y2hSZXF1ZXN0VXJsKHVybCwgcGF0aCwgYmFzZVVybCkge1xuICBjb25zdCBub3JtYWxpemVkUGF0aCA9IG5vcm1hbGl6ZVBhdGgocGF0aCwgYmFzZVVybCk7XG4gIGNvbnN0IGNsZWFuUGF0aCA9IHR5cGVvZiBub3JtYWxpemVkUGF0aCA9PT0gXCJzdHJpbmdcIiA/IGNvZXJjZVBhdGgobm9ybWFsaXplZFBhdGgpIDogbm9ybWFsaXplZFBhdGg7XG4gIGNvbnN0IGNsZWFuVXJsMiA9IGdldENsZWFuVXJsKHVybCk7XG4gIGNvbnN0IHJlc3VsdCA9IG1hdGNoKGNsZWFuUGF0aCwgeyBkZWNvZGU6IGRlY29kZVVSSUNvbXBvbmVudCB9KShjbGVhblVybDIpO1xuICBjb25zdCBwYXJhbXMgPSByZXN1bHQgJiYgcmVzdWx0LnBhcmFtcyB8fCB7fTtcbiAgcmV0dXJuIHtcbiAgICBtYXRjaGVzOiByZXN1bHQgIT09IGZhbHNlLFxuICAgIHBhcmFtc1xuICB9O1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vQGJ1bmRsZWQtZXMtbW9kdWxlcytjb29raWVAMi4wLjAvbm9kZV9tb2R1bGVzL0BidW5kbGVkLWVzLW1vZHVsZXMvY29va2llL2luZGV4LWVzbS5qc1xudmFyIF9fY3JlYXRlMiA9IE9iamVjdC5jcmVhdGU7XG52YXIgX19kZWZQcm9wMyA9IE9iamVjdC5kZWZpbmVQcm9wZXJ0eTtcbnZhciBfX2dldE93blByb3BEZXNjMiA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3I7XG52YXIgX19nZXRPd25Qcm9wTmFtZXMyID0gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXM7XG52YXIgX19nZXRQcm90b09mMiA9IE9iamVjdC5nZXRQcm90b3R5cGVPZjtcbnZhciBfX2hhc093blByb3AyID0gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eTtcbnZhciBfX2NvbW1vbkpTMiA9IChjYiwgbW9kKSA9PiBmdW5jdGlvbiBfX3JlcXVpcmUoKSB7XG4gIHJldHVybiBtb2QgfHwgKDAsIGNiW19fZ2V0T3duUHJvcE5hbWVzMihjYilbMF1dKSgobW9kID0geyBleHBvcnRzOiB7fSB9KS5leHBvcnRzLCBtb2QpLCBtb2QuZXhwb3J0cztcbn07XG52YXIgX19jb3B5UHJvcHMyID0gKHRvLCBmcm9tLCBleGNlcHQsIGRlc2MpID0+IHtcbiAgaWYgKGZyb20gJiYgdHlwZW9mIGZyb20gPT09IFwib2JqZWN0XCIgfHwgdHlwZW9mIGZyb20gPT09IFwiZnVuY3Rpb25cIikge1xuICAgIGZvciAobGV0IGtleSBvZiBfX2dldE93blByb3BOYW1lczIoZnJvbSkpXG4gICAgICBpZiAoIV9faGFzT3duUHJvcDIuY2FsbCh0bywga2V5KSAmJiBrZXkgIT09IGV4Y2VwdClcbiAgICAgICAgX19kZWZQcm9wMyh0bywga2V5LCB7IGdldDogKCkgPT4gZnJvbVtrZXldLCBlbnVtZXJhYmxlOiAhKGRlc2MgPSBfX2dldE93blByb3BEZXNjMihmcm9tLCBrZXkpKSB8fCBkZXNjLmVudW1lcmFibGUgfSk7XG4gIH1cbiAgcmV0dXJuIHRvO1xufTtcbnZhciBfX3RvRVNNMiA9IChtb2QsIGlzTm9kZU1vZGUsIHRhcmdldCkgPT4gKHRhcmdldCA9IG1vZCAhPSBudWxsID8gX19jcmVhdGUyKF9fZ2V0UHJvdG9PZjIobW9kKSkgOiB7fSwgX19jb3B5UHJvcHMyKFxuICAvLyBJZiB0aGUgaW1wb3J0ZXIgaXMgaW4gbm9kZSBjb21wYXRpYmlsaXR5IG1vZGUgb3IgdGhpcyBpcyBub3QgYW4gRVNNXG4gIC8vIGZpbGUgdGhhdCBoYXMgYmVlbiBjb252ZXJ0ZWQgdG8gYSBDb21tb25KUyBmaWxlIHVzaW5nIGEgQmFiZWwtXG4gIC8vIGNvbXBhdGlibGUgdHJhbnNmb3JtIChpLmUuIFwiX19lc01vZHVsZVwiIGhhcyBub3QgYmVlbiBzZXQpLCB0aGVuIHNldFxuICAvLyBcImRlZmF1bHRcIiB0byB0aGUgQ29tbW9uSlMgXCJtb2R1bGUuZXhwb3J0c1wiIGZvciBub2RlIGNvbXBhdGliaWxpdHkuXG4gIGlzTm9kZU1vZGUgfHwgIW1vZCB8fCAhbW9kLl9fZXNNb2R1bGUgPyBfX2RlZlByb3AzKHRhcmdldCwgXCJkZWZhdWx0XCIsIHsgdmFsdWU6IG1vZCwgZW51bWVyYWJsZTogdHJ1ZSB9KSA6IHRhcmdldCxcbiAgbW9kXG4pKTtcbnZhciByZXF1aXJlX2Nvb2tpZSA9IF9fY29tbW9uSlMyKHtcbiAgXCJub2RlX21vZHVsZXMvY29va2llL2luZGV4LmpzXCIoZXhwb3J0cykge1xuICAgIFwidXNlIHN0cmljdFwiO1xuICAgIGV4cG9ydHMucGFyc2UgPSBwYXJzZTM7XG4gICAgZXhwb3J0cy5zZXJpYWxpemUgPSBzZXJpYWxpemU7XG4gICAgdmFyIF9fdG9TdHJpbmcgPSBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nO1xuICAgIHZhciBmaWVsZENvbnRlbnRSZWdFeHAgPSAvXltcXHUwMDA5XFx1MDAyMC1cXHUwMDdlXFx1MDA4MC1cXHUwMGZmXSskLztcbiAgICBmdW5jdGlvbiBwYXJzZTMoc3RyLCBvcHRpb25zKSB7XG4gICAgICBpZiAodHlwZW9mIHN0ciAhPT0gXCJzdHJpbmdcIikge1xuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiYXJndW1lbnQgc3RyIG11c3QgYmUgYSBzdHJpbmdcIik7XG4gICAgICB9XG4gICAgICB2YXIgb2JqID0ge307XG4gICAgICB2YXIgb3B0ID0gb3B0aW9ucyB8fCB7fTtcbiAgICAgIHZhciBkZWMgPSBvcHQuZGVjb2RlIHx8IGRlY29kZTtcbiAgICAgIHZhciBpbmRleCA9IDA7XG4gICAgICB3aGlsZSAoaW5kZXggPCBzdHIubGVuZ3RoKSB7XG4gICAgICAgIHZhciBlcUlkeCA9IHN0ci5pbmRleE9mKFwiPVwiLCBpbmRleCk7XG4gICAgICAgIGlmIChlcUlkeCA9PT0gLTEpIHtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICB2YXIgZW5kSWR4ID0gc3RyLmluZGV4T2YoXCI7XCIsIGluZGV4KTtcbiAgICAgICAgaWYgKGVuZElkeCA9PT0gLTEpIHtcbiAgICAgICAgICBlbmRJZHggPSBzdHIubGVuZ3RoO1xuICAgICAgICB9IGVsc2UgaWYgKGVuZElkeCA8IGVxSWR4KSB7XG4gICAgICAgICAgaW5kZXggPSBzdHIubGFzdEluZGV4T2YoXCI7XCIsIGVxSWR4IC0gMSkgKyAxO1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIHZhciBrZXkgPSBzdHIuc2xpY2UoaW5kZXgsIGVxSWR4KS50cmltKCk7XG4gICAgICAgIGlmICh2b2lkIDAgPT09IG9ialtrZXldKSB7XG4gICAgICAgICAgdmFyIHZhbCA9IHN0ci5zbGljZShlcUlkeCArIDEsIGVuZElkeCkudHJpbSgpO1xuICAgICAgICAgIGlmICh2YWwuY2hhckNvZGVBdCgwKSA9PT0gMzQpIHtcbiAgICAgICAgICAgIHZhbCA9IHZhbC5zbGljZSgxLCAtMSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIG9ialtrZXldID0gdHJ5RGVjb2RlKHZhbCwgZGVjKTtcbiAgICAgICAgfVxuICAgICAgICBpbmRleCA9IGVuZElkeCArIDE7XG4gICAgICB9XG4gICAgICByZXR1cm4gb2JqO1xuICAgIH1cbiAgICBmdW5jdGlvbiBzZXJpYWxpemUobmFtZSwgdmFsLCBvcHRpb25zKSB7XG4gICAgICB2YXIgb3B0ID0gb3B0aW9ucyB8fCB7fTtcbiAgICAgIHZhciBlbmMgPSBvcHQuZW5jb2RlIHx8IGVuY29kZTtcbiAgICAgIGlmICh0eXBlb2YgZW5jICE9PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIm9wdGlvbiBlbmNvZGUgaXMgaW52YWxpZFwiKTtcbiAgICAgIH1cbiAgICAgIGlmICghZmllbGRDb250ZW50UmVnRXhwLnRlc3QobmFtZSkpIHtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcImFyZ3VtZW50IG5hbWUgaXMgaW52YWxpZFwiKTtcbiAgICAgIH1cbiAgICAgIHZhciB2YWx1ZSA9IGVuYyh2YWwpO1xuICAgICAgaWYgKHZhbHVlICYmICFmaWVsZENvbnRlbnRSZWdFeHAudGVzdCh2YWx1ZSkpIHtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcImFyZ3VtZW50IHZhbCBpcyBpbnZhbGlkXCIpO1xuICAgICAgfVxuICAgICAgdmFyIHN0ciA9IG5hbWUgKyBcIj1cIiArIHZhbHVlO1xuICAgICAgaWYgKG51bGwgIT0gb3B0Lm1heEFnZSkge1xuICAgICAgICB2YXIgbWF4QWdlID0gb3B0Lm1heEFnZSAtIDA7XG4gICAgICAgIGlmIChpc05hTihtYXhBZ2UpIHx8ICFpc0Zpbml0ZShtYXhBZ2UpKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIm9wdGlvbiBtYXhBZ2UgaXMgaW52YWxpZFwiKTtcbiAgICAgICAgfVxuICAgICAgICBzdHIgKz0gXCI7IE1heC1BZ2U9XCIgKyBNYXRoLmZsb29yKG1heEFnZSk7XG4gICAgICB9XG4gICAgICBpZiAob3B0LmRvbWFpbikge1xuICAgICAgICBpZiAoIWZpZWxkQ29udGVudFJlZ0V4cC50ZXN0KG9wdC5kb21haW4pKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIm9wdGlvbiBkb21haW4gaXMgaW52YWxpZFwiKTtcbiAgICAgICAgfVxuICAgICAgICBzdHIgKz0gXCI7IERvbWFpbj1cIiArIG9wdC5kb21haW47XG4gICAgICB9XG4gICAgICBpZiAob3B0LnBhdGgpIHtcbiAgICAgICAgaWYgKCFmaWVsZENvbnRlbnRSZWdFeHAudGVzdChvcHQucGF0aCkpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwib3B0aW9uIHBhdGggaXMgaW52YWxpZFwiKTtcbiAgICAgICAgfVxuICAgICAgICBzdHIgKz0gXCI7IFBhdGg9XCIgKyBvcHQucGF0aDtcbiAgICAgIH1cbiAgICAgIGlmIChvcHQuZXhwaXJlcykge1xuICAgICAgICB2YXIgZXhwaXJlcyA9IG9wdC5leHBpcmVzO1xuICAgICAgICBpZiAoIWlzRGF0ZShleHBpcmVzKSB8fCBpc05hTihleHBpcmVzLnZhbHVlT2YoKSkpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwib3B0aW9uIGV4cGlyZXMgaXMgaW52YWxpZFwiKTtcbiAgICAgICAgfVxuICAgICAgICBzdHIgKz0gXCI7IEV4cGlyZXM9XCIgKyBleHBpcmVzLnRvVVRDU3RyaW5nKCk7XG4gICAgICB9XG4gICAgICBpZiAob3B0Lmh0dHBPbmx5KSB7XG4gICAgICAgIHN0ciArPSBcIjsgSHR0cE9ubHlcIjtcbiAgICAgIH1cbiAgICAgIGlmIChvcHQuc2VjdXJlKSB7XG4gICAgICAgIHN0ciArPSBcIjsgU2VjdXJlXCI7XG4gICAgICB9XG4gICAgICBpZiAob3B0LnByaW9yaXR5KSB7XG4gICAgICAgIHZhciBwcmlvcml0eSA9IHR5cGVvZiBvcHQucHJpb3JpdHkgPT09IFwic3RyaW5nXCIgPyBvcHQucHJpb3JpdHkudG9Mb3dlckNhc2UoKSA6IG9wdC5wcmlvcml0eTtcbiAgICAgICAgc3dpdGNoIChwcmlvcml0eSkge1xuICAgICAgICAgIGNhc2UgXCJsb3dcIjpcbiAgICAgICAgICAgIHN0ciArPSBcIjsgUHJpb3JpdHk9TG93XCI7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgICBjYXNlIFwibWVkaXVtXCI6XG4gICAgICAgICAgICBzdHIgKz0gXCI7IFByaW9yaXR5PU1lZGl1bVwiO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgY2FzZSBcImhpZ2hcIjpcbiAgICAgICAgICAgIHN0ciArPSBcIjsgUHJpb3JpdHk9SGlnaFwiO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJvcHRpb24gcHJpb3JpdHkgaXMgaW52YWxpZFwiKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKG9wdC5zYW1lU2l0ZSkge1xuICAgICAgICB2YXIgc2FtZVNpdGUgPSB0eXBlb2Ygb3B0LnNhbWVTaXRlID09PSBcInN0cmluZ1wiID8gb3B0LnNhbWVTaXRlLnRvTG93ZXJDYXNlKCkgOiBvcHQuc2FtZVNpdGU7XG4gICAgICAgIHN3aXRjaCAoc2FtZVNpdGUpIHtcbiAgICAgICAgICBjYXNlIHRydWU6XG4gICAgICAgICAgICBzdHIgKz0gXCI7IFNhbWVTaXRlPVN0cmljdFwiO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgY2FzZSBcImxheFwiOlxuICAgICAgICAgICAgc3RyICs9IFwiOyBTYW1lU2l0ZT1MYXhcIjtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIGNhc2UgXCJzdHJpY3RcIjpcbiAgICAgICAgICAgIHN0ciArPSBcIjsgU2FtZVNpdGU9U3RyaWN0XCI7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgICBjYXNlIFwibm9uZVwiOlxuICAgICAgICAgICAgc3RyICs9IFwiOyBTYW1lU2l0ZT1Ob25lXCI7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIm9wdGlvbiBzYW1lU2l0ZSBpcyBpbnZhbGlkXCIpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gc3RyO1xuICAgIH1cbiAgICBmdW5jdGlvbiBkZWNvZGUoc3RyKSB7XG4gICAgICByZXR1cm4gc3RyLmluZGV4T2YoXCIlXCIpICE9PSAtMSA/IGRlY29kZVVSSUNvbXBvbmVudChzdHIpIDogc3RyO1xuICAgIH1cbiAgICBmdW5jdGlvbiBlbmNvZGUodmFsKSB7XG4gICAgICByZXR1cm4gZW5jb2RlVVJJQ29tcG9uZW50KHZhbCk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGlzRGF0ZSh2YWwpIHtcbiAgICAgIHJldHVybiBfX3RvU3RyaW5nLmNhbGwodmFsKSA9PT0gXCJbb2JqZWN0IERhdGVdXCIgfHwgdmFsIGluc3RhbmNlb2YgRGF0ZTtcbiAgICB9XG4gICAgZnVuY3Rpb24gdHJ5RGVjb2RlKHN0ciwgZGVjb2RlMikge1xuICAgICAgdHJ5IHtcbiAgICAgICAgcmV0dXJuIGRlY29kZTIoc3RyKTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgcmV0dXJuIHN0cjtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn0pO1xudmFyIGltcG9ydF9jb29raWUgPSBfX3RvRVNNMihyZXF1aXJlX2Nvb2tpZSgpLCAxKTtcbnZhciBzb3VyY2VfZGVmYXVsdDIgPSBpbXBvcnRfY29va2llLmRlZmF1bHQ7XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9tc3dAMi4yLjFfdHlwZXNjcmlwdEA1LjMuMy9ub2RlX21vZHVsZXMvbXN3L2xpYi9jb3JlL3V0aWxzL3JlcXVlc3QvZ2V0UmVxdWVzdENvb2tpZXMubWpzXG5mdW5jdGlvbiBnZXRBbGxEb2N1bWVudENvb2tpZXMoKSB7XG4gIHJldHVybiBzb3VyY2VfZGVmYXVsdDIucGFyc2UoZG9jdW1lbnQuY29va2llKTtcbn1cbmZ1bmN0aW9uIGdldFJlcXVlc3RDb29raWVzKHJlcXVlc3QpIHtcbiAgaWYgKHR5cGVvZiBkb2N1bWVudCA9PT0gXCJ1bmRlZmluZWRcIiB8fCB0eXBlb2YgbG9jYXRpb24gPT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICByZXR1cm4ge307XG4gIH1cbiAgc3dpdGNoIChyZXF1ZXN0LmNyZWRlbnRpYWxzKSB7XG4gICAgY2FzZSBcInNhbWUtb3JpZ2luXCI6IHtcbiAgICAgIGNvbnN0IHVybCA9IG5ldyBVUkwocmVxdWVzdC51cmwpO1xuICAgICAgcmV0dXJuIGxvY2F0aW9uLm9yaWdpbiA9PT0gdXJsLm9yaWdpbiA/IGdldEFsbERvY3VtZW50Q29va2llcygpIDoge307XG4gICAgfVxuICAgIGNhc2UgXCJpbmNsdWRlXCI6IHtcbiAgICAgIHJldHVybiBnZXRBbGxEb2N1bWVudENvb2tpZXMoKTtcbiAgICB9XG4gICAgZGVmYXVsdDoge1xuICAgICAgcmV0dXJuIHt9O1xuICAgIH1cbiAgfVxufVxuZnVuY3Rpb24gZ2V0QWxsUmVxdWVzdENvb2tpZXMocmVxdWVzdCkge1xuICB2YXIgX2EyO1xuICBjb25zdCByZXF1ZXN0Q29va2llc1N0cmluZyA9IHJlcXVlc3QuaGVhZGVycy5nZXQoXCJjb29raWVcIik7XG4gIGNvbnN0IGNvb2tpZXNGcm9tSGVhZGVycyA9IHJlcXVlc3RDb29raWVzU3RyaW5nID8gc291cmNlX2RlZmF1bHQyLnBhcnNlKHJlcXVlc3RDb29raWVzU3RyaW5nKSA6IHt9O1xuICBzdG9yZS5oeWRyYXRlKCk7XG4gIGNvbnN0IGNvb2tpZXNGcm9tU3RvcmUgPSBBcnJheS5mcm9tKChfYTIgPSBzdG9yZS5nZXQocmVxdWVzdCkpID09IG51bGwgPyB2b2lkIDAgOiBfYTIuZW50cmllcygpKS5yZWR1Y2UoKGNvb2tpZXMsIFtuYW1lLCB7IHZhbHVlIH1dKSA9PiB7XG4gICAgcmV0dXJuIE9iamVjdC5hc3NpZ24oY29va2llcywgeyBbbmFtZS50cmltKCldOiB2YWx1ZSB9KTtcbiAgfSwge30pO1xuICBjb25zdCBjb29raWVzRnJvbURvY3VtZW50ID0gZ2V0UmVxdWVzdENvb2tpZXMocmVxdWVzdCk7XG4gIGNvbnN0IGZvcndhcmRlZENvb2tpZXMgPSB7XG4gICAgLi4uY29va2llc0Zyb21Eb2N1bWVudCxcbiAgICAuLi5jb29raWVzRnJvbVN0b3JlXG4gIH07XG4gIGZvciAoY29uc3QgW25hbWUsIHZhbHVlXSBvZiBPYmplY3QuZW50cmllcyhmb3J3YXJkZWRDb29raWVzKSkge1xuICAgIHJlcXVlc3QuaGVhZGVycy5hcHBlbmQoXCJjb29raWVcIiwgc291cmNlX2RlZmF1bHQyLnNlcmlhbGl6ZShuYW1lLCB2YWx1ZSkpO1xuICB9XG4gIHJldHVybiB7XG4gICAgLi4uZm9yd2FyZGVkQ29va2llcyxcbiAgICAuLi5jb29raWVzRnJvbUhlYWRlcnNcbiAgfTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL21zd0AyLjIuMV90eXBlc2NyaXB0QDUuMy4zL25vZGVfbW9kdWxlcy9tc3cvbGliL2NvcmUvaGFuZGxlcnMvSHR0cEhhbmRsZXIubWpzXG52YXIgSHR0cE1ldGhvZHMgPSAoKEh0dHBNZXRob2RzMikgPT4ge1xuICBIdHRwTWV0aG9kczJbXCJIRUFEXCJdID0gXCJIRUFEXCI7XG4gIEh0dHBNZXRob2RzMltcIkdFVFwiXSA9IFwiR0VUXCI7XG4gIEh0dHBNZXRob2RzMltcIlBPU1RcIl0gPSBcIlBPU1RcIjtcbiAgSHR0cE1ldGhvZHMyW1wiUFVUXCJdID0gXCJQVVRcIjtcbiAgSHR0cE1ldGhvZHMyW1wiUEFUQ0hcIl0gPSBcIlBBVENIXCI7XG4gIEh0dHBNZXRob2RzMltcIk9QVElPTlNcIl0gPSBcIk9QVElPTlNcIjtcbiAgSHR0cE1ldGhvZHMyW1wiREVMRVRFXCJdID0gXCJERUxFVEVcIjtcbiAgcmV0dXJuIEh0dHBNZXRob2RzMjtcbn0pKEh0dHBNZXRob2RzIHx8IHt9KTtcbnZhciBIdHRwSGFuZGxlciA9IGNsYXNzIGV4dGVuZHMgUmVxdWVzdEhhbmRsZXIge1xuICBjb25zdHJ1Y3RvcihtZXRob2QsIHBhdGgsIHJlc29sdmVyLCBvcHRpb25zKSB7XG4gICAgc3VwZXIoe1xuICAgICAgaW5mbzoge1xuICAgICAgICBoZWFkZXI6IGAke21ldGhvZH0gJHtwYXRofWAsXG4gICAgICAgIHBhdGgsXG4gICAgICAgIG1ldGhvZFxuICAgICAgfSxcbiAgICAgIHJlc29sdmVyLFxuICAgICAgb3B0aW9uc1xuICAgIH0pO1xuICAgIHRoaXMuY2hlY2tSZWR1bmRhbnRRdWVyeVBhcmFtZXRlcnMoKTtcbiAgfVxuICBjaGVja1JlZHVuZGFudFF1ZXJ5UGFyYW1ldGVycygpIHtcbiAgICBjb25zdCB7IG1ldGhvZCwgcGF0aCB9ID0gdGhpcy5pbmZvO1xuICAgIGlmIChwYXRoIGluc3RhbmNlb2YgUmVnRXhwKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHVybCA9IGNsZWFuVXJsKHBhdGgpO1xuICAgIGlmICh1cmwgPT09IHBhdGgpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3Qgc2VhcmNoUGFyYW1zID0gZ2V0U2VhcmNoUGFyYW1zKHBhdGgpO1xuICAgIGNvbnN0IHF1ZXJ5UGFyYW1zID0gW107XG4gICAgc2VhcmNoUGFyYW1zLmZvckVhY2goKF8sIHBhcmFtTmFtZSkgPT4ge1xuICAgICAgcXVlcnlQYXJhbXMucHVzaChwYXJhbU5hbWUpO1xuICAgIH0pO1xuICAgIGRldlV0aWxzLndhcm4oXG4gICAgICBgRm91bmQgYSByZWR1bmRhbnQgdXNhZ2Ugb2YgcXVlcnkgcGFyYW1ldGVycyBpbiB0aGUgcmVxdWVzdCBoYW5kbGVyIFVSTCBmb3IgXCIke21ldGhvZH0gJHtwYXRofVwiLiBQbGVhc2UgbWF0Y2ggYWdhaW5zdCBhIHBhdGggaW5zdGVhZCBhbmQgYWNjZXNzIHF1ZXJ5IHBhcmFtZXRlcnMgaW4gdGhlIHJlc3BvbnNlIHJlc29sdmVyIGZ1bmN0aW9uIHVzaW5nIFwicmVxLnVybC5zZWFyY2hQYXJhbXNcIi5gXG4gICAgKTtcbiAgfVxuICBhc3luYyBwYXJzZShhcmdzKSB7XG4gICAgdmFyIF9hMjtcbiAgICBjb25zdCB1cmwgPSBuZXcgVVJMKGFyZ3MucmVxdWVzdC51cmwpO1xuICAgIGNvbnN0IG1hdGNoMiA9IG1hdGNoUmVxdWVzdFVybChcbiAgICAgIHVybCxcbiAgICAgIHRoaXMuaW5mby5wYXRoLFxuICAgICAgKF9hMiA9IGFyZ3MucmVzb2x1dGlvbkNvbnRleHQpID09IG51bGwgPyB2b2lkIDAgOiBfYTIuYmFzZVVybFxuICAgICk7XG4gICAgY29uc3QgY29va2llcyA9IGdldEFsbFJlcXVlc3RDb29raWVzKGFyZ3MucmVxdWVzdCk7XG4gICAgcmV0dXJuIHtcbiAgICAgIG1hdGNoOiBtYXRjaDIsXG4gICAgICBjb29raWVzXG4gICAgfTtcbiAgfVxuICBwcmVkaWNhdGUoYXJncykge1xuICAgIGNvbnN0IGhhc01hdGNoaW5nTWV0aG9kID0gdGhpcy5tYXRjaE1ldGhvZChhcmdzLnJlcXVlc3QubWV0aG9kKTtcbiAgICBjb25zdCBoYXNNYXRjaGluZ1VybCA9IGFyZ3MucGFyc2VkUmVzdWx0Lm1hdGNoLm1hdGNoZXM7XG4gICAgcmV0dXJuIGhhc01hdGNoaW5nTWV0aG9kICYmIGhhc01hdGNoaW5nVXJsO1xuICB9XG4gIG1hdGNoTWV0aG9kKGFjdHVhbE1ldGhvZCkge1xuICAgIHJldHVybiB0aGlzLmluZm8ubWV0aG9kIGluc3RhbmNlb2YgUmVnRXhwID8gdGhpcy5pbmZvLm1ldGhvZC50ZXN0KGFjdHVhbE1ldGhvZCkgOiBpc1N0cmluZ0VxdWFsKHRoaXMuaW5mby5tZXRob2QsIGFjdHVhbE1ldGhvZCk7XG4gIH1cbiAgZXh0ZW5kUmVzb2x2ZXJBcmdzKGFyZ3MpIHtcbiAgICB2YXIgX2EyO1xuICAgIHJldHVybiB7XG4gICAgICBwYXJhbXM6ICgoX2EyID0gYXJncy5wYXJzZWRSZXN1bHQubWF0Y2gpID09IG51bGwgPyB2b2lkIDAgOiBfYTIucGFyYW1zKSB8fCB7fSxcbiAgICAgIGNvb2tpZXM6IGFyZ3MucGFyc2VkUmVzdWx0LmNvb2tpZXNcbiAgICB9O1xuICB9XG4gIGFzeW5jIGxvZyhhcmdzKSB7XG4gICAgY29uc3QgcHVibGljVXJsID0gdG9QdWJsaWNVcmwoYXJncy5yZXF1ZXN0LnVybCk7XG4gICAgY29uc3QgbG9nZ2VkUmVxdWVzdCA9IGF3YWl0IHNlcmlhbGl6ZVJlcXVlc3QoYXJncy5yZXF1ZXN0KTtcbiAgICBjb25zdCBsb2dnZWRSZXNwb25zZSA9IGF3YWl0IHNlcmlhbGl6ZVJlc3BvbnNlKGFyZ3MucmVzcG9uc2UpO1xuICAgIGNvbnN0IHN0YXR1c0NvbG9yID0gZ2V0U3RhdHVzQ29kZUNvbG9yKGxvZ2dlZFJlc3BvbnNlLnN0YXR1cyk7XG4gICAgY29uc29sZS5ncm91cENvbGxhcHNlZChcbiAgICAgIGRldlV0aWxzLmZvcm1hdE1lc3NhZ2UoXG4gICAgICAgIGAke2dldFRpbWVzdGFtcCgpfSAke2FyZ3MucmVxdWVzdC5tZXRob2R9ICR7cHVibGljVXJsfSAoJWMke2xvZ2dlZFJlc3BvbnNlLnN0YXR1c30gJHtsb2dnZWRSZXNwb25zZS5zdGF0dXNUZXh0fSVjKWBcbiAgICAgICksXG4gICAgICBgY29sb3I6JHtzdGF0dXNDb2xvcn1gLFxuICAgICAgXCJjb2xvcjppbmhlcml0XCJcbiAgICApO1xuICAgIGNvbnNvbGUubG9nKFwiUmVxdWVzdFwiLCBsb2dnZWRSZXF1ZXN0KTtcbiAgICBjb25zb2xlLmxvZyhcIkhhbmRsZXI6XCIsIHRoaXMpO1xuICAgIGNvbnNvbGUubG9nKFwiUmVzcG9uc2VcIiwgbG9nZ2VkUmVzcG9uc2UpO1xuICAgIGNvbnNvbGUuZ3JvdXBFbmQoKTtcbiAgfVxufTtcblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL21zd0AyLjIuMV90eXBlc2NyaXB0QDUuMy4zL25vZGVfbW9kdWxlcy9tc3cvbGliL2NvcmUvaHR0cC5tanNcbmZ1bmN0aW9uIGNyZWF0ZUh0dHBIYW5kbGVyKG1ldGhvZCkge1xuICByZXR1cm4gKHBhdGgsIHJlc29sdmVyLCBvcHRpb25zID0ge30pID0+IHtcbiAgICByZXR1cm4gbmV3IEh0dHBIYW5kbGVyKG1ldGhvZCwgcGF0aCwgcmVzb2x2ZXIsIG9wdGlvbnMpO1xuICB9O1xufVxudmFyIGh0dHAgPSB7XG4gIGFsbDogY3JlYXRlSHR0cEhhbmRsZXIoLy4rLyksXG4gIGhlYWQ6IGNyZWF0ZUh0dHBIYW5kbGVyKEh0dHBNZXRob2RzLkhFQUQpLFxuICBnZXQ6IGNyZWF0ZUh0dHBIYW5kbGVyKEh0dHBNZXRob2RzLkdFVCksXG4gIHBvc3Q6IGNyZWF0ZUh0dHBIYW5kbGVyKEh0dHBNZXRob2RzLlBPU1QpLFxuICBwdXQ6IGNyZWF0ZUh0dHBIYW5kbGVyKEh0dHBNZXRob2RzLlBVVCksXG4gIGRlbGV0ZTogY3JlYXRlSHR0cEhhbmRsZXIoSHR0cE1ldGhvZHMuREVMRVRFKSxcbiAgcGF0Y2g6IGNyZWF0ZUh0dHBIYW5kbGVyKEh0dHBNZXRob2RzLlBBVENIKSxcbiAgb3B0aW9uczogY3JlYXRlSHR0cEhhbmRsZXIoSHR0cE1ldGhvZHMuT1BUSU9OUylcbn07XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC92ZXJzaW9uLm1qc1xudmFyIHZlcnNpb25JbmZvID0gT2JqZWN0LmZyZWV6ZSh7XG4gIG1ham9yOiAxNixcbiAgbWlub3I6IDgsXG4gIHBhdGNoOiAxLFxuICBwcmVSZWxlYXNlVGFnOiBudWxsXG59KTtcblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL2pzdXRpbHMvZGV2QXNzZXJ0Lm1qc1xuZnVuY3Rpb24gZGV2QXNzZXJ0KGNvbmRpdGlvbiwgbWVzc2FnZTMpIHtcbiAgY29uc3QgYm9vbGVhbkNvbmRpdGlvbiA9IEJvb2xlYW4oY29uZGl0aW9uKTtcbiAgaWYgKCFib29sZWFuQ29uZGl0aW9uKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKG1lc3NhZ2UzKTtcbiAgfVxufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvanN1dGlscy9pc09iamVjdExpa2UubWpzXG5mdW5jdGlvbiBpc09iamVjdExpa2UodmFsdWUpIHtcbiAgcmV0dXJuIHR5cGVvZiB2YWx1ZSA9PSBcIm9iamVjdFwiICYmIHZhbHVlICE9PSBudWxsO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvanN1dGlscy9pbnZhcmlhbnQubWpzXG5mdW5jdGlvbiBpbnZhcmlhbnQyKGNvbmRpdGlvbiwgbWVzc2FnZTMpIHtcbiAgY29uc3QgYm9vbGVhbkNvbmRpdGlvbiA9IEJvb2xlYW4oY29uZGl0aW9uKTtcbiAgaWYgKCFib29sZWFuQ29uZGl0aW9uKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgbWVzc2FnZTMgIT0gbnVsbCA/IG1lc3NhZ2UzIDogXCJVbmV4cGVjdGVkIGludmFyaWFudCB0cmlnZ2VyZWQuXCJcbiAgICApO1xuICB9XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC9sYW5ndWFnZS9sb2NhdGlvbi5tanNcbnZhciBMaW5lUmVnRXhwID0gL1xcclxcbnxbXFxuXFxyXS9nO1xuZnVuY3Rpb24gZ2V0TG9jYXRpb24oc291cmNlLCBwb3NpdGlvbikge1xuICBsZXQgbGFzdExpbmVTdGFydCA9IDA7XG4gIGxldCBsaW5lID0gMTtcbiAgZm9yIChjb25zdCBtYXRjaDIgb2Ygc291cmNlLmJvZHkubWF0Y2hBbGwoTGluZVJlZ0V4cCkpIHtcbiAgICB0eXBlb2YgbWF0Y2gyLmluZGV4ID09PSBcIm51bWJlclwiIHx8IGludmFyaWFudDIoZmFsc2UpO1xuICAgIGlmIChtYXRjaDIuaW5kZXggPj0gcG9zaXRpb24pIHtcbiAgICAgIGJyZWFrO1xuICAgIH1cbiAgICBsYXN0TGluZVN0YXJ0ID0gbWF0Y2gyLmluZGV4ICsgbWF0Y2gyWzBdLmxlbmd0aDtcbiAgICBsaW5lICs9IDE7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBsaW5lLFxuICAgIGNvbHVtbjogcG9zaXRpb24gKyAxIC0gbGFzdExpbmVTdGFydFxuICB9O1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvbGFuZ3VhZ2UvcHJpbnRMb2NhdGlvbi5tanNcbmZ1bmN0aW9uIHByaW50TG9jYXRpb24obG9jYXRpb24yKSB7XG4gIHJldHVybiBwcmludFNvdXJjZUxvY2F0aW9uKFxuICAgIGxvY2F0aW9uMi5zb3VyY2UsXG4gICAgZ2V0TG9jYXRpb24obG9jYXRpb24yLnNvdXJjZSwgbG9jYXRpb24yLnN0YXJ0KVxuICApO1xufVxuZnVuY3Rpb24gcHJpbnRTb3VyY2VMb2NhdGlvbihzb3VyY2UsIHNvdXJjZUxvY2F0aW9uKSB7XG4gIGNvbnN0IGZpcnN0TGluZUNvbHVtbk9mZnNldCA9IHNvdXJjZS5sb2NhdGlvbk9mZnNldC5jb2x1bW4gLSAxO1xuICBjb25zdCBib2R5ID0gXCJcIi5wYWRTdGFydChmaXJzdExpbmVDb2x1bW5PZmZzZXQpICsgc291cmNlLmJvZHk7XG4gIGNvbnN0IGxpbmVJbmRleCA9IHNvdXJjZUxvY2F0aW9uLmxpbmUgLSAxO1xuICBjb25zdCBsaW5lT2Zmc2V0ID0gc291cmNlLmxvY2F0aW9uT2Zmc2V0LmxpbmUgLSAxO1xuICBjb25zdCBsaW5lTnVtID0gc291cmNlTG9jYXRpb24ubGluZSArIGxpbmVPZmZzZXQ7XG4gIGNvbnN0IGNvbHVtbk9mZnNldCA9IHNvdXJjZUxvY2F0aW9uLmxpbmUgPT09IDEgPyBmaXJzdExpbmVDb2x1bW5PZmZzZXQgOiAwO1xuICBjb25zdCBjb2x1bW5OdW0gPSBzb3VyY2VMb2NhdGlvbi5jb2x1bW4gKyBjb2x1bW5PZmZzZXQ7XG4gIGNvbnN0IGxvY2F0aW9uU3RyID0gYCR7c291cmNlLm5hbWV9OiR7bGluZU51bX06JHtjb2x1bW5OdW19XG5gO1xuICBjb25zdCBsaW5lcyA9IGJvZHkuc3BsaXQoL1xcclxcbnxbXFxuXFxyXS9nKTtcbiAgY29uc3QgbG9jYXRpb25MaW5lID0gbGluZXNbbGluZUluZGV4XTtcbiAgaWYgKGxvY2F0aW9uTGluZS5sZW5ndGggPiAxMjApIHtcbiAgICBjb25zdCBzdWJMaW5lSW5kZXggPSBNYXRoLmZsb29yKGNvbHVtbk51bSAvIDgwKTtcbiAgICBjb25zdCBzdWJMaW5lQ29sdW1uTnVtID0gY29sdW1uTnVtICUgODA7XG4gICAgY29uc3Qgc3ViTGluZXMgPSBbXTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxvY2F0aW9uTGluZS5sZW5ndGg7IGkgKz0gODApIHtcbiAgICAgIHN1YkxpbmVzLnB1c2gobG9jYXRpb25MaW5lLnNsaWNlKGksIGkgKyA4MCkpO1xuICAgIH1cbiAgICByZXR1cm4gbG9jYXRpb25TdHIgKyBwcmludFByZWZpeGVkTGluZXMoW1xuICAgICAgW2Ake2xpbmVOdW19IHxgLCBzdWJMaW5lc1swXV0sXG4gICAgICAuLi5zdWJMaW5lcy5zbGljZSgxLCBzdWJMaW5lSW5kZXggKyAxKS5tYXAoKHN1YkxpbmUpID0+IFtcInxcIiwgc3ViTGluZV0pLFxuICAgICAgW1wifFwiLCBcIl5cIi5wYWRTdGFydChzdWJMaW5lQ29sdW1uTnVtKV0sXG4gICAgICBbXCJ8XCIsIHN1YkxpbmVzW3N1YkxpbmVJbmRleCArIDFdXVxuICAgIF0pO1xuICB9XG4gIHJldHVybiBsb2NhdGlvblN0ciArIHByaW50UHJlZml4ZWRMaW5lcyhbXG4gICAgLy8gTGluZXMgc3BlY2lmaWVkIGxpa2UgdGhpczogW1wicHJlZml4XCIsIFwic3RyaW5nXCJdLFxuICAgIFtgJHtsaW5lTnVtIC0gMX0gfGAsIGxpbmVzW2xpbmVJbmRleCAtIDFdXSxcbiAgICBbYCR7bGluZU51bX0gfGAsIGxvY2F0aW9uTGluZV0sXG4gICAgW1wifFwiLCBcIl5cIi5wYWRTdGFydChjb2x1bW5OdW0pXSxcbiAgICBbYCR7bGluZU51bSArIDF9IHxgLCBsaW5lc1tsaW5lSW5kZXggKyAxXV1cbiAgXSk7XG59XG5mdW5jdGlvbiBwcmludFByZWZpeGVkTGluZXMobGluZXMpIHtcbiAgY29uc3QgZXhpc3RpbmdMaW5lcyA9IGxpbmVzLmZpbHRlcigoW18sIGxpbmVdKSA9PiBsaW5lICE9PSB2b2lkIDApO1xuICBjb25zdCBwYWRMZW4gPSBNYXRoLm1heCguLi5leGlzdGluZ0xpbmVzLm1hcCgoW3ByZWZpeF0pID0+IHByZWZpeC5sZW5ndGgpKTtcbiAgcmV0dXJuIGV4aXN0aW5nTGluZXMubWFwKChbcHJlZml4LCBsaW5lXSkgPT4gcHJlZml4LnBhZFN0YXJ0KHBhZExlbikgKyAobGluZSA/IFwiIFwiICsgbGluZSA6IFwiXCIpKS5qb2luKFwiXFxuXCIpO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvZXJyb3IvR3JhcGhRTEVycm9yLm1qc1xuZnVuY3Rpb24gdG9Ob3JtYWxpemVkT3B0aW9ucyhhcmdzKSB7XG4gIGNvbnN0IGZpcnN0QXJnID0gYXJnc1swXTtcbiAgaWYgKGZpcnN0QXJnID09IG51bGwgfHwgXCJraW5kXCIgaW4gZmlyc3RBcmcgfHwgXCJsZW5ndGhcIiBpbiBmaXJzdEFyZykge1xuICAgIHJldHVybiB7XG4gICAgICBub2RlczogZmlyc3RBcmcsXG4gICAgICBzb3VyY2U6IGFyZ3NbMV0sXG4gICAgICBwb3NpdGlvbnM6IGFyZ3NbMl0sXG4gICAgICBwYXRoOiBhcmdzWzNdLFxuICAgICAgb3JpZ2luYWxFcnJvcjogYXJnc1s0XSxcbiAgICAgIGV4dGVuc2lvbnM6IGFyZ3NbNV1cbiAgICB9O1xuICB9XG4gIHJldHVybiBmaXJzdEFyZztcbn1cbnZhciBHcmFwaFFMRXJyb3IgPSBjbGFzcyBfR3JhcGhRTEVycm9yIGV4dGVuZHMgRXJyb3Ige1xuICAvKipcbiAgICogQW4gYXJyYXkgb2YgYHsgbGluZSwgY29sdW1uIH1gIGxvY2F0aW9ucyB3aXRoaW4gdGhlIHNvdXJjZSBHcmFwaFFMIGRvY3VtZW50XG4gICAqIHdoaWNoIGNvcnJlc3BvbmQgdG8gdGhpcyBlcnJvci5cbiAgICpcbiAgICogRXJyb3JzIGR1cmluZyB2YWxpZGF0aW9uIG9mdGVuIGNvbnRhaW4gbXVsdGlwbGUgbG9jYXRpb25zLCBmb3IgZXhhbXBsZSB0b1xuICAgKiBwb2ludCBvdXQgdHdvIHRoaW5ncyB3aXRoIHRoZSBzYW1lIG5hbWUuIEVycm9ycyBkdXJpbmcgZXhlY3V0aW9uIGluY2x1ZGUgYVxuICAgKiBzaW5nbGUgbG9jYXRpb24sIHRoZSBmaWVsZCB3aGljaCBwcm9kdWNlZCB0aGUgZXJyb3IuXG4gICAqXG4gICAqIEVudW1lcmFibGUsIGFuZCBhcHBlYXJzIGluIHRoZSByZXN1bHQgb2YgSlNPTi5zdHJpbmdpZnkoKS5cbiAgICovXG4gIC8qKlxuICAgKiBBbiBhcnJheSBkZXNjcmliaW5nIHRoZSBKU09OLXBhdGggaW50byB0aGUgZXhlY3V0aW9uIHJlc3BvbnNlIHdoaWNoXG4gICAqIGNvcnJlc3BvbmRzIHRvIHRoaXMgZXJyb3IuIE9ubHkgaW5jbHVkZWQgZm9yIGVycm9ycyBkdXJpbmcgZXhlY3V0aW9uLlxuICAgKlxuICAgKiBFbnVtZXJhYmxlLCBhbmQgYXBwZWFycyBpbiB0aGUgcmVzdWx0IG9mIEpTT04uc3RyaW5naWZ5KCkuXG4gICAqL1xuICAvKipcbiAgICogQW4gYXJyYXkgb2YgR3JhcGhRTCBBU1QgTm9kZXMgY29ycmVzcG9uZGluZyB0byB0aGlzIGVycm9yLlxuICAgKi9cbiAgLyoqXG4gICAqIFRoZSBzb3VyY2UgR3JhcGhRTCBkb2N1bWVudCBmb3IgdGhlIGZpcnN0IGxvY2F0aW9uIG9mIHRoaXMgZXJyb3IuXG4gICAqXG4gICAqIE5vdGUgdGhhdCBpZiB0aGlzIEVycm9yIHJlcHJlc2VudHMgbW9yZSB0aGFuIG9uZSBub2RlLCB0aGUgc291cmNlIG1heSBub3RcbiAgICogcmVwcmVzZW50IG5vZGVzIGFmdGVyIHRoZSBmaXJzdCBub2RlLlxuICAgKi9cbiAgLyoqXG4gICAqIEFuIGFycmF5IG9mIGNoYXJhY3RlciBvZmZzZXRzIHdpdGhpbiB0aGUgc291cmNlIEdyYXBoUUwgZG9jdW1lbnRcbiAgICogd2hpY2ggY29ycmVzcG9uZCB0byB0aGlzIGVycm9yLlxuICAgKi9cbiAgLyoqXG4gICAqIFRoZSBvcmlnaW5hbCBlcnJvciB0aHJvd24gZnJvbSBhIGZpZWxkIHJlc29sdmVyIGR1cmluZyBleGVjdXRpb24uXG4gICAqL1xuICAvKipcbiAgICogRXh0ZW5zaW9uIGZpZWxkcyB0byBhZGQgdG8gdGhlIGZvcm1hdHRlZCBlcnJvci5cbiAgICovXG4gIC8qKlxuICAgKiBAZGVwcmVjYXRlZCBQbGVhc2UgdXNlIHRoZSBgR3JhcGhRTEVycm9yT3B0aW9uc2AgY29uc3RydWN0b3Igb3ZlcmxvYWQgaW5zdGVhZC5cbiAgICovXG4gIGNvbnN0cnVjdG9yKG1lc3NhZ2UzLCAuLi5yYXdBcmdzKSB7XG4gICAgdmFyIF90aGlzJG5vZGVzLCBfbm9kZUxvY2F0aW9ucyQsIF9yZWY7XG4gICAgY29uc3QgeyBub2Rlcywgc291cmNlLCBwb3NpdGlvbnMsIHBhdGgsIG9yaWdpbmFsRXJyb3IsIGV4dGVuc2lvbnMgfSA9IHRvTm9ybWFsaXplZE9wdGlvbnMocmF3QXJncyk7XG4gICAgc3VwZXIobWVzc2FnZTMpO1xuICAgIHRoaXMubmFtZSA9IFwiR3JhcGhRTEVycm9yXCI7XG4gICAgdGhpcy5wYXRoID0gcGF0aCAhPT0gbnVsbCAmJiBwYXRoICE9PSB2b2lkIDAgPyBwYXRoIDogdm9pZCAwO1xuICAgIHRoaXMub3JpZ2luYWxFcnJvciA9IG9yaWdpbmFsRXJyb3IgIT09IG51bGwgJiYgb3JpZ2luYWxFcnJvciAhPT0gdm9pZCAwID8gb3JpZ2luYWxFcnJvciA6IHZvaWQgMDtcbiAgICB0aGlzLm5vZGVzID0gdW5kZWZpbmVkSWZFbXB0eShcbiAgICAgIEFycmF5LmlzQXJyYXkobm9kZXMpID8gbm9kZXMgOiBub2RlcyA/IFtub2Rlc10gOiB2b2lkIDBcbiAgICApO1xuICAgIGNvbnN0IG5vZGVMb2NhdGlvbnMgPSB1bmRlZmluZWRJZkVtcHR5KFxuICAgICAgKF90aGlzJG5vZGVzID0gdGhpcy5ub2RlcykgPT09IG51bGwgfHwgX3RoaXMkbm9kZXMgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF90aGlzJG5vZGVzLm1hcCgobm9kZSkgPT4gbm9kZS5sb2MpLmZpbHRlcigobG9jKSA9PiBsb2MgIT0gbnVsbClcbiAgICApO1xuICAgIHRoaXMuc291cmNlID0gc291cmNlICE9PSBudWxsICYmIHNvdXJjZSAhPT0gdm9pZCAwID8gc291cmNlIDogbm9kZUxvY2F0aW9ucyA9PT0gbnVsbCB8fCBub2RlTG9jYXRpb25zID09PSB2b2lkIDAgPyB2b2lkIDAgOiAoX25vZGVMb2NhdGlvbnMkID0gbm9kZUxvY2F0aW9uc1swXSkgPT09IG51bGwgfHwgX25vZGVMb2NhdGlvbnMkID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfbm9kZUxvY2F0aW9ucyQuc291cmNlO1xuICAgIHRoaXMucG9zaXRpb25zID0gcG9zaXRpb25zICE9PSBudWxsICYmIHBvc2l0aW9ucyAhPT0gdm9pZCAwID8gcG9zaXRpb25zIDogbm9kZUxvY2F0aW9ucyA9PT0gbnVsbCB8fCBub2RlTG9jYXRpb25zID09PSB2b2lkIDAgPyB2b2lkIDAgOiBub2RlTG9jYXRpb25zLm1hcCgobG9jKSA9PiBsb2Muc3RhcnQpO1xuICAgIHRoaXMubG9jYXRpb25zID0gcG9zaXRpb25zICYmIHNvdXJjZSA/IHBvc2l0aW9ucy5tYXAoKHBvcykgPT4gZ2V0TG9jYXRpb24oc291cmNlLCBwb3MpKSA6IG5vZGVMb2NhdGlvbnMgPT09IG51bGwgfHwgbm9kZUxvY2F0aW9ucyA9PT0gdm9pZCAwID8gdm9pZCAwIDogbm9kZUxvY2F0aW9ucy5tYXAoKGxvYykgPT4gZ2V0TG9jYXRpb24obG9jLnNvdXJjZSwgbG9jLnN0YXJ0KSk7XG4gICAgY29uc3Qgb3JpZ2luYWxFeHRlbnNpb25zID0gaXNPYmplY3RMaWtlKFxuICAgICAgb3JpZ2luYWxFcnJvciA9PT0gbnVsbCB8fCBvcmlnaW5hbEVycm9yID09PSB2b2lkIDAgPyB2b2lkIDAgOiBvcmlnaW5hbEVycm9yLmV4dGVuc2lvbnNcbiAgICApID8gb3JpZ2luYWxFcnJvciA9PT0gbnVsbCB8fCBvcmlnaW5hbEVycm9yID09PSB2b2lkIDAgPyB2b2lkIDAgOiBvcmlnaW5hbEVycm9yLmV4dGVuc2lvbnMgOiB2b2lkIDA7XG4gICAgdGhpcy5leHRlbnNpb25zID0gKF9yZWYgPSBleHRlbnNpb25zICE9PSBudWxsICYmIGV4dGVuc2lvbnMgIT09IHZvaWQgMCA/IGV4dGVuc2lvbnMgOiBvcmlnaW5hbEV4dGVuc2lvbnMpICE9PSBudWxsICYmIF9yZWYgIT09IHZvaWQgMCA/IF9yZWYgOiAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydGllcyh0aGlzLCB7XG4gICAgICBtZXNzYWdlOiB7XG4gICAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgICBlbnVtZXJhYmxlOiB0cnVlXG4gICAgICB9LFxuICAgICAgbmFtZToge1xuICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZVxuICAgICAgfSxcbiAgICAgIG5vZGVzOiB7XG4gICAgICAgIGVudW1lcmFibGU6IGZhbHNlXG4gICAgICB9LFxuICAgICAgc291cmNlOiB7XG4gICAgICAgIGVudW1lcmFibGU6IGZhbHNlXG4gICAgICB9LFxuICAgICAgcG9zaXRpb25zOiB7XG4gICAgICAgIGVudW1lcmFibGU6IGZhbHNlXG4gICAgICB9LFxuICAgICAgb3JpZ2luYWxFcnJvcjoge1xuICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZVxuICAgICAgfVxuICAgIH0pO1xuICAgIGlmIChvcmlnaW5hbEVycm9yICE9PSBudWxsICYmIG9yaWdpbmFsRXJyb3IgIT09IHZvaWQgMCAmJiBvcmlnaW5hbEVycm9yLnN0YWNrKSB7XG4gICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJzdGFja1wiLCB7XG4gICAgICAgIHZhbHVlOiBvcmlnaW5hbEVycm9yLnN0YWNrLFxuICAgICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgICB9KTtcbiAgICB9IGVsc2UgaWYgKEVycm9yLmNhcHR1cmVTdGFja1RyYWNlKSB7XG4gICAgICBFcnJvci5jYXB0dXJlU3RhY2tUcmFjZSh0aGlzLCBfR3JhcGhRTEVycm9yKTtcbiAgICB9IGVsc2Uge1xuICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIFwic3RhY2tcIiwge1xuICAgICAgICB2YWx1ZTogRXJyb3IoKS5zdGFjayxcbiAgICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgICAgfSk7XG4gICAgfVxuICB9XG4gIGdldCBbU3ltYm9sLnRvU3RyaW5nVGFnXSgpIHtcbiAgICByZXR1cm4gXCJHcmFwaFFMRXJyb3JcIjtcbiAgfVxuICB0b1N0cmluZygpIHtcbiAgICBsZXQgb3V0cHV0ID0gdGhpcy5tZXNzYWdlO1xuICAgIGlmICh0aGlzLm5vZGVzKSB7XG4gICAgICBmb3IgKGNvbnN0IG5vZGUgb2YgdGhpcy5ub2Rlcykge1xuICAgICAgICBpZiAobm9kZS5sb2MpIHtcbiAgICAgICAgICBvdXRwdXQgKz0gXCJcXG5cXG5cIiArIHByaW50TG9jYXRpb24obm9kZS5sb2MpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSBlbHNlIGlmICh0aGlzLnNvdXJjZSAmJiB0aGlzLmxvY2F0aW9ucykge1xuICAgICAgZm9yIChjb25zdCBsb2NhdGlvbjIgb2YgdGhpcy5sb2NhdGlvbnMpIHtcbiAgICAgICAgb3V0cHV0ICs9IFwiXFxuXFxuXCIgKyBwcmludFNvdXJjZUxvY2F0aW9uKHRoaXMuc291cmNlLCBsb2NhdGlvbjIpO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gb3V0cHV0O1xuICB9XG4gIHRvSlNPTigpIHtcbiAgICBjb25zdCBmb3JtYXR0ZWRFcnJvciA9IHtcbiAgICAgIG1lc3NhZ2U6IHRoaXMubWVzc2FnZVxuICAgIH07XG4gICAgaWYgKHRoaXMubG9jYXRpb25zICE9IG51bGwpIHtcbiAgICAgIGZvcm1hdHRlZEVycm9yLmxvY2F0aW9ucyA9IHRoaXMubG9jYXRpb25zO1xuICAgIH1cbiAgICBpZiAodGhpcy5wYXRoICE9IG51bGwpIHtcbiAgICAgIGZvcm1hdHRlZEVycm9yLnBhdGggPSB0aGlzLnBhdGg7XG4gICAgfVxuICAgIGlmICh0aGlzLmV4dGVuc2lvbnMgIT0gbnVsbCAmJiBPYmplY3Qua2V5cyh0aGlzLmV4dGVuc2lvbnMpLmxlbmd0aCA+IDApIHtcbiAgICAgIGZvcm1hdHRlZEVycm9yLmV4dGVuc2lvbnMgPSB0aGlzLmV4dGVuc2lvbnM7XG4gICAgfVxuICAgIHJldHVybiBmb3JtYXR0ZWRFcnJvcjtcbiAgfVxufTtcbmZ1bmN0aW9uIHVuZGVmaW5lZElmRW1wdHkoYXJyYXkpIHtcbiAgcmV0dXJuIGFycmF5ID09PSB2b2lkIDAgfHwgYXJyYXkubGVuZ3RoID09PSAwID8gdm9pZCAwIDogYXJyYXk7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC9lcnJvci9zeW50YXhFcnJvci5tanNcbmZ1bmN0aW9uIHN5bnRheEVycm9yKHNvdXJjZSwgcG9zaXRpb24sIGRlc2NyaXB0aW9uKSB7XG4gIHJldHVybiBuZXcgR3JhcGhRTEVycm9yKGBTeW50YXggRXJyb3I6ICR7ZGVzY3JpcHRpb259YCwge1xuICAgIHNvdXJjZSxcbiAgICBwb3NpdGlvbnM6IFtwb3NpdGlvbl1cbiAgfSk7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC9sYW5ndWFnZS9hc3QubWpzXG52YXIgTG9jYXRpb24gPSBjbGFzcyB7XG4gIC8qKlxuICAgKiBUaGUgY2hhcmFjdGVyIG9mZnNldCBhdCB3aGljaCB0aGlzIE5vZGUgYmVnaW5zLlxuICAgKi9cbiAgLyoqXG4gICAqIFRoZSBjaGFyYWN0ZXIgb2Zmc2V0IGF0IHdoaWNoIHRoaXMgTm9kZSBlbmRzLlxuICAgKi9cbiAgLyoqXG4gICAqIFRoZSBUb2tlbiBhdCB3aGljaCB0aGlzIE5vZGUgYmVnaW5zLlxuICAgKi9cbiAgLyoqXG4gICAqIFRoZSBUb2tlbiBhdCB3aGljaCB0aGlzIE5vZGUgZW5kcy5cbiAgICovXG4gIC8qKlxuICAgKiBUaGUgU291cmNlIGRvY3VtZW50IHRoZSBBU1QgcmVwcmVzZW50cy5cbiAgICovXG4gIGNvbnN0cnVjdG9yKHN0YXJ0VG9rZW4sIGVuZFRva2VuLCBzb3VyY2UpIHtcbiAgICB0aGlzLnN0YXJ0ID0gc3RhcnRUb2tlbi5zdGFydDtcbiAgICB0aGlzLmVuZCA9IGVuZFRva2VuLmVuZDtcbiAgICB0aGlzLnN0YXJ0VG9rZW4gPSBzdGFydFRva2VuO1xuICAgIHRoaXMuZW5kVG9rZW4gPSBlbmRUb2tlbjtcbiAgICB0aGlzLnNvdXJjZSA9IHNvdXJjZTtcbiAgfVxuICBnZXQgW1N5bWJvbC50b1N0cmluZ1RhZ10oKSB7XG4gICAgcmV0dXJuIFwiTG9jYXRpb25cIjtcbiAgfVxuICB0b0pTT04oKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHN0YXJ0OiB0aGlzLnN0YXJ0LFxuICAgICAgZW5kOiB0aGlzLmVuZFxuICAgIH07XG4gIH1cbn07XG52YXIgVG9rZW4gPSBjbGFzcyB7XG4gIC8qKlxuICAgKiBUaGUga2luZCBvZiBUb2tlbi5cbiAgICovXG4gIC8qKlxuICAgKiBUaGUgY2hhcmFjdGVyIG9mZnNldCBhdCB3aGljaCB0aGlzIE5vZGUgYmVnaW5zLlxuICAgKi9cbiAgLyoqXG4gICAqIFRoZSBjaGFyYWN0ZXIgb2Zmc2V0IGF0IHdoaWNoIHRoaXMgTm9kZSBlbmRzLlxuICAgKi9cbiAgLyoqXG4gICAqIFRoZSAxLWluZGV4ZWQgbGluZSBudW1iZXIgb24gd2hpY2ggdGhpcyBUb2tlbiBhcHBlYXJzLlxuICAgKi9cbiAgLyoqXG4gICAqIFRoZSAxLWluZGV4ZWQgY29sdW1uIG51bWJlciBhdCB3aGljaCB0aGlzIFRva2VuIGJlZ2lucy5cbiAgICovXG4gIC8qKlxuICAgKiBGb3Igbm9uLXB1bmN0dWF0aW9uIHRva2VucywgcmVwcmVzZW50cyB0aGUgaW50ZXJwcmV0ZWQgdmFsdWUgb2YgdGhlIHRva2VuLlxuICAgKlxuICAgKiBOb3RlOiBpcyB1bmRlZmluZWQgZm9yIHB1bmN0dWF0aW9uIHRva2VucywgYnV0IHR5cGVkIGFzIHN0cmluZyBmb3JcbiAgICogY29udmVuaWVuY2UgaW4gdGhlIHBhcnNlci5cbiAgICovXG4gIC8qKlxuICAgKiBUb2tlbnMgZXhpc3QgYXMgbm9kZXMgaW4gYSBkb3VibGUtbGlua2VkLWxpc3QgYW1vbmdzdCBhbGwgdG9rZW5zXG4gICAqIGluY2x1ZGluZyBpZ25vcmVkIHRva2Vucy4gPFNPRj4gaXMgYWx3YXlzIHRoZSBmaXJzdCBub2RlIGFuZCA8RU9GPlxuICAgKiB0aGUgbGFzdC5cbiAgICovXG4gIGNvbnN0cnVjdG9yKGtpbmQsIHN0YXJ0LCBlbmQsIGxpbmUsIGNvbHVtbiwgdmFsdWUpIHtcbiAgICB0aGlzLmtpbmQgPSBraW5kO1xuICAgIHRoaXMuc3RhcnQgPSBzdGFydDtcbiAgICB0aGlzLmVuZCA9IGVuZDtcbiAgICB0aGlzLmxpbmUgPSBsaW5lO1xuICAgIHRoaXMuY29sdW1uID0gY29sdW1uO1xuICAgIHRoaXMudmFsdWUgPSB2YWx1ZTtcbiAgICB0aGlzLnByZXYgPSBudWxsO1xuICAgIHRoaXMubmV4dCA9IG51bGw7XG4gIH1cbiAgZ2V0IFtTeW1ib2wudG9TdHJpbmdUYWddKCkge1xuICAgIHJldHVybiBcIlRva2VuXCI7XG4gIH1cbiAgdG9KU09OKCkge1xuICAgIHJldHVybiB7XG4gICAgICBraW5kOiB0aGlzLmtpbmQsXG4gICAgICB2YWx1ZTogdGhpcy52YWx1ZSxcbiAgICAgIGxpbmU6IHRoaXMubGluZSxcbiAgICAgIGNvbHVtbjogdGhpcy5jb2x1bW5cbiAgICB9O1xuICB9XG59O1xudmFyIFF1ZXJ5RG9jdW1lbnRLZXlzID0ge1xuICBOYW1lOiBbXSxcbiAgRG9jdW1lbnQ6IFtcImRlZmluaXRpb25zXCJdLFxuICBPcGVyYXRpb25EZWZpbml0aW9uOiBbXG4gICAgXCJuYW1lXCIsXG4gICAgXCJ2YXJpYWJsZURlZmluaXRpb25zXCIsXG4gICAgXCJkaXJlY3RpdmVzXCIsXG4gICAgXCJzZWxlY3Rpb25TZXRcIlxuICBdLFxuICBWYXJpYWJsZURlZmluaXRpb246IFtcInZhcmlhYmxlXCIsIFwidHlwZVwiLCBcImRlZmF1bHRWYWx1ZVwiLCBcImRpcmVjdGl2ZXNcIl0sXG4gIFZhcmlhYmxlOiBbXCJuYW1lXCJdLFxuICBTZWxlY3Rpb25TZXQ6IFtcInNlbGVjdGlvbnNcIl0sXG4gIEZpZWxkOiBbXCJhbGlhc1wiLCBcIm5hbWVcIiwgXCJhcmd1bWVudHNcIiwgXCJkaXJlY3RpdmVzXCIsIFwic2VsZWN0aW9uU2V0XCJdLFxuICBBcmd1bWVudDogW1wibmFtZVwiLCBcInZhbHVlXCJdLFxuICBGcmFnbWVudFNwcmVhZDogW1wibmFtZVwiLCBcImRpcmVjdGl2ZXNcIl0sXG4gIElubGluZUZyYWdtZW50OiBbXCJ0eXBlQ29uZGl0aW9uXCIsIFwiZGlyZWN0aXZlc1wiLCBcInNlbGVjdGlvblNldFwiXSxcbiAgRnJhZ21lbnREZWZpbml0aW9uOiBbXG4gICAgXCJuYW1lXCIsXG4gICAgLy8gTm90ZTogZnJhZ21lbnQgdmFyaWFibGUgZGVmaW5pdGlvbnMgYXJlIGRlcHJlY2F0ZWQgYW5kIHdpbGwgcmVtb3ZlZCBpbiB2MTcuMC4wXG4gICAgXCJ2YXJpYWJsZURlZmluaXRpb25zXCIsXG4gICAgXCJ0eXBlQ29uZGl0aW9uXCIsXG4gICAgXCJkaXJlY3RpdmVzXCIsXG4gICAgXCJzZWxlY3Rpb25TZXRcIlxuICBdLFxuICBJbnRWYWx1ZTogW10sXG4gIEZsb2F0VmFsdWU6IFtdLFxuICBTdHJpbmdWYWx1ZTogW10sXG4gIEJvb2xlYW5WYWx1ZTogW10sXG4gIE51bGxWYWx1ZTogW10sXG4gIEVudW1WYWx1ZTogW10sXG4gIExpc3RWYWx1ZTogW1widmFsdWVzXCJdLFxuICBPYmplY3RWYWx1ZTogW1wiZmllbGRzXCJdLFxuICBPYmplY3RGaWVsZDogW1wibmFtZVwiLCBcInZhbHVlXCJdLFxuICBEaXJlY3RpdmU6IFtcIm5hbWVcIiwgXCJhcmd1bWVudHNcIl0sXG4gIE5hbWVkVHlwZTogW1wibmFtZVwiXSxcbiAgTGlzdFR5cGU6IFtcInR5cGVcIl0sXG4gIE5vbk51bGxUeXBlOiBbXCJ0eXBlXCJdLFxuICBTY2hlbWFEZWZpbml0aW9uOiBbXCJkZXNjcmlwdGlvblwiLCBcImRpcmVjdGl2ZXNcIiwgXCJvcGVyYXRpb25UeXBlc1wiXSxcbiAgT3BlcmF0aW9uVHlwZURlZmluaXRpb246IFtcInR5cGVcIl0sXG4gIFNjYWxhclR5cGVEZWZpbml0aW9uOiBbXCJkZXNjcmlwdGlvblwiLCBcIm5hbWVcIiwgXCJkaXJlY3RpdmVzXCJdLFxuICBPYmplY3RUeXBlRGVmaW5pdGlvbjogW1xuICAgIFwiZGVzY3JpcHRpb25cIixcbiAgICBcIm5hbWVcIixcbiAgICBcImludGVyZmFjZXNcIixcbiAgICBcImRpcmVjdGl2ZXNcIixcbiAgICBcImZpZWxkc1wiXG4gIF0sXG4gIEZpZWxkRGVmaW5pdGlvbjogW1wiZGVzY3JpcHRpb25cIiwgXCJuYW1lXCIsIFwiYXJndW1lbnRzXCIsIFwidHlwZVwiLCBcImRpcmVjdGl2ZXNcIl0sXG4gIElucHV0VmFsdWVEZWZpbml0aW9uOiBbXG4gICAgXCJkZXNjcmlwdGlvblwiLFxuICAgIFwibmFtZVwiLFxuICAgIFwidHlwZVwiLFxuICAgIFwiZGVmYXVsdFZhbHVlXCIsXG4gICAgXCJkaXJlY3RpdmVzXCJcbiAgXSxcbiAgSW50ZXJmYWNlVHlwZURlZmluaXRpb246IFtcbiAgICBcImRlc2NyaXB0aW9uXCIsXG4gICAgXCJuYW1lXCIsXG4gICAgXCJpbnRlcmZhY2VzXCIsXG4gICAgXCJkaXJlY3RpdmVzXCIsXG4gICAgXCJmaWVsZHNcIlxuICBdLFxuICBVbmlvblR5cGVEZWZpbml0aW9uOiBbXCJkZXNjcmlwdGlvblwiLCBcIm5hbWVcIiwgXCJkaXJlY3RpdmVzXCIsIFwidHlwZXNcIl0sXG4gIEVudW1UeXBlRGVmaW5pdGlvbjogW1wiZGVzY3JpcHRpb25cIiwgXCJuYW1lXCIsIFwiZGlyZWN0aXZlc1wiLCBcInZhbHVlc1wiXSxcbiAgRW51bVZhbHVlRGVmaW5pdGlvbjogW1wiZGVzY3JpcHRpb25cIiwgXCJuYW1lXCIsIFwiZGlyZWN0aXZlc1wiXSxcbiAgSW5wdXRPYmplY3RUeXBlRGVmaW5pdGlvbjogW1wiZGVzY3JpcHRpb25cIiwgXCJuYW1lXCIsIFwiZGlyZWN0aXZlc1wiLCBcImZpZWxkc1wiXSxcbiAgRGlyZWN0aXZlRGVmaW5pdGlvbjogW1wiZGVzY3JpcHRpb25cIiwgXCJuYW1lXCIsIFwiYXJndW1lbnRzXCIsIFwibG9jYXRpb25zXCJdLFxuICBTY2hlbWFFeHRlbnNpb246IFtcImRpcmVjdGl2ZXNcIiwgXCJvcGVyYXRpb25UeXBlc1wiXSxcbiAgU2NhbGFyVHlwZUV4dGVuc2lvbjogW1wibmFtZVwiLCBcImRpcmVjdGl2ZXNcIl0sXG4gIE9iamVjdFR5cGVFeHRlbnNpb246IFtcIm5hbWVcIiwgXCJpbnRlcmZhY2VzXCIsIFwiZGlyZWN0aXZlc1wiLCBcImZpZWxkc1wiXSxcbiAgSW50ZXJmYWNlVHlwZUV4dGVuc2lvbjogW1wibmFtZVwiLCBcImludGVyZmFjZXNcIiwgXCJkaXJlY3RpdmVzXCIsIFwiZmllbGRzXCJdLFxuICBVbmlvblR5cGVFeHRlbnNpb246IFtcIm5hbWVcIiwgXCJkaXJlY3RpdmVzXCIsIFwidHlwZXNcIl0sXG4gIEVudW1UeXBlRXh0ZW5zaW9uOiBbXCJuYW1lXCIsIFwiZGlyZWN0aXZlc1wiLCBcInZhbHVlc1wiXSxcbiAgSW5wdXRPYmplY3RUeXBlRXh0ZW5zaW9uOiBbXCJuYW1lXCIsIFwiZGlyZWN0aXZlc1wiLCBcImZpZWxkc1wiXVxufTtcbnZhciBraW5kVmFsdWVzID0gbmV3IFNldChPYmplY3Qua2V5cyhRdWVyeURvY3VtZW50S2V5cykpO1xuZnVuY3Rpb24gaXNOb2RlKG1heWJlTm9kZSkge1xuICBjb25zdCBtYXliZUtpbmQgPSBtYXliZU5vZGUgPT09IG51bGwgfHwgbWF5YmVOb2RlID09PSB2b2lkIDAgPyB2b2lkIDAgOiBtYXliZU5vZGUua2luZDtcbiAgcmV0dXJuIHR5cGVvZiBtYXliZUtpbmQgPT09IFwic3RyaW5nXCIgJiYga2luZFZhbHVlcy5oYXMobWF5YmVLaW5kKTtcbn1cbnZhciBPcGVyYXRpb25UeXBlTm9kZTtcbihmdW5jdGlvbihPcGVyYXRpb25UeXBlTm9kZTIpIHtcbiAgT3BlcmF0aW9uVHlwZU5vZGUyW1wiUVVFUllcIl0gPSBcInF1ZXJ5XCI7XG4gIE9wZXJhdGlvblR5cGVOb2RlMltcIk1VVEFUSU9OXCJdID0gXCJtdXRhdGlvblwiO1xuICBPcGVyYXRpb25UeXBlTm9kZTJbXCJTVUJTQ1JJUFRJT05cIl0gPSBcInN1YnNjcmlwdGlvblwiO1xufSkoT3BlcmF0aW9uVHlwZU5vZGUgfHwgKE9wZXJhdGlvblR5cGVOb2RlID0ge30pKTtcblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL2xhbmd1YWdlL2RpcmVjdGl2ZUxvY2F0aW9uLm1qc1xudmFyIERpcmVjdGl2ZUxvY2F0aW9uO1xuKGZ1bmN0aW9uKERpcmVjdGl2ZUxvY2F0aW9uMikge1xuICBEaXJlY3RpdmVMb2NhdGlvbjJbXCJRVUVSWVwiXSA9IFwiUVVFUllcIjtcbiAgRGlyZWN0aXZlTG9jYXRpb24yW1wiTVVUQVRJT05cIl0gPSBcIk1VVEFUSU9OXCI7XG4gIERpcmVjdGl2ZUxvY2F0aW9uMltcIlNVQlNDUklQVElPTlwiXSA9IFwiU1VCU0NSSVBUSU9OXCI7XG4gIERpcmVjdGl2ZUxvY2F0aW9uMltcIkZJRUxEXCJdID0gXCJGSUVMRFwiO1xuICBEaXJlY3RpdmVMb2NhdGlvbjJbXCJGUkFHTUVOVF9ERUZJTklUSU9OXCJdID0gXCJGUkFHTUVOVF9ERUZJTklUSU9OXCI7XG4gIERpcmVjdGl2ZUxvY2F0aW9uMltcIkZSQUdNRU5UX1NQUkVBRFwiXSA9IFwiRlJBR01FTlRfU1BSRUFEXCI7XG4gIERpcmVjdGl2ZUxvY2F0aW9uMltcIklOTElORV9GUkFHTUVOVFwiXSA9IFwiSU5MSU5FX0ZSQUdNRU5UXCI7XG4gIERpcmVjdGl2ZUxvY2F0aW9uMltcIlZBUklBQkxFX0RFRklOSVRJT05cIl0gPSBcIlZBUklBQkxFX0RFRklOSVRJT05cIjtcbiAgRGlyZWN0aXZlTG9jYXRpb24yW1wiU0NIRU1BXCJdID0gXCJTQ0hFTUFcIjtcbiAgRGlyZWN0aXZlTG9jYXRpb24yW1wiU0NBTEFSXCJdID0gXCJTQ0FMQVJcIjtcbiAgRGlyZWN0aXZlTG9jYXRpb24yW1wiT0JKRUNUXCJdID0gXCJPQkpFQ1RcIjtcbiAgRGlyZWN0aXZlTG9jYXRpb24yW1wiRklFTERfREVGSU5JVElPTlwiXSA9IFwiRklFTERfREVGSU5JVElPTlwiO1xuICBEaXJlY3RpdmVMb2NhdGlvbjJbXCJBUkdVTUVOVF9ERUZJTklUSU9OXCJdID0gXCJBUkdVTUVOVF9ERUZJTklUSU9OXCI7XG4gIERpcmVjdGl2ZUxvY2F0aW9uMltcIklOVEVSRkFDRVwiXSA9IFwiSU5URVJGQUNFXCI7XG4gIERpcmVjdGl2ZUxvY2F0aW9uMltcIlVOSU9OXCJdID0gXCJVTklPTlwiO1xuICBEaXJlY3RpdmVMb2NhdGlvbjJbXCJFTlVNXCJdID0gXCJFTlVNXCI7XG4gIERpcmVjdGl2ZUxvY2F0aW9uMltcIkVOVU1fVkFMVUVcIl0gPSBcIkVOVU1fVkFMVUVcIjtcbiAgRGlyZWN0aXZlTG9jYXRpb24yW1wiSU5QVVRfT0JKRUNUXCJdID0gXCJJTlBVVF9PQkpFQ1RcIjtcbiAgRGlyZWN0aXZlTG9jYXRpb24yW1wiSU5QVVRfRklFTERfREVGSU5JVElPTlwiXSA9IFwiSU5QVVRfRklFTERfREVGSU5JVElPTlwiO1xufSkoRGlyZWN0aXZlTG9jYXRpb24gfHwgKERpcmVjdGl2ZUxvY2F0aW9uID0ge30pKTtcblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL2xhbmd1YWdlL2tpbmRzLm1qc1xudmFyIEtpbmQ7XG4oZnVuY3Rpb24oS2luZDIpIHtcbiAgS2luZDJbXCJOQU1FXCJdID0gXCJOYW1lXCI7XG4gIEtpbmQyW1wiRE9DVU1FTlRcIl0gPSBcIkRvY3VtZW50XCI7XG4gIEtpbmQyW1wiT1BFUkFUSU9OX0RFRklOSVRJT05cIl0gPSBcIk9wZXJhdGlvbkRlZmluaXRpb25cIjtcbiAgS2luZDJbXCJWQVJJQUJMRV9ERUZJTklUSU9OXCJdID0gXCJWYXJpYWJsZURlZmluaXRpb25cIjtcbiAgS2luZDJbXCJTRUxFQ1RJT05fU0VUXCJdID0gXCJTZWxlY3Rpb25TZXRcIjtcbiAgS2luZDJbXCJGSUVMRFwiXSA9IFwiRmllbGRcIjtcbiAgS2luZDJbXCJBUkdVTUVOVFwiXSA9IFwiQXJndW1lbnRcIjtcbiAgS2luZDJbXCJGUkFHTUVOVF9TUFJFQURcIl0gPSBcIkZyYWdtZW50U3ByZWFkXCI7XG4gIEtpbmQyW1wiSU5MSU5FX0ZSQUdNRU5UXCJdID0gXCJJbmxpbmVGcmFnbWVudFwiO1xuICBLaW5kMltcIkZSQUdNRU5UX0RFRklOSVRJT05cIl0gPSBcIkZyYWdtZW50RGVmaW5pdGlvblwiO1xuICBLaW5kMltcIlZBUklBQkxFXCJdID0gXCJWYXJpYWJsZVwiO1xuICBLaW5kMltcIklOVFwiXSA9IFwiSW50VmFsdWVcIjtcbiAgS2luZDJbXCJGTE9BVFwiXSA9IFwiRmxvYXRWYWx1ZVwiO1xuICBLaW5kMltcIlNUUklOR1wiXSA9IFwiU3RyaW5nVmFsdWVcIjtcbiAgS2luZDJbXCJCT09MRUFOXCJdID0gXCJCb29sZWFuVmFsdWVcIjtcbiAgS2luZDJbXCJOVUxMXCJdID0gXCJOdWxsVmFsdWVcIjtcbiAgS2luZDJbXCJFTlVNXCJdID0gXCJFbnVtVmFsdWVcIjtcbiAgS2luZDJbXCJMSVNUXCJdID0gXCJMaXN0VmFsdWVcIjtcbiAgS2luZDJbXCJPQkpFQ1RcIl0gPSBcIk9iamVjdFZhbHVlXCI7XG4gIEtpbmQyW1wiT0JKRUNUX0ZJRUxEXCJdID0gXCJPYmplY3RGaWVsZFwiO1xuICBLaW5kMltcIkRJUkVDVElWRVwiXSA9IFwiRGlyZWN0aXZlXCI7XG4gIEtpbmQyW1wiTkFNRURfVFlQRVwiXSA9IFwiTmFtZWRUeXBlXCI7XG4gIEtpbmQyW1wiTElTVF9UWVBFXCJdID0gXCJMaXN0VHlwZVwiO1xuICBLaW5kMltcIk5PTl9OVUxMX1RZUEVcIl0gPSBcIk5vbk51bGxUeXBlXCI7XG4gIEtpbmQyW1wiU0NIRU1BX0RFRklOSVRJT05cIl0gPSBcIlNjaGVtYURlZmluaXRpb25cIjtcbiAgS2luZDJbXCJPUEVSQVRJT05fVFlQRV9ERUZJTklUSU9OXCJdID0gXCJPcGVyYXRpb25UeXBlRGVmaW5pdGlvblwiO1xuICBLaW5kMltcIlNDQUxBUl9UWVBFX0RFRklOSVRJT05cIl0gPSBcIlNjYWxhclR5cGVEZWZpbml0aW9uXCI7XG4gIEtpbmQyW1wiT0JKRUNUX1RZUEVfREVGSU5JVElPTlwiXSA9IFwiT2JqZWN0VHlwZURlZmluaXRpb25cIjtcbiAgS2luZDJbXCJGSUVMRF9ERUZJTklUSU9OXCJdID0gXCJGaWVsZERlZmluaXRpb25cIjtcbiAgS2luZDJbXCJJTlBVVF9WQUxVRV9ERUZJTklUSU9OXCJdID0gXCJJbnB1dFZhbHVlRGVmaW5pdGlvblwiO1xuICBLaW5kMltcIklOVEVSRkFDRV9UWVBFX0RFRklOSVRJT05cIl0gPSBcIkludGVyZmFjZVR5cGVEZWZpbml0aW9uXCI7XG4gIEtpbmQyW1wiVU5JT05fVFlQRV9ERUZJTklUSU9OXCJdID0gXCJVbmlvblR5cGVEZWZpbml0aW9uXCI7XG4gIEtpbmQyW1wiRU5VTV9UWVBFX0RFRklOSVRJT05cIl0gPSBcIkVudW1UeXBlRGVmaW5pdGlvblwiO1xuICBLaW5kMltcIkVOVU1fVkFMVUVfREVGSU5JVElPTlwiXSA9IFwiRW51bVZhbHVlRGVmaW5pdGlvblwiO1xuICBLaW5kMltcIklOUFVUX09CSkVDVF9UWVBFX0RFRklOSVRJT05cIl0gPSBcIklucHV0T2JqZWN0VHlwZURlZmluaXRpb25cIjtcbiAgS2luZDJbXCJESVJFQ1RJVkVfREVGSU5JVElPTlwiXSA9IFwiRGlyZWN0aXZlRGVmaW5pdGlvblwiO1xuICBLaW5kMltcIlNDSEVNQV9FWFRFTlNJT05cIl0gPSBcIlNjaGVtYUV4dGVuc2lvblwiO1xuICBLaW5kMltcIlNDQUxBUl9UWVBFX0VYVEVOU0lPTlwiXSA9IFwiU2NhbGFyVHlwZUV4dGVuc2lvblwiO1xuICBLaW5kMltcIk9CSkVDVF9UWVBFX0VYVEVOU0lPTlwiXSA9IFwiT2JqZWN0VHlwZUV4dGVuc2lvblwiO1xuICBLaW5kMltcIklOVEVSRkFDRV9UWVBFX0VYVEVOU0lPTlwiXSA9IFwiSW50ZXJmYWNlVHlwZUV4dGVuc2lvblwiO1xuICBLaW5kMltcIlVOSU9OX1RZUEVfRVhURU5TSU9OXCJdID0gXCJVbmlvblR5cGVFeHRlbnNpb25cIjtcbiAgS2luZDJbXCJFTlVNX1RZUEVfRVhURU5TSU9OXCJdID0gXCJFbnVtVHlwZUV4dGVuc2lvblwiO1xuICBLaW5kMltcIklOUFVUX09CSkVDVF9UWVBFX0VYVEVOU0lPTlwiXSA9IFwiSW5wdXRPYmplY3RUeXBlRXh0ZW5zaW9uXCI7XG59KShLaW5kIHx8IChLaW5kID0ge30pKTtcblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL2xhbmd1YWdlL2NoYXJhY3RlckNsYXNzZXMubWpzXG5mdW5jdGlvbiBpc1doaXRlU3BhY2UoY29kZSkge1xuICByZXR1cm4gY29kZSA9PT0gOSB8fCBjb2RlID09PSAzMjtcbn1cbmZ1bmN0aW9uIGlzRGlnaXQoY29kZSkge1xuICByZXR1cm4gY29kZSA+PSA0OCAmJiBjb2RlIDw9IDU3O1xufVxuZnVuY3Rpb24gaXNMZXR0ZXIoY29kZSkge1xuICByZXR1cm4gY29kZSA+PSA5NyAmJiBjb2RlIDw9IDEyMiB8fCAvLyBBLVpcbiAgY29kZSA+PSA2NSAmJiBjb2RlIDw9IDkwO1xufVxuZnVuY3Rpb24gaXNOYW1lU3RhcnQoY29kZSkge1xuICByZXR1cm4gaXNMZXR0ZXIoY29kZSkgfHwgY29kZSA9PT0gOTU7XG59XG5mdW5jdGlvbiBpc05hbWVDb250aW51ZShjb2RlKSB7XG4gIHJldHVybiBpc0xldHRlcihjb2RlKSB8fCBpc0RpZ2l0KGNvZGUpIHx8IGNvZGUgPT09IDk1O1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvbGFuZ3VhZ2UvYmxvY2tTdHJpbmcubWpzXG5mdW5jdGlvbiBkZWRlbnRCbG9ja1N0cmluZ0xpbmVzKGxpbmVzKSB7XG4gIHZhciBfZmlyc3ROb25FbXB0eUxpbmUyO1xuICBsZXQgY29tbW9uSW5kZW50ID0gTnVtYmVyLk1BWF9TQUZFX0lOVEVHRVI7XG4gIGxldCBmaXJzdE5vbkVtcHR5TGluZSA9IG51bGw7XG4gIGxldCBsYXN0Tm9uRW1wdHlMaW5lID0gLTE7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgbGluZXMubGVuZ3RoOyArK2kpIHtcbiAgICB2YXIgX2ZpcnN0Tm9uRW1wdHlMaW5lO1xuICAgIGNvbnN0IGxpbmUgPSBsaW5lc1tpXTtcbiAgICBjb25zdCBpbmRlbnQyID0gbGVhZGluZ1doaXRlc3BhY2UobGluZSk7XG4gICAgaWYgKGluZGVudDIgPT09IGxpbmUubGVuZ3RoKSB7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgZmlyc3ROb25FbXB0eUxpbmUgPSAoX2ZpcnN0Tm9uRW1wdHlMaW5lID0gZmlyc3ROb25FbXB0eUxpbmUpICE9PSBudWxsICYmIF9maXJzdE5vbkVtcHR5TGluZSAhPT0gdm9pZCAwID8gX2ZpcnN0Tm9uRW1wdHlMaW5lIDogaTtcbiAgICBsYXN0Tm9uRW1wdHlMaW5lID0gaTtcbiAgICBpZiAoaSAhPT0gMCAmJiBpbmRlbnQyIDwgY29tbW9uSW5kZW50KSB7XG4gICAgICBjb21tb25JbmRlbnQgPSBpbmRlbnQyO1xuICAgIH1cbiAgfVxuICByZXR1cm4gbGluZXMubWFwKChsaW5lLCBpKSA9PiBpID09PSAwID8gbGluZSA6IGxpbmUuc2xpY2UoY29tbW9uSW5kZW50KSkuc2xpY2UoXG4gICAgKF9maXJzdE5vbkVtcHR5TGluZTIgPSBmaXJzdE5vbkVtcHR5TGluZSkgIT09IG51bGwgJiYgX2ZpcnN0Tm9uRW1wdHlMaW5lMiAhPT0gdm9pZCAwID8gX2ZpcnN0Tm9uRW1wdHlMaW5lMiA6IDAsXG4gICAgbGFzdE5vbkVtcHR5TGluZSArIDFcbiAgKTtcbn1cbmZ1bmN0aW9uIGxlYWRpbmdXaGl0ZXNwYWNlKHN0cikge1xuICBsZXQgaSA9IDA7XG4gIHdoaWxlIChpIDwgc3RyLmxlbmd0aCAmJiBpc1doaXRlU3BhY2Uoc3RyLmNoYXJDb2RlQXQoaSkpKSB7XG4gICAgKytpO1xuICB9XG4gIHJldHVybiBpO1xufVxuZnVuY3Rpb24gcHJpbnRCbG9ja1N0cmluZyh2YWx1ZSwgb3B0aW9ucykge1xuICBjb25zdCBlc2NhcGVkVmFsdWUgPSB2YWx1ZS5yZXBsYWNlKC9cIlwiXCIvZywgJ1xcXFxcIlwiXCInKTtcbiAgY29uc3QgbGluZXMgPSBlc2NhcGVkVmFsdWUuc3BsaXQoL1xcclxcbnxbXFxuXFxyXS9nKTtcbiAgY29uc3QgaXNTaW5nbGVMaW5lID0gbGluZXMubGVuZ3RoID09PSAxO1xuICBjb25zdCBmb3JjZUxlYWRpbmdOZXdMaW5lID0gbGluZXMubGVuZ3RoID4gMSAmJiBsaW5lcy5zbGljZSgxKS5ldmVyeSgobGluZSkgPT4gbGluZS5sZW5ndGggPT09IDAgfHwgaXNXaGl0ZVNwYWNlKGxpbmUuY2hhckNvZGVBdCgwKSkpO1xuICBjb25zdCBoYXNUcmFpbGluZ1RyaXBsZVF1b3RlcyA9IGVzY2FwZWRWYWx1ZS5lbmRzV2l0aCgnXFxcXFwiXCJcIicpO1xuICBjb25zdCBoYXNUcmFpbGluZ1F1b3RlID0gdmFsdWUuZW5kc1dpdGgoJ1wiJykgJiYgIWhhc1RyYWlsaW5nVHJpcGxlUXVvdGVzO1xuICBjb25zdCBoYXNUcmFpbGluZ1NsYXNoID0gdmFsdWUuZW5kc1dpdGgoXCJcXFxcXCIpO1xuICBjb25zdCBmb3JjZVRyYWlsaW5nTmV3bGluZSA9IGhhc1RyYWlsaW5nUXVvdGUgfHwgaGFzVHJhaWxpbmdTbGFzaDtcbiAgY29uc3QgcHJpbnRBc011bHRpcGxlTGluZXMgPSAhKG9wdGlvbnMgIT09IG51bGwgJiYgb3B0aW9ucyAhPT0gdm9pZCAwICYmIG9wdGlvbnMubWluaW1pemUpICYmIC8vIGFkZCBsZWFkaW5nIGFuZCB0cmFpbGluZyBuZXcgbGluZXMgb25seSBpZiBpdCBpbXByb3ZlcyByZWFkYWJpbGl0eVxuICAoIWlzU2luZ2xlTGluZSB8fCB2YWx1ZS5sZW5ndGggPiA3MCB8fCBmb3JjZVRyYWlsaW5nTmV3bGluZSB8fCBmb3JjZUxlYWRpbmdOZXdMaW5lIHx8IGhhc1RyYWlsaW5nVHJpcGxlUXVvdGVzKTtcbiAgbGV0IHJlc3VsdCA9IFwiXCI7XG4gIGNvbnN0IHNraXBMZWFkaW5nTmV3TGluZSA9IGlzU2luZ2xlTGluZSAmJiBpc1doaXRlU3BhY2UodmFsdWUuY2hhckNvZGVBdCgwKSk7XG4gIGlmIChwcmludEFzTXVsdGlwbGVMaW5lcyAmJiAhc2tpcExlYWRpbmdOZXdMaW5lIHx8IGZvcmNlTGVhZGluZ05ld0xpbmUpIHtcbiAgICByZXN1bHQgKz0gXCJcXG5cIjtcbiAgfVxuICByZXN1bHQgKz0gZXNjYXBlZFZhbHVlO1xuICBpZiAocHJpbnRBc011bHRpcGxlTGluZXMgfHwgZm9yY2VUcmFpbGluZ05ld2xpbmUpIHtcbiAgICByZXN1bHQgKz0gXCJcXG5cIjtcbiAgfVxuICByZXR1cm4gJ1wiXCJcIicgKyByZXN1bHQgKyAnXCJcIlwiJztcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL2xhbmd1YWdlL3Rva2VuS2luZC5tanNcbnZhciBUb2tlbktpbmQ7XG4oZnVuY3Rpb24oVG9rZW5LaW5kMikge1xuICBUb2tlbktpbmQyW1wiU09GXCJdID0gXCI8U09GPlwiO1xuICBUb2tlbktpbmQyW1wiRU9GXCJdID0gXCI8RU9GPlwiO1xuICBUb2tlbktpbmQyW1wiQkFOR1wiXSA9IFwiIVwiO1xuICBUb2tlbktpbmQyW1wiRE9MTEFSXCJdID0gXCIkXCI7XG4gIFRva2VuS2luZDJbXCJBTVBcIl0gPSBcIiZcIjtcbiAgVG9rZW5LaW5kMltcIlBBUkVOX0xcIl0gPSBcIihcIjtcbiAgVG9rZW5LaW5kMltcIlBBUkVOX1JcIl0gPSBcIilcIjtcbiAgVG9rZW5LaW5kMltcIlNQUkVBRFwiXSA9IFwiLi4uXCI7XG4gIFRva2VuS2luZDJbXCJDT0xPTlwiXSA9IFwiOlwiO1xuICBUb2tlbktpbmQyW1wiRVFVQUxTXCJdID0gXCI9XCI7XG4gIFRva2VuS2luZDJbXCJBVFwiXSA9IFwiQFwiO1xuICBUb2tlbktpbmQyW1wiQlJBQ0tFVF9MXCJdID0gXCJbXCI7XG4gIFRva2VuS2luZDJbXCJCUkFDS0VUX1JcIl0gPSBcIl1cIjtcbiAgVG9rZW5LaW5kMltcIkJSQUNFX0xcIl0gPSBcIntcIjtcbiAgVG9rZW5LaW5kMltcIlBJUEVcIl0gPSBcInxcIjtcbiAgVG9rZW5LaW5kMltcIkJSQUNFX1JcIl0gPSBcIn1cIjtcbiAgVG9rZW5LaW5kMltcIk5BTUVcIl0gPSBcIk5hbWVcIjtcbiAgVG9rZW5LaW5kMltcIklOVFwiXSA9IFwiSW50XCI7XG4gIFRva2VuS2luZDJbXCJGTE9BVFwiXSA9IFwiRmxvYXRcIjtcbiAgVG9rZW5LaW5kMltcIlNUUklOR1wiXSA9IFwiU3RyaW5nXCI7XG4gIFRva2VuS2luZDJbXCJCTE9DS19TVFJJTkdcIl0gPSBcIkJsb2NrU3RyaW5nXCI7XG4gIFRva2VuS2luZDJbXCJDT01NRU5UXCJdID0gXCJDb21tZW50XCI7XG59KShUb2tlbktpbmQgfHwgKFRva2VuS2luZCA9IHt9KSk7XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC9sYW5ndWFnZS9sZXhlci5tanNcbnZhciBMZXhlciA9IGNsYXNzIHtcbiAgLyoqXG4gICAqIFRoZSBwcmV2aW91c2x5IGZvY3VzZWQgbm9uLWlnbm9yZWQgdG9rZW4uXG4gICAqL1xuICAvKipcbiAgICogVGhlIGN1cnJlbnRseSBmb2N1c2VkIG5vbi1pZ25vcmVkIHRva2VuLlxuICAgKi9cbiAgLyoqXG4gICAqIFRoZSAoMS1pbmRleGVkKSBsaW5lIGNvbnRhaW5pbmcgdGhlIGN1cnJlbnQgdG9rZW4uXG4gICAqL1xuICAvKipcbiAgICogVGhlIGNoYXJhY3RlciBvZmZzZXQgYXQgd2hpY2ggdGhlIGN1cnJlbnQgbGluZSBiZWdpbnMuXG4gICAqL1xuICBjb25zdHJ1Y3Rvcihzb3VyY2UpIHtcbiAgICBjb25zdCBzdGFydE9mRmlsZVRva2VuID0gbmV3IFRva2VuKFRva2VuS2luZC5TT0YsIDAsIDAsIDAsIDApO1xuICAgIHRoaXMuc291cmNlID0gc291cmNlO1xuICAgIHRoaXMubGFzdFRva2VuID0gc3RhcnRPZkZpbGVUb2tlbjtcbiAgICB0aGlzLnRva2VuID0gc3RhcnRPZkZpbGVUb2tlbjtcbiAgICB0aGlzLmxpbmUgPSAxO1xuICAgIHRoaXMubGluZVN0YXJ0ID0gMDtcbiAgfVxuICBnZXQgW1N5bWJvbC50b1N0cmluZ1RhZ10oKSB7XG4gICAgcmV0dXJuIFwiTGV4ZXJcIjtcbiAgfVxuICAvKipcbiAgICogQWR2YW5jZXMgdGhlIHRva2VuIHN0cmVhbSB0byB0aGUgbmV4dCBub24taWdub3JlZCB0b2tlbi5cbiAgICovXG4gIGFkdmFuY2UoKSB7XG4gICAgdGhpcy5sYXN0VG9rZW4gPSB0aGlzLnRva2VuO1xuICAgIGNvbnN0IHRva2VuID0gdGhpcy50b2tlbiA9IHRoaXMubG9va2FoZWFkKCk7XG4gICAgcmV0dXJuIHRva2VuO1xuICB9XG4gIC8qKlxuICAgKiBMb29rcyBhaGVhZCBhbmQgcmV0dXJucyB0aGUgbmV4dCBub24taWdub3JlZCB0b2tlbiwgYnV0IGRvZXMgbm90IGNoYW5nZVxuICAgKiB0aGUgc3RhdGUgb2YgTGV4ZXIuXG4gICAqL1xuICBsb29rYWhlYWQoKSB7XG4gICAgbGV0IHRva2VuID0gdGhpcy50b2tlbjtcbiAgICBpZiAodG9rZW4ua2luZCAhPT0gVG9rZW5LaW5kLkVPRikge1xuICAgICAgZG8ge1xuICAgICAgICBpZiAodG9rZW4ubmV4dCkge1xuICAgICAgICAgIHRva2VuID0gdG9rZW4ubmV4dDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjb25zdCBuZXh0VG9rZW4gPSByZWFkTmV4dFRva2VuKHRoaXMsIHRva2VuLmVuZCk7XG4gICAgICAgICAgdG9rZW4ubmV4dCA9IG5leHRUb2tlbjtcbiAgICAgICAgICBuZXh0VG9rZW4ucHJldiA9IHRva2VuO1xuICAgICAgICAgIHRva2VuID0gbmV4dFRva2VuO1xuICAgICAgICB9XG4gICAgICB9IHdoaWxlICh0b2tlbi5raW5kID09PSBUb2tlbktpbmQuQ09NTUVOVCk7XG4gICAgfVxuICAgIHJldHVybiB0b2tlbjtcbiAgfVxufTtcbmZ1bmN0aW9uIGlzUHVuY3R1YXRvclRva2VuS2luZChraW5kKSB7XG4gIHJldHVybiBraW5kID09PSBUb2tlbktpbmQuQkFORyB8fCBraW5kID09PSBUb2tlbktpbmQuRE9MTEFSIHx8IGtpbmQgPT09IFRva2VuS2luZC5BTVAgfHwga2luZCA9PT0gVG9rZW5LaW5kLlBBUkVOX0wgfHwga2luZCA9PT0gVG9rZW5LaW5kLlBBUkVOX1IgfHwga2luZCA9PT0gVG9rZW5LaW5kLlNQUkVBRCB8fCBraW5kID09PSBUb2tlbktpbmQuQ09MT04gfHwga2luZCA9PT0gVG9rZW5LaW5kLkVRVUFMUyB8fCBraW5kID09PSBUb2tlbktpbmQuQVQgfHwga2luZCA9PT0gVG9rZW5LaW5kLkJSQUNLRVRfTCB8fCBraW5kID09PSBUb2tlbktpbmQuQlJBQ0tFVF9SIHx8IGtpbmQgPT09IFRva2VuS2luZC5CUkFDRV9MIHx8IGtpbmQgPT09IFRva2VuS2luZC5QSVBFIHx8IGtpbmQgPT09IFRva2VuS2luZC5CUkFDRV9SO1xufVxuZnVuY3Rpb24gaXNVbmljb2RlU2NhbGFyVmFsdWUoY29kZSkge1xuICByZXR1cm4gY29kZSA+PSAwICYmIGNvZGUgPD0gNTUyOTUgfHwgY29kZSA+PSA1NzM0NCAmJiBjb2RlIDw9IDExMTQxMTE7XG59XG5mdW5jdGlvbiBpc1N1cHBsZW1lbnRhcnlDb2RlUG9pbnQoYm9keSwgbG9jYXRpb24yKSB7XG4gIHJldHVybiBpc0xlYWRpbmdTdXJyb2dhdGUoYm9keS5jaGFyQ29kZUF0KGxvY2F0aW9uMikpICYmIGlzVHJhaWxpbmdTdXJyb2dhdGUoYm9keS5jaGFyQ29kZUF0KGxvY2F0aW9uMiArIDEpKTtcbn1cbmZ1bmN0aW9uIGlzTGVhZGluZ1N1cnJvZ2F0ZShjb2RlKSB7XG4gIHJldHVybiBjb2RlID49IDU1Mjk2ICYmIGNvZGUgPD0gNTYzMTk7XG59XG5mdW5jdGlvbiBpc1RyYWlsaW5nU3Vycm9nYXRlKGNvZGUpIHtcbiAgcmV0dXJuIGNvZGUgPj0gNTYzMjAgJiYgY29kZSA8PSA1NzM0Mztcbn1cbmZ1bmN0aW9uIHByaW50Q29kZVBvaW50QXQobGV4ZXIyLCBsb2NhdGlvbjIpIHtcbiAgY29uc3QgY29kZSA9IGxleGVyMi5zb3VyY2UuYm9keS5jb2RlUG9pbnRBdChsb2NhdGlvbjIpO1xuICBpZiAoY29kZSA9PT0gdm9pZCAwKSB7XG4gICAgcmV0dXJuIFRva2VuS2luZC5FT0Y7XG4gIH0gZWxzZSBpZiAoY29kZSA+PSAzMiAmJiBjb2RlIDw9IDEyNikge1xuICAgIGNvbnN0IGNoYXIgPSBTdHJpbmcuZnJvbUNvZGVQb2ludChjb2RlKTtcbiAgICByZXR1cm4gY2hhciA9PT0gJ1wiJyA/IGAnXCInYCA6IGBcIiR7Y2hhcn1cImA7XG4gIH1cbiAgcmV0dXJuIFwiVStcIiArIGNvZGUudG9TdHJpbmcoMTYpLnRvVXBwZXJDYXNlKCkucGFkU3RhcnQoNCwgXCIwXCIpO1xufVxuZnVuY3Rpb24gY3JlYXRlVG9rZW4obGV4ZXIyLCBraW5kLCBzdGFydCwgZW5kLCB2YWx1ZSkge1xuICBjb25zdCBsaW5lID0gbGV4ZXIyLmxpbmU7XG4gIGNvbnN0IGNvbCA9IDEgKyBzdGFydCAtIGxleGVyMi5saW5lU3RhcnQ7XG4gIHJldHVybiBuZXcgVG9rZW4oa2luZCwgc3RhcnQsIGVuZCwgbGluZSwgY29sLCB2YWx1ZSk7XG59XG5mdW5jdGlvbiByZWFkTmV4dFRva2VuKGxleGVyMiwgc3RhcnQpIHtcbiAgY29uc3QgYm9keSA9IGxleGVyMi5zb3VyY2UuYm9keTtcbiAgY29uc3QgYm9keUxlbmd0aCA9IGJvZHkubGVuZ3RoO1xuICBsZXQgcG9zaXRpb24gPSBzdGFydDtcbiAgd2hpbGUgKHBvc2l0aW9uIDwgYm9keUxlbmd0aCkge1xuICAgIGNvbnN0IGNvZGUgPSBib2R5LmNoYXJDb2RlQXQocG9zaXRpb24pO1xuICAgIHN3aXRjaCAoY29kZSkge1xuICAgICAgY2FzZSA2NTI3OTpcbiAgICAgIGNhc2UgOTpcbiAgICAgIGNhc2UgMzI6XG4gICAgICBjYXNlIDQ0OlxuICAgICAgICArK3Bvc2l0aW9uO1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIGNhc2UgMTA6XG4gICAgICAgICsrcG9zaXRpb247XG4gICAgICAgICsrbGV4ZXIyLmxpbmU7XG4gICAgICAgIGxleGVyMi5saW5lU3RhcnQgPSBwb3NpdGlvbjtcbiAgICAgICAgY29udGludWU7XG4gICAgICBjYXNlIDEzOlxuICAgICAgICBpZiAoYm9keS5jaGFyQ29kZUF0KHBvc2l0aW9uICsgMSkgPT09IDEwKSB7XG4gICAgICAgICAgcG9zaXRpb24gKz0gMjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICArK3Bvc2l0aW9uO1xuICAgICAgICB9XG4gICAgICAgICsrbGV4ZXIyLmxpbmU7XG4gICAgICAgIGxleGVyMi5saW5lU3RhcnQgPSBwb3NpdGlvbjtcbiAgICAgICAgY29udGludWU7XG4gICAgICBjYXNlIDM1OlxuICAgICAgICByZXR1cm4gcmVhZENvbW1lbnQobGV4ZXIyLCBwb3NpdGlvbik7XG4gICAgICBjYXNlIDMzOlxuICAgICAgICByZXR1cm4gY3JlYXRlVG9rZW4obGV4ZXIyLCBUb2tlbktpbmQuQkFORywgcG9zaXRpb24sIHBvc2l0aW9uICsgMSk7XG4gICAgICBjYXNlIDM2OlxuICAgICAgICByZXR1cm4gY3JlYXRlVG9rZW4obGV4ZXIyLCBUb2tlbktpbmQuRE9MTEFSLCBwb3NpdGlvbiwgcG9zaXRpb24gKyAxKTtcbiAgICAgIGNhc2UgMzg6XG4gICAgICAgIHJldHVybiBjcmVhdGVUb2tlbihsZXhlcjIsIFRva2VuS2luZC5BTVAsIHBvc2l0aW9uLCBwb3NpdGlvbiArIDEpO1xuICAgICAgY2FzZSA0MDpcbiAgICAgICAgcmV0dXJuIGNyZWF0ZVRva2VuKGxleGVyMiwgVG9rZW5LaW5kLlBBUkVOX0wsIHBvc2l0aW9uLCBwb3NpdGlvbiArIDEpO1xuICAgICAgY2FzZSA0MTpcbiAgICAgICAgcmV0dXJuIGNyZWF0ZVRva2VuKGxleGVyMiwgVG9rZW5LaW5kLlBBUkVOX1IsIHBvc2l0aW9uLCBwb3NpdGlvbiArIDEpO1xuICAgICAgY2FzZSA0NjpcbiAgICAgICAgaWYgKGJvZHkuY2hhckNvZGVBdChwb3NpdGlvbiArIDEpID09PSA0NiAmJiBib2R5LmNoYXJDb2RlQXQocG9zaXRpb24gKyAyKSA9PT0gNDYpIHtcbiAgICAgICAgICByZXR1cm4gY3JlYXRlVG9rZW4obGV4ZXIyLCBUb2tlbktpbmQuU1BSRUFELCBwb3NpdGlvbiwgcG9zaXRpb24gKyAzKTtcbiAgICAgICAgfVxuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgNTg6XG4gICAgICAgIHJldHVybiBjcmVhdGVUb2tlbihsZXhlcjIsIFRva2VuS2luZC5DT0xPTiwgcG9zaXRpb24sIHBvc2l0aW9uICsgMSk7XG4gICAgICBjYXNlIDYxOlxuICAgICAgICByZXR1cm4gY3JlYXRlVG9rZW4obGV4ZXIyLCBUb2tlbktpbmQuRVFVQUxTLCBwb3NpdGlvbiwgcG9zaXRpb24gKyAxKTtcbiAgICAgIGNhc2UgNjQ6XG4gICAgICAgIHJldHVybiBjcmVhdGVUb2tlbihsZXhlcjIsIFRva2VuS2luZC5BVCwgcG9zaXRpb24sIHBvc2l0aW9uICsgMSk7XG4gICAgICBjYXNlIDkxOlxuICAgICAgICByZXR1cm4gY3JlYXRlVG9rZW4obGV4ZXIyLCBUb2tlbktpbmQuQlJBQ0tFVF9MLCBwb3NpdGlvbiwgcG9zaXRpb24gKyAxKTtcbiAgICAgIGNhc2UgOTM6XG4gICAgICAgIHJldHVybiBjcmVhdGVUb2tlbihsZXhlcjIsIFRva2VuS2luZC5CUkFDS0VUX1IsIHBvc2l0aW9uLCBwb3NpdGlvbiArIDEpO1xuICAgICAgY2FzZSAxMjM6XG4gICAgICAgIHJldHVybiBjcmVhdGVUb2tlbihsZXhlcjIsIFRva2VuS2luZC5CUkFDRV9MLCBwb3NpdGlvbiwgcG9zaXRpb24gKyAxKTtcbiAgICAgIGNhc2UgMTI0OlxuICAgICAgICByZXR1cm4gY3JlYXRlVG9rZW4obGV4ZXIyLCBUb2tlbktpbmQuUElQRSwgcG9zaXRpb24sIHBvc2l0aW9uICsgMSk7XG4gICAgICBjYXNlIDEyNTpcbiAgICAgICAgcmV0dXJuIGNyZWF0ZVRva2VuKGxleGVyMiwgVG9rZW5LaW5kLkJSQUNFX1IsIHBvc2l0aW9uLCBwb3NpdGlvbiArIDEpO1xuICAgICAgY2FzZSAzNDpcbiAgICAgICAgaWYgKGJvZHkuY2hhckNvZGVBdChwb3NpdGlvbiArIDEpID09PSAzNCAmJiBib2R5LmNoYXJDb2RlQXQocG9zaXRpb24gKyAyKSA9PT0gMzQpIHtcbiAgICAgICAgICByZXR1cm4gcmVhZEJsb2NrU3RyaW5nKGxleGVyMiwgcG9zaXRpb24pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZWFkU3RyaW5nKGxleGVyMiwgcG9zaXRpb24pO1xuICAgIH1cbiAgICBpZiAoaXNEaWdpdChjb2RlKSB8fCBjb2RlID09PSA0NSkge1xuICAgICAgcmV0dXJuIHJlYWROdW1iZXIobGV4ZXIyLCBwb3NpdGlvbiwgY29kZSk7XG4gICAgfVxuICAgIGlmIChpc05hbWVTdGFydChjb2RlKSkge1xuICAgICAgcmV0dXJuIHJlYWROYW1lKGxleGVyMiwgcG9zaXRpb24pO1xuICAgIH1cbiAgICB0aHJvdyBzeW50YXhFcnJvcihcbiAgICAgIGxleGVyMi5zb3VyY2UsXG4gICAgICBwb3NpdGlvbixcbiAgICAgIGNvZGUgPT09IDM5ID8gYFVuZXhwZWN0ZWQgc2luZ2xlIHF1b3RlIGNoYXJhY3RlciAoJyksIGRpZCB5b3UgbWVhbiB0byB1c2UgYSBkb3VibGUgcXVvdGUgKFwiKT9gIDogaXNVbmljb2RlU2NhbGFyVmFsdWUoY29kZSkgfHwgaXNTdXBwbGVtZW50YXJ5Q29kZVBvaW50KGJvZHksIHBvc2l0aW9uKSA/IGBVbmV4cGVjdGVkIGNoYXJhY3RlcjogJHtwcmludENvZGVQb2ludEF0KGxleGVyMiwgcG9zaXRpb24pfS5gIDogYEludmFsaWQgY2hhcmFjdGVyOiAke3ByaW50Q29kZVBvaW50QXQobGV4ZXIyLCBwb3NpdGlvbil9LmBcbiAgICApO1xuICB9XG4gIHJldHVybiBjcmVhdGVUb2tlbihsZXhlcjIsIFRva2VuS2luZC5FT0YsIGJvZHlMZW5ndGgsIGJvZHlMZW5ndGgpO1xufVxuZnVuY3Rpb24gcmVhZENvbW1lbnQobGV4ZXIyLCBzdGFydCkge1xuICBjb25zdCBib2R5ID0gbGV4ZXIyLnNvdXJjZS5ib2R5O1xuICBjb25zdCBib2R5TGVuZ3RoID0gYm9keS5sZW5ndGg7XG4gIGxldCBwb3NpdGlvbiA9IHN0YXJ0ICsgMTtcbiAgd2hpbGUgKHBvc2l0aW9uIDwgYm9keUxlbmd0aCkge1xuICAgIGNvbnN0IGNvZGUgPSBib2R5LmNoYXJDb2RlQXQocG9zaXRpb24pO1xuICAgIGlmIChjb2RlID09PSAxMCB8fCBjb2RlID09PSAxMykge1xuICAgICAgYnJlYWs7XG4gICAgfVxuICAgIGlmIChpc1VuaWNvZGVTY2FsYXJWYWx1ZShjb2RlKSkge1xuICAgICAgKytwb3NpdGlvbjtcbiAgICB9IGVsc2UgaWYgKGlzU3VwcGxlbWVudGFyeUNvZGVQb2ludChib2R5LCBwb3NpdGlvbikpIHtcbiAgICAgIHBvc2l0aW9uICs9IDI7XG4gICAgfSBlbHNlIHtcbiAgICAgIGJyZWFrO1xuICAgIH1cbiAgfVxuICByZXR1cm4gY3JlYXRlVG9rZW4oXG4gICAgbGV4ZXIyLFxuICAgIFRva2VuS2luZC5DT01NRU5ULFxuICAgIHN0YXJ0LFxuICAgIHBvc2l0aW9uLFxuICAgIGJvZHkuc2xpY2Uoc3RhcnQgKyAxLCBwb3NpdGlvbilcbiAgKTtcbn1cbmZ1bmN0aW9uIHJlYWROdW1iZXIobGV4ZXIyLCBzdGFydCwgZmlyc3RDb2RlKSB7XG4gIGNvbnN0IGJvZHkgPSBsZXhlcjIuc291cmNlLmJvZHk7XG4gIGxldCBwb3NpdGlvbiA9IHN0YXJ0O1xuICBsZXQgY29kZSA9IGZpcnN0Q29kZTtcbiAgbGV0IGlzRmxvYXQgPSBmYWxzZTtcbiAgaWYgKGNvZGUgPT09IDQ1KSB7XG4gICAgY29kZSA9IGJvZHkuY2hhckNvZGVBdCgrK3Bvc2l0aW9uKTtcbiAgfVxuICBpZiAoY29kZSA9PT0gNDgpIHtcbiAgICBjb2RlID0gYm9keS5jaGFyQ29kZUF0KCsrcG9zaXRpb24pO1xuICAgIGlmIChpc0RpZ2l0KGNvZGUpKSB7XG4gICAgICB0aHJvdyBzeW50YXhFcnJvcihcbiAgICAgICAgbGV4ZXIyLnNvdXJjZSxcbiAgICAgICAgcG9zaXRpb24sXG4gICAgICAgIGBJbnZhbGlkIG51bWJlciwgdW5leHBlY3RlZCBkaWdpdCBhZnRlciAwOiAke3ByaW50Q29kZVBvaW50QXQoXG4gICAgICAgICAgbGV4ZXIyLFxuICAgICAgICAgIHBvc2l0aW9uXG4gICAgICAgICl9LmBcbiAgICAgICk7XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIHBvc2l0aW9uID0gcmVhZERpZ2l0cyhsZXhlcjIsIHBvc2l0aW9uLCBjb2RlKTtcbiAgICBjb2RlID0gYm9keS5jaGFyQ29kZUF0KHBvc2l0aW9uKTtcbiAgfVxuICBpZiAoY29kZSA9PT0gNDYpIHtcbiAgICBpc0Zsb2F0ID0gdHJ1ZTtcbiAgICBjb2RlID0gYm9keS5jaGFyQ29kZUF0KCsrcG9zaXRpb24pO1xuICAgIHBvc2l0aW9uID0gcmVhZERpZ2l0cyhsZXhlcjIsIHBvc2l0aW9uLCBjb2RlKTtcbiAgICBjb2RlID0gYm9keS5jaGFyQ29kZUF0KHBvc2l0aW9uKTtcbiAgfVxuICBpZiAoY29kZSA9PT0gNjkgfHwgY29kZSA9PT0gMTAxKSB7XG4gICAgaXNGbG9hdCA9IHRydWU7XG4gICAgY29kZSA9IGJvZHkuY2hhckNvZGVBdCgrK3Bvc2l0aW9uKTtcbiAgICBpZiAoY29kZSA9PT0gNDMgfHwgY29kZSA9PT0gNDUpIHtcbiAgICAgIGNvZGUgPSBib2R5LmNoYXJDb2RlQXQoKytwb3NpdGlvbik7XG4gICAgfVxuICAgIHBvc2l0aW9uID0gcmVhZERpZ2l0cyhsZXhlcjIsIHBvc2l0aW9uLCBjb2RlKTtcbiAgICBjb2RlID0gYm9keS5jaGFyQ29kZUF0KHBvc2l0aW9uKTtcbiAgfVxuICBpZiAoY29kZSA9PT0gNDYgfHwgaXNOYW1lU3RhcnQoY29kZSkpIHtcbiAgICB0aHJvdyBzeW50YXhFcnJvcihcbiAgICAgIGxleGVyMi5zb3VyY2UsXG4gICAgICBwb3NpdGlvbixcbiAgICAgIGBJbnZhbGlkIG51bWJlciwgZXhwZWN0ZWQgZGlnaXQgYnV0IGdvdDogJHtwcmludENvZGVQb2ludEF0KFxuICAgICAgICBsZXhlcjIsXG4gICAgICAgIHBvc2l0aW9uXG4gICAgICApfS5gXG4gICAgKTtcbiAgfVxuICByZXR1cm4gY3JlYXRlVG9rZW4oXG4gICAgbGV4ZXIyLFxuICAgIGlzRmxvYXQgPyBUb2tlbktpbmQuRkxPQVQgOiBUb2tlbktpbmQuSU5ULFxuICAgIHN0YXJ0LFxuICAgIHBvc2l0aW9uLFxuICAgIGJvZHkuc2xpY2Uoc3RhcnQsIHBvc2l0aW9uKVxuICApO1xufVxuZnVuY3Rpb24gcmVhZERpZ2l0cyhsZXhlcjIsIHN0YXJ0LCBmaXJzdENvZGUpIHtcbiAgaWYgKCFpc0RpZ2l0KGZpcnN0Q29kZSkpIHtcbiAgICB0aHJvdyBzeW50YXhFcnJvcihcbiAgICAgIGxleGVyMi5zb3VyY2UsXG4gICAgICBzdGFydCxcbiAgICAgIGBJbnZhbGlkIG51bWJlciwgZXhwZWN0ZWQgZGlnaXQgYnV0IGdvdDogJHtwcmludENvZGVQb2ludEF0KFxuICAgICAgICBsZXhlcjIsXG4gICAgICAgIHN0YXJ0XG4gICAgICApfS5gXG4gICAgKTtcbiAgfVxuICBjb25zdCBib2R5ID0gbGV4ZXIyLnNvdXJjZS5ib2R5O1xuICBsZXQgcG9zaXRpb24gPSBzdGFydCArIDE7XG4gIHdoaWxlIChpc0RpZ2l0KGJvZHkuY2hhckNvZGVBdChwb3NpdGlvbikpKSB7XG4gICAgKytwb3NpdGlvbjtcbiAgfVxuICByZXR1cm4gcG9zaXRpb247XG59XG5mdW5jdGlvbiByZWFkU3RyaW5nKGxleGVyMiwgc3RhcnQpIHtcbiAgY29uc3QgYm9keSA9IGxleGVyMi5zb3VyY2UuYm9keTtcbiAgY29uc3QgYm9keUxlbmd0aCA9IGJvZHkubGVuZ3RoO1xuICBsZXQgcG9zaXRpb24gPSBzdGFydCArIDE7XG4gIGxldCBjaHVua1N0YXJ0ID0gcG9zaXRpb247XG4gIGxldCB2YWx1ZSA9IFwiXCI7XG4gIHdoaWxlIChwb3NpdGlvbiA8IGJvZHlMZW5ndGgpIHtcbiAgICBjb25zdCBjb2RlID0gYm9keS5jaGFyQ29kZUF0KHBvc2l0aW9uKTtcbiAgICBpZiAoY29kZSA9PT0gMzQpIHtcbiAgICAgIHZhbHVlICs9IGJvZHkuc2xpY2UoY2h1bmtTdGFydCwgcG9zaXRpb24pO1xuICAgICAgcmV0dXJuIGNyZWF0ZVRva2VuKGxleGVyMiwgVG9rZW5LaW5kLlNUUklORywgc3RhcnQsIHBvc2l0aW9uICsgMSwgdmFsdWUpO1xuICAgIH1cbiAgICBpZiAoY29kZSA9PT0gOTIpIHtcbiAgICAgIHZhbHVlICs9IGJvZHkuc2xpY2UoY2h1bmtTdGFydCwgcG9zaXRpb24pO1xuICAgICAgY29uc3QgZXNjYXBlID0gYm9keS5jaGFyQ29kZUF0KHBvc2l0aW9uICsgMSkgPT09IDExNyA/IGJvZHkuY2hhckNvZGVBdChwb3NpdGlvbiArIDIpID09PSAxMjMgPyByZWFkRXNjYXBlZFVuaWNvZGVWYXJpYWJsZVdpZHRoKGxleGVyMiwgcG9zaXRpb24pIDogcmVhZEVzY2FwZWRVbmljb2RlRml4ZWRXaWR0aChsZXhlcjIsIHBvc2l0aW9uKSA6IHJlYWRFc2NhcGVkQ2hhcmFjdGVyKGxleGVyMiwgcG9zaXRpb24pO1xuICAgICAgdmFsdWUgKz0gZXNjYXBlLnZhbHVlO1xuICAgICAgcG9zaXRpb24gKz0gZXNjYXBlLnNpemU7XG4gICAgICBjaHVua1N0YXJ0ID0gcG9zaXRpb247XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgaWYgKGNvZGUgPT09IDEwIHx8IGNvZGUgPT09IDEzKSB7XG4gICAgICBicmVhaztcbiAgICB9XG4gICAgaWYgKGlzVW5pY29kZVNjYWxhclZhbHVlKGNvZGUpKSB7XG4gICAgICArK3Bvc2l0aW9uO1xuICAgIH0gZWxzZSBpZiAoaXNTdXBwbGVtZW50YXJ5Q29kZVBvaW50KGJvZHksIHBvc2l0aW9uKSkge1xuICAgICAgcG9zaXRpb24gKz0gMjtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhyb3cgc3ludGF4RXJyb3IoXG4gICAgICAgIGxleGVyMi5zb3VyY2UsXG4gICAgICAgIHBvc2l0aW9uLFxuICAgICAgICBgSW52YWxpZCBjaGFyYWN0ZXIgd2l0aGluIFN0cmluZzogJHtwcmludENvZGVQb2ludEF0KFxuICAgICAgICAgIGxleGVyMixcbiAgICAgICAgICBwb3NpdGlvblxuICAgICAgICApfS5gXG4gICAgICApO1xuICAgIH1cbiAgfVxuICB0aHJvdyBzeW50YXhFcnJvcihsZXhlcjIuc291cmNlLCBwb3NpdGlvbiwgXCJVbnRlcm1pbmF0ZWQgc3RyaW5nLlwiKTtcbn1cbmZ1bmN0aW9uIHJlYWRFc2NhcGVkVW5pY29kZVZhcmlhYmxlV2lkdGgobGV4ZXIyLCBwb3NpdGlvbikge1xuICBjb25zdCBib2R5ID0gbGV4ZXIyLnNvdXJjZS5ib2R5O1xuICBsZXQgcG9pbnQgPSAwO1xuICBsZXQgc2l6ZSA9IDM7XG4gIHdoaWxlIChzaXplIDwgMTIpIHtcbiAgICBjb25zdCBjb2RlID0gYm9keS5jaGFyQ29kZUF0KHBvc2l0aW9uICsgc2l6ZSsrKTtcbiAgICBpZiAoY29kZSA9PT0gMTI1KSB7XG4gICAgICBpZiAoc2l6ZSA8IDUgfHwgIWlzVW5pY29kZVNjYWxhclZhbHVlKHBvaW50KSkge1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICAgIHJldHVybiB7XG4gICAgICAgIHZhbHVlOiBTdHJpbmcuZnJvbUNvZGVQb2ludChwb2ludCksXG4gICAgICAgIHNpemVcbiAgICAgIH07XG4gICAgfVxuICAgIHBvaW50ID0gcG9pbnQgPDwgNCB8IHJlYWRIZXhEaWdpdChjb2RlKTtcbiAgICBpZiAocG9pbnQgPCAwKSB7XG4gICAgICBicmVhaztcbiAgICB9XG4gIH1cbiAgdGhyb3cgc3ludGF4RXJyb3IoXG4gICAgbGV4ZXIyLnNvdXJjZSxcbiAgICBwb3NpdGlvbixcbiAgICBgSW52YWxpZCBVbmljb2RlIGVzY2FwZSBzZXF1ZW5jZTogXCIke2JvZHkuc2xpY2UoXG4gICAgICBwb3NpdGlvbixcbiAgICAgIHBvc2l0aW9uICsgc2l6ZVxuICAgICl9XCIuYFxuICApO1xufVxuZnVuY3Rpb24gcmVhZEVzY2FwZWRVbmljb2RlRml4ZWRXaWR0aChsZXhlcjIsIHBvc2l0aW9uKSB7XG4gIGNvbnN0IGJvZHkgPSBsZXhlcjIuc291cmNlLmJvZHk7XG4gIGNvbnN0IGNvZGUgPSByZWFkMTZCaXRIZXhDb2RlKGJvZHksIHBvc2l0aW9uICsgMik7XG4gIGlmIChpc1VuaWNvZGVTY2FsYXJWYWx1ZShjb2RlKSkge1xuICAgIHJldHVybiB7XG4gICAgICB2YWx1ZTogU3RyaW5nLmZyb21Db2RlUG9pbnQoY29kZSksXG4gICAgICBzaXplOiA2XG4gICAgfTtcbiAgfVxuICBpZiAoaXNMZWFkaW5nU3Vycm9nYXRlKGNvZGUpKSB7XG4gICAgaWYgKGJvZHkuY2hhckNvZGVBdChwb3NpdGlvbiArIDYpID09PSA5MiAmJiBib2R5LmNoYXJDb2RlQXQocG9zaXRpb24gKyA3KSA9PT0gMTE3KSB7XG4gICAgICBjb25zdCB0cmFpbGluZ0NvZGUgPSByZWFkMTZCaXRIZXhDb2RlKGJvZHksIHBvc2l0aW9uICsgOCk7XG4gICAgICBpZiAoaXNUcmFpbGluZ1N1cnJvZ2F0ZSh0cmFpbGluZ0NvZGUpKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgdmFsdWU6IFN0cmluZy5mcm9tQ29kZVBvaW50KGNvZGUsIHRyYWlsaW5nQ29kZSksXG4gICAgICAgICAgc2l6ZTogMTJcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgdGhyb3cgc3ludGF4RXJyb3IoXG4gICAgbGV4ZXIyLnNvdXJjZSxcbiAgICBwb3NpdGlvbixcbiAgICBgSW52YWxpZCBVbmljb2RlIGVzY2FwZSBzZXF1ZW5jZTogXCIke2JvZHkuc2xpY2UocG9zaXRpb24sIHBvc2l0aW9uICsgNil9XCIuYFxuICApO1xufVxuZnVuY3Rpb24gcmVhZDE2Qml0SGV4Q29kZShib2R5LCBwb3NpdGlvbikge1xuICByZXR1cm4gcmVhZEhleERpZ2l0KGJvZHkuY2hhckNvZGVBdChwb3NpdGlvbikpIDw8IDEyIHwgcmVhZEhleERpZ2l0KGJvZHkuY2hhckNvZGVBdChwb3NpdGlvbiArIDEpKSA8PCA4IHwgcmVhZEhleERpZ2l0KGJvZHkuY2hhckNvZGVBdChwb3NpdGlvbiArIDIpKSA8PCA0IHwgcmVhZEhleERpZ2l0KGJvZHkuY2hhckNvZGVBdChwb3NpdGlvbiArIDMpKTtcbn1cbmZ1bmN0aW9uIHJlYWRIZXhEaWdpdChjb2RlKSB7XG4gIHJldHVybiBjb2RlID49IDQ4ICYmIGNvZGUgPD0gNTcgPyBjb2RlIC0gNDggOiBjb2RlID49IDY1ICYmIGNvZGUgPD0gNzAgPyBjb2RlIC0gNTUgOiBjb2RlID49IDk3ICYmIGNvZGUgPD0gMTAyID8gY29kZSAtIDg3IDogLTE7XG59XG5mdW5jdGlvbiByZWFkRXNjYXBlZENoYXJhY3RlcihsZXhlcjIsIHBvc2l0aW9uKSB7XG4gIGNvbnN0IGJvZHkgPSBsZXhlcjIuc291cmNlLmJvZHk7XG4gIGNvbnN0IGNvZGUgPSBib2R5LmNoYXJDb2RlQXQocG9zaXRpb24gKyAxKTtcbiAgc3dpdGNoIChjb2RlKSB7XG4gICAgY2FzZSAzNDpcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHZhbHVlOiAnXCInLFxuICAgICAgICBzaXplOiAyXG4gICAgICB9O1xuICAgIGNhc2UgOTI6XG4gICAgICByZXR1cm4ge1xuICAgICAgICB2YWx1ZTogXCJcXFxcXCIsXG4gICAgICAgIHNpemU6IDJcbiAgICAgIH07XG4gICAgY2FzZSA0NzpcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHZhbHVlOiBcIi9cIixcbiAgICAgICAgc2l6ZTogMlxuICAgICAgfTtcbiAgICBjYXNlIDk4OlxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgdmFsdWU6IFwiXFxiXCIsXG4gICAgICAgIHNpemU6IDJcbiAgICAgIH07XG4gICAgY2FzZSAxMDI6XG4gICAgICByZXR1cm4ge1xuICAgICAgICB2YWx1ZTogXCJcXGZcIixcbiAgICAgICAgc2l6ZTogMlxuICAgICAgfTtcbiAgICBjYXNlIDExMDpcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHZhbHVlOiBcIlxcblwiLFxuICAgICAgICBzaXplOiAyXG4gICAgICB9O1xuICAgIGNhc2UgMTE0OlxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgdmFsdWU6IFwiXFxyXCIsXG4gICAgICAgIHNpemU6IDJcbiAgICAgIH07XG4gICAgY2FzZSAxMTY6XG4gICAgICByZXR1cm4ge1xuICAgICAgICB2YWx1ZTogXCJcdFwiLFxuICAgICAgICBzaXplOiAyXG4gICAgICB9O1xuICB9XG4gIHRocm93IHN5bnRheEVycm9yKFxuICAgIGxleGVyMi5zb3VyY2UsXG4gICAgcG9zaXRpb24sXG4gICAgYEludmFsaWQgY2hhcmFjdGVyIGVzY2FwZSBzZXF1ZW5jZTogXCIke2JvZHkuc2xpY2UoXG4gICAgICBwb3NpdGlvbixcbiAgICAgIHBvc2l0aW9uICsgMlxuICAgICl9XCIuYFxuICApO1xufVxuZnVuY3Rpb24gcmVhZEJsb2NrU3RyaW5nKGxleGVyMiwgc3RhcnQpIHtcbiAgY29uc3QgYm9keSA9IGxleGVyMi5zb3VyY2UuYm9keTtcbiAgY29uc3QgYm9keUxlbmd0aCA9IGJvZHkubGVuZ3RoO1xuICBsZXQgbGluZVN0YXJ0ID0gbGV4ZXIyLmxpbmVTdGFydDtcbiAgbGV0IHBvc2l0aW9uID0gc3RhcnQgKyAzO1xuICBsZXQgY2h1bmtTdGFydCA9IHBvc2l0aW9uO1xuICBsZXQgY3VycmVudExpbmUgPSBcIlwiO1xuICBjb25zdCBibG9ja0xpbmVzID0gW107XG4gIHdoaWxlIChwb3NpdGlvbiA8IGJvZHlMZW5ndGgpIHtcbiAgICBjb25zdCBjb2RlID0gYm9keS5jaGFyQ29kZUF0KHBvc2l0aW9uKTtcbiAgICBpZiAoY29kZSA9PT0gMzQgJiYgYm9keS5jaGFyQ29kZUF0KHBvc2l0aW9uICsgMSkgPT09IDM0ICYmIGJvZHkuY2hhckNvZGVBdChwb3NpdGlvbiArIDIpID09PSAzNCkge1xuICAgICAgY3VycmVudExpbmUgKz0gYm9keS5zbGljZShjaHVua1N0YXJ0LCBwb3NpdGlvbik7XG4gICAgICBibG9ja0xpbmVzLnB1c2goY3VycmVudExpbmUpO1xuICAgICAgY29uc3QgdG9rZW4gPSBjcmVhdGVUb2tlbihcbiAgICAgICAgbGV4ZXIyLFxuICAgICAgICBUb2tlbktpbmQuQkxPQ0tfU1RSSU5HLFxuICAgICAgICBzdGFydCxcbiAgICAgICAgcG9zaXRpb24gKyAzLFxuICAgICAgICAvLyBSZXR1cm4gYSBzdHJpbmcgb2YgdGhlIGxpbmVzIGpvaW5lZCB3aXRoIFUrMDAwQS5cbiAgICAgICAgZGVkZW50QmxvY2tTdHJpbmdMaW5lcyhibG9ja0xpbmVzKS5qb2luKFwiXFxuXCIpXG4gICAgICApO1xuICAgICAgbGV4ZXIyLmxpbmUgKz0gYmxvY2tMaW5lcy5sZW5ndGggLSAxO1xuICAgICAgbGV4ZXIyLmxpbmVTdGFydCA9IGxpbmVTdGFydDtcbiAgICAgIHJldHVybiB0b2tlbjtcbiAgICB9XG4gICAgaWYgKGNvZGUgPT09IDkyICYmIGJvZHkuY2hhckNvZGVBdChwb3NpdGlvbiArIDEpID09PSAzNCAmJiBib2R5LmNoYXJDb2RlQXQocG9zaXRpb24gKyAyKSA9PT0gMzQgJiYgYm9keS5jaGFyQ29kZUF0KHBvc2l0aW9uICsgMykgPT09IDM0KSB7XG4gICAgICBjdXJyZW50TGluZSArPSBib2R5LnNsaWNlKGNodW5rU3RhcnQsIHBvc2l0aW9uKTtcbiAgICAgIGNodW5rU3RhcnQgPSBwb3NpdGlvbiArIDE7XG4gICAgICBwb3NpdGlvbiArPSA0O1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmIChjb2RlID09PSAxMCB8fCBjb2RlID09PSAxMykge1xuICAgICAgY3VycmVudExpbmUgKz0gYm9keS5zbGljZShjaHVua1N0YXJ0LCBwb3NpdGlvbik7XG4gICAgICBibG9ja0xpbmVzLnB1c2goY3VycmVudExpbmUpO1xuICAgICAgaWYgKGNvZGUgPT09IDEzICYmIGJvZHkuY2hhckNvZGVBdChwb3NpdGlvbiArIDEpID09PSAxMCkge1xuICAgICAgICBwb3NpdGlvbiArPSAyO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgKytwb3NpdGlvbjtcbiAgICAgIH1cbiAgICAgIGN1cnJlbnRMaW5lID0gXCJcIjtcbiAgICAgIGNodW5rU3RhcnQgPSBwb3NpdGlvbjtcbiAgICAgIGxpbmVTdGFydCA9IHBvc2l0aW9uO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmIChpc1VuaWNvZGVTY2FsYXJWYWx1ZShjb2RlKSkge1xuICAgICAgKytwb3NpdGlvbjtcbiAgICB9IGVsc2UgaWYgKGlzU3VwcGxlbWVudGFyeUNvZGVQb2ludChib2R5LCBwb3NpdGlvbikpIHtcbiAgICAgIHBvc2l0aW9uICs9IDI7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRocm93IHN5bnRheEVycm9yKFxuICAgICAgICBsZXhlcjIuc291cmNlLFxuICAgICAgICBwb3NpdGlvbixcbiAgICAgICAgYEludmFsaWQgY2hhcmFjdGVyIHdpdGhpbiBTdHJpbmc6ICR7cHJpbnRDb2RlUG9pbnRBdChcbiAgICAgICAgICBsZXhlcjIsXG4gICAgICAgICAgcG9zaXRpb25cbiAgICAgICAgKX0uYFxuICAgICAgKTtcbiAgICB9XG4gIH1cbiAgdGhyb3cgc3ludGF4RXJyb3IobGV4ZXIyLnNvdXJjZSwgcG9zaXRpb24sIFwiVW50ZXJtaW5hdGVkIHN0cmluZy5cIik7XG59XG5mdW5jdGlvbiByZWFkTmFtZShsZXhlcjIsIHN0YXJ0KSB7XG4gIGNvbnN0IGJvZHkgPSBsZXhlcjIuc291cmNlLmJvZHk7XG4gIGNvbnN0IGJvZHlMZW5ndGggPSBib2R5Lmxlbmd0aDtcbiAgbGV0IHBvc2l0aW9uID0gc3RhcnQgKyAxO1xuICB3aGlsZSAocG9zaXRpb24gPCBib2R5TGVuZ3RoKSB7XG4gICAgY29uc3QgY29kZSA9IGJvZHkuY2hhckNvZGVBdChwb3NpdGlvbik7XG4gICAgaWYgKGlzTmFtZUNvbnRpbnVlKGNvZGUpKSB7XG4gICAgICArK3Bvc2l0aW9uO1xuICAgIH0gZWxzZSB7XG4gICAgICBicmVhaztcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGNyZWF0ZVRva2VuKFxuICAgIGxleGVyMixcbiAgICBUb2tlbktpbmQuTkFNRSxcbiAgICBzdGFydCxcbiAgICBwb3NpdGlvbixcbiAgICBib2R5LnNsaWNlKHN0YXJ0LCBwb3NpdGlvbilcbiAgKTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL2pzdXRpbHMvaW5zcGVjdC5tanNcbnZhciBNQVhfQVJSQVlfTEVOR1RIID0gMTA7XG52YXIgTUFYX1JFQ1VSU0lWRV9ERVBUSCA9IDI7XG5mdW5jdGlvbiBpbnNwZWN0KHZhbHVlKSB7XG4gIHJldHVybiBmb3JtYXRWYWx1ZSh2YWx1ZSwgW10pO1xufVxuZnVuY3Rpb24gZm9ybWF0VmFsdWUodmFsdWUsIHNlZW5WYWx1ZXMpIHtcbiAgc3dpdGNoICh0eXBlb2YgdmFsdWUpIHtcbiAgICBjYXNlIFwic3RyaW5nXCI6XG4gICAgICByZXR1cm4gSlNPTi5zdHJpbmdpZnkodmFsdWUpO1xuICAgIGNhc2UgXCJmdW5jdGlvblwiOlxuICAgICAgcmV0dXJuIHZhbHVlLm5hbWUgPyBgW2Z1bmN0aW9uICR7dmFsdWUubmFtZX1dYCA6IFwiW2Z1bmN0aW9uXVwiO1xuICAgIGNhc2UgXCJvYmplY3RcIjpcbiAgICAgIHJldHVybiBmb3JtYXRPYmplY3RWYWx1ZSh2YWx1ZSwgc2VlblZhbHVlcyk7XG4gICAgZGVmYXVsdDpcbiAgICAgIHJldHVybiBTdHJpbmcodmFsdWUpO1xuICB9XG59XG5mdW5jdGlvbiBmb3JtYXRPYmplY3RWYWx1ZSh2YWx1ZSwgcHJldmlvdXNseVNlZW5WYWx1ZXMpIHtcbiAgaWYgKHZhbHVlID09PSBudWxsKSB7XG4gICAgcmV0dXJuIFwibnVsbFwiO1xuICB9XG4gIGlmIChwcmV2aW91c2x5U2VlblZhbHVlcy5pbmNsdWRlcyh2YWx1ZSkpIHtcbiAgICByZXR1cm4gXCJbQ2lyY3VsYXJdXCI7XG4gIH1cbiAgY29uc3Qgc2VlblZhbHVlcyA9IFsuLi5wcmV2aW91c2x5U2VlblZhbHVlcywgdmFsdWVdO1xuICBpZiAoaXNKU09OYWJsZSh2YWx1ZSkpIHtcbiAgICBjb25zdCBqc29uVmFsdWUgPSB2YWx1ZS50b0pTT04oKTtcbiAgICBpZiAoanNvblZhbHVlICE9PSB2YWx1ZSkge1xuICAgICAgcmV0dXJuIHR5cGVvZiBqc29uVmFsdWUgPT09IFwic3RyaW5nXCIgPyBqc29uVmFsdWUgOiBmb3JtYXRWYWx1ZShqc29uVmFsdWUsIHNlZW5WYWx1ZXMpO1xuICAgIH1cbiAgfSBlbHNlIGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSkge1xuICAgIHJldHVybiBmb3JtYXRBcnJheSh2YWx1ZSwgc2VlblZhbHVlcyk7XG4gIH1cbiAgcmV0dXJuIGZvcm1hdE9iamVjdCh2YWx1ZSwgc2VlblZhbHVlcyk7XG59XG5mdW5jdGlvbiBpc0pTT05hYmxlKHZhbHVlKSB7XG4gIHJldHVybiB0eXBlb2YgdmFsdWUudG9KU09OID09PSBcImZ1bmN0aW9uXCI7XG59XG5mdW5jdGlvbiBmb3JtYXRPYmplY3Qob2JqZWN0LCBzZWVuVmFsdWVzKSB7XG4gIGNvbnN0IGVudHJpZXMgPSBPYmplY3QuZW50cmllcyhvYmplY3QpO1xuICBpZiAoZW50cmllcy5sZW5ndGggPT09IDApIHtcbiAgICByZXR1cm4gXCJ7fVwiO1xuICB9XG4gIGlmIChzZWVuVmFsdWVzLmxlbmd0aCA+IE1BWF9SRUNVUlNJVkVfREVQVEgpIHtcbiAgICByZXR1cm4gXCJbXCIgKyBnZXRPYmplY3RUYWcob2JqZWN0KSArIFwiXVwiO1xuICB9XG4gIGNvbnN0IHByb3BlcnRpZXMgPSBlbnRyaWVzLm1hcChcbiAgICAoW2tleSwgdmFsdWVdKSA9PiBrZXkgKyBcIjogXCIgKyBmb3JtYXRWYWx1ZSh2YWx1ZSwgc2VlblZhbHVlcylcbiAgKTtcbiAgcmV0dXJuIFwieyBcIiArIHByb3BlcnRpZXMuam9pbihcIiwgXCIpICsgXCIgfVwiO1xufVxuZnVuY3Rpb24gZm9ybWF0QXJyYXkoYXJyYXksIHNlZW5WYWx1ZXMpIHtcbiAgaWYgKGFycmF5Lmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiBcIltdXCI7XG4gIH1cbiAgaWYgKHNlZW5WYWx1ZXMubGVuZ3RoID4gTUFYX1JFQ1VSU0lWRV9ERVBUSCkge1xuICAgIHJldHVybiBcIltBcnJheV1cIjtcbiAgfVxuICBjb25zdCBsZW4gPSBNYXRoLm1pbihNQVhfQVJSQVlfTEVOR1RILCBhcnJheS5sZW5ndGgpO1xuICBjb25zdCByZW1haW5pbmcgPSBhcnJheS5sZW5ndGggLSBsZW47XG4gIGNvbnN0IGl0ZW1zID0gW107XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgbGVuOyArK2kpIHtcbiAgICBpdGVtcy5wdXNoKGZvcm1hdFZhbHVlKGFycmF5W2ldLCBzZWVuVmFsdWVzKSk7XG4gIH1cbiAgaWYgKHJlbWFpbmluZyA9PT0gMSkge1xuICAgIGl0ZW1zLnB1c2goXCIuLi4gMSBtb3JlIGl0ZW1cIik7XG4gIH0gZWxzZSBpZiAocmVtYWluaW5nID4gMSkge1xuICAgIGl0ZW1zLnB1c2goYC4uLiAke3JlbWFpbmluZ30gbW9yZSBpdGVtc2ApO1xuICB9XG4gIHJldHVybiBcIltcIiArIGl0ZW1zLmpvaW4oXCIsIFwiKSArIFwiXVwiO1xufVxuZnVuY3Rpb24gZ2V0T2JqZWN0VGFnKG9iamVjdCkge1xuICBjb25zdCB0YWcgPSBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwob2JqZWN0KS5yZXBsYWNlKC9eXFxbb2JqZWN0IC8sIFwiXCIpLnJlcGxhY2UoL10kLywgXCJcIik7XG4gIGlmICh0YWcgPT09IFwiT2JqZWN0XCIgJiYgdHlwZW9mIG9iamVjdC5jb25zdHJ1Y3RvciA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgY29uc3QgbmFtZSA9IG9iamVjdC5jb25zdHJ1Y3Rvci5uYW1lO1xuICAgIGlmICh0eXBlb2YgbmFtZSA9PT0gXCJzdHJpbmdcIiAmJiBuYW1lICE9PSBcIlwiKSB7XG4gICAgICByZXR1cm4gbmFtZTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHRhZztcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL2pzdXRpbHMvaW5zdGFuY2VPZi5tanNcbnZhciBpbnN0YW5jZU9mID0gKFxuICAvKiBjOCBpZ25vcmUgbmV4dCA2ICovXG4gIC8vIEZJWE1FOiBodHRwczovL2dpdGh1Yi5jb20vZ3JhcGhxbC9ncmFwaHFsLWpzL2lzc3Vlcy8yMzE3XG4gIGdsb2JhbFRoaXMucHJvY2VzcyAmJiBnbG9iYWxUaGlzLnByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIiA/IGZ1bmN0aW9uIGluc3RhbmNlT2YyKHZhbHVlLCBjb25zdHJ1Y3Rvcikge1xuICAgIHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIGNvbnN0cnVjdG9yO1xuICB9IDogZnVuY3Rpb24gaW5zdGFuY2VPZjModmFsdWUsIGNvbnN0cnVjdG9yKSB7XG4gICAgaWYgKHZhbHVlIGluc3RhbmNlb2YgY29uc3RydWN0b3IpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIHZhbHVlID09PSBcIm9iamVjdFwiICYmIHZhbHVlICE9PSBudWxsKSB7XG4gICAgICB2YXIgX3ZhbHVlJGNvbnN0cnVjdG9yO1xuICAgICAgY29uc3QgY2xhc3NOYW1lID0gY29uc3RydWN0b3IucHJvdG90eXBlW1N5bWJvbC50b1N0cmluZ1RhZ107XG4gICAgICBjb25zdCB2YWx1ZUNsYXNzTmFtZSA9IChcbiAgICAgICAgLy8gV2Ugc3RpbGwgbmVlZCB0byBzdXBwb3J0IGNvbnN0cnVjdG9yJ3MgbmFtZSB0byBkZXRlY3QgY29uZmxpY3RzIHdpdGggb2xkZXIgdmVyc2lvbnMgb2YgdGhpcyBsaWJyYXJ5LlxuICAgICAgICBTeW1ib2wudG9TdHJpbmdUYWcgaW4gdmFsdWUgPyB2YWx1ZVtTeW1ib2wudG9TdHJpbmdUYWddIDogKF92YWx1ZSRjb25zdHJ1Y3RvciA9IHZhbHVlLmNvbnN0cnVjdG9yKSA9PT0gbnVsbCB8fCBfdmFsdWUkY29uc3RydWN0b3IgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF92YWx1ZSRjb25zdHJ1Y3Rvci5uYW1lXG4gICAgICApO1xuICAgICAgaWYgKGNsYXNzTmFtZSA9PT0gdmFsdWVDbGFzc05hbWUpIHtcbiAgICAgICAgY29uc3Qgc3RyaW5naWZpZWRWYWx1ZSA9IGluc3BlY3QodmFsdWUpO1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYENhbm5vdCB1c2UgJHtjbGFzc05hbWV9IFwiJHtzdHJpbmdpZmllZFZhbHVlfVwiIGZyb20gYW5vdGhlciBtb2R1bGUgb3IgcmVhbG0uXG5cbkVuc3VyZSB0aGF0IHRoZXJlIGlzIG9ubHkgb25lIGluc3RhbmNlIG9mIFwiZ3JhcGhxbFwiIGluIHRoZSBub2RlX21vZHVsZXNcbmRpcmVjdG9yeS4gSWYgZGlmZmVyZW50IHZlcnNpb25zIG9mIFwiZ3JhcGhxbFwiIGFyZSB0aGUgZGVwZW5kZW5jaWVzIG9mIG90aGVyXG5yZWxpZWQgb24gbW9kdWxlcywgdXNlIFwicmVzb2x1dGlvbnNcIiB0byBlbnN1cmUgb25seSBvbmUgdmVyc2lvbiBpcyBpbnN0YWxsZWQuXG5cbmh0dHBzOi8veWFybnBrZy5jb20vZW4vZG9jcy9zZWxlY3RpdmUtdmVyc2lvbi1yZXNvbHV0aW9uc1xuXG5EdXBsaWNhdGUgXCJncmFwaHFsXCIgbW9kdWxlcyBjYW5ub3QgYmUgdXNlZCBhdCB0aGUgc2FtZSB0aW1lIHNpbmNlIGRpZmZlcmVudFxudmVyc2lvbnMgbWF5IGhhdmUgZGlmZmVyZW50IGNhcGFiaWxpdGllcyBhbmQgYmVoYXZpb3IuIFRoZSBkYXRhIGZyb20gb25lXG52ZXJzaW9uIHVzZWQgaW4gdGhlIGZ1bmN0aW9uIGZyb20gYW5vdGhlciBjb3VsZCBwcm9kdWNlIGNvbmZ1c2luZyBhbmRcbnNwdXJpb3VzIHJlc3VsdHMuYCk7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuKTtcblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL2xhbmd1YWdlL3NvdXJjZS5tanNcbnZhciBTb3VyY2UgPSBjbGFzcyB7XG4gIGNvbnN0cnVjdG9yKGJvZHksIG5hbWUgPSBcIkdyYXBoUUwgcmVxdWVzdFwiLCBsb2NhdGlvbk9mZnNldCA9IHtcbiAgICBsaW5lOiAxLFxuICAgIGNvbHVtbjogMVxuICB9KSB7XG4gICAgdHlwZW9mIGJvZHkgPT09IFwic3RyaW5nXCIgfHwgZGV2QXNzZXJ0KGZhbHNlLCBgQm9keSBtdXN0IGJlIGEgc3RyaW5nLiBSZWNlaXZlZDogJHtpbnNwZWN0KGJvZHkpfS5gKTtcbiAgICB0aGlzLmJvZHkgPSBib2R5O1xuICAgIHRoaXMubmFtZSA9IG5hbWU7XG4gICAgdGhpcy5sb2NhdGlvbk9mZnNldCA9IGxvY2F0aW9uT2Zmc2V0O1xuICAgIHRoaXMubG9jYXRpb25PZmZzZXQubGluZSA+IDAgfHwgZGV2QXNzZXJ0KFxuICAgICAgZmFsc2UsXG4gICAgICBcImxpbmUgaW4gbG9jYXRpb25PZmZzZXQgaXMgMS1pbmRleGVkIGFuZCBtdXN0IGJlIHBvc2l0aXZlLlwiXG4gICAgKTtcbiAgICB0aGlzLmxvY2F0aW9uT2Zmc2V0LmNvbHVtbiA+IDAgfHwgZGV2QXNzZXJ0KFxuICAgICAgZmFsc2UsXG4gICAgICBcImNvbHVtbiBpbiBsb2NhdGlvbk9mZnNldCBpcyAxLWluZGV4ZWQgYW5kIG11c3QgYmUgcG9zaXRpdmUuXCJcbiAgICApO1xuICB9XG4gIGdldCBbU3ltYm9sLnRvU3RyaW5nVGFnXSgpIHtcbiAgICByZXR1cm4gXCJTb3VyY2VcIjtcbiAgfVxufTtcbmZ1bmN0aW9uIGlzU291cmNlKHNvdXJjZSkge1xuICByZXR1cm4gaW5zdGFuY2VPZihzb3VyY2UsIFNvdXJjZSk7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC9sYW5ndWFnZS9wYXJzZXIubWpzXG5mdW5jdGlvbiBwYXJzZTIoc291cmNlLCBvcHRpb25zKSB7XG4gIGNvbnN0IHBhcnNlciA9IG5ldyBQYXJzZXIoc291cmNlLCBvcHRpb25zKTtcbiAgcmV0dXJuIHBhcnNlci5wYXJzZURvY3VtZW50KCk7XG59XG52YXIgUGFyc2VyID0gY2xhc3Mge1xuICBjb25zdHJ1Y3Rvcihzb3VyY2UsIG9wdGlvbnMgPSB7fSkge1xuICAgIGNvbnN0IHNvdXJjZU9iaiA9IGlzU291cmNlKHNvdXJjZSkgPyBzb3VyY2UgOiBuZXcgU291cmNlKHNvdXJjZSk7XG4gICAgdGhpcy5fbGV4ZXIgPSBuZXcgTGV4ZXIoc291cmNlT2JqKTtcbiAgICB0aGlzLl9vcHRpb25zID0gb3B0aW9ucztcbiAgICB0aGlzLl90b2tlbkNvdW50ZXIgPSAwO1xuICB9XG4gIC8qKlxuICAgKiBDb252ZXJ0cyBhIG5hbWUgbGV4IHRva2VuIGludG8gYSBuYW1lIHBhcnNlIG5vZGUuXG4gICAqL1xuICBwYXJzZU5hbWUoKSB7XG4gICAgY29uc3QgdG9rZW4gPSB0aGlzLmV4cGVjdFRva2VuKFRva2VuS2luZC5OQU1FKTtcbiAgICByZXR1cm4gdGhpcy5ub2RlKHRva2VuLCB7XG4gICAgICBraW5kOiBLaW5kLk5BTUUsXG4gICAgICB2YWx1ZTogdG9rZW4udmFsdWVcbiAgICB9KTtcbiAgfVxuICAvLyBJbXBsZW1lbnRzIHRoZSBwYXJzaW5nIHJ1bGVzIGluIHRoZSBEb2N1bWVudCBzZWN0aW9uLlxuICAvKipcbiAgICogRG9jdW1lbnQgOiBEZWZpbml0aW9uK1xuICAgKi9cbiAgcGFyc2VEb2N1bWVudCgpIHtcbiAgICByZXR1cm4gdGhpcy5ub2RlKHRoaXMuX2xleGVyLnRva2VuLCB7XG4gICAgICBraW5kOiBLaW5kLkRPQ1VNRU5ULFxuICAgICAgZGVmaW5pdGlvbnM6IHRoaXMubWFueShcbiAgICAgICAgVG9rZW5LaW5kLlNPRixcbiAgICAgICAgdGhpcy5wYXJzZURlZmluaXRpb24sXG4gICAgICAgIFRva2VuS2luZC5FT0ZcbiAgICAgIClcbiAgICB9KTtcbiAgfVxuICAvKipcbiAgICogRGVmaW5pdGlvbiA6XG4gICAqICAgLSBFeGVjdXRhYmxlRGVmaW5pdGlvblxuICAgKiAgIC0gVHlwZVN5c3RlbURlZmluaXRpb25cbiAgICogICAtIFR5cGVTeXN0ZW1FeHRlbnNpb25cbiAgICpcbiAgICogRXhlY3V0YWJsZURlZmluaXRpb24gOlxuICAgKiAgIC0gT3BlcmF0aW9uRGVmaW5pdGlvblxuICAgKiAgIC0gRnJhZ21lbnREZWZpbml0aW9uXG4gICAqXG4gICAqIFR5cGVTeXN0ZW1EZWZpbml0aW9uIDpcbiAgICogICAtIFNjaGVtYURlZmluaXRpb25cbiAgICogICAtIFR5cGVEZWZpbml0aW9uXG4gICAqICAgLSBEaXJlY3RpdmVEZWZpbml0aW9uXG4gICAqXG4gICAqIFR5cGVEZWZpbml0aW9uIDpcbiAgICogICAtIFNjYWxhclR5cGVEZWZpbml0aW9uXG4gICAqICAgLSBPYmplY3RUeXBlRGVmaW5pdGlvblxuICAgKiAgIC0gSW50ZXJmYWNlVHlwZURlZmluaXRpb25cbiAgICogICAtIFVuaW9uVHlwZURlZmluaXRpb25cbiAgICogICAtIEVudW1UeXBlRGVmaW5pdGlvblxuICAgKiAgIC0gSW5wdXRPYmplY3RUeXBlRGVmaW5pdGlvblxuICAgKi9cbiAgcGFyc2VEZWZpbml0aW9uKCkge1xuICAgIGlmICh0aGlzLnBlZWsoVG9rZW5LaW5kLkJSQUNFX0wpKSB7XG4gICAgICByZXR1cm4gdGhpcy5wYXJzZU9wZXJhdGlvbkRlZmluaXRpb24oKTtcbiAgICB9XG4gICAgY29uc3QgaGFzRGVzY3JpcHRpb24gPSB0aGlzLnBlZWtEZXNjcmlwdGlvbigpO1xuICAgIGNvbnN0IGtleXdvcmRUb2tlbiA9IGhhc0Rlc2NyaXB0aW9uID8gdGhpcy5fbGV4ZXIubG9va2FoZWFkKCkgOiB0aGlzLl9sZXhlci50b2tlbjtcbiAgICBpZiAoa2V5d29yZFRva2VuLmtpbmQgPT09IFRva2VuS2luZC5OQU1FKSB7XG4gICAgICBzd2l0Y2ggKGtleXdvcmRUb2tlbi52YWx1ZSkge1xuICAgICAgICBjYXNlIFwic2NoZW1hXCI6XG4gICAgICAgICAgcmV0dXJuIHRoaXMucGFyc2VTY2hlbWFEZWZpbml0aW9uKCk7XG4gICAgICAgIGNhc2UgXCJzY2FsYXJcIjpcbiAgICAgICAgICByZXR1cm4gdGhpcy5wYXJzZVNjYWxhclR5cGVEZWZpbml0aW9uKCk7XG4gICAgICAgIGNhc2UgXCJ0eXBlXCI6XG4gICAgICAgICAgcmV0dXJuIHRoaXMucGFyc2VPYmplY3RUeXBlRGVmaW5pdGlvbigpO1xuICAgICAgICBjYXNlIFwiaW50ZXJmYWNlXCI6XG4gICAgICAgICAgcmV0dXJuIHRoaXMucGFyc2VJbnRlcmZhY2VUeXBlRGVmaW5pdGlvbigpO1xuICAgICAgICBjYXNlIFwidW5pb25cIjpcbiAgICAgICAgICByZXR1cm4gdGhpcy5wYXJzZVVuaW9uVHlwZURlZmluaXRpb24oKTtcbiAgICAgICAgY2FzZSBcImVudW1cIjpcbiAgICAgICAgICByZXR1cm4gdGhpcy5wYXJzZUVudW1UeXBlRGVmaW5pdGlvbigpO1xuICAgICAgICBjYXNlIFwiaW5wdXRcIjpcbiAgICAgICAgICByZXR1cm4gdGhpcy5wYXJzZUlucHV0T2JqZWN0VHlwZURlZmluaXRpb24oKTtcbiAgICAgICAgY2FzZSBcImRpcmVjdGl2ZVwiOlxuICAgICAgICAgIHJldHVybiB0aGlzLnBhcnNlRGlyZWN0aXZlRGVmaW5pdGlvbigpO1xuICAgICAgfVxuICAgICAgaWYgKGhhc0Rlc2NyaXB0aW9uKSB7XG4gICAgICAgIHRocm93IHN5bnRheEVycm9yKFxuICAgICAgICAgIHRoaXMuX2xleGVyLnNvdXJjZSxcbiAgICAgICAgICB0aGlzLl9sZXhlci50b2tlbi5zdGFydCxcbiAgICAgICAgICBcIlVuZXhwZWN0ZWQgZGVzY3JpcHRpb24sIGRlc2NyaXB0aW9ucyBhcmUgc3VwcG9ydGVkIG9ubHkgb24gdHlwZSBkZWZpbml0aW9ucy5cIlxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgc3dpdGNoIChrZXl3b3JkVG9rZW4udmFsdWUpIHtcbiAgICAgICAgY2FzZSBcInF1ZXJ5XCI6XG4gICAgICAgIGNhc2UgXCJtdXRhdGlvblwiOlxuICAgICAgICBjYXNlIFwic3Vic2NyaXB0aW9uXCI6XG4gICAgICAgICAgcmV0dXJuIHRoaXMucGFyc2VPcGVyYXRpb25EZWZpbml0aW9uKCk7XG4gICAgICAgIGNhc2UgXCJmcmFnbWVudFwiOlxuICAgICAgICAgIHJldHVybiB0aGlzLnBhcnNlRnJhZ21lbnREZWZpbml0aW9uKCk7XG4gICAgICAgIGNhc2UgXCJleHRlbmRcIjpcbiAgICAgICAgICByZXR1cm4gdGhpcy5wYXJzZVR5cGVTeXN0ZW1FeHRlbnNpb24oKTtcbiAgICAgIH1cbiAgICB9XG4gICAgdGhyb3cgdGhpcy51bmV4cGVjdGVkKGtleXdvcmRUb2tlbik7XG4gIH1cbiAgLy8gSW1wbGVtZW50cyB0aGUgcGFyc2luZyBydWxlcyBpbiB0aGUgT3BlcmF0aW9ucyBzZWN0aW9uLlxuICAvKipcbiAgICogT3BlcmF0aW9uRGVmaW5pdGlvbiA6XG4gICAqICAtIFNlbGVjdGlvblNldFxuICAgKiAgLSBPcGVyYXRpb25UeXBlIE5hbWU/IFZhcmlhYmxlRGVmaW5pdGlvbnM/IERpcmVjdGl2ZXM/IFNlbGVjdGlvblNldFxuICAgKi9cbiAgcGFyc2VPcGVyYXRpb25EZWZpbml0aW9uKCkge1xuICAgIGNvbnN0IHN0YXJ0ID0gdGhpcy5fbGV4ZXIudG9rZW47XG4gICAgaWYgKHRoaXMucGVlayhUb2tlbktpbmQuQlJBQ0VfTCkpIHtcbiAgICAgIHJldHVybiB0aGlzLm5vZGUoc3RhcnQsIHtcbiAgICAgICAga2luZDogS2luZC5PUEVSQVRJT05fREVGSU5JVElPTixcbiAgICAgICAgb3BlcmF0aW9uOiBPcGVyYXRpb25UeXBlTm9kZS5RVUVSWSxcbiAgICAgICAgbmFtZTogdm9pZCAwLFxuICAgICAgICB2YXJpYWJsZURlZmluaXRpb25zOiBbXSxcbiAgICAgICAgZGlyZWN0aXZlczogW10sXG4gICAgICAgIHNlbGVjdGlvblNldDogdGhpcy5wYXJzZVNlbGVjdGlvblNldCgpXG4gICAgICB9KTtcbiAgICB9XG4gICAgY29uc3Qgb3BlcmF0aW9uID0gdGhpcy5wYXJzZU9wZXJhdGlvblR5cGUoKTtcbiAgICBsZXQgbmFtZTtcbiAgICBpZiAodGhpcy5wZWVrKFRva2VuS2luZC5OQU1FKSkge1xuICAgICAgbmFtZSA9IHRoaXMucGFyc2VOYW1lKCk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLm5vZGUoc3RhcnQsIHtcbiAgICAgIGtpbmQ6IEtpbmQuT1BFUkFUSU9OX0RFRklOSVRJT04sXG4gICAgICBvcGVyYXRpb24sXG4gICAgICBuYW1lLFxuICAgICAgdmFyaWFibGVEZWZpbml0aW9uczogdGhpcy5wYXJzZVZhcmlhYmxlRGVmaW5pdGlvbnMoKSxcbiAgICAgIGRpcmVjdGl2ZXM6IHRoaXMucGFyc2VEaXJlY3RpdmVzKGZhbHNlKSxcbiAgICAgIHNlbGVjdGlvblNldDogdGhpcy5wYXJzZVNlbGVjdGlvblNldCgpXG4gICAgfSk7XG4gIH1cbiAgLyoqXG4gICAqIE9wZXJhdGlvblR5cGUgOiBvbmUgb2YgcXVlcnkgbXV0YXRpb24gc3Vic2NyaXB0aW9uXG4gICAqL1xuICBwYXJzZU9wZXJhdGlvblR5cGUoKSB7XG4gICAgY29uc3Qgb3BlcmF0aW9uVG9rZW4gPSB0aGlzLmV4cGVjdFRva2VuKFRva2VuS2luZC5OQU1FKTtcbiAgICBzd2l0Y2ggKG9wZXJhdGlvblRva2VuLnZhbHVlKSB7XG4gICAgICBjYXNlIFwicXVlcnlcIjpcbiAgICAgICAgcmV0dXJuIE9wZXJhdGlvblR5cGVOb2RlLlFVRVJZO1xuICAgICAgY2FzZSBcIm11dGF0aW9uXCI6XG4gICAgICAgIHJldHVybiBPcGVyYXRpb25UeXBlTm9kZS5NVVRBVElPTjtcbiAgICAgIGNhc2UgXCJzdWJzY3JpcHRpb25cIjpcbiAgICAgICAgcmV0dXJuIE9wZXJhdGlvblR5cGVOb2RlLlNVQlNDUklQVElPTjtcbiAgICB9XG4gICAgdGhyb3cgdGhpcy51bmV4cGVjdGVkKG9wZXJhdGlvblRva2VuKTtcbiAgfVxuICAvKipcbiAgICogVmFyaWFibGVEZWZpbml0aW9ucyA6ICggVmFyaWFibGVEZWZpbml0aW9uKyApXG4gICAqL1xuICBwYXJzZVZhcmlhYmxlRGVmaW5pdGlvbnMoKSB7XG4gICAgcmV0dXJuIHRoaXMub3B0aW9uYWxNYW55KFxuICAgICAgVG9rZW5LaW5kLlBBUkVOX0wsXG4gICAgICB0aGlzLnBhcnNlVmFyaWFibGVEZWZpbml0aW9uLFxuICAgICAgVG9rZW5LaW5kLlBBUkVOX1JcbiAgICApO1xuICB9XG4gIC8qKlxuICAgKiBWYXJpYWJsZURlZmluaXRpb24gOiBWYXJpYWJsZSA6IFR5cGUgRGVmYXVsdFZhbHVlPyBEaXJlY3RpdmVzW0NvbnN0XT9cbiAgICovXG4gIHBhcnNlVmFyaWFibGVEZWZpbml0aW9uKCkge1xuICAgIHJldHVybiB0aGlzLm5vZGUodGhpcy5fbGV4ZXIudG9rZW4sIHtcbiAgICAgIGtpbmQ6IEtpbmQuVkFSSUFCTEVfREVGSU5JVElPTixcbiAgICAgIHZhcmlhYmxlOiB0aGlzLnBhcnNlVmFyaWFibGUoKSxcbiAgICAgIHR5cGU6ICh0aGlzLmV4cGVjdFRva2VuKFRva2VuS2luZC5DT0xPTiksIHRoaXMucGFyc2VUeXBlUmVmZXJlbmNlKCkpLFxuICAgICAgZGVmYXVsdFZhbHVlOiB0aGlzLmV4cGVjdE9wdGlvbmFsVG9rZW4oVG9rZW5LaW5kLkVRVUFMUykgPyB0aGlzLnBhcnNlQ29uc3RWYWx1ZUxpdGVyYWwoKSA6IHZvaWQgMCxcbiAgICAgIGRpcmVjdGl2ZXM6IHRoaXMucGFyc2VDb25zdERpcmVjdGl2ZXMoKVxuICAgIH0pO1xuICB9XG4gIC8qKlxuICAgKiBWYXJpYWJsZSA6ICQgTmFtZVxuICAgKi9cbiAgcGFyc2VWYXJpYWJsZSgpIHtcbiAgICBjb25zdCBzdGFydCA9IHRoaXMuX2xleGVyLnRva2VuO1xuICAgIHRoaXMuZXhwZWN0VG9rZW4oVG9rZW5LaW5kLkRPTExBUik7XG4gICAgcmV0dXJuIHRoaXMubm9kZShzdGFydCwge1xuICAgICAga2luZDogS2luZC5WQVJJQUJMRSxcbiAgICAgIG5hbWU6IHRoaXMucGFyc2VOYW1lKClcbiAgICB9KTtcbiAgfVxuICAvKipcbiAgICogYGBgXG4gICAqIFNlbGVjdGlvblNldCA6IHsgU2VsZWN0aW9uKyB9XG4gICAqIGBgYFxuICAgKi9cbiAgcGFyc2VTZWxlY3Rpb25TZXQoKSB7XG4gICAgcmV0dXJuIHRoaXMubm9kZSh0aGlzLl9sZXhlci50b2tlbiwge1xuICAgICAga2luZDogS2luZC5TRUxFQ1RJT05fU0VULFxuICAgICAgc2VsZWN0aW9uczogdGhpcy5tYW55KFxuICAgICAgICBUb2tlbktpbmQuQlJBQ0VfTCxcbiAgICAgICAgdGhpcy5wYXJzZVNlbGVjdGlvbixcbiAgICAgICAgVG9rZW5LaW5kLkJSQUNFX1JcbiAgICAgIClcbiAgICB9KTtcbiAgfVxuICAvKipcbiAgICogU2VsZWN0aW9uIDpcbiAgICogICAtIEZpZWxkXG4gICAqICAgLSBGcmFnbWVudFNwcmVhZFxuICAgKiAgIC0gSW5saW5lRnJhZ21lbnRcbiAgICovXG4gIHBhcnNlU2VsZWN0aW9uKCkge1xuICAgIHJldHVybiB0aGlzLnBlZWsoVG9rZW5LaW5kLlNQUkVBRCkgPyB0aGlzLnBhcnNlRnJhZ21lbnQoKSA6IHRoaXMucGFyc2VGaWVsZCgpO1xuICB9XG4gIC8qKlxuICAgKiBGaWVsZCA6IEFsaWFzPyBOYW1lIEFyZ3VtZW50cz8gRGlyZWN0aXZlcz8gU2VsZWN0aW9uU2V0P1xuICAgKlxuICAgKiBBbGlhcyA6IE5hbWUgOlxuICAgKi9cbiAgcGFyc2VGaWVsZCgpIHtcbiAgICBjb25zdCBzdGFydCA9IHRoaXMuX2xleGVyLnRva2VuO1xuICAgIGNvbnN0IG5hbWVPckFsaWFzID0gdGhpcy5wYXJzZU5hbWUoKTtcbiAgICBsZXQgYWxpYXM7XG4gICAgbGV0IG5hbWU7XG4gICAgaWYgKHRoaXMuZXhwZWN0T3B0aW9uYWxUb2tlbihUb2tlbktpbmQuQ09MT04pKSB7XG4gICAgICBhbGlhcyA9IG5hbWVPckFsaWFzO1xuICAgICAgbmFtZSA9IHRoaXMucGFyc2VOYW1lKCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIG5hbWUgPSBuYW1lT3JBbGlhcztcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMubm9kZShzdGFydCwge1xuICAgICAga2luZDogS2luZC5GSUVMRCxcbiAgICAgIGFsaWFzLFxuICAgICAgbmFtZSxcbiAgICAgIGFyZ3VtZW50czogdGhpcy5wYXJzZUFyZ3VtZW50cyhmYWxzZSksXG4gICAgICBkaXJlY3RpdmVzOiB0aGlzLnBhcnNlRGlyZWN0aXZlcyhmYWxzZSksXG4gICAgICBzZWxlY3Rpb25TZXQ6IHRoaXMucGVlayhUb2tlbktpbmQuQlJBQ0VfTCkgPyB0aGlzLnBhcnNlU2VsZWN0aW9uU2V0KCkgOiB2b2lkIDBcbiAgICB9KTtcbiAgfVxuICAvKipcbiAgICogQXJndW1lbnRzW0NvbnN0XSA6ICggQXJndW1lbnRbP0NvbnN0XSsgKVxuICAgKi9cbiAgcGFyc2VBcmd1bWVudHMoaXNDb25zdCkge1xuICAgIGNvbnN0IGl0ZW0gPSBpc0NvbnN0ID8gdGhpcy5wYXJzZUNvbnN0QXJndW1lbnQgOiB0aGlzLnBhcnNlQXJndW1lbnQ7XG4gICAgcmV0dXJuIHRoaXMub3B0aW9uYWxNYW55KFRva2VuS2luZC5QQVJFTl9MLCBpdGVtLCBUb2tlbktpbmQuUEFSRU5fUik7XG4gIH1cbiAgLyoqXG4gICAqIEFyZ3VtZW50W0NvbnN0XSA6IE5hbWUgOiBWYWx1ZVs/Q29uc3RdXG4gICAqL1xuICBwYXJzZUFyZ3VtZW50KGlzQ29uc3QgPSBmYWxzZSkge1xuICAgIGNvbnN0IHN0YXJ0ID0gdGhpcy5fbGV4ZXIudG9rZW47XG4gICAgY29uc3QgbmFtZSA9IHRoaXMucGFyc2VOYW1lKCk7XG4gICAgdGhpcy5leHBlY3RUb2tlbihUb2tlbktpbmQuQ09MT04pO1xuICAgIHJldHVybiB0aGlzLm5vZGUoc3RhcnQsIHtcbiAgICAgIGtpbmQ6IEtpbmQuQVJHVU1FTlQsXG4gICAgICBuYW1lLFxuICAgICAgdmFsdWU6IHRoaXMucGFyc2VWYWx1ZUxpdGVyYWwoaXNDb25zdClcbiAgICB9KTtcbiAgfVxuICBwYXJzZUNvbnN0QXJndW1lbnQoKSB7XG4gICAgcmV0dXJuIHRoaXMucGFyc2VBcmd1bWVudCh0cnVlKTtcbiAgfVxuICAvLyBJbXBsZW1lbnRzIHRoZSBwYXJzaW5nIHJ1bGVzIGluIHRoZSBGcmFnbWVudHMgc2VjdGlvbi5cbiAgLyoqXG4gICAqIENvcnJlc3BvbmRzIHRvIGJvdGggRnJhZ21lbnRTcHJlYWQgYW5kIElubGluZUZyYWdtZW50IGluIHRoZSBzcGVjLlxuICAgKlxuICAgKiBGcmFnbWVudFNwcmVhZCA6IC4uLiBGcmFnbWVudE5hbWUgRGlyZWN0aXZlcz9cbiAgICpcbiAgICogSW5saW5lRnJhZ21lbnQgOiAuLi4gVHlwZUNvbmRpdGlvbj8gRGlyZWN0aXZlcz8gU2VsZWN0aW9uU2V0XG4gICAqL1xuICBwYXJzZUZyYWdtZW50KCkge1xuICAgIGNvbnN0IHN0YXJ0ID0gdGhpcy5fbGV4ZXIudG9rZW47XG4gICAgdGhpcy5leHBlY3RUb2tlbihUb2tlbktpbmQuU1BSRUFEKTtcbiAgICBjb25zdCBoYXNUeXBlQ29uZGl0aW9uID0gdGhpcy5leHBlY3RPcHRpb25hbEtleXdvcmQoXCJvblwiKTtcbiAgICBpZiAoIWhhc1R5cGVDb25kaXRpb24gJiYgdGhpcy5wZWVrKFRva2VuS2luZC5OQU1FKSkge1xuICAgICAgcmV0dXJuIHRoaXMubm9kZShzdGFydCwge1xuICAgICAgICBraW5kOiBLaW5kLkZSQUdNRU5UX1NQUkVBRCxcbiAgICAgICAgbmFtZTogdGhpcy5wYXJzZUZyYWdtZW50TmFtZSgpLFxuICAgICAgICBkaXJlY3RpdmVzOiB0aGlzLnBhcnNlRGlyZWN0aXZlcyhmYWxzZSlcbiAgICAgIH0pO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5ub2RlKHN0YXJ0LCB7XG4gICAgICBraW5kOiBLaW5kLklOTElORV9GUkFHTUVOVCxcbiAgICAgIHR5cGVDb25kaXRpb246IGhhc1R5cGVDb25kaXRpb24gPyB0aGlzLnBhcnNlTmFtZWRUeXBlKCkgOiB2b2lkIDAsXG4gICAgICBkaXJlY3RpdmVzOiB0aGlzLnBhcnNlRGlyZWN0aXZlcyhmYWxzZSksXG4gICAgICBzZWxlY3Rpb25TZXQ6IHRoaXMucGFyc2VTZWxlY3Rpb25TZXQoKVxuICAgIH0pO1xuICB9XG4gIC8qKlxuICAgKiBGcmFnbWVudERlZmluaXRpb24gOlxuICAgKiAgIC0gZnJhZ21lbnQgRnJhZ21lbnROYW1lIG9uIFR5cGVDb25kaXRpb24gRGlyZWN0aXZlcz8gU2VsZWN0aW9uU2V0XG4gICAqXG4gICAqIFR5cGVDb25kaXRpb24gOiBOYW1lZFR5cGVcbiAgICovXG4gIHBhcnNlRnJhZ21lbnREZWZpbml0aW9uKCkge1xuICAgIGNvbnN0IHN0YXJ0ID0gdGhpcy5fbGV4ZXIudG9rZW47XG4gICAgdGhpcy5leHBlY3RLZXl3b3JkKFwiZnJhZ21lbnRcIik7XG4gICAgaWYgKHRoaXMuX29wdGlvbnMuYWxsb3dMZWdhY3lGcmFnbWVudFZhcmlhYmxlcyA9PT0gdHJ1ZSkge1xuICAgICAgcmV0dXJuIHRoaXMubm9kZShzdGFydCwge1xuICAgICAgICBraW5kOiBLaW5kLkZSQUdNRU5UX0RFRklOSVRJT04sXG4gICAgICAgIG5hbWU6IHRoaXMucGFyc2VGcmFnbWVudE5hbWUoKSxcbiAgICAgICAgdmFyaWFibGVEZWZpbml0aW9uczogdGhpcy5wYXJzZVZhcmlhYmxlRGVmaW5pdGlvbnMoKSxcbiAgICAgICAgdHlwZUNvbmRpdGlvbjogKHRoaXMuZXhwZWN0S2V5d29yZChcIm9uXCIpLCB0aGlzLnBhcnNlTmFtZWRUeXBlKCkpLFxuICAgICAgICBkaXJlY3RpdmVzOiB0aGlzLnBhcnNlRGlyZWN0aXZlcyhmYWxzZSksXG4gICAgICAgIHNlbGVjdGlvblNldDogdGhpcy5wYXJzZVNlbGVjdGlvblNldCgpXG4gICAgICB9KTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMubm9kZShzdGFydCwge1xuICAgICAga2luZDogS2luZC5GUkFHTUVOVF9ERUZJTklUSU9OLFxuICAgICAgbmFtZTogdGhpcy5wYXJzZUZyYWdtZW50TmFtZSgpLFxuICAgICAgdHlwZUNvbmRpdGlvbjogKHRoaXMuZXhwZWN0S2V5d29yZChcIm9uXCIpLCB0aGlzLnBhcnNlTmFtZWRUeXBlKCkpLFxuICAgICAgZGlyZWN0aXZlczogdGhpcy5wYXJzZURpcmVjdGl2ZXMoZmFsc2UpLFxuICAgICAgc2VsZWN0aW9uU2V0OiB0aGlzLnBhcnNlU2VsZWN0aW9uU2V0KClcbiAgICB9KTtcbiAgfVxuICAvKipcbiAgICogRnJhZ21lbnROYW1lIDogTmFtZSBidXQgbm90IGBvbmBcbiAgICovXG4gIHBhcnNlRnJhZ21lbnROYW1lKCkge1xuICAgIGlmICh0aGlzLl9sZXhlci50b2tlbi52YWx1ZSA9PT0gXCJvblwiKSB7XG4gICAgICB0aHJvdyB0aGlzLnVuZXhwZWN0ZWQoKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMucGFyc2VOYW1lKCk7XG4gIH1cbiAgLy8gSW1wbGVtZW50cyB0aGUgcGFyc2luZyBydWxlcyBpbiB0aGUgVmFsdWVzIHNlY3Rpb24uXG4gIC8qKlxuICAgKiBWYWx1ZVtDb25zdF0gOlxuICAgKiAgIC0gW35Db25zdF0gVmFyaWFibGVcbiAgICogICAtIEludFZhbHVlXG4gICAqICAgLSBGbG9hdFZhbHVlXG4gICAqICAgLSBTdHJpbmdWYWx1ZVxuICAgKiAgIC0gQm9vbGVhblZhbHVlXG4gICAqICAgLSBOdWxsVmFsdWVcbiAgICogICAtIEVudW1WYWx1ZVxuICAgKiAgIC0gTGlzdFZhbHVlWz9Db25zdF1cbiAgICogICAtIE9iamVjdFZhbHVlWz9Db25zdF1cbiAgICpcbiAgICogQm9vbGVhblZhbHVlIDogb25lIG9mIGB0cnVlYCBgZmFsc2VgXG4gICAqXG4gICAqIE51bGxWYWx1ZSA6IGBudWxsYFxuICAgKlxuICAgKiBFbnVtVmFsdWUgOiBOYW1lIGJ1dCBub3QgYHRydWVgLCBgZmFsc2VgIG9yIGBudWxsYFxuICAgKi9cbiAgcGFyc2VWYWx1ZUxpdGVyYWwoaXNDb25zdCkge1xuICAgIGNvbnN0IHRva2VuID0gdGhpcy5fbGV4ZXIudG9rZW47XG4gICAgc3dpdGNoICh0b2tlbi5raW5kKSB7XG4gICAgICBjYXNlIFRva2VuS2luZC5CUkFDS0VUX0w6XG4gICAgICAgIHJldHVybiB0aGlzLnBhcnNlTGlzdChpc0NvbnN0KTtcbiAgICAgIGNhc2UgVG9rZW5LaW5kLkJSQUNFX0w6XG4gICAgICAgIHJldHVybiB0aGlzLnBhcnNlT2JqZWN0KGlzQ29uc3QpO1xuICAgICAgY2FzZSBUb2tlbktpbmQuSU5UOlxuICAgICAgICB0aGlzLmFkdmFuY2VMZXhlcigpO1xuICAgICAgICByZXR1cm4gdGhpcy5ub2RlKHRva2VuLCB7XG4gICAgICAgICAga2luZDogS2luZC5JTlQsXG4gICAgICAgICAgdmFsdWU6IHRva2VuLnZhbHVlXG4gICAgICAgIH0pO1xuICAgICAgY2FzZSBUb2tlbktpbmQuRkxPQVQ6XG4gICAgICAgIHRoaXMuYWR2YW5jZUxleGVyKCk7XG4gICAgICAgIHJldHVybiB0aGlzLm5vZGUodG9rZW4sIHtcbiAgICAgICAgICBraW5kOiBLaW5kLkZMT0FULFxuICAgICAgICAgIHZhbHVlOiB0b2tlbi52YWx1ZVxuICAgICAgICB9KTtcbiAgICAgIGNhc2UgVG9rZW5LaW5kLlNUUklORzpcbiAgICAgIGNhc2UgVG9rZW5LaW5kLkJMT0NLX1NUUklORzpcbiAgICAgICAgcmV0dXJuIHRoaXMucGFyc2VTdHJpbmdMaXRlcmFsKCk7XG4gICAgICBjYXNlIFRva2VuS2luZC5OQU1FOlxuICAgICAgICB0aGlzLmFkdmFuY2VMZXhlcigpO1xuICAgICAgICBzd2l0Y2ggKHRva2VuLnZhbHVlKSB7XG4gICAgICAgICAgY2FzZSBcInRydWVcIjpcbiAgICAgICAgICAgIHJldHVybiB0aGlzLm5vZGUodG9rZW4sIHtcbiAgICAgICAgICAgICAga2luZDogS2luZC5CT09MRUFOLFxuICAgICAgICAgICAgICB2YWx1ZTogdHJ1ZVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgY2FzZSBcImZhbHNlXCI6XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5ub2RlKHRva2VuLCB7XG4gICAgICAgICAgICAgIGtpbmQ6IEtpbmQuQk9PTEVBTixcbiAgICAgICAgICAgICAgdmFsdWU6IGZhbHNlXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICBjYXNlIFwibnVsbFwiOlxuICAgICAgICAgICAgcmV0dXJuIHRoaXMubm9kZSh0b2tlbiwge1xuICAgICAgICAgICAgICBraW5kOiBLaW5kLk5VTExcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5ub2RlKHRva2VuLCB7XG4gICAgICAgICAgICAgIGtpbmQ6IEtpbmQuRU5VTSxcbiAgICAgICAgICAgICAgdmFsdWU6IHRva2VuLnZhbHVlXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgY2FzZSBUb2tlbktpbmQuRE9MTEFSOlxuICAgICAgICBpZiAoaXNDb25zdCkge1xuICAgICAgICAgIHRoaXMuZXhwZWN0VG9rZW4oVG9rZW5LaW5kLkRPTExBUik7XG4gICAgICAgICAgaWYgKHRoaXMuX2xleGVyLnRva2VuLmtpbmQgPT09IFRva2VuS2luZC5OQU1FKSB7XG4gICAgICAgICAgICBjb25zdCB2YXJOYW1lID0gdGhpcy5fbGV4ZXIudG9rZW4udmFsdWU7XG4gICAgICAgICAgICB0aHJvdyBzeW50YXhFcnJvcihcbiAgICAgICAgICAgICAgdGhpcy5fbGV4ZXIuc291cmNlLFxuICAgICAgICAgICAgICB0b2tlbi5zdGFydCxcbiAgICAgICAgICAgICAgYFVuZXhwZWN0ZWQgdmFyaWFibGUgXCIkJHt2YXJOYW1lfVwiIGluIGNvbnN0YW50IHZhbHVlLmBcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRocm93IHRoaXMudW5leHBlY3RlZCh0b2tlbik7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLnBhcnNlVmFyaWFibGUoKTtcbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIHRocm93IHRoaXMudW5leHBlY3RlZCgpO1xuICAgIH1cbiAgfVxuICBwYXJzZUNvbnN0VmFsdWVMaXRlcmFsKCkge1xuICAgIHJldHVybiB0aGlzLnBhcnNlVmFsdWVMaXRlcmFsKHRydWUpO1xuICB9XG4gIHBhcnNlU3RyaW5nTGl0ZXJhbCgpIHtcbiAgICBjb25zdCB0b2tlbiA9IHRoaXMuX2xleGVyLnRva2VuO1xuICAgIHRoaXMuYWR2YW5jZUxleGVyKCk7XG4gICAgcmV0dXJuIHRoaXMubm9kZSh0b2tlbiwge1xuICAgICAga2luZDogS2luZC5TVFJJTkcsXG4gICAgICB2YWx1ZTogdG9rZW4udmFsdWUsXG4gICAgICBibG9jazogdG9rZW4ua2luZCA9PT0gVG9rZW5LaW5kLkJMT0NLX1NUUklOR1xuICAgIH0pO1xuICB9XG4gIC8qKlxuICAgKiBMaXN0VmFsdWVbQ29uc3RdIDpcbiAgICogICAtIFsgXVxuICAgKiAgIC0gWyBWYWx1ZVs/Q29uc3RdKyBdXG4gICAqL1xuICBwYXJzZUxpc3QoaXNDb25zdCkge1xuICAgIGNvbnN0IGl0ZW0gPSAoKSA9PiB0aGlzLnBhcnNlVmFsdWVMaXRlcmFsKGlzQ29uc3QpO1xuICAgIHJldHVybiB0aGlzLm5vZGUodGhpcy5fbGV4ZXIudG9rZW4sIHtcbiAgICAgIGtpbmQ6IEtpbmQuTElTVCxcbiAgICAgIHZhbHVlczogdGhpcy5hbnkoVG9rZW5LaW5kLkJSQUNLRVRfTCwgaXRlbSwgVG9rZW5LaW5kLkJSQUNLRVRfUilcbiAgICB9KTtcbiAgfVxuICAvKipcbiAgICogYGBgXG4gICAqIE9iamVjdFZhbHVlW0NvbnN0XSA6XG4gICAqICAgLSB7IH1cbiAgICogICAtIHsgT2JqZWN0RmllbGRbP0NvbnN0XSsgfVxuICAgKiBgYGBcbiAgICovXG4gIHBhcnNlT2JqZWN0KGlzQ29uc3QpIHtcbiAgICBjb25zdCBpdGVtID0gKCkgPT4gdGhpcy5wYXJzZU9iamVjdEZpZWxkKGlzQ29uc3QpO1xuICAgIHJldHVybiB0aGlzLm5vZGUodGhpcy5fbGV4ZXIudG9rZW4sIHtcbiAgICAgIGtpbmQ6IEtpbmQuT0JKRUNULFxuICAgICAgZmllbGRzOiB0aGlzLmFueShUb2tlbktpbmQuQlJBQ0VfTCwgaXRlbSwgVG9rZW5LaW5kLkJSQUNFX1IpXG4gICAgfSk7XG4gIH1cbiAgLyoqXG4gICAqIE9iamVjdEZpZWxkW0NvbnN0XSA6IE5hbWUgOiBWYWx1ZVs/Q29uc3RdXG4gICAqL1xuICBwYXJzZU9iamVjdEZpZWxkKGlzQ29uc3QpIHtcbiAgICBjb25zdCBzdGFydCA9IHRoaXMuX2xleGVyLnRva2VuO1xuICAgIGNvbnN0IG5hbWUgPSB0aGlzLnBhcnNlTmFtZSgpO1xuICAgIHRoaXMuZXhwZWN0VG9rZW4oVG9rZW5LaW5kLkNPTE9OKTtcbiAgICByZXR1cm4gdGhpcy5ub2RlKHN0YXJ0LCB7XG4gICAgICBraW5kOiBLaW5kLk9CSkVDVF9GSUVMRCxcbiAgICAgIG5hbWUsXG4gICAgICB2YWx1ZTogdGhpcy5wYXJzZVZhbHVlTGl0ZXJhbChpc0NvbnN0KVxuICAgIH0pO1xuICB9XG4gIC8vIEltcGxlbWVudHMgdGhlIHBhcnNpbmcgcnVsZXMgaW4gdGhlIERpcmVjdGl2ZXMgc2VjdGlvbi5cbiAgLyoqXG4gICAqIERpcmVjdGl2ZXNbQ29uc3RdIDogRGlyZWN0aXZlWz9Db25zdF0rXG4gICAqL1xuICBwYXJzZURpcmVjdGl2ZXMoaXNDb25zdCkge1xuICAgIGNvbnN0IGRpcmVjdGl2ZXMgPSBbXTtcbiAgICB3aGlsZSAodGhpcy5wZWVrKFRva2VuS2luZC5BVCkpIHtcbiAgICAgIGRpcmVjdGl2ZXMucHVzaCh0aGlzLnBhcnNlRGlyZWN0aXZlKGlzQ29uc3QpKTtcbiAgICB9XG4gICAgcmV0dXJuIGRpcmVjdGl2ZXM7XG4gIH1cbiAgcGFyc2VDb25zdERpcmVjdGl2ZXMoKSB7XG4gICAgcmV0dXJuIHRoaXMucGFyc2VEaXJlY3RpdmVzKHRydWUpO1xuICB9XG4gIC8qKlxuICAgKiBgYGBcbiAgICogRGlyZWN0aXZlW0NvbnN0XSA6IEAgTmFtZSBBcmd1bWVudHNbP0NvbnN0XT9cbiAgICogYGBgXG4gICAqL1xuICBwYXJzZURpcmVjdGl2ZShpc0NvbnN0KSB7XG4gICAgY29uc3Qgc3RhcnQgPSB0aGlzLl9sZXhlci50b2tlbjtcbiAgICB0aGlzLmV4cGVjdFRva2VuKFRva2VuS2luZC5BVCk7XG4gICAgcmV0dXJuIHRoaXMubm9kZShzdGFydCwge1xuICAgICAga2luZDogS2luZC5ESVJFQ1RJVkUsXG4gICAgICBuYW1lOiB0aGlzLnBhcnNlTmFtZSgpLFxuICAgICAgYXJndW1lbnRzOiB0aGlzLnBhcnNlQXJndW1lbnRzKGlzQ29uc3QpXG4gICAgfSk7XG4gIH1cbiAgLy8gSW1wbGVtZW50cyB0aGUgcGFyc2luZyBydWxlcyBpbiB0aGUgVHlwZXMgc2VjdGlvbi5cbiAgLyoqXG4gICAqIFR5cGUgOlxuICAgKiAgIC0gTmFtZWRUeXBlXG4gICAqICAgLSBMaXN0VHlwZVxuICAgKiAgIC0gTm9uTnVsbFR5cGVcbiAgICovXG4gIHBhcnNlVHlwZVJlZmVyZW5jZSgpIHtcbiAgICBjb25zdCBzdGFydCA9IHRoaXMuX2xleGVyLnRva2VuO1xuICAgIGxldCB0eXBlO1xuICAgIGlmICh0aGlzLmV4cGVjdE9wdGlvbmFsVG9rZW4oVG9rZW5LaW5kLkJSQUNLRVRfTCkpIHtcbiAgICAgIGNvbnN0IGlubmVyVHlwZSA9IHRoaXMucGFyc2VUeXBlUmVmZXJlbmNlKCk7XG4gICAgICB0aGlzLmV4cGVjdFRva2VuKFRva2VuS2luZC5CUkFDS0VUX1IpO1xuICAgICAgdHlwZSA9IHRoaXMubm9kZShzdGFydCwge1xuICAgICAgICBraW5kOiBLaW5kLkxJU1RfVFlQRSxcbiAgICAgICAgdHlwZTogaW5uZXJUeXBlXG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgdHlwZSA9IHRoaXMucGFyc2VOYW1lZFR5cGUoKTtcbiAgICB9XG4gICAgaWYgKHRoaXMuZXhwZWN0T3B0aW9uYWxUb2tlbihUb2tlbktpbmQuQkFORykpIHtcbiAgICAgIHJldHVybiB0aGlzLm5vZGUoc3RhcnQsIHtcbiAgICAgICAga2luZDogS2luZC5OT05fTlVMTF9UWVBFLFxuICAgICAgICB0eXBlXG4gICAgICB9KTtcbiAgICB9XG4gICAgcmV0dXJuIHR5cGU7XG4gIH1cbiAgLyoqXG4gICAqIE5hbWVkVHlwZSA6IE5hbWVcbiAgICovXG4gIHBhcnNlTmFtZWRUeXBlKCkge1xuICAgIHJldHVybiB0aGlzLm5vZGUodGhpcy5fbGV4ZXIudG9rZW4sIHtcbiAgICAgIGtpbmQ6IEtpbmQuTkFNRURfVFlQRSxcbiAgICAgIG5hbWU6IHRoaXMucGFyc2VOYW1lKClcbiAgICB9KTtcbiAgfVxuICAvLyBJbXBsZW1lbnRzIHRoZSBwYXJzaW5nIHJ1bGVzIGluIHRoZSBUeXBlIERlZmluaXRpb24gc2VjdGlvbi5cbiAgcGVla0Rlc2NyaXB0aW9uKCkge1xuICAgIHJldHVybiB0aGlzLnBlZWsoVG9rZW5LaW5kLlNUUklORykgfHwgdGhpcy5wZWVrKFRva2VuS2luZC5CTE9DS19TVFJJTkcpO1xuICB9XG4gIC8qKlxuICAgKiBEZXNjcmlwdGlvbiA6IFN0cmluZ1ZhbHVlXG4gICAqL1xuICBwYXJzZURlc2NyaXB0aW9uKCkge1xuICAgIGlmICh0aGlzLnBlZWtEZXNjcmlwdGlvbigpKSB7XG4gICAgICByZXR1cm4gdGhpcy5wYXJzZVN0cmluZ0xpdGVyYWwoKTtcbiAgICB9XG4gIH1cbiAgLyoqXG4gICAqIGBgYFxuICAgKiBTY2hlbWFEZWZpbml0aW9uIDogRGVzY3JpcHRpb24/IHNjaGVtYSBEaXJlY3RpdmVzW0NvbnN0XT8geyBPcGVyYXRpb25UeXBlRGVmaW5pdGlvbisgfVxuICAgKiBgYGBcbiAgICovXG4gIHBhcnNlU2NoZW1hRGVmaW5pdGlvbigpIHtcbiAgICBjb25zdCBzdGFydCA9IHRoaXMuX2xleGVyLnRva2VuO1xuICAgIGNvbnN0IGRlc2NyaXB0aW9uID0gdGhpcy5wYXJzZURlc2NyaXB0aW9uKCk7XG4gICAgdGhpcy5leHBlY3RLZXl3b3JkKFwic2NoZW1hXCIpO1xuICAgIGNvbnN0IGRpcmVjdGl2ZXMgPSB0aGlzLnBhcnNlQ29uc3REaXJlY3RpdmVzKCk7XG4gICAgY29uc3Qgb3BlcmF0aW9uVHlwZXMgPSB0aGlzLm1hbnkoXG4gICAgICBUb2tlbktpbmQuQlJBQ0VfTCxcbiAgICAgIHRoaXMucGFyc2VPcGVyYXRpb25UeXBlRGVmaW5pdGlvbixcbiAgICAgIFRva2VuS2luZC5CUkFDRV9SXG4gICAgKTtcbiAgICByZXR1cm4gdGhpcy5ub2RlKHN0YXJ0LCB7XG4gICAgICBraW5kOiBLaW5kLlNDSEVNQV9ERUZJTklUSU9OLFxuICAgICAgZGVzY3JpcHRpb24sXG4gICAgICBkaXJlY3RpdmVzLFxuICAgICAgb3BlcmF0aW9uVHlwZXNcbiAgICB9KTtcbiAgfVxuICAvKipcbiAgICogT3BlcmF0aW9uVHlwZURlZmluaXRpb24gOiBPcGVyYXRpb25UeXBlIDogTmFtZWRUeXBlXG4gICAqL1xuICBwYXJzZU9wZXJhdGlvblR5cGVEZWZpbml0aW9uKCkge1xuICAgIGNvbnN0IHN0YXJ0ID0gdGhpcy5fbGV4ZXIudG9rZW47XG4gICAgY29uc3Qgb3BlcmF0aW9uID0gdGhpcy5wYXJzZU9wZXJhdGlvblR5cGUoKTtcbiAgICB0aGlzLmV4cGVjdFRva2VuKFRva2VuS2luZC5DT0xPTik7XG4gICAgY29uc3QgdHlwZSA9IHRoaXMucGFyc2VOYW1lZFR5cGUoKTtcbiAgICByZXR1cm4gdGhpcy5ub2RlKHN0YXJ0LCB7XG4gICAgICBraW5kOiBLaW5kLk9QRVJBVElPTl9UWVBFX0RFRklOSVRJT04sXG4gICAgICBvcGVyYXRpb24sXG4gICAgICB0eXBlXG4gICAgfSk7XG4gIH1cbiAgLyoqXG4gICAqIFNjYWxhclR5cGVEZWZpbml0aW9uIDogRGVzY3JpcHRpb24/IHNjYWxhciBOYW1lIERpcmVjdGl2ZXNbQ29uc3RdP1xuICAgKi9cbiAgcGFyc2VTY2FsYXJUeXBlRGVmaW5pdGlvbigpIHtcbiAgICBjb25zdCBzdGFydCA9IHRoaXMuX2xleGVyLnRva2VuO1xuICAgIGNvbnN0IGRlc2NyaXB0aW9uID0gdGhpcy5wYXJzZURlc2NyaXB0aW9uKCk7XG4gICAgdGhpcy5leHBlY3RLZXl3b3JkKFwic2NhbGFyXCIpO1xuICAgIGNvbnN0IG5hbWUgPSB0aGlzLnBhcnNlTmFtZSgpO1xuICAgIGNvbnN0IGRpcmVjdGl2ZXMgPSB0aGlzLnBhcnNlQ29uc3REaXJlY3RpdmVzKCk7XG4gICAgcmV0dXJuIHRoaXMubm9kZShzdGFydCwge1xuICAgICAga2luZDogS2luZC5TQ0FMQVJfVFlQRV9ERUZJTklUSU9OLFxuICAgICAgZGVzY3JpcHRpb24sXG4gICAgICBuYW1lLFxuICAgICAgZGlyZWN0aXZlc1xuICAgIH0pO1xuICB9XG4gIC8qKlxuICAgKiBPYmplY3RUeXBlRGVmaW5pdGlvbiA6XG4gICAqICAgRGVzY3JpcHRpb24/XG4gICAqICAgdHlwZSBOYW1lIEltcGxlbWVudHNJbnRlcmZhY2VzPyBEaXJlY3RpdmVzW0NvbnN0XT8gRmllbGRzRGVmaW5pdGlvbj9cbiAgICovXG4gIHBhcnNlT2JqZWN0VHlwZURlZmluaXRpb24oKSB7XG4gICAgY29uc3Qgc3RhcnQgPSB0aGlzLl9sZXhlci50b2tlbjtcbiAgICBjb25zdCBkZXNjcmlwdGlvbiA9IHRoaXMucGFyc2VEZXNjcmlwdGlvbigpO1xuICAgIHRoaXMuZXhwZWN0S2V5d29yZChcInR5cGVcIik7XG4gICAgY29uc3QgbmFtZSA9IHRoaXMucGFyc2VOYW1lKCk7XG4gICAgY29uc3QgaW50ZXJmYWNlcyA9IHRoaXMucGFyc2VJbXBsZW1lbnRzSW50ZXJmYWNlcygpO1xuICAgIGNvbnN0IGRpcmVjdGl2ZXMgPSB0aGlzLnBhcnNlQ29uc3REaXJlY3RpdmVzKCk7XG4gICAgY29uc3QgZmllbGRzID0gdGhpcy5wYXJzZUZpZWxkc0RlZmluaXRpb24oKTtcbiAgICByZXR1cm4gdGhpcy5ub2RlKHN0YXJ0LCB7XG4gICAgICBraW5kOiBLaW5kLk9CSkVDVF9UWVBFX0RFRklOSVRJT04sXG4gICAgICBkZXNjcmlwdGlvbixcbiAgICAgIG5hbWUsXG4gICAgICBpbnRlcmZhY2VzLFxuICAgICAgZGlyZWN0aXZlcyxcbiAgICAgIGZpZWxkc1xuICAgIH0pO1xuICB9XG4gIC8qKlxuICAgKiBJbXBsZW1lbnRzSW50ZXJmYWNlcyA6XG4gICAqICAgLSBpbXBsZW1lbnRzIGAmYD8gTmFtZWRUeXBlXG4gICAqICAgLSBJbXBsZW1lbnRzSW50ZXJmYWNlcyAmIE5hbWVkVHlwZVxuICAgKi9cbiAgcGFyc2VJbXBsZW1lbnRzSW50ZXJmYWNlcygpIHtcbiAgICByZXR1cm4gdGhpcy5leHBlY3RPcHRpb25hbEtleXdvcmQoXCJpbXBsZW1lbnRzXCIpID8gdGhpcy5kZWxpbWl0ZWRNYW55KFRva2VuS2luZC5BTVAsIHRoaXMucGFyc2VOYW1lZFR5cGUpIDogW107XG4gIH1cbiAgLyoqXG4gICAqIGBgYFxuICAgKiBGaWVsZHNEZWZpbml0aW9uIDogeyBGaWVsZERlZmluaXRpb24rIH1cbiAgICogYGBgXG4gICAqL1xuICBwYXJzZUZpZWxkc0RlZmluaXRpb24oKSB7XG4gICAgcmV0dXJuIHRoaXMub3B0aW9uYWxNYW55KFxuICAgICAgVG9rZW5LaW5kLkJSQUNFX0wsXG4gICAgICB0aGlzLnBhcnNlRmllbGREZWZpbml0aW9uLFxuICAgICAgVG9rZW5LaW5kLkJSQUNFX1JcbiAgICApO1xuICB9XG4gIC8qKlxuICAgKiBGaWVsZERlZmluaXRpb24gOlxuICAgKiAgIC0gRGVzY3JpcHRpb24/IE5hbWUgQXJndW1lbnRzRGVmaW5pdGlvbj8gOiBUeXBlIERpcmVjdGl2ZXNbQ29uc3RdP1xuICAgKi9cbiAgcGFyc2VGaWVsZERlZmluaXRpb24oKSB7XG4gICAgY29uc3Qgc3RhcnQgPSB0aGlzLl9sZXhlci50b2tlbjtcbiAgICBjb25zdCBkZXNjcmlwdGlvbiA9IHRoaXMucGFyc2VEZXNjcmlwdGlvbigpO1xuICAgIGNvbnN0IG5hbWUgPSB0aGlzLnBhcnNlTmFtZSgpO1xuICAgIGNvbnN0IGFyZ3MgPSB0aGlzLnBhcnNlQXJndW1lbnREZWZzKCk7XG4gICAgdGhpcy5leHBlY3RUb2tlbihUb2tlbktpbmQuQ09MT04pO1xuICAgIGNvbnN0IHR5cGUgPSB0aGlzLnBhcnNlVHlwZVJlZmVyZW5jZSgpO1xuICAgIGNvbnN0IGRpcmVjdGl2ZXMgPSB0aGlzLnBhcnNlQ29uc3REaXJlY3RpdmVzKCk7XG4gICAgcmV0dXJuIHRoaXMubm9kZShzdGFydCwge1xuICAgICAga2luZDogS2luZC5GSUVMRF9ERUZJTklUSU9OLFxuICAgICAgZGVzY3JpcHRpb24sXG4gICAgICBuYW1lLFxuICAgICAgYXJndW1lbnRzOiBhcmdzLFxuICAgICAgdHlwZSxcbiAgICAgIGRpcmVjdGl2ZXNcbiAgICB9KTtcbiAgfVxuICAvKipcbiAgICogQXJndW1lbnRzRGVmaW5pdGlvbiA6ICggSW5wdXRWYWx1ZURlZmluaXRpb24rIClcbiAgICovXG4gIHBhcnNlQXJndW1lbnREZWZzKCkge1xuICAgIHJldHVybiB0aGlzLm9wdGlvbmFsTWFueShcbiAgICAgIFRva2VuS2luZC5QQVJFTl9MLFxuICAgICAgdGhpcy5wYXJzZUlucHV0VmFsdWVEZWYsXG4gICAgICBUb2tlbktpbmQuUEFSRU5fUlxuICAgICk7XG4gIH1cbiAgLyoqXG4gICAqIElucHV0VmFsdWVEZWZpbml0aW9uIDpcbiAgICogICAtIERlc2NyaXB0aW9uPyBOYW1lIDogVHlwZSBEZWZhdWx0VmFsdWU/IERpcmVjdGl2ZXNbQ29uc3RdP1xuICAgKi9cbiAgcGFyc2VJbnB1dFZhbHVlRGVmKCkge1xuICAgIGNvbnN0IHN0YXJ0ID0gdGhpcy5fbGV4ZXIudG9rZW47XG4gICAgY29uc3QgZGVzY3JpcHRpb24gPSB0aGlzLnBhcnNlRGVzY3JpcHRpb24oKTtcbiAgICBjb25zdCBuYW1lID0gdGhpcy5wYXJzZU5hbWUoKTtcbiAgICB0aGlzLmV4cGVjdFRva2VuKFRva2VuS2luZC5DT0xPTik7XG4gICAgY29uc3QgdHlwZSA9IHRoaXMucGFyc2VUeXBlUmVmZXJlbmNlKCk7XG4gICAgbGV0IGRlZmF1bHRWYWx1ZTtcbiAgICBpZiAodGhpcy5leHBlY3RPcHRpb25hbFRva2VuKFRva2VuS2luZC5FUVVBTFMpKSB7XG4gICAgICBkZWZhdWx0VmFsdWUgPSB0aGlzLnBhcnNlQ29uc3RWYWx1ZUxpdGVyYWwoKTtcbiAgICB9XG4gICAgY29uc3QgZGlyZWN0aXZlcyA9IHRoaXMucGFyc2VDb25zdERpcmVjdGl2ZXMoKTtcbiAgICByZXR1cm4gdGhpcy5ub2RlKHN0YXJ0LCB7XG4gICAgICBraW5kOiBLaW5kLklOUFVUX1ZBTFVFX0RFRklOSVRJT04sXG4gICAgICBkZXNjcmlwdGlvbixcbiAgICAgIG5hbWUsXG4gICAgICB0eXBlLFxuICAgICAgZGVmYXVsdFZhbHVlLFxuICAgICAgZGlyZWN0aXZlc1xuICAgIH0pO1xuICB9XG4gIC8qKlxuICAgKiBJbnRlcmZhY2VUeXBlRGVmaW5pdGlvbiA6XG4gICAqICAgLSBEZXNjcmlwdGlvbj8gaW50ZXJmYWNlIE5hbWUgRGlyZWN0aXZlc1tDb25zdF0/IEZpZWxkc0RlZmluaXRpb24/XG4gICAqL1xuICBwYXJzZUludGVyZmFjZVR5cGVEZWZpbml0aW9uKCkge1xuICAgIGNvbnN0IHN0YXJ0ID0gdGhpcy5fbGV4ZXIudG9rZW47XG4gICAgY29uc3QgZGVzY3JpcHRpb24gPSB0aGlzLnBhcnNlRGVzY3JpcHRpb24oKTtcbiAgICB0aGlzLmV4cGVjdEtleXdvcmQoXCJpbnRlcmZhY2VcIik7XG4gICAgY29uc3QgbmFtZSA9IHRoaXMucGFyc2VOYW1lKCk7XG4gICAgY29uc3QgaW50ZXJmYWNlcyA9IHRoaXMucGFyc2VJbXBsZW1lbnRzSW50ZXJmYWNlcygpO1xuICAgIGNvbnN0IGRpcmVjdGl2ZXMgPSB0aGlzLnBhcnNlQ29uc3REaXJlY3RpdmVzKCk7XG4gICAgY29uc3QgZmllbGRzID0gdGhpcy5wYXJzZUZpZWxkc0RlZmluaXRpb24oKTtcbiAgICByZXR1cm4gdGhpcy5ub2RlKHN0YXJ0LCB7XG4gICAgICBraW5kOiBLaW5kLklOVEVSRkFDRV9UWVBFX0RFRklOSVRJT04sXG4gICAgICBkZXNjcmlwdGlvbixcbiAgICAgIG5hbWUsXG4gICAgICBpbnRlcmZhY2VzLFxuICAgICAgZGlyZWN0aXZlcyxcbiAgICAgIGZpZWxkc1xuICAgIH0pO1xuICB9XG4gIC8qKlxuICAgKiBVbmlvblR5cGVEZWZpbml0aW9uIDpcbiAgICogICAtIERlc2NyaXB0aW9uPyB1bmlvbiBOYW1lIERpcmVjdGl2ZXNbQ29uc3RdPyBVbmlvbk1lbWJlclR5cGVzP1xuICAgKi9cbiAgcGFyc2VVbmlvblR5cGVEZWZpbml0aW9uKCkge1xuICAgIGNvbnN0IHN0YXJ0ID0gdGhpcy5fbGV4ZXIudG9rZW47XG4gICAgY29uc3QgZGVzY3JpcHRpb24gPSB0aGlzLnBhcnNlRGVzY3JpcHRpb24oKTtcbiAgICB0aGlzLmV4cGVjdEtleXdvcmQoXCJ1bmlvblwiKTtcbiAgICBjb25zdCBuYW1lID0gdGhpcy5wYXJzZU5hbWUoKTtcbiAgICBjb25zdCBkaXJlY3RpdmVzID0gdGhpcy5wYXJzZUNvbnN0RGlyZWN0aXZlcygpO1xuICAgIGNvbnN0IHR5cGVzID0gdGhpcy5wYXJzZVVuaW9uTWVtYmVyVHlwZXMoKTtcbiAgICByZXR1cm4gdGhpcy5ub2RlKHN0YXJ0LCB7XG4gICAgICBraW5kOiBLaW5kLlVOSU9OX1RZUEVfREVGSU5JVElPTixcbiAgICAgIGRlc2NyaXB0aW9uLFxuICAgICAgbmFtZSxcbiAgICAgIGRpcmVjdGl2ZXMsXG4gICAgICB0eXBlc1xuICAgIH0pO1xuICB9XG4gIC8qKlxuICAgKiBVbmlvbk1lbWJlclR5cGVzIDpcbiAgICogICAtID0gYHxgPyBOYW1lZFR5cGVcbiAgICogICAtIFVuaW9uTWVtYmVyVHlwZXMgfCBOYW1lZFR5cGVcbiAgICovXG4gIHBhcnNlVW5pb25NZW1iZXJUeXBlcygpIHtcbiAgICByZXR1cm4gdGhpcy5leHBlY3RPcHRpb25hbFRva2VuKFRva2VuS2luZC5FUVVBTFMpID8gdGhpcy5kZWxpbWl0ZWRNYW55KFRva2VuS2luZC5QSVBFLCB0aGlzLnBhcnNlTmFtZWRUeXBlKSA6IFtdO1xuICB9XG4gIC8qKlxuICAgKiBFbnVtVHlwZURlZmluaXRpb24gOlxuICAgKiAgIC0gRGVzY3JpcHRpb24/IGVudW0gTmFtZSBEaXJlY3RpdmVzW0NvbnN0XT8gRW51bVZhbHVlc0RlZmluaXRpb24/XG4gICAqL1xuICBwYXJzZUVudW1UeXBlRGVmaW5pdGlvbigpIHtcbiAgICBjb25zdCBzdGFydCA9IHRoaXMuX2xleGVyLnRva2VuO1xuICAgIGNvbnN0IGRlc2NyaXB0aW9uID0gdGhpcy5wYXJzZURlc2NyaXB0aW9uKCk7XG4gICAgdGhpcy5leHBlY3RLZXl3b3JkKFwiZW51bVwiKTtcbiAgICBjb25zdCBuYW1lID0gdGhpcy5wYXJzZU5hbWUoKTtcbiAgICBjb25zdCBkaXJlY3RpdmVzID0gdGhpcy5wYXJzZUNvbnN0RGlyZWN0aXZlcygpO1xuICAgIGNvbnN0IHZhbHVlcyA9IHRoaXMucGFyc2VFbnVtVmFsdWVzRGVmaW5pdGlvbigpO1xuICAgIHJldHVybiB0aGlzLm5vZGUoc3RhcnQsIHtcbiAgICAgIGtpbmQ6IEtpbmQuRU5VTV9UWVBFX0RFRklOSVRJT04sXG4gICAgICBkZXNjcmlwdGlvbixcbiAgICAgIG5hbWUsXG4gICAgICBkaXJlY3RpdmVzLFxuICAgICAgdmFsdWVzXG4gICAgfSk7XG4gIH1cbiAgLyoqXG4gICAqIGBgYFxuICAgKiBFbnVtVmFsdWVzRGVmaW5pdGlvbiA6IHsgRW51bVZhbHVlRGVmaW5pdGlvbisgfVxuICAgKiBgYGBcbiAgICovXG4gIHBhcnNlRW51bVZhbHVlc0RlZmluaXRpb24oKSB7XG4gICAgcmV0dXJuIHRoaXMub3B0aW9uYWxNYW55KFxuICAgICAgVG9rZW5LaW5kLkJSQUNFX0wsXG4gICAgICB0aGlzLnBhcnNlRW51bVZhbHVlRGVmaW5pdGlvbixcbiAgICAgIFRva2VuS2luZC5CUkFDRV9SXG4gICAgKTtcbiAgfVxuICAvKipcbiAgICogRW51bVZhbHVlRGVmaW5pdGlvbiA6IERlc2NyaXB0aW9uPyBFbnVtVmFsdWUgRGlyZWN0aXZlc1tDb25zdF0/XG4gICAqL1xuICBwYXJzZUVudW1WYWx1ZURlZmluaXRpb24oKSB7XG4gICAgY29uc3Qgc3RhcnQgPSB0aGlzLl9sZXhlci50b2tlbjtcbiAgICBjb25zdCBkZXNjcmlwdGlvbiA9IHRoaXMucGFyc2VEZXNjcmlwdGlvbigpO1xuICAgIGNvbnN0IG5hbWUgPSB0aGlzLnBhcnNlRW51bVZhbHVlTmFtZSgpO1xuICAgIGNvbnN0IGRpcmVjdGl2ZXMgPSB0aGlzLnBhcnNlQ29uc3REaXJlY3RpdmVzKCk7XG4gICAgcmV0dXJuIHRoaXMubm9kZShzdGFydCwge1xuICAgICAga2luZDogS2luZC5FTlVNX1ZBTFVFX0RFRklOSVRJT04sXG4gICAgICBkZXNjcmlwdGlvbixcbiAgICAgIG5hbWUsXG4gICAgICBkaXJlY3RpdmVzXG4gICAgfSk7XG4gIH1cbiAgLyoqXG4gICAqIEVudW1WYWx1ZSA6IE5hbWUgYnV0IG5vdCBgdHJ1ZWAsIGBmYWxzZWAgb3IgYG51bGxgXG4gICAqL1xuICBwYXJzZUVudW1WYWx1ZU5hbWUoKSB7XG4gICAgaWYgKHRoaXMuX2xleGVyLnRva2VuLnZhbHVlID09PSBcInRydWVcIiB8fCB0aGlzLl9sZXhlci50b2tlbi52YWx1ZSA9PT0gXCJmYWxzZVwiIHx8IHRoaXMuX2xleGVyLnRva2VuLnZhbHVlID09PSBcIm51bGxcIikge1xuICAgICAgdGhyb3cgc3ludGF4RXJyb3IoXG4gICAgICAgIHRoaXMuX2xleGVyLnNvdXJjZSxcbiAgICAgICAgdGhpcy5fbGV4ZXIudG9rZW4uc3RhcnQsXG4gICAgICAgIGAke2dldFRva2VuRGVzYyhcbiAgICAgICAgICB0aGlzLl9sZXhlci50b2tlblxuICAgICAgICApfSBpcyByZXNlcnZlZCBhbmQgY2Fubm90IGJlIHVzZWQgZm9yIGFuIGVudW0gdmFsdWUuYFxuICAgICAgKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMucGFyc2VOYW1lKCk7XG4gIH1cbiAgLyoqXG4gICAqIElucHV0T2JqZWN0VHlwZURlZmluaXRpb24gOlxuICAgKiAgIC0gRGVzY3JpcHRpb24/IGlucHV0IE5hbWUgRGlyZWN0aXZlc1tDb25zdF0/IElucHV0RmllbGRzRGVmaW5pdGlvbj9cbiAgICovXG4gIHBhcnNlSW5wdXRPYmplY3RUeXBlRGVmaW5pdGlvbigpIHtcbiAgICBjb25zdCBzdGFydCA9IHRoaXMuX2xleGVyLnRva2VuO1xuICAgIGNvbnN0IGRlc2NyaXB0aW9uID0gdGhpcy5wYXJzZURlc2NyaXB0aW9uKCk7XG4gICAgdGhpcy5leHBlY3RLZXl3b3JkKFwiaW5wdXRcIik7XG4gICAgY29uc3QgbmFtZSA9IHRoaXMucGFyc2VOYW1lKCk7XG4gICAgY29uc3QgZGlyZWN0aXZlcyA9IHRoaXMucGFyc2VDb25zdERpcmVjdGl2ZXMoKTtcbiAgICBjb25zdCBmaWVsZHMgPSB0aGlzLnBhcnNlSW5wdXRGaWVsZHNEZWZpbml0aW9uKCk7XG4gICAgcmV0dXJuIHRoaXMubm9kZShzdGFydCwge1xuICAgICAga2luZDogS2luZC5JTlBVVF9PQkpFQ1RfVFlQRV9ERUZJTklUSU9OLFxuICAgICAgZGVzY3JpcHRpb24sXG4gICAgICBuYW1lLFxuICAgICAgZGlyZWN0aXZlcyxcbiAgICAgIGZpZWxkc1xuICAgIH0pO1xuICB9XG4gIC8qKlxuICAgKiBgYGBcbiAgICogSW5wdXRGaWVsZHNEZWZpbml0aW9uIDogeyBJbnB1dFZhbHVlRGVmaW5pdGlvbisgfVxuICAgKiBgYGBcbiAgICovXG4gIHBhcnNlSW5wdXRGaWVsZHNEZWZpbml0aW9uKCkge1xuICAgIHJldHVybiB0aGlzLm9wdGlvbmFsTWFueShcbiAgICAgIFRva2VuS2luZC5CUkFDRV9MLFxuICAgICAgdGhpcy5wYXJzZUlucHV0VmFsdWVEZWYsXG4gICAgICBUb2tlbktpbmQuQlJBQ0VfUlxuICAgICk7XG4gIH1cbiAgLyoqXG4gICAqIFR5cGVTeXN0ZW1FeHRlbnNpb24gOlxuICAgKiAgIC0gU2NoZW1hRXh0ZW5zaW9uXG4gICAqICAgLSBUeXBlRXh0ZW5zaW9uXG4gICAqXG4gICAqIFR5cGVFeHRlbnNpb24gOlxuICAgKiAgIC0gU2NhbGFyVHlwZUV4dGVuc2lvblxuICAgKiAgIC0gT2JqZWN0VHlwZUV4dGVuc2lvblxuICAgKiAgIC0gSW50ZXJmYWNlVHlwZUV4dGVuc2lvblxuICAgKiAgIC0gVW5pb25UeXBlRXh0ZW5zaW9uXG4gICAqICAgLSBFbnVtVHlwZUV4dGVuc2lvblxuICAgKiAgIC0gSW5wdXRPYmplY3RUeXBlRGVmaW5pdGlvblxuICAgKi9cbiAgcGFyc2VUeXBlU3lzdGVtRXh0ZW5zaW9uKCkge1xuICAgIGNvbnN0IGtleXdvcmRUb2tlbiA9IHRoaXMuX2xleGVyLmxvb2thaGVhZCgpO1xuICAgIGlmIChrZXl3b3JkVG9rZW4ua2luZCA9PT0gVG9rZW5LaW5kLk5BTUUpIHtcbiAgICAgIHN3aXRjaCAoa2V5d29yZFRva2VuLnZhbHVlKSB7XG4gICAgICAgIGNhc2UgXCJzY2hlbWFcIjpcbiAgICAgICAgICByZXR1cm4gdGhpcy5wYXJzZVNjaGVtYUV4dGVuc2lvbigpO1xuICAgICAgICBjYXNlIFwic2NhbGFyXCI6XG4gICAgICAgICAgcmV0dXJuIHRoaXMucGFyc2VTY2FsYXJUeXBlRXh0ZW5zaW9uKCk7XG4gICAgICAgIGNhc2UgXCJ0eXBlXCI6XG4gICAgICAgICAgcmV0dXJuIHRoaXMucGFyc2VPYmplY3RUeXBlRXh0ZW5zaW9uKCk7XG4gICAgICAgIGNhc2UgXCJpbnRlcmZhY2VcIjpcbiAgICAgICAgICByZXR1cm4gdGhpcy5wYXJzZUludGVyZmFjZVR5cGVFeHRlbnNpb24oKTtcbiAgICAgICAgY2FzZSBcInVuaW9uXCI6XG4gICAgICAgICAgcmV0dXJuIHRoaXMucGFyc2VVbmlvblR5cGVFeHRlbnNpb24oKTtcbiAgICAgICAgY2FzZSBcImVudW1cIjpcbiAgICAgICAgICByZXR1cm4gdGhpcy5wYXJzZUVudW1UeXBlRXh0ZW5zaW9uKCk7XG4gICAgICAgIGNhc2UgXCJpbnB1dFwiOlxuICAgICAgICAgIHJldHVybiB0aGlzLnBhcnNlSW5wdXRPYmplY3RUeXBlRXh0ZW5zaW9uKCk7XG4gICAgICB9XG4gICAgfVxuICAgIHRocm93IHRoaXMudW5leHBlY3RlZChrZXl3b3JkVG9rZW4pO1xuICB9XG4gIC8qKlxuICAgKiBgYGBcbiAgICogU2NoZW1hRXh0ZW5zaW9uIDpcbiAgICogIC0gZXh0ZW5kIHNjaGVtYSBEaXJlY3RpdmVzW0NvbnN0XT8geyBPcGVyYXRpb25UeXBlRGVmaW5pdGlvbisgfVxuICAgKiAgLSBleHRlbmQgc2NoZW1hIERpcmVjdGl2ZXNbQ29uc3RdXG4gICAqIGBgYFxuICAgKi9cbiAgcGFyc2VTY2hlbWFFeHRlbnNpb24oKSB7XG4gICAgY29uc3Qgc3RhcnQgPSB0aGlzLl9sZXhlci50b2tlbjtcbiAgICB0aGlzLmV4cGVjdEtleXdvcmQoXCJleHRlbmRcIik7XG4gICAgdGhpcy5leHBlY3RLZXl3b3JkKFwic2NoZW1hXCIpO1xuICAgIGNvbnN0IGRpcmVjdGl2ZXMgPSB0aGlzLnBhcnNlQ29uc3REaXJlY3RpdmVzKCk7XG4gICAgY29uc3Qgb3BlcmF0aW9uVHlwZXMgPSB0aGlzLm9wdGlvbmFsTWFueShcbiAgICAgIFRva2VuS2luZC5CUkFDRV9MLFxuICAgICAgdGhpcy5wYXJzZU9wZXJhdGlvblR5cGVEZWZpbml0aW9uLFxuICAgICAgVG9rZW5LaW5kLkJSQUNFX1JcbiAgICApO1xuICAgIGlmIChkaXJlY3RpdmVzLmxlbmd0aCA9PT0gMCAmJiBvcGVyYXRpb25UeXBlcy5sZW5ndGggPT09IDApIHtcbiAgICAgIHRocm93IHRoaXMudW5leHBlY3RlZCgpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5ub2RlKHN0YXJ0LCB7XG4gICAgICBraW5kOiBLaW5kLlNDSEVNQV9FWFRFTlNJT04sXG4gICAgICBkaXJlY3RpdmVzLFxuICAgICAgb3BlcmF0aW9uVHlwZXNcbiAgICB9KTtcbiAgfVxuICAvKipcbiAgICogU2NhbGFyVHlwZUV4dGVuc2lvbiA6XG4gICAqICAgLSBleHRlbmQgc2NhbGFyIE5hbWUgRGlyZWN0aXZlc1tDb25zdF1cbiAgICovXG4gIHBhcnNlU2NhbGFyVHlwZUV4dGVuc2lvbigpIHtcbiAgICBjb25zdCBzdGFydCA9IHRoaXMuX2xleGVyLnRva2VuO1xuICAgIHRoaXMuZXhwZWN0S2V5d29yZChcImV4dGVuZFwiKTtcbiAgICB0aGlzLmV4cGVjdEtleXdvcmQoXCJzY2FsYXJcIik7XG4gICAgY29uc3QgbmFtZSA9IHRoaXMucGFyc2VOYW1lKCk7XG4gICAgY29uc3QgZGlyZWN0aXZlcyA9IHRoaXMucGFyc2VDb25zdERpcmVjdGl2ZXMoKTtcbiAgICBpZiAoZGlyZWN0aXZlcy5sZW5ndGggPT09IDApIHtcbiAgICAgIHRocm93IHRoaXMudW5leHBlY3RlZCgpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5ub2RlKHN0YXJ0LCB7XG4gICAgICBraW5kOiBLaW5kLlNDQUxBUl9UWVBFX0VYVEVOU0lPTixcbiAgICAgIG5hbWUsXG4gICAgICBkaXJlY3RpdmVzXG4gICAgfSk7XG4gIH1cbiAgLyoqXG4gICAqIE9iamVjdFR5cGVFeHRlbnNpb24gOlxuICAgKiAgLSBleHRlbmQgdHlwZSBOYW1lIEltcGxlbWVudHNJbnRlcmZhY2VzPyBEaXJlY3RpdmVzW0NvbnN0XT8gRmllbGRzRGVmaW5pdGlvblxuICAgKiAgLSBleHRlbmQgdHlwZSBOYW1lIEltcGxlbWVudHNJbnRlcmZhY2VzPyBEaXJlY3RpdmVzW0NvbnN0XVxuICAgKiAgLSBleHRlbmQgdHlwZSBOYW1lIEltcGxlbWVudHNJbnRlcmZhY2VzXG4gICAqL1xuICBwYXJzZU9iamVjdFR5cGVFeHRlbnNpb24oKSB7XG4gICAgY29uc3Qgc3RhcnQgPSB0aGlzLl9sZXhlci50b2tlbjtcbiAgICB0aGlzLmV4cGVjdEtleXdvcmQoXCJleHRlbmRcIik7XG4gICAgdGhpcy5leHBlY3RLZXl3b3JkKFwidHlwZVwiKTtcbiAgICBjb25zdCBuYW1lID0gdGhpcy5wYXJzZU5hbWUoKTtcbiAgICBjb25zdCBpbnRlcmZhY2VzID0gdGhpcy5wYXJzZUltcGxlbWVudHNJbnRlcmZhY2VzKCk7XG4gICAgY29uc3QgZGlyZWN0aXZlcyA9IHRoaXMucGFyc2VDb25zdERpcmVjdGl2ZXMoKTtcbiAgICBjb25zdCBmaWVsZHMgPSB0aGlzLnBhcnNlRmllbGRzRGVmaW5pdGlvbigpO1xuICAgIGlmIChpbnRlcmZhY2VzLmxlbmd0aCA9PT0gMCAmJiBkaXJlY3RpdmVzLmxlbmd0aCA9PT0gMCAmJiBmaWVsZHMubGVuZ3RoID09PSAwKSB7XG4gICAgICB0aHJvdyB0aGlzLnVuZXhwZWN0ZWQoKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMubm9kZShzdGFydCwge1xuICAgICAga2luZDogS2luZC5PQkpFQ1RfVFlQRV9FWFRFTlNJT04sXG4gICAgICBuYW1lLFxuICAgICAgaW50ZXJmYWNlcyxcbiAgICAgIGRpcmVjdGl2ZXMsXG4gICAgICBmaWVsZHNcbiAgICB9KTtcbiAgfVxuICAvKipcbiAgICogSW50ZXJmYWNlVHlwZUV4dGVuc2lvbiA6XG4gICAqICAtIGV4dGVuZCBpbnRlcmZhY2UgTmFtZSBJbXBsZW1lbnRzSW50ZXJmYWNlcz8gRGlyZWN0aXZlc1tDb25zdF0/IEZpZWxkc0RlZmluaXRpb25cbiAgICogIC0gZXh0ZW5kIGludGVyZmFjZSBOYW1lIEltcGxlbWVudHNJbnRlcmZhY2VzPyBEaXJlY3RpdmVzW0NvbnN0XVxuICAgKiAgLSBleHRlbmQgaW50ZXJmYWNlIE5hbWUgSW1wbGVtZW50c0ludGVyZmFjZXNcbiAgICovXG4gIHBhcnNlSW50ZXJmYWNlVHlwZUV4dGVuc2lvbigpIHtcbiAgICBjb25zdCBzdGFydCA9IHRoaXMuX2xleGVyLnRva2VuO1xuICAgIHRoaXMuZXhwZWN0S2V5d29yZChcImV4dGVuZFwiKTtcbiAgICB0aGlzLmV4cGVjdEtleXdvcmQoXCJpbnRlcmZhY2VcIik7XG4gICAgY29uc3QgbmFtZSA9IHRoaXMucGFyc2VOYW1lKCk7XG4gICAgY29uc3QgaW50ZXJmYWNlcyA9IHRoaXMucGFyc2VJbXBsZW1lbnRzSW50ZXJmYWNlcygpO1xuICAgIGNvbnN0IGRpcmVjdGl2ZXMgPSB0aGlzLnBhcnNlQ29uc3REaXJlY3RpdmVzKCk7XG4gICAgY29uc3QgZmllbGRzID0gdGhpcy5wYXJzZUZpZWxkc0RlZmluaXRpb24oKTtcbiAgICBpZiAoaW50ZXJmYWNlcy5sZW5ndGggPT09IDAgJiYgZGlyZWN0aXZlcy5sZW5ndGggPT09IDAgJiYgZmllbGRzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgdGhyb3cgdGhpcy51bmV4cGVjdGVkKCk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLm5vZGUoc3RhcnQsIHtcbiAgICAgIGtpbmQ6IEtpbmQuSU5URVJGQUNFX1RZUEVfRVhURU5TSU9OLFxuICAgICAgbmFtZSxcbiAgICAgIGludGVyZmFjZXMsXG4gICAgICBkaXJlY3RpdmVzLFxuICAgICAgZmllbGRzXG4gICAgfSk7XG4gIH1cbiAgLyoqXG4gICAqIFVuaW9uVHlwZUV4dGVuc2lvbiA6XG4gICAqICAgLSBleHRlbmQgdW5pb24gTmFtZSBEaXJlY3RpdmVzW0NvbnN0XT8gVW5pb25NZW1iZXJUeXBlc1xuICAgKiAgIC0gZXh0ZW5kIHVuaW9uIE5hbWUgRGlyZWN0aXZlc1tDb25zdF1cbiAgICovXG4gIHBhcnNlVW5pb25UeXBlRXh0ZW5zaW9uKCkge1xuICAgIGNvbnN0IHN0YXJ0ID0gdGhpcy5fbGV4ZXIudG9rZW47XG4gICAgdGhpcy5leHBlY3RLZXl3b3JkKFwiZXh0ZW5kXCIpO1xuICAgIHRoaXMuZXhwZWN0S2V5d29yZChcInVuaW9uXCIpO1xuICAgIGNvbnN0IG5hbWUgPSB0aGlzLnBhcnNlTmFtZSgpO1xuICAgIGNvbnN0IGRpcmVjdGl2ZXMgPSB0aGlzLnBhcnNlQ29uc3REaXJlY3RpdmVzKCk7XG4gICAgY29uc3QgdHlwZXMgPSB0aGlzLnBhcnNlVW5pb25NZW1iZXJUeXBlcygpO1xuICAgIGlmIChkaXJlY3RpdmVzLmxlbmd0aCA9PT0gMCAmJiB0eXBlcy5sZW5ndGggPT09IDApIHtcbiAgICAgIHRocm93IHRoaXMudW5leHBlY3RlZCgpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5ub2RlKHN0YXJ0LCB7XG4gICAgICBraW5kOiBLaW5kLlVOSU9OX1RZUEVfRVhURU5TSU9OLFxuICAgICAgbmFtZSxcbiAgICAgIGRpcmVjdGl2ZXMsXG4gICAgICB0eXBlc1xuICAgIH0pO1xuICB9XG4gIC8qKlxuICAgKiBFbnVtVHlwZUV4dGVuc2lvbiA6XG4gICAqICAgLSBleHRlbmQgZW51bSBOYW1lIERpcmVjdGl2ZXNbQ29uc3RdPyBFbnVtVmFsdWVzRGVmaW5pdGlvblxuICAgKiAgIC0gZXh0ZW5kIGVudW0gTmFtZSBEaXJlY3RpdmVzW0NvbnN0XVxuICAgKi9cbiAgcGFyc2VFbnVtVHlwZUV4dGVuc2lvbigpIHtcbiAgICBjb25zdCBzdGFydCA9IHRoaXMuX2xleGVyLnRva2VuO1xuICAgIHRoaXMuZXhwZWN0S2V5d29yZChcImV4dGVuZFwiKTtcbiAgICB0aGlzLmV4cGVjdEtleXdvcmQoXCJlbnVtXCIpO1xuICAgIGNvbnN0IG5hbWUgPSB0aGlzLnBhcnNlTmFtZSgpO1xuICAgIGNvbnN0IGRpcmVjdGl2ZXMgPSB0aGlzLnBhcnNlQ29uc3REaXJlY3RpdmVzKCk7XG4gICAgY29uc3QgdmFsdWVzID0gdGhpcy5wYXJzZUVudW1WYWx1ZXNEZWZpbml0aW9uKCk7XG4gICAgaWYgKGRpcmVjdGl2ZXMubGVuZ3RoID09PSAwICYmIHZhbHVlcy5sZW5ndGggPT09IDApIHtcbiAgICAgIHRocm93IHRoaXMudW5leHBlY3RlZCgpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5ub2RlKHN0YXJ0LCB7XG4gICAgICBraW5kOiBLaW5kLkVOVU1fVFlQRV9FWFRFTlNJT04sXG4gICAgICBuYW1lLFxuICAgICAgZGlyZWN0aXZlcyxcbiAgICAgIHZhbHVlc1xuICAgIH0pO1xuICB9XG4gIC8qKlxuICAgKiBJbnB1dE9iamVjdFR5cGVFeHRlbnNpb24gOlxuICAgKiAgIC0gZXh0ZW5kIGlucHV0IE5hbWUgRGlyZWN0aXZlc1tDb25zdF0/IElucHV0RmllbGRzRGVmaW5pdGlvblxuICAgKiAgIC0gZXh0ZW5kIGlucHV0IE5hbWUgRGlyZWN0aXZlc1tDb25zdF1cbiAgICovXG4gIHBhcnNlSW5wdXRPYmplY3RUeXBlRXh0ZW5zaW9uKCkge1xuICAgIGNvbnN0IHN0YXJ0ID0gdGhpcy5fbGV4ZXIudG9rZW47XG4gICAgdGhpcy5leHBlY3RLZXl3b3JkKFwiZXh0ZW5kXCIpO1xuICAgIHRoaXMuZXhwZWN0S2V5d29yZChcImlucHV0XCIpO1xuICAgIGNvbnN0IG5hbWUgPSB0aGlzLnBhcnNlTmFtZSgpO1xuICAgIGNvbnN0IGRpcmVjdGl2ZXMgPSB0aGlzLnBhcnNlQ29uc3REaXJlY3RpdmVzKCk7XG4gICAgY29uc3QgZmllbGRzID0gdGhpcy5wYXJzZUlucHV0RmllbGRzRGVmaW5pdGlvbigpO1xuICAgIGlmIChkaXJlY3RpdmVzLmxlbmd0aCA9PT0gMCAmJiBmaWVsZHMubGVuZ3RoID09PSAwKSB7XG4gICAgICB0aHJvdyB0aGlzLnVuZXhwZWN0ZWQoKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMubm9kZShzdGFydCwge1xuICAgICAga2luZDogS2luZC5JTlBVVF9PQkpFQ1RfVFlQRV9FWFRFTlNJT04sXG4gICAgICBuYW1lLFxuICAgICAgZGlyZWN0aXZlcyxcbiAgICAgIGZpZWxkc1xuICAgIH0pO1xuICB9XG4gIC8qKlxuICAgKiBgYGBcbiAgICogRGlyZWN0aXZlRGVmaW5pdGlvbiA6XG4gICAqICAgLSBEZXNjcmlwdGlvbj8gZGlyZWN0aXZlIEAgTmFtZSBBcmd1bWVudHNEZWZpbml0aW9uPyBgcmVwZWF0YWJsZWA/IG9uIERpcmVjdGl2ZUxvY2F0aW9uc1xuICAgKiBgYGBcbiAgICovXG4gIHBhcnNlRGlyZWN0aXZlRGVmaW5pdGlvbigpIHtcbiAgICBjb25zdCBzdGFydCA9IHRoaXMuX2xleGVyLnRva2VuO1xuICAgIGNvbnN0IGRlc2NyaXB0aW9uID0gdGhpcy5wYXJzZURlc2NyaXB0aW9uKCk7XG4gICAgdGhpcy5leHBlY3RLZXl3b3JkKFwiZGlyZWN0aXZlXCIpO1xuICAgIHRoaXMuZXhwZWN0VG9rZW4oVG9rZW5LaW5kLkFUKTtcbiAgICBjb25zdCBuYW1lID0gdGhpcy5wYXJzZU5hbWUoKTtcbiAgICBjb25zdCBhcmdzID0gdGhpcy5wYXJzZUFyZ3VtZW50RGVmcygpO1xuICAgIGNvbnN0IHJlcGVhdGFibGUgPSB0aGlzLmV4cGVjdE9wdGlvbmFsS2V5d29yZChcInJlcGVhdGFibGVcIik7XG4gICAgdGhpcy5leHBlY3RLZXl3b3JkKFwib25cIik7XG4gICAgY29uc3QgbG9jYXRpb25zID0gdGhpcy5wYXJzZURpcmVjdGl2ZUxvY2F0aW9ucygpO1xuICAgIHJldHVybiB0aGlzLm5vZGUoc3RhcnQsIHtcbiAgICAgIGtpbmQ6IEtpbmQuRElSRUNUSVZFX0RFRklOSVRJT04sXG4gICAgICBkZXNjcmlwdGlvbixcbiAgICAgIG5hbWUsXG4gICAgICBhcmd1bWVudHM6IGFyZ3MsXG4gICAgICByZXBlYXRhYmxlLFxuICAgICAgbG9jYXRpb25zXG4gICAgfSk7XG4gIH1cbiAgLyoqXG4gICAqIERpcmVjdGl2ZUxvY2F0aW9ucyA6XG4gICAqICAgLSBgfGA/IERpcmVjdGl2ZUxvY2F0aW9uXG4gICAqICAgLSBEaXJlY3RpdmVMb2NhdGlvbnMgfCBEaXJlY3RpdmVMb2NhdGlvblxuICAgKi9cbiAgcGFyc2VEaXJlY3RpdmVMb2NhdGlvbnMoKSB7XG4gICAgcmV0dXJuIHRoaXMuZGVsaW1pdGVkTWFueShUb2tlbktpbmQuUElQRSwgdGhpcy5wYXJzZURpcmVjdGl2ZUxvY2F0aW9uKTtcbiAgfVxuICAvKlxuICAgKiBEaXJlY3RpdmVMb2NhdGlvbiA6XG4gICAqICAgLSBFeGVjdXRhYmxlRGlyZWN0aXZlTG9jYXRpb25cbiAgICogICAtIFR5cGVTeXN0ZW1EaXJlY3RpdmVMb2NhdGlvblxuICAgKlxuICAgKiBFeGVjdXRhYmxlRGlyZWN0aXZlTG9jYXRpb24gOiBvbmUgb2ZcbiAgICogICBgUVVFUllgXG4gICAqICAgYE1VVEFUSU9OYFxuICAgKiAgIGBTVUJTQ1JJUFRJT05gXG4gICAqICAgYEZJRUxEYFxuICAgKiAgIGBGUkFHTUVOVF9ERUZJTklUSU9OYFxuICAgKiAgIGBGUkFHTUVOVF9TUFJFQURgXG4gICAqICAgYElOTElORV9GUkFHTUVOVGBcbiAgICpcbiAgICogVHlwZVN5c3RlbURpcmVjdGl2ZUxvY2F0aW9uIDogb25lIG9mXG4gICAqICAgYFNDSEVNQWBcbiAgICogICBgU0NBTEFSYFxuICAgKiAgIGBPQkpFQ1RgXG4gICAqICAgYEZJRUxEX0RFRklOSVRJT05gXG4gICAqICAgYEFSR1VNRU5UX0RFRklOSVRJT05gXG4gICAqICAgYElOVEVSRkFDRWBcbiAgICogICBgVU5JT05gXG4gICAqICAgYEVOVU1gXG4gICAqICAgYEVOVU1fVkFMVUVgXG4gICAqICAgYElOUFVUX09CSkVDVGBcbiAgICogICBgSU5QVVRfRklFTERfREVGSU5JVElPTmBcbiAgICovXG4gIHBhcnNlRGlyZWN0aXZlTG9jYXRpb24oKSB7XG4gICAgY29uc3Qgc3RhcnQgPSB0aGlzLl9sZXhlci50b2tlbjtcbiAgICBjb25zdCBuYW1lID0gdGhpcy5wYXJzZU5hbWUoKTtcbiAgICBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKERpcmVjdGl2ZUxvY2F0aW9uLCBuYW1lLnZhbHVlKSkge1xuICAgICAgcmV0dXJuIG5hbWU7XG4gICAgfVxuICAgIHRocm93IHRoaXMudW5leHBlY3RlZChzdGFydCk7XG4gIH1cbiAgLy8gQ29yZSBwYXJzaW5nIHV0aWxpdHkgZnVuY3Rpb25zXG4gIC8qKlxuICAgKiBSZXR1cm5zIGEgbm9kZSB0aGF0LCBpZiBjb25maWd1cmVkIHRvIGRvIHNvLCBzZXRzIGEgXCJsb2NcIiBmaWVsZCBhcyBhXG4gICAqIGxvY2F0aW9uIG9iamVjdCwgdXNlZCB0byBpZGVudGlmeSB0aGUgcGxhY2UgaW4gdGhlIHNvdXJjZSB0aGF0IGNyZWF0ZWQgYVxuICAgKiBnaXZlbiBwYXJzZWQgb2JqZWN0LlxuICAgKi9cbiAgbm9kZShzdGFydFRva2VuLCBub2RlKSB7XG4gICAgaWYgKHRoaXMuX29wdGlvbnMubm9Mb2NhdGlvbiAhPT0gdHJ1ZSkge1xuICAgICAgbm9kZS5sb2MgPSBuZXcgTG9jYXRpb24oXG4gICAgICAgIHN0YXJ0VG9rZW4sXG4gICAgICAgIHRoaXMuX2xleGVyLmxhc3RUb2tlbixcbiAgICAgICAgdGhpcy5fbGV4ZXIuc291cmNlXG4gICAgICApO1xuICAgIH1cbiAgICByZXR1cm4gbm9kZTtcbiAgfVxuICAvKipcbiAgICogRGV0ZXJtaW5lcyBpZiB0aGUgbmV4dCB0b2tlbiBpcyBvZiBhIGdpdmVuIGtpbmRcbiAgICovXG4gIHBlZWsoa2luZCkge1xuICAgIHJldHVybiB0aGlzLl9sZXhlci50b2tlbi5raW5kID09PSBraW5kO1xuICB9XG4gIC8qKlxuICAgKiBJZiB0aGUgbmV4dCB0b2tlbiBpcyBvZiB0aGUgZ2l2ZW4ga2luZCwgcmV0dXJuIHRoYXQgdG9rZW4gYWZ0ZXIgYWR2YW5jaW5nIHRoZSBsZXhlci5cbiAgICogT3RoZXJ3aXNlLCBkbyBub3QgY2hhbmdlIHRoZSBwYXJzZXIgc3RhdGUgYW5kIHRocm93IGFuIGVycm9yLlxuICAgKi9cbiAgZXhwZWN0VG9rZW4oa2luZCkge1xuICAgIGNvbnN0IHRva2VuID0gdGhpcy5fbGV4ZXIudG9rZW47XG4gICAgaWYgKHRva2VuLmtpbmQgPT09IGtpbmQpIHtcbiAgICAgIHRoaXMuYWR2YW5jZUxleGVyKCk7XG4gICAgICByZXR1cm4gdG9rZW47XG4gICAgfVxuICAgIHRocm93IHN5bnRheEVycm9yKFxuICAgICAgdGhpcy5fbGV4ZXIuc291cmNlLFxuICAgICAgdG9rZW4uc3RhcnQsXG4gICAgICBgRXhwZWN0ZWQgJHtnZXRUb2tlbktpbmREZXNjKGtpbmQpfSwgZm91bmQgJHtnZXRUb2tlbkRlc2ModG9rZW4pfS5gXG4gICAgKTtcbiAgfVxuICAvKipcbiAgICogSWYgdGhlIG5leHQgdG9rZW4gaXMgb2YgdGhlIGdpdmVuIGtpbmQsIHJldHVybiBcInRydWVcIiBhZnRlciBhZHZhbmNpbmcgdGhlIGxleGVyLlxuICAgKiBPdGhlcndpc2UsIGRvIG5vdCBjaGFuZ2UgdGhlIHBhcnNlciBzdGF0ZSBhbmQgcmV0dXJuIFwiZmFsc2VcIi5cbiAgICovXG4gIGV4cGVjdE9wdGlvbmFsVG9rZW4oa2luZCkge1xuICAgIGNvbnN0IHRva2VuID0gdGhpcy5fbGV4ZXIudG9rZW47XG4gICAgaWYgKHRva2VuLmtpbmQgPT09IGtpbmQpIHtcbiAgICAgIHRoaXMuYWR2YW5jZUxleGVyKCk7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIC8qKlxuICAgKiBJZiB0aGUgbmV4dCB0b2tlbiBpcyBhIGdpdmVuIGtleXdvcmQsIGFkdmFuY2UgdGhlIGxleGVyLlxuICAgKiBPdGhlcndpc2UsIGRvIG5vdCBjaGFuZ2UgdGhlIHBhcnNlciBzdGF0ZSBhbmQgdGhyb3cgYW4gZXJyb3IuXG4gICAqL1xuICBleHBlY3RLZXl3b3JkKHZhbHVlKSB7XG4gICAgY29uc3QgdG9rZW4gPSB0aGlzLl9sZXhlci50b2tlbjtcbiAgICBpZiAodG9rZW4ua2luZCA9PT0gVG9rZW5LaW5kLk5BTUUgJiYgdG9rZW4udmFsdWUgPT09IHZhbHVlKSB7XG4gICAgICB0aGlzLmFkdmFuY2VMZXhlcigpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aHJvdyBzeW50YXhFcnJvcihcbiAgICAgICAgdGhpcy5fbGV4ZXIuc291cmNlLFxuICAgICAgICB0b2tlbi5zdGFydCxcbiAgICAgICAgYEV4cGVjdGVkIFwiJHt2YWx1ZX1cIiwgZm91bmQgJHtnZXRUb2tlbkRlc2ModG9rZW4pfS5gXG4gICAgICApO1xuICAgIH1cbiAgfVxuICAvKipcbiAgICogSWYgdGhlIG5leHQgdG9rZW4gaXMgYSBnaXZlbiBrZXl3b3JkLCByZXR1cm4gXCJ0cnVlXCIgYWZ0ZXIgYWR2YW5jaW5nIHRoZSBsZXhlci5cbiAgICogT3RoZXJ3aXNlLCBkbyBub3QgY2hhbmdlIHRoZSBwYXJzZXIgc3RhdGUgYW5kIHJldHVybiBcImZhbHNlXCIuXG4gICAqL1xuICBleHBlY3RPcHRpb25hbEtleXdvcmQodmFsdWUpIHtcbiAgICBjb25zdCB0b2tlbiA9IHRoaXMuX2xleGVyLnRva2VuO1xuICAgIGlmICh0b2tlbi5raW5kID09PSBUb2tlbktpbmQuTkFNRSAmJiB0b2tlbi52YWx1ZSA9PT0gdmFsdWUpIHtcbiAgICAgIHRoaXMuYWR2YW5jZUxleGVyKCk7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIC8qKlxuICAgKiBIZWxwZXIgZnVuY3Rpb24gZm9yIGNyZWF0aW5nIGFuIGVycm9yIHdoZW4gYW4gdW5leHBlY3RlZCBsZXhlZCB0b2tlbiBpcyBlbmNvdW50ZXJlZC5cbiAgICovXG4gIHVuZXhwZWN0ZWQoYXRUb2tlbikge1xuICAgIGNvbnN0IHRva2VuID0gYXRUb2tlbiAhPT0gbnVsbCAmJiBhdFRva2VuICE9PSB2b2lkIDAgPyBhdFRva2VuIDogdGhpcy5fbGV4ZXIudG9rZW47XG4gICAgcmV0dXJuIHN5bnRheEVycm9yKFxuICAgICAgdGhpcy5fbGV4ZXIuc291cmNlLFxuICAgICAgdG9rZW4uc3RhcnQsXG4gICAgICBgVW5leHBlY3RlZCAke2dldFRva2VuRGVzYyh0b2tlbil9LmBcbiAgICApO1xuICB9XG4gIC8qKlxuICAgKiBSZXR1cm5zIGEgcG9zc2libHkgZW1wdHkgbGlzdCBvZiBwYXJzZSBub2RlcywgZGV0ZXJtaW5lZCBieSB0aGUgcGFyc2VGbi5cbiAgICogVGhpcyBsaXN0IGJlZ2lucyB3aXRoIGEgbGV4IHRva2VuIG9mIG9wZW5LaW5kIGFuZCBlbmRzIHdpdGggYSBsZXggdG9rZW4gb2YgY2xvc2VLaW5kLlxuICAgKiBBZHZhbmNlcyB0aGUgcGFyc2VyIHRvIHRoZSBuZXh0IGxleCB0b2tlbiBhZnRlciB0aGUgY2xvc2luZyB0b2tlbi5cbiAgICovXG4gIGFueShvcGVuS2luZCwgcGFyc2VGbiwgY2xvc2VLaW5kKSB7XG4gICAgdGhpcy5leHBlY3RUb2tlbihvcGVuS2luZCk7XG4gICAgY29uc3Qgbm9kZXMgPSBbXTtcbiAgICB3aGlsZSAoIXRoaXMuZXhwZWN0T3B0aW9uYWxUb2tlbihjbG9zZUtpbmQpKSB7XG4gICAgICBub2Rlcy5wdXNoKHBhcnNlRm4uY2FsbCh0aGlzKSk7XG4gICAgfVxuICAgIHJldHVybiBub2RlcztcbiAgfVxuICAvKipcbiAgICogUmV0dXJucyBhIGxpc3Qgb2YgcGFyc2Ugbm9kZXMsIGRldGVybWluZWQgYnkgdGhlIHBhcnNlRm4uXG4gICAqIEl0IGNhbiBiZSBlbXB0eSBvbmx5IGlmIG9wZW4gdG9rZW4gaXMgbWlzc2luZyBvdGhlcndpc2UgaXQgd2lsbCBhbHdheXMgcmV0dXJuIG5vbi1lbXB0eSBsaXN0XG4gICAqIHRoYXQgYmVnaW5zIHdpdGggYSBsZXggdG9rZW4gb2Ygb3BlbktpbmQgYW5kIGVuZHMgd2l0aCBhIGxleCB0b2tlbiBvZiBjbG9zZUtpbmQuXG4gICAqIEFkdmFuY2VzIHRoZSBwYXJzZXIgdG8gdGhlIG5leHQgbGV4IHRva2VuIGFmdGVyIHRoZSBjbG9zaW5nIHRva2VuLlxuICAgKi9cbiAgb3B0aW9uYWxNYW55KG9wZW5LaW5kLCBwYXJzZUZuLCBjbG9zZUtpbmQpIHtcbiAgICBpZiAodGhpcy5leHBlY3RPcHRpb25hbFRva2VuKG9wZW5LaW5kKSkge1xuICAgICAgY29uc3Qgbm9kZXMgPSBbXTtcbiAgICAgIGRvIHtcbiAgICAgICAgbm9kZXMucHVzaChwYXJzZUZuLmNhbGwodGhpcykpO1xuICAgICAgfSB3aGlsZSAoIXRoaXMuZXhwZWN0T3B0aW9uYWxUb2tlbihjbG9zZUtpbmQpKTtcbiAgICAgIHJldHVybiBub2RlcztcbiAgICB9XG4gICAgcmV0dXJuIFtdO1xuICB9XG4gIC8qKlxuICAgKiBSZXR1cm5zIGEgbm9uLWVtcHR5IGxpc3Qgb2YgcGFyc2Ugbm9kZXMsIGRldGVybWluZWQgYnkgdGhlIHBhcnNlRm4uXG4gICAqIFRoaXMgbGlzdCBiZWdpbnMgd2l0aCBhIGxleCB0b2tlbiBvZiBvcGVuS2luZCBhbmQgZW5kcyB3aXRoIGEgbGV4IHRva2VuIG9mIGNsb3NlS2luZC5cbiAgICogQWR2YW5jZXMgdGhlIHBhcnNlciB0byB0aGUgbmV4dCBsZXggdG9rZW4gYWZ0ZXIgdGhlIGNsb3NpbmcgdG9rZW4uXG4gICAqL1xuICBtYW55KG9wZW5LaW5kLCBwYXJzZUZuLCBjbG9zZUtpbmQpIHtcbiAgICB0aGlzLmV4cGVjdFRva2VuKG9wZW5LaW5kKTtcbiAgICBjb25zdCBub2RlcyA9IFtdO1xuICAgIGRvIHtcbiAgICAgIG5vZGVzLnB1c2gocGFyc2VGbi5jYWxsKHRoaXMpKTtcbiAgICB9IHdoaWxlICghdGhpcy5leHBlY3RPcHRpb25hbFRva2VuKGNsb3NlS2luZCkpO1xuICAgIHJldHVybiBub2RlcztcbiAgfVxuICAvKipcbiAgICogUmV0dXJucyBhIG5vbi1lbXB0eSBsaXN0IG9mIHBhcnNlIG5vZGVzLCBkZXRlcm1pbmVkIGJ5IHRoZSBwYXJzZUZuLlxuICAgKiBUaGlzIGxpc3QgbWF5IGJlZ2luIHdpdGggYSBsZXggdG9rZW4gb2YgZGVsaW1pdGVyS2luZCBmb2xsb3dlZCBieSBpdGVtcyBzZXBhcmF0ZWQgYnkgbGV4IHRva2VucyBvZiB0b2tlbktpbmQuXG4gICAqIEFkdmFuY2VzIHRoZSBwYXJzZXIgdG8gdGhlIG5leHQgbGV4IHRva2VuIGFmdGVyIGxhc3QgaXRlbSBpbiB0aGUgbGlzdC5cbiAgICovXG4gIGRlbGltaXRlZE1hbnkoZGVsaW1pdGVyS2luZCwgcGFyc2VGbikge1xuICAgIHRoaXMuZXhwZWN0T3B0aW9uYWxUb2tlbihkZWxpbWl0ZXJLaW5kKTtcbiAgICBjb25zdCBub2RlcyA9IFtdO1xuICAgIGRvIHtcbiAgICAgIG5vZGVzLnB1c2gocGFyc2VGbi5jYWxsKHRoaXMpKTtcbiAgICB9IHdoaWxlICh0aGlzLmV4cGVjdE9wdGlvbmFsVG9rZW4oZGVsaW1pdGVyS2luZCkpO1xuICAgIHJldHVybiBub2RlcztcbiAgfVxuICBhZHZhbmNlTGV4ZXIoKSB7XG4gICAgY29uc3QgeyBtYXhUb2tlbnMgfSA9IHRoaXMuX29wdGlvbnM7XG4gICAgY29uc3QgdG9rZW4gPSB0aGlzLl9sZXhlci5hZHZhbmNlKCk7XG4gICAgaWYgKG1heFRva2VucyAhPT0gdm9pZCAwICYmIHRva2VuLmtpbmQgIT09IFRva2VuS2luZC5FT0YpIHtcbiAgICAgICsrdGhpcy5fdG9rZW5Db3VudGVyO1xuICAgICAgaWYgKHRoaXMuX3Rva2VuQ291bnRlciA+IG1heFRva2Vucykge1xuICAgICAgICB0aHJvdyBzeW50YXhFcnJvcihcbiAgICAgICAgICB0aGlzLl9sZXhlci5zb3VyY2UsXG4gICAgICAgICAgdG9rZW4uc3RhcnQsXG4gICAgICAgICAgYERvY3VtZW50IGNvbnRhaW5zIG1vcmUgdGhhdCAke21heFRva2Vuc30gdG9rZW5zLiBQYXJzaW5nIGFib3J0ZWQuYFxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cbiAgfVxufTtcbmZ1bmN0aW9uIGdldFRva2VuRGVzYyh0b2tlbikge1xuICBjb25zdCB2YWx1ZSA9IHRva2VuLnZhbHVlO1xuICByZXR1cm4gZ2V0VG9rZW5LaW5kRGVzYyh0b2tlbi5raW5kKSArICh2YWx1ZSAhPSBudWxsID8gYCBcIiR7dmFsdWV9XCJgIDogXCJcIik7XG59XG5mdW5jdGlvbiBnZXRUb2tlbktpbmREZXNjKGtpbmQpIHtcbiAgcmV0dXJuIGlzUHVuY3R1YXRvclRva2VuS2luZChraW5kKSA/IGBcIiR7a2luZH1cImAgOiBraW5kO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvanN1dGlscy9kaWRZb3VNZWFuLm1qc1xudmFyIE1BWF9TVUdHRVNUSU9OUyA9IDU7XG5mdW5jdGlvbiBkaWRZb3VNZWFuKGZpcnN0QXJnLCBzZWNvbmRBcmcpIHtcbiAgY29uc3QgW3N1Yk1lc3NhZ2UsIHN1Z2dlc3Rpb25zQXJnXSA9IHNlY29uZEFyZyA/IFtmaXJzdEFyZywgc2Vjb25kQXJnXSA6IFt2b2lkIDAsIGZpcnN0QXJnXTtcbiAgbGV0IG1lc3NhZ2UzID0gXCIgRGlkIHlvdSBtZWFuIFwiO1xuICBpZiAoc3ViTWVzc2FnZSkge1xuICAgIG1lc3NhZ2UzICs9IHN1Yk1lc3NhZ2UgKyBcIiBcIjtcbiAgfVxuICBjb25zdCBzdWdnZXN0aW9ucyA9IHN1Z2dlc3Rpb25zQXJnLm1hcCgoeCkgPT4gYFwiJHt4fVwiYCk7XG4gIHN3aXRjaCAoc3VnZ2VzdGlvbnMubGVuZ3RoKSB7XG4gICAgY2FzZSAwOlxuICAgICAgcmV0dXJuIFwiXCI7XG4gICAgY2FzZSAxOlxuICAgICAgcmV0dXJuIG1lc3NhZ2UzICsgc3VnZ2VzdGlvbnNbMF0gKyBcIj9cIjtcbiAgICBjYXNlIDI6XG4gICAgICByZXR1cm4gbWVzc2FnZTMgKyBzdWdnZXN0aW9uc1swXSArIFwiIG9yIFwiICsgc3VnZ2VzdGlvbnNbMV0gKyBcIj9cIjtcbiAgfVxuICBjb25zdCBzZWxlY3RlZCA9IHN1Z2dlc3Rpb25zLnNsaWNlKDAsIE1BWF9TVUdHRVNUSU9OUyk7XG4gIGNvbnN0IGxhc3RJdGVtID0gc2VsZWN0ZWQucG9wKCk7XG4gIHJldHVybiBtZXNzYWdlMyArIHNlbGVjdGVkLmpvaW4oXCIsIFwiKSArIFwiLCBvciBcIiArIGxhc3RJdGVtICsgXCI/XCI7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC9qc3V0aWxzL2lkZW50aXR5RnVuYy5tanNcbmZ1bmN0aW9uIGlkZW50aXR5RnVuYyh4KSB7XG4gIHJldHVybiB4O1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvanN1dGlscy9rZXlNYXAubWpzXG5mdW5jdGlvbiBrZXlNYXAobGlzdCwga2V5Rm4pIHtcbiAgY29uc3QgcmVzdWx0ID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIGZvciAoY29uc3QgaXRlbSBvZiBsaXN0KSB7XG4gICAgcmVzdWx0W2tleUZuKGl0ZW0pXSA9IGl0ZW07XG4gIH1cbiAgcmV0dXJuIHJlc3VsdDtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL2pzdXRpbHMva2V5VmFsTWFwLm1qc1xuZnVuY3Rpb24ga2V5VmFsTWFwKGxpc3QsIGtleUZuLCB2YWxGbikge1xuICBjb25zdCByZXN1bHQgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgZm9yIChjb25zdCBpdGVtIG9mIGxpc3QpIHtcbiAgICByZXN1bHRba2V5Rm4oaXRlbSldID0gdmFsRm4oaXRlbSk7XG4gIH1cbiAgcmV0dXJuIHJlc3VsdDtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL2pzdXRpbHMvbWFwVmFsdWUubWpzXG5mdW5jdGlvbiBtYXBWYWx1ZShtYXAsIGZuKSB7XG4gIGNvbnN0IHJlc3VsdCA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICBmb3IgKGNvbnN0IGtleSBvZiBPYmplY3Qua2V5cyhtYXApKSB7XG4gICAgcmVzdWx0W2tleV0gPSBmbihtYXBba2V5XSwga2V5KTtcbiAgfVxuICByZXR1cm4gcmVzdWx0O1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvanN1dGlscy9uYXR1cmFsQ29tcGFyZS5tanNcbmZ1bmN0aW9uIG5hdHVyYWxDb21wYXJlKGFTdHIsIGJTdHIpIHtcbiAgbGV0IGFJbmRleCA9IDA7XG4gIGxldCBiSW5kZXggPSAwO1xuICB3aGlsZSAoYUluZGV4IDwgYVN0ci5sZW5ndGggJiYgYkluZGV4IDwgYlN0ci5sZW5ndGgpIHtcbiAgICBsZXQgYUNoYXIgPSBhU3RyLmNoYXJDb2RlQXQoYUluZGV4KTtcbiAgICBsZXQgYkNoYXIgPSBiU3RyLmNoYXJDb2RlQXQoYkluZGV4KTtcbiAgICBpZiAoaXNEaWdpdDIoYUNoYXIpICYmIGlzRGlnaXQyKGJDaGFyKSkge1xuICAgICAgbGV0IGFOdW0gPSAwO1xuICAgICAgZG8ge1xuICAgICAgICArK2FJbmRleDtcbiAgICAgICAgYU51bSA9IGFOdW0gKiAxMCArIGFDaGFyIC0gRElHSVRfMDtcbiAgICAgICAgYUNoYXIgPSBhU3RyLmNoYXJDb2RlQXQoYUluZGV4KTtcbiAgICAgIH0gd2hpbGUgKGlzRGlnaXQyKGFDaGFyKSAmJiBhTnVtID4gMCk7XG4gICAgICBsZXQgYk51bSA9IDA7XG4gICAgICBkbyB7XG4gICAgICAgICsrYkluZGV4O1xuICAgICAgICBiTnVtID0gYk51bSAqIDEwICsgYkNoYXIgLSBESUdJVF8wO1xuICAgICAgICBiQ2hhciA9IGJTdHIuY2hhckNvZGVBdChiSW5kZXgpO1xuICAgICAgfSB3aGlsZSAoaXNEaWdpdDIoYkNoYXIpICYmIGJOdW0gPiAwKTtcbiAgICAgIGlmIChhTnVtIDwgYk51bSkge1xuICAgICAgICByZXR1cm4gLTE7XG4gICAgICB9XG4gICAgICBpZiAoYU51bSA+IGJOdW0pIHtcbiAgICAgICAgcmV0dXJuIDE7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmIChhQ2hhciA8IGJDaGFyKSB7XG4gICAgICAgIHJldHVybiAtMTtcbiAgICAgIH1cbiAgICAgIGlmIChhQ2hhciA+IGJDaGFyKSB7XG4gICAgICAgIHJldHVybiAxO1xuICAgICAgfVxuICAgICAgKythSW5kZXg7XG4gICAgICArK2JJbmRleDtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGFTdHIubGVuZ3RoIC0gYlN0ci5sZW5ndGg7XG59XG52YXIgRElHSVRfMCA9IDQ4O1xudmFyIERJR0lUXzkgPSA1NztcbmZ1bmN0aW9uIGlzRGlnaXQyKGNvZGUpIHtcbiAgcmV0dXJuICFpc05hTihjb2RlKSAmJiBESUdJVF8wIDw9IGNvZGUgJiYgY29kZSA8PSBESUdJVF85O1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvanN1dGlscy9zdWdnZXN0aW9uTGlzdC5tanNcbmZ1bmN0aW9uIHN1Z2dlc3Rpb25MaXN0KGlucHV0LCBvcHRpb25zKSB7XG4gIGNvbnN0IG9wdGlvbnNCeURpc3RhbmNlID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIGNvbnN0IGxleGljYWxEaXN0YW5jZSA9IG5ldyBMZXhpY2FsRGlzdGFuY2UoaW5wdXQpO1xuICBjb25zdCB0aHJlc2hvbGQgPSBNYXRoLmZsb29yKGlucHV0Lmxlbmd0aCAqIDAuNCkgKyAxO1xuICBmb3IgKGNvbnN0IG9wdGlvbiBvZiBvcHRpb25zKSB7XG4gICAgY29uc3QgZGlzdGFuY2UgPSBsZXhpY2FsRGlzdGFuY2UubWVhc3VyZShvcHRpb24sIHRocmVzaG9sZCk7XG4gICAgaWYgKGRpc3RhbmNlICE9PSB2b2lkIDApIHtcbiAgICAgIG9wdGlvbnNCeURpc3RhbmNlW29wdGlvbl0gPSBkaXN0YW5jZTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIE9iamVjdC5rZXlzKG9wdGlvbnNCeURpc3RhbmNlKS5zb3J0KChhLCBiKSA9PiB7XG4gICAgY29uc3QgZGlzdGFuY2VEaWZmID0gb3B0aW9uc0J5RGlzdGFuY2VbYV0gLSBvcHRpb25zQnlEaXN0YW5jZVtiXTtcbiAgICByZXR1cm4gZGlzdGFuY2VEaWZmICE9PSAwID8gZGlzdGFuY2VEaWZmIDogbmF0dXJhbENvbXBhcmUoYSwgYik7XG4gIH0pO1xufVxudmFyIExleGljYWxEaXN0YW5jZSA9IGNsYXNzIHtcbiAgY29uc3RydWN0b3IoaW5wdXQpIHtcbiAgICB0aGlzLl9pbnB1dCA9IGlucHV0O1xuICAgIHRoaXMuX2lucHV0TG93ZXJDYXNlID0gaW5wdXQudG9Mb3dlckNhc2UoKTtcbiAgICB0aGlzLl9pbnB1dEFycmF5ID0gc3RyaW5nVG9BcnJheSh0aGlzLl9pbnB1dExvd2VyQ2FzZSk7XG4gICAgdGhpcy5fcm93cyA9IFtcbiAgICAgIG5ldyBBcnJheShpbnB1dC5sZW5ndGggKyAxKS5maWxsKDApLFxuICAgICAgbmV3IEFycmF5KGlucHV0Lmxlbmd0aCArIDEpLmZpbGwoMCksXG4gICAgICBuZXcgQXJyYXkoaW5wdXQubGVuZ3RoICsgMSkuZmlsbCgwKVxuICAgIF07XG4gIH1cbiAgbWVhc3VyZShvcHRpb24sIHRocmVzaG9sZCkge1xuICAgIGlmICh0aGlzLl9pbnB1dCA9PT0gb3B0aW9uKSB7XG4gICAgICByZXR1cm4gMDtcbiAgICB9XG4gICAgY29uc3Qgb3B0aW9uTG93ZXJDYXNlID0gb3B0aW9uLnRvTG93ZXJDYXNlKCk7XG4gICAgaWYgKHRoaXMuX2lucHV0TG93ZXJDYXNlID09PSBvcHRpb25Mb3dlckNhc2UpIHtcbiAgICAgIHJldHVybiAxO1xuICAgIH1cbiAgICBsZXQgYSA9IHN0cmluZ1RvQXJyYXkob3B0aW9uTG93ZXJDYXNlKTtcbiAgICBsZXQgYiA9IHRoaXMuX2lucHV0QXJyYXk7XG4gICAgaWYgKGEubGVuZ3RoIDwgYi5sZW5ndGgpIHtcbiAgICAgIGNvbnN0IHRtcCA9IGE7XG4gICAgICBhID0gYjtcbiAgICAgIGIgPSB0bXA7XG4gICAgfVxuICAgIGNvbnN0IGFMZW5ndGggPSBhLmxlbmd0aDtcbiAgICBjb25zdCBiTGVuZ3RoID0gYi5sZW5ndGg7XG4gICAgaWYgKGFMZW5ndGggLSBiTGVuZ3RoID4gdGhyZXNob2xkKSB7XG4gICAgICByZXR1cm4gdm9pZCAwO1xuICAgIH1cbiAgICBjb25zdCByb3dzID0gdGhpcy5fcm93cztcbiAgICBmb3IgKGxldCBqID0gMDsgaiA8PSBiTGVuZ3RoOyBqKyspIHtcbiAgICAgIHJvd3NbMF1bal0gPSBqO1xuICAgIH1cbiAgICBmb3IgKGxldCBpID0gMTsgaSA8PSBhTGVuZ3RoOyBpKyspIHtcbiAgICAgIGNvbnN0IHVwUm93ID0gcm93c1soaSAtIDEpICUgM107XG4gICAgICBjb25zdCBjdXJyZW50Um93ID0gcm93c1tpICUgM107XG4gICAgICBsZXQgc21hbGxlc3RDZWxsID0gY3VycmVudFJvd1swXSA9IGk7XG4gICAgICBmb3IgKGxldCBqID0gMTsgaiA8PSBiTGVuZ3RoOyBqKyspIHtcbiAgICAgICAgY29uc3QgY29zdCA9IGFbaSAtIDFdID09PSBiW2ogLSAxXSA/IDAgOiAxO1xuICAgICAgICBsZXQgY3VycmVudENlbGwgPSBNYXRoLm1pbihcbiAgICAgICAgICB1cFJvd1tqXSArIDEsXG4gICAgICAgICAgLy8gZGVsZXRlXG4gICAgICAgICAgY3VycmVudFJvd1tqIC0gMV0gKyAxLFxuICAgICAgICAgIC8vIGluc2VydFxuICAgICAgICAgIHVwUm93W2ogLSAxXSArIGNvc3RcbiAgICAgICAgICAvLyBzdWJzdGl0dXRlXG4gICAgICAgICk7XG4gICAgICAgIGlmIChpID4gMSAmJiBqID4gMSAmJiBhW2kgLSAxXSA9PT0gYltqIC0gMl0gJiYgYVtpIC0gMl0gPT09IGJbaiAtIDFdKSB7XG4gICAgICAgICAgY29uc3QgZG91YmxlRGlhZ29uYWxDZWxsID0gcm93c1soaSAtIDIpICUgM11baiAtIDJdO1xuICAgICAgICAgIGN1cnJlbnRDZWxsID0gTWF0aC5taW4oY3VycmVudENlbGwsIGRvdWJsZURpYWdvbmFsQ2VsbCArIDEpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChjdXJyZW50Q2VsbCA8IHNtYWxsZXN0Q2VsbCkge1xuICAgICAgICAgIHNtYWxsZXN0Q2VsbCA9IGN1cnJlbnRDZWxsO1xuICAgICAgICB9XG4gICAgICAgIGN1cnJlbnRSb3dbal0gPSBjdXJyZW50Q2VsbDtcbiAgICAgIH1cbiAgICAgIGlmIChzbWFsbGVzdENlbGwgPiB0aHJlc2hvbGQpIHtcbiAgICAgICAgcmV0dXJuIHZvaWQgMDtcbiAgICAgIH1cbiAgICB9XG4gICAgY29uc3QgZGlzdGFuY2UgPSByb3dzW2FMZW5ndGggJSAzXVtiTGVuZ3RoXTtcbiAgICByZXR1cm4gZGlzdGFuY2UgPD0gdGhyZXNob2xkID8gZGlzdGFuY2UgOiB2b2lkIDA7XG4gIH1cbn07XG5mdW5jdGlvbiBzdHJpbmdUb0FycmF5KHN0cikge1xuICBjb25zdCBzdHJMZW5ndGggPSBzdHIubGVuZ3RoO1xuICBjb25zdCBhcnJheSA9IG5ldyBBcnJheShzdHJMZW5ndGgpO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IHN0ckxlbmd0aDsgKytpKSB7XG4gICAgYXJyYXlbaV0gPSBzdHIuY2hhckNvZGVBdChpKTtcbiAgfVxuICByZXR1cm4gYXJyYXk7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC9qc3V0aWxzL3RvT2JqTWFwLm1qc1xuZnVuY3Rpb24gdG9PYmpNYXAob2JqKSB7XG4gIGlmIChvYmogPT0gbnVsbCkge1xuICAgIHJldHVybiAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgfVxuICBpZiAoT2JqZWN0LmdldFByb3RvdHlwZU9mKG9iaikgPT09IG51bGwpIHtcbiAgICByZXR1cm4gb2JqO1xuICB9XG4gIGNvbnN0IG1hcCA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICBmb3IgKGNvbnN0IFtrZXksIHZhbHVlXSBvZiBPYmplY3QuZW50cmllcyhvYmopKSB7XG4gICAgbWFwW2tleV0gPSB2YWx1ZTtcbiAgfVxuICByZXR1cm4gbWFwO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvbGFuZ3VhZ2UvcHJpbnRTdHJpbmcubWpzXG5mdW5jdGlvbiBwcmludFN0cmluZyhzdHIpIHtcbiAgcmV0dXJuIGBcIiR7c3RyLnJlcGxhY2UoZXNjYXBlZFJlZ0V4cCwgZXNjYXBlZFJlcGxhY2VyKX1cImA7XG59XG52YXIgZXNjYXBlZFJlZ0V4cCA9IC9bXFx4MDAtXFx4MWZcXHgyMlxceDVjXFx4N2YtXFx4OWZdL2c7XG5mdW5jdGlvbiBlc2NhcGVkUmVwbGFjZXIoc3RyKSB7XG4gIHJldHVybiBlc2NhcGVTZXF1ZW5jZXNbc3RyLmNoYXJDb2RlQXQoMCldO1xufVxudmFyIGVzY2FwZVNlcXVlbmNlcyA9IFtcbiAgXCJcXFxcdTAwMDBcIixcbiAgXCJcXFxcdTAwMDFcIixcbiAgXCJcXFxcdTAwMDJcIixcbiAgXCJcXFxcdTAwMDNcIixcbiAgXCJcXFxcdTAwMDRcIixcbiAgXCJcXFxcdTAwMDVcIixcbiAgXCJcXFxcdTAwMDZcIixcbiAgXCJcXFxcdTAwMDdcIixcbiAgXCJcXFxcYlwiLFxuICBcIlxcXFx0XCIsXG4gIFwiXFxcXG5cIixcbiAgXCJcXFxcdTAwMEJcIixcbiAgXCJcXFxcZlwiLFxuICBcIlxcXFxyXCIsXG4gIFwiXFxcXHUwMDBFXCIsXG4gIFwiXFxcXHUwMDBGXCIsXG4gIFwiXFxcXHUwMDEwXCIsXG4gIFwiXFxcXHUwMDExXCIsXG4gIFwiXFxcXHUwMDEyXCIsXG4gIFwiXFxcXHUwMDEzXCIsXG4gIFwiXFxcXHUwMDE0XCIsXG4gIFwiXFxcXHUwMDE1XCIsXG4gIFwiXFxcXHUwMDE2XCIsXG4gIFwiXFxcXHUwMDE3XCIsXG4gIFwiXFxcXHUwMDE4XCIsXG4gIFwiXFxcXHUwMDE5XCIsXG4gIFwiXFxcXHUwMDFBXCIsXG4gIFwiXFxcXHUwMDFCXCIsXG4gIFwiXFxcXHUwMDFDXCIsXG4gIFwiXFxcXHUwMDFEXCIsXG4gIFwiXFxcXHUwMDFFXCIsXG4gIFwiXFxcXHUwMDFGXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gICdcXFxcXCInLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICAvLyAyRlxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICAvLyAzRlxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICAvLyA0RlxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlwiLFxuICBcIlxcXFxcXFxcXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIC8vIDVGXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIC8vIDZGXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXFxcXHUwMDdGXCIsXG4gIFwiXFxcXHUwMDgwXCIsXG4gIFwiXFxcXHUwMDgxXCIsXG4gIFwiXFxcXHUwMDgyXCIsXG4gIFwiXFxcXHUwMDgzXCIsXG4gIFwiXFxcXHUwMDg0XCIsXG4gIFwiXFxcXHUwMDg1XCIsXG4gIFwiXFxcXHUwMDg2XCIsXG4gIFwiXFxcXHUwMDg3XCIsXG4gIFwiXFxcXHUwMDg4XCIsXG4gIFwiXFxcXHUwMDg5XCIsXG4gIFwiXFxcXHUwMDhBXCIsXG4gIFwiXFxcXHUwMDhCXCIsXG4gIFwiXFxcXHUwMDhDXCIsXG4gIFwiXFxcXHUwMDhEXCIsXG4gIFwiXFxcXHUwMDhFXCIsXG4gIFwiXFxcXHUwMDhGXCIsXG4gIFwiXFxcXHUwMDkwXCIsXG4gIFwiXFxcXHUwMDkxXCIsXG4gIFwiXFxcXHUwMDkyXCIsXG4gIFwiXFxcXHUwMDkzXCIsXG4gIFwiXFxcXHUwMDk0XCIsXG4gIFwiXFxcXHUwMDk1XCIsXG4gIFwiXFxcXHUwMDk2XCIsXG4gIFwiXFxcXHUwMDk3XCIsXG4gIFwiXFxcXHUwMDk4XCIsXG4gIFwiXFxcXHUwMDk5XCIsXG4gIFwiXFxcXHUwMDlBXCIsXG4gIFwiXFxcXHUwMDlCXCIsXG4gIFwiXFxcXHUwMDlDXCIsXG4gIFwiXFxcXHUwMDlEXCIsXG4gIFwiXFxcXHUwMDlFXCIsXG4gIFwiXFxcXHUwMDlGXCJcbl07XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC9sYW5ndWFnZS92aXNpdG9yLm1qc1xudmFyIEJSRUFLID0gT2JqZWN0LmZyZWV6ZSh7fSk7XG5mdW5jdGlvbiB2aXNpdChyb290LCB2aXNpdG9yLCB2aXNpdG9yS2V5cyA9IFF1ZXJ5RG9jdW1lbnRLZXlzKSB7XG4gIGNvbnN0IGVudGVyTGVhdmVNYXAgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuICBmb3IgKGNvbnN0IGtpbmQgb2YgT2JqZWN0LnZhbHVlcyhLaW5kKSkge1xuICAgIGVudGVyTGVhdmVNYXAuc2V0KGtpbmQsIGdldEVudGVyTGVhdmVGb3JLaW5kKHZpc2l0b3IsIGtpbmQpKTtcbiAgfVxuICBsZXQgc3RhY2sgPSB2b2lkIDA7XG4gIGxldCBpbkFycmF5ID0gQXJyYXkuaXNBcnJheShyb290KTtcbiAgbGV0IGtleXMgPSBbcm9vdF07XG4gIGxldCBpbmRleCA9IC0xO1xuICBsZXQgZWRpdHMgPSBbXTtcbiAgbGV0IG5vZGUgPSByb290O1xuICBsZXQga2V5ID0gdm9pZCAwO1xuICBsZXQgcGFyZW50ID0gdm9pZCAwO1xuICBjb25zdCBwYXRoID0gW107XG4gIGNvbnN0IGFuY2VzdG9ycyA9IFtdO1xuICBkbyB7XG4gICAgaW5kZXgrKztcbiAgICBjb25zdCBpc0xlYXZpbmcgPSBpbmRleCA9PT0ga2V5cy5sZW5ndGg7XG4gICAgY29uc3QgaXNFZGl0ZWQgPSBpc0xlYXZpbmcgJiYgZWRpdHMubGVuZ3RoICE9PSAwO1xuICAgIGlmIChpc0xlYXZpbmcpIHtcbiAgICAgIGtleSA9IGFuY2VzdG9ycy5sZW5ndGggPT09IDAgPyB2b2lkIDAgOiBwYXRoW3BhdGgubGVuZ3RoIC0gMV07XG4gICAgICBub2RlID0gcGFyZW50O1xuICAgICAgcGFyZW50ID0gYW5jZXN0b3JzLnBvcCgpO1xuICAgICAgaWYgKGlzRWRpdGVkKSB7XG4gICAgICAgIGlmIChpbkFycmF5KSB7XG4gICAgICAgICAgbm9kZSA9IG5vZGUuc2xpY2UoKTtcbiAgICAgICAgICBsZXQgZWRpdE9mZnNldCA9IDA7XG4gICAgICAgICAgZm9yIChjb25zdCBbZWRpdEtleSwgZWRpdFZhbHVlXSBvZiBlZGl0cykge1xuICAgICAgICAgICAgY29uc3QgYXJyYXlLZXkgPSBlZGl0S2V5IC0gZWRpdE9mZnNldDtcbiAgICAgICAgICAgIGlmIChlZGl0VmFsdWUgPT09IG51bGwpIHtcbiAgICAgICAgICAgICAgbm9kZS5zcGxpY2UoYXJyYXlLZXksIDEpO1xuICAgICAgICAgICAgICBlZGl0T2Zmc2V0Kys7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICBub2RlW2FycmF5S2V5XSA9IGVkaXRWYWx1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgbm9kZSA9IE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKFxuICAgICAgICAgICAge30sXG4gICAgICAgICAgICBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyhub2RlKVxuICAgICAgICAgICk7XG4gICAgICAgICAgZm9yIChjb25zdCBbZWRpdEtleSwgZWRpdFZhbHVlXSBvZiBlZGl0cykge1xuICAgICAgICAgICAgbm9kZVtlZGl0S2V5XSA9IGVkaXRWYWx1ZTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGluZGV4ID0gc3RhY2suaW5kZXg7XG4gICAgICBrZXlzID0gc3RhY2sua2V5cztcbiAgICAgIGVkaXRzID0gc3RhY2suZWRpdHM7XG4gICAgICBpbkFycmF5ID0gc3RhY2suaW5BcnJheTtcbiAgICAgIHN0YWNrID0gc3RhY2sucHJldjtcbiAgICB9IGVsc2UgaWYgKHBhcmVudCkge1xuICAgICAga2V5ID0gaW5BcnJheSA/IGluZGV4IDoga2V5c1tpbmRleF07XG4gICAgICBub2RlID0gcGFyZW50W2tleV07XG4gICAgICBpZiAobm9kZSA9PT0gbnVsbCB8fCBub2RlID09PSB2b2lkIDApIHtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG4gICAgICBwYXRoLnB1c2goa2V5KTtcbiAgICB9XG4gICAgbGV0IHJlc3VsdDtcbiAgICBpZiAoIUFycmF5LmlzQXJyYXkobm9kZSkpIHtcbiAgICAgIHZhciBfZW50ZXJMZWF2ZU1hcCRnZXQsIF9lbnRlckxlYXZlTWFwJGdldDI7XG4gICAgICBpc05vZGUobm9kZSkgfHwgZGV2QXNzZXJ0KGZhbHNlLCBgSW52YWxpZCBBU1QgTm9kZTogJHtpbnNwZWN0KG5vZGUpfS5gKTtcbiAgICAgIGNvbnN0IHZpc2l0Rm4gPSBpc0xlYXZpbmcgPyAoX2VudGVyTGVhdmVNYXAkZ2V0ID0gZW50ZXJMZWF2ZU1hcC5nZXQobm9kZS5raW5kKSkgPT09IG51bGwgfHwgX2VudGVyTGVhdmVNYXAkZ2V0ID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfZW50ZXJMZWF2ZU1hcCRnZXQubGVhdmUgOiAoX2VudGVyTGVhdmVNYXAkZ2V0MiA9IGVudGVyTGVhdmVNYXAuZ2V0KG5vZGUua2luZCkpID09PSBudWxsIHx8IF9lbnRlckxlYXZlTWFwJGdldDIgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9lbnRlckxlYXZlTWFwJGdldDIuZW50ZXI7XG4gICAgICByZXN1bHQgPSB2aXNpdEZuID09PSBudWxsIHx8IHZpc2l0Rm4gPT09IHZvaWQgMCA/IHZvaWQgMCA6IHZpc2l0Rm4uY2FsbCh2aXNpdG9yLCBub2RlLCBrZXksIHBhcmVudCwgcGF0aCwgYW5jZXN0b3JzKTtcbiAgICAgIGlmIChyZXN1bHQgPT09IEJSRUFLKSB7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgaWYgKHJlc3VsdCA9PT0gZmFsc2UpIHtcbiAgICAgICAgaWYgKCFpc0xlYXZpbmcpIHtcbiAgICAgICAgICBwYXRoLnBvcCgpO1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKHJlc3VsdCAhPT0gdm9pZCAwKSB7XG4gICAgICAgIGVkaXRzLnB1c2goW2tleSwgcmVzdWx0XSk7XG4gICAgICAgIGlmICghaXNMZWF2aW5nKSB7XG4gICAgICAgICAgaWYgKGlzTm9kZShyZXN1bHQpKSB7XG4gICAgICAgICAgICBub2RlID0gcmVzdWx0O1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBwYXRoLnBvcCgpO1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChyZXN1bHQgPT09IHZvaWQgMCAmJiBpc0VkaXRlZCkge1xuICAgICAgZWRpdHMucHVzaChba2V5LCBub2RlXSk7XG4gICAgfVxuICAgIGlmIChpc0xlYXZpbmcpIHtcbiAgICAgIHBhdGgucG9wKCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHZhciBfbm9kZSRraW5kO1xuICAgICAgc3RhY2sgPSB7XG4gICAgICAgIGluQXJyYXksXG4gICAgICAgIGluZGV4LFxuICAgICAgICBrZXlzLFxuICAgICAgICBlZGl0cyxcbiAgICAgICAgcHJldjogc3RhY2tcbiAgICAgIH07XG4gICAgICBpbkFycmF5ID0gQXJyYXkuaXNBcnJheShub2RlKTtcbiAgICAgIGtleXMgPSBpbkFycmF5ID8gbm9kZSA6IChfbm9kZSRraW5kID0gdmlzaXRvcktleXNbbm9kZS5raW5kXSkgIT09IG51bGwgJiYgX25vZGUka2luZCAhPT0gdm9pZCAwID8gX25vZGUka2luZCA6IFtdO1xuICAgICAgaW5kZXggPSAtMTtcbiAgICAgIGVkaXRzID0gW107XG4gICAgICBpZiAocGFyZW50KSB7XG4gICAgICAgIGFuY2VzdG9ycy5wdXNoKHBhcmVudCk7XG4gICAgICB9XG4gICAgICBwYXJlbnQgPSBub2RlO1xuICAgIH1cbiAgfSB3aGlsZSAoc3RhY2sgIT09IHZvaWQgMCk7XG4gIGlmIChlZGl0cy5sZW5ndGggIT09IDApIHtcbiAgICByZXR1cm4gZWRpdHNbZWRpdHMubGVuZ3RoIC0gMV1bMV07XG4gIH1cbiAgcmV0dXJuIHJvb3Q7XG59XG5mdW5jdGlvbiBnZXRFbnRlckxlYXZlRm9yS2luZCh2aXNpdG9yLCBraW5kKSB7XG4gIGNvbnN0IGtpbmRWaXNpdG9yID0gdmlzaXRvcltraW5kXTtcbiAgaWYgKHR5cGVvZiBraW5kVmlzaXRvciA9PT0gXCJvYmplY3RcIikge1xuICAgIHJldHVybiBraW5kVmlzaXRvcjtcbiAgfSBlbHNlIGlmICh0eXBlb2Yga2luZFZpc2l0b3IgPT09IFwiZnVuY3Rpb25cIikge1xuICAgIHJldHVybiB7XG4gICAgICBlbnRlcjoga2luZFZpc2l0b3IsXG4gICAgICBsZWF2ZTogdm9pZCAwXG4gICAgfTtcbiAgfVxuICByZXR1cm4ge1xuICAgIGVudGVyOiB2aXNpdG9yLmVudGVyLFxuICAgIGxlYXZlOiB2aXNpdG9yLmxlYXZlXG4gIH07XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC9sYW5ndWFnZS9wcmludGVyLm1qc1xuZnVuY3Rpb24gcHJpbnQoYXN0KSB7XG4gIHJldHVybiB2aXNpdChhc3QsIHByaW50RG9jQVNUUmVkdWNlcik7XG59XG52YXIgTUFYX0xJTkVfTEVOR1RIID0gODA7XG52YXIgcHJpbnREb2NBU1RSZWR1Y2VyID0ge1xuICBOYW1lOiB7XG4gICAgbGVhdmU6IChub2RlKSA9PiBub2RlLnZhbHVlXG4gIH0sXG4gIFZhcmlhYmxlOiB7XG4gICAgbGVhdmU6IChub2RlKSA9PiBcIiRcIiArIG5vZGUubmFtZVxuICB9LFxuICAvLyBEb2N1bWVudFxuICBEb2N1bWVudDoge1xuICAgIGxlYXZlOiAobm9kZSkgPT4gam9pbihub2RlLmRlZmluaXRpb25zLCBcIlxcblxcblwiKVxuICB9LFxuICBPcGVyYXRpb25EZWZpbml0aW9uOiB7XG4gICAgbGVhdmUobm9kZSkge1xuICAgICAgY29uc3QgdmFyRGVmcyA9IHdyYXAoXCIoXCIsIGpvaW4obm9kZS52YXJpYWJsZURlZmluaXRpb25zLCBcIiwgXCIpLCBcIilcIik7XG4gICAgICBjb25zdCBwcmVmaXggPSBqb2luKFxuICAgICAgICBbXG4gICAgICAgICAgbm9kZS5vcGVyYXRpb24sXG4gICAgICAgICAgam9pbihbbm9kZS5uYW1lLCB2YXJEZWZzXSksXG4gICAgICAgICAgam9pbihub2RlLmRpcmVjdGl2ZXMsIFwiIFwiKVxuICAgICAgICBdLFxuICAgICAgICBcIiBcIlxuICAgICAgKTtcbiAgICAgIHJldHVybiAocHJlZml4ID09PSBcInF1ZXJ5XCIgPyBcIlwiIDogcHJlZml4ICsgXCIgXCIpICsgbm9kZS5zZWxlY3Rpb25TZXQ7XG4gICAgfVxuICB9LFxuICBWYXJpYWJsZURlZmluaXRpb246IHtcbiAgICBsZWF2ZTogKHsgdmFyaWFibGUsIHR5cGUsIGRlZmF1bHRWYWx1ZSwgZGlyZWN0aXZlcyB9KSA9PiB2YXJpYWJsZSArIFwiOiBcIiArIHR5cGUgKyB3cmFwKFwiID0gXCIsIGRlZmF1bHRWYWx1ZSkgKyB3cmFwKFwiIFwiLCBqb2luKGRpcmVjdGl2ZXMsIFwiIFwiKSlcbiAgfSxcbiAgU2VsZWN0aW9uU2V0OiB7XG4gICAgbGVhdmU6ICh7IHNlbGVjdGlvbnMgfSkgPT4gYmxvY2soc2VsZWN0aW9ucylcbiAgfSxcbiAgRmllbGQ6IHtcbiAgICBsZWF2ZSh7IGFsaWFzLCBuYW1lLCBhcmd1bWVudHM6IGFyZ3MsIGRpcmVjdGl2ZXMsIHNlbGVjdGlvblNldCB9KSB7XG4gICAgICBjb25zdCBwcmVmaXggPSB3cmFwKFwiXCIsIGFsaWFzLCBcIjogXCIpICsgbmFtZTtcbiAgICAgIGxldCBhcmdzTGluZSA9IHByZWZpeCArIHdyYXAoXCIoXCIsIGpvaW4oYXJncywgXCIsIFwiKSwgXCIpXCIpO1xuICAgICAgaWYgKGFyZ3NMaW5lLmxlbmd0aCA+IE1BWF9MSU5FX0xFTkdUSCkge1xuICAgICAgICBhcmdzTGluZSA9IHByZWZpeCArIHdyYXAoXCIoXFxuXCIsIGluZGVudChqb2luKGFyZ3MsIFwiXFxuXCIpKSwgXCJcXG4pXCIpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGpvaW4oW2FyZ3NMaW5lLCBqb2luKGRpcmVjdGl2ZXMsIFwiIFwiKSwgc2VsZWN0aW9uU2V0XSwgXCIgXCIpO1xuICAgIH1cbiAgfSxcbiAgQXJndW1lbnQ6IHtcbiAgICBsZWF2ZTogKHsgbmFtZSwgdmFsdWUgfSkgPT4gbmFtZSArIFwiOiBcIiArIHZhbHVlXG4gIH0sXG4gIC8vIEZyYWdtZW50c1xuICBGcmFnbWVudFNwcmVhZDoge1xuICAgIGxlYXZlOiAoeyBuYW1lLCBkaXJlY3RpdmVzIH0pID0+IFwiLi4uXCIgKyBuYW1lICsgd3JhcChcIiBcIiwgam9pbihkaXJlY3RpdmVzLCBcIiBcIikpXG4gIH0sXG4gIElubGluZUZyYWdtZW50OiB7XG4gICAgbGVhdmU6ICh7IHR5cGVDb25kaXRpb24sIGRpcmVjdGl2ZXMsIHNlbGVjdGlvblNldCB9KSA9PiBqb2luKFxuICAgICAgW1xuICAgICAgICBcIi4uLlwiLFxuICAgICAgICB3cmFwKFwib24gXCIsIHR5cGVDb25kaXRpb24pLFxuICAgICAgICBqb2luKGRpcmVjdGl2ZXMsIFwiIFwiKSxcbiAgICAgICAgc2VsZWN0aW9uU2V0XG4gICAgICBdLFxuICAgICAgXCIgXCJcbiAgICApXG4gIH0sXG4gIEZyYWdtZW50RGVmaW5pdGlvbjoge1xuICAgIGxlYXZlOiAoeyBuYW1lLCB0eXBlQ29uZGl0aW9uLCB2YXJpYWJsZURlZmluaXRpb25zLCBkaXJlY3RpdmVzLCBzZWxlY3Rpb25TZXQgfSkgPT4gKFxuICAgICAgLy8gb3IgcmVtb3ZlZCBpbiB0aGUgZnV0dXJlLlxuICAgICAgYGZyYWdtZW50ICR7bmFtZX0ke3dyYXAoXCIoXCIsIGpvaW4odmFyaWFibGVEZWZpbml0aW9ucywgXCIsIFwiKSwgXCIpXCIpfSBvbiAke3R5cGVDb25kaXRpb259ICR7d3JhcChcIlwiLCBqb2luKGRpcmVjdGl2ZXMsIFwiIFwiKSwgXCIgXCIpfWAgKyBzZWxlY3Rpb25TZXRcbiAgICApXG4gIH0sXG4gIC8vIFZhbHVlXG4gIEludFZhbHVlOiB7XG4gICAgbGVhdmU6ICh7IHZhbHVlIH0pID0+IHZhbHVlXG4gIH0sXG4gIEZsb2F0VmFsdWU6IHtcbiAgICBsZWF2ZTogKHsgdmFsdWUgfSkgPT4gdmFsdWVcbiAgfSxcbiAgU3RyaW5nVmFsdWU6IHtcbiAgICBsZWF2ZTogKHsgdmFsdWUsIGJsb2NrOiBpc0Jsb2NrU3RyaW5nIH0pID0+IGlzQmxvY2tTdHJpbmcgPyBwcmludEJsb2NrU3RyaW5nKHZhbHVlKSA6IHByaW50U3RyaW5nKHZhbHVlKVxuICB9LFxuICBCb29sZWFuVmFsdWU6IHtcbiAgICBsZWF2ZTogKHsgdmFsdWUgfSkgPT4gdmFsdWUgPyBcInRydWVcIiA6IFwiZmFsc2VcIlxuICB9LFxuICBOdWxsVmFsdWU6IHtcbiAgICBsZWF2ZTogKCkgPT4gXCJudWxsXCJcbiAgfSxcbiAgRW51bVZhbHVlOiB7XG4gICAgbGVhdmU6ICh7IHZhbHVlIH0pID0+IHZhbHVlXG4gIH0sXG4gIExpc3RWYWx1ZToge1xuICAgIGxlYXZlOiAoeyB2YWx1ZXMgfSkgPT4gXCJbXCIgKyBqb2luKHZhbHVlcywgXCIsIFwiKSArIFwiXVwiXG4gIH0sXG4gIE9iamVjdFZhbHVlOiB7XG4gICAgbGVhdmU6ICh7IGZpZWxkcyB9KSA9PiBcIntcIiArIGpvaW4oZmllbGRzLCBcIiwgXCIpICsgXCJ9XCJcbiAgfSxcbiAgT2JqZWN0RmllbGQ6IHtcbiAgICBsZWF2ZTogKHsgbmFtZSwgdmFsdWUgfSkgPT4gbmFtZSArIFwiOiBcIiArIHZhbHVlXG4gIH0sXG4gIC8vIERpcmVjdGl2ZVxuICBEaXJlY3RpdmU6IHtcbiAgICBsZWF2ZTogKHsgbmFtZSwgYXJndW1lbnRzOiBhcmdzIH0pID0+IFwiQFwiICsgbmFtZSArIHdyYXAoXCIoXCIsIGpvaW4oYXJncywgXCIsIFwiKSwgXCIpXCIpXG4gIH0sXG4gIC8vIFR5cGVcbiAgTmFtZWRUeXBlOiB7XG4gICAgbGVhdmU6ICh7IG5hbWUgfSkgPT4gbmFtZVxuICB9LFxuICBMaXN0VHlwZToge1xuICAgIGxlYXZlOiAoeyB0eXBlIH0pID0+IFwiW1wiICsgdHlwZSArIFwiXVwiXG4gIH0sXG4gIE5vbk51bGxUeXBlOiB7XG4gICAgbGVhdmU6ICh7IHR5cGUgfSkgPT4gdHlwZSArIFwiIVwiXG4gIH0sXG4gIC8vIFR5cGUgU3lzdGVtIERlZmluaXRpb25zXG4gIFNjaGVtYURlZmluaXRpb246IHtcbiAgICBsZWF2ZTogKHsgZGVzY3JpcHRpb24sIGRpcmVjdGl2ZXMsIG9wZXJhdGlvblR5cGVzIH0pID0+IHdyYXAoXCJcIiwgZGVzY3JpcHRpb24sIFwiXFxuXCIpICsgam9pbihbXCJzY2hlbWFcIiwgam9pbihkaXJlY3RpdmVzLCBcIiBcIiksIGJsb2NrKG9wZXJhdGlvblR5cGVzKV0sIFwiIFwiKVxuICB9LFxuICBPcGVyYXRpb25UeXBlRGVmaW5pdGlvbjoge1xuICAgIGxlYXZlOiAoeyBvcGVyYXRpb24sIHR5cGUgfSkgPT4gb3BlcmF0aW9uICsgXCI6IFwiICsgdHlwZVxuICB9LFxuICBTY2FsYXJUeXBlRGVmaW5pdGlvbjoge1xuICAgIGxlYXZlOiAoeyBkZXNjcmlwdGlvbiwgbmFtZSwgZGlyZWN0aXZlcyB9KSA9PiB3cmFwKFwiXCIsIGRlc2NyaXB0aW9uLCBcIlxcblwiKSArIGpvaW4oW1wic2NhbGFyXCIsIG5hbWUsIGpvaW4oZGlyZWN0aXZlcywgXCIgXCIpXSwgXCIgXCIpXG4gIH0sXG4gIE9iamVjdFR5cGVEZWZpbml0aW9uOiB7XG4gICAgbGVhdmU6ICh7IGRlc2NyaXB0aW9uLCBuYW1lLCBpbnRlcmZhY2VzLCBkaXJlY3RpdmVzLCBmaWVsZHMgfSkgPT4gd3JhcChcIlwiLCBkZXNjcmlwdGlvbiwgXCJcXG5cIikgKyBqb2luKFxuICAgICAgW1xuICAgICAgICBcInR5cGVcIixcbiAgICAgICAgbmFtZSxcbiAgICAgICAgd3JhcChcImltcGxlbWVudHMgXCIsIGpvaW4oaW50ZXJmYWNlcywgXCIgJiBcIikpLFxuICAgICAgICBqb2luKGRpcmVjdGl2ZXMsIFwiIFwiKSxcbiAgICAgICAgYmxvY2soZmllbGRzKVxuICAgICAgXSxcbiAgICAgIFwiIFwiXG4gICAgKVxuICB9LFxuICBGaWVsZERlZmluaXRpb246IHtcbiAgICBsZWF2ZTogKHsgZGVzY3JpcHRpb24sIG5hbWUsIGFyZ3VtZW50czogYXJncywgdHlwZSwgZGlyZWN0aXZlcyB9KSA9PiB3cmFwKFwiXCIsIGRlc2NyaXB0aW9uLCBcIlxcblwiKSArIG5hbWUgKyAoaGFzTXVsdGlsaW5lSXRlbXMoYXJncykgPyB3cmFwKFwiKFxcblwiLCBpbmRlbnQoam9pbihhcmdzLCBcIlxcblwiKSksIFwiXFxuKVwiKSA6IHdyYXAoXCIoXCIsIGpvaW4oYXJncywgXCIsIFwiKSwgXCIpXCIpKSArIFwiOiBcIiArIHR5cGUgKyB3cmFwKFwiIFwiLCBqb2luKGRpcmVjdGl2ZXMsIFwiIFwiKSlcbiAgfSxcbiAgSW5wdXRWYWx1ZURlZmluaXRpb246IHtcbiAgICBsZWF2ZTogKHsgZGVzY3JpcHRpb24sIG5hbWUsIHR5cGUsIGRlZmF1bHRWYWx1ZSwgZGlyZWN0aXZlcyB9KSA9PiB3cmFwKFwiXCIsIGRlc2NyaXB0aW9uLCBcIlxcblwiKSArIGpvaW4oXG4gICAgICBbbmFtZSArIFwiOiBcIiArIHR5cGUsIHdyYXAoXCI9IFwiLCBkZWZhdWx0VmFsdWUpLCBqb2luKGRpcmVjdGl2ZXMsIFwiIFwiKV0sXG4gICAgICBcIiBcIlxuICAgIClcbiAgfSxcbiAgSW50ZXJmYWNlVHlwZURlZmluaXRpb246IHtcbiAgICBsZWF2ZTogKHsgZGVzY3JpcHRpb24sIG5hbWUsIGludGVyZmFjZXMsIGRpcmVjdGl2ZXMsIGZpZWxkcyB9KSA9PiB3cmFwKFwiXCIsIGRlc2NyaXB0aW9uLCBcIlxcblwiKSArIGpvaW4oXG4gICAgICBbXG4gICAgICAgIFwiaW50ZXJmYWNlXCIsXG4gICAgICAgIG5hbWUsXG4gICAgICAgIHdyYXAoXCJpbXBsZW1lbnRzIFwiLCBqb2luKGludGVyZmFjZXMsIFwiICYgXCIpKSxcbiAgICAgICAgam9pbihkaXJlY3RpdmVzLCBcIiBcIiksXG4gICAgICAgIGJsb2NrKGZpZWxkcylcbiAgICAgIF0sXG4gICAgICBcIiBcIlxuICAgIClcbiAgfSxcbiAgVW5pb25UeXBlRGVmaW5pdGlvbjoge1xuICAgIGxlYXZlOiAoeyBkZXNjcmlwdGlvbiwgbmFtZSwgZGlyZWN0aXZlcywgdHlwZXMgfSkgPT4gd3JhcChcIlwiLCBkZXNjcmlwdGlvbiwgXCJcXG5cIikgKyBqb2luKFxuICAgICAgW1widW5pb25cIiwgbmFtZSwgam9pbihkaXJlY3RpdmVzLCBcIiBcIiksIHdyYXAoXCI9IFwiLCBqb2luKHR5cGVzLCBcIiB8IFwiKSldLFxuICAgICAgXCIgXCJcbiAgICApXG4gIH0sXG4gIEVudW1UeXBlRGVmaW5pdGlvbjoge1xuICAgIGxlYXZlOiAoeyBkZXNjcmlwdGlvbiwgbmFtZSwgZGlyZWN0aXZlcywgdmFsdWVzIH0pID0+IHdyYXAoXCJcIiwgZGVzY3JpcHRpb24sIFwiXFxuXCIpICsgam9pbihbXCJlbnVtXCIsIG5hbWUsIGpvaW4oZGlyZWN0aXZlcywgXCIgXCIpLCBibG9jayh2YWx1ZXMpXSwgXCIgXCIpXG4gIH0sXG4gIEVudW1WYWx1ZURlZmluaXRpb246IHtcbiAgICBsZWF2ZTogKHsgZGVzY3JpcHRpb24sIG5hbWUsIGRpcmVjdGl2ZXMgfSkgPT4gd3JhcChcIlwiLCBkZXNjcmlwdGlvbiwgXCJcXG5cIikgKyBqb2luKFtuYW1lLCBqb2luKGRpcmVjdGl2ZXMsIFwiIFwiKV0sIFwiIFwiKVxuICB9LFxuICBJbnB1dE9iamVjdFR5cGVEZWZpbml0aW9uOiB7XG4gICAgbGVhdmU6ICh7IGRlc2NyaXB0aW9uLCBuYW1lLCBkaXJlY3RpdmVzLCBmaWVsZHMgfSkgPT4gd3JhcChcIlwiLCBkZXNjcmlwdGlvbiwgXCJcXG5cIikgKyBqb2luKFtcImlucHV0XCIsIG5hbWUsIGpvaW4oZGlyZWN0aXZlcywgXCIgXCIpLCBibG9jayhmaWVsZHMpXSwgXCIgXCIpXG4gIH0sXG4gIERpcmVjdGl2ZURlZmluaXRpb246IHtcbiAgICBsZWF2ZTogKHsgZGVzY3JpcHRpb24sIG5hbWUsIGFyZ3VtZW50czogYXJncywgcmVwZWF0YWJsZSwgbG9jYXRpb25zIH0pID0+IHdyYXAoXCJcIiwgZGVzY3JpcHRpb24sIFwiXFxuXCIpICsgXCJkaXJlY3RpdmUgQFwiICsgbmFtZSArIChoYXNNdWx0aWxpbmVJdGVtcyhhcmdzKSA/IHdyYXAoXCIoXFxuXCIsIGluZGVudChqb2luKGFyZ3MsIFwiXFxuXCIpKSwgXCJcXG4pXCIpIDogd3JhcChcIihcIiwgam9pbihhcmdzLCBcIiwgXCIpLCBcIilcIikpICsgKHJlcGVhdGFibGUgPyBcIiByZXBlYXRhYmxlXCIgOiBcIlwiKSArIFwiIG9uIFwiICsgam9pbihsb2NhdGlvbnMsIFwiIHwgXCIpXG4gIH0sXG4gIFNjaGVtYUV4dGVuc2lvbjoge1xuICAgIGxlYXZlOiAoeyBkaXJlY3RpdmVzLCBvcGVyYXRpb25UeXBlcyB9KSA9PiBqb2luKFxuICAgICAgW1wiZXh0ZW5kIHNjaGVtYVwiLCBqb2luKGRpcmVjdGl2ZXMsIFwiIFwiKSwgYmxvY2sob3BlcmF0aW9uVHlwZXMpXSxcbiAgICAgIFwiIFwiXG4gICAgKVxuICB9LFxuICBTY2FsYXJUeXBlRXh0ZW5zaW9uOiB7XG4gICAgbGVhdmU6ICh7IG5hbWUsIGRpcmVjdGl2ZXMgfSkgPT4gam9pbihbXCJleHRlbmQgc2NhbGFyXCIsIG5hbWUsIGpvaW4oZGlyZWN0aXZlcywgXCIgXCIpXSwgXCIgXCIpXG4gIH0sXG4gIE9iamVjdFR5cGVFeHRlbnNpb246IHtcbiAgICBsZWF2ZTogKHsgbmFtZSwgaW50ZXJmYWNlcywgZGlyZWN0aXZlcywgZmllbGRzIH0pID0+IGpvaW4oXG4gICAgICBbXG4gICAgICAgIFwiZXh0ZW5kIHR5cGVcIixcbiAgICAgICAgbmFtZSxcbiAgICAgICAgd3JhcChcImltcGxlbWVudHMgXCIsIGpvaW4oaW50ZXJmYWNlcywgXCIgJiBcIikpLFxuICAgICAgICBqb2luKGRpcmVjdGl2ZXMsIFwiIFwiKSxcbiAgICAgICAgYmxvY2soZmllbGRzKVxuICAgICAgXSxcbiAgICAgIFwiIFwiXG4gICAgKVxuICB9LFxuICBJbnRlcmZhY2VUeXBlRXh0ZW5zaW9uOiB7XG4gICAgbGVhdmU6ICh7IG5hbWUsIGludGVyZmFjZXMsIGRpcmVjdGl2ZXMsIGZpZWxkcyB9KSA9PiBqb2luKFxuICAgICAgW1xuICAgICAgICBcImV4dGVuZCBpbnRlcmZhY2VcIixcbiAgICAgICAgbmFtZSxcbiAgICAgICAgd3JhcChcImltcGxlbWVudHMgXCIsIGpvaW4oaW50ZXJmYWNlcywgXCIgJiBcIikpLFxuICAgICAgICBqb2luKGRpcmVjdGl2ZXMsIFwiIFwiKSxcbiAgICAgICAgYmxvY2soZmllbGRzKVxuICAgICAgXSxcbiAgICAgIFwiIFwiXG4gICAgKVxuICB9LFxuICBVbmlvblR5cGVFeHRlbnNpb246IHtcbiAgICBsZWF2ZTogKHsgbmFtZSwgZGlyZWN0aXZlcywgdHlwZXMgfSkgPT4gam9pbihcbiAgICAgIFtcbiAgICAgICAgXCJleHRlbmQgdW5pb25cIixcbiAgICAgICAgbmFtZSxcbiAgICAgICAgam9pbihkaXJlY3RpdmVzLCBcIiBcIiksXG4gICAgICAgIHdyYXAoXCI9IFwiLCBqb2luKHR5cGVzLCBcIiB8IFwiKSlcbiAgICAgIF0sXG4gICAgICBcIiBcIlxuICAgIClcbiAgfSxcbiAgRW51bVR5cGVFeHRlbnNpb246IHtcbiAgICBsZWF2ZTogKHsgbmFtZSwgZGlyZWN0aXZlcywgdmFsdWVzIH0pID0+IGpvaW4oW1wiZXh0ZW5kIGVudW1cIiwgbmFtZSwgam9pbihkaXJlY3RpdmVzLCBcIiBcIiksIGJsb2NrKHZhbHVlcyldLCBcIiBcIilcbiAgfSxcbiAgSW5wdXRPYmplY3RUeXBlRXh0ZW5zaW9uOiB7XG4gICAgbGVhdmU6ICh7IG5hbWUsIGRpcmVjdGl2ZXMsIGZpZWxkcyB9KSA9PiBqb2luKFtcImV4dGVuZCBpbnB1dFwiLCBuYW1lLCBqb2luKGRpcmVjdGl2ZXMsIFwiIFwiKSwgYmxvY2soZmllbGRzKV0sIFwiIFwiKVxuICB9XG59O1xuZnVuY3Rpb24gam9pbihtYXliZUFycmF5LCBzZXBhcmF0b3IgPSBcIlwiKSB7XG4gIHZhciBfbWF5YmVBcnJheSRmaWx0ZXIkam87XG4gIHJldHVybiAoX21heWJlQXJyYXkkZmlsdGVyJGpvID0gbWF5YmVBcnJheSA9PT0gbnVsbCB8fCBtYXliZUFycmF5ID09PSB2b2lkIDAgPyB2b2lkIDAgOiBtYXliZUFycmF5LmZpbHRlcigoeCkgPT4geCkuam9pbihzZXBhcmF0b3IpKSAhPT0gbnVsbCAmJiBfbWF5YmVBcnJheSRmaWx0ZXIkam8gIT09IHZvaWQgMCA/IF9tYXliZUFycmF5JGZpbHRlciRqbyA6IFwiXCI7XG59XG5mdW5jdGlvbiBibG9jayhhcnJheSkge1xuICByZXR1cm4gd3JhcChcIntcXG5cIiwgaW5kZW50KGpvaW4oYXJyYXksIFwiXFxuXCIpKSwgXCJcXG59XCIpO1xufVxuZnVuY3Rpb24gd3JhcChzdGFydCwgbWF5YmVTdHJpbmcsIGVuZCA9IFwiXCIpIHtcbiAgcmV0dXJuIG1heWJlU3RyaW5nICE9IG51bGwgJiYgbWF5YmVTdHJpbmcgIT09IFwiXCIgPyBzdGFydCArIG1heWJlU3RyaW5nICsgZW5kIDogXCJcIjtcbn1cbmZ1bmN0aW9uIGluZGVudChzdHIpIHtcbiAgcmV0dXJuIHdyYXAoXCIgIFwiLCBzdHIucmVwbGFjZSgvXFxuL2csIFwiXFxuICBcIikpO1xufVxuZnVuY3Rpb24gaGFzTXVsdGlsaW5lSXRlbXMobWF5YmVBcnJheSkge1xuICB2YXIgX21heWJlQXJyYXkkc29tZTtcbiAgcmV0dXJuIChfbWF5YmVBcnJheSRzb21lID0gbWF5YmVBcnJheSA9PT0gbnVsbCB8fCBtYXliZUFycmF5ID09PSB2b2lkIDAgPyB2b2lkIDAgOiBtYXliZUFycmF5LnNvbWUoKHN0cikgPT4gc3RyLmluY2x1ZGVzKFwiXFxuXCIpKSkgIT09IG51bGwgJiYgX21heWJlQXJyYXkkc29tZSAhPT0gdm9pZCAwID8gX21heWJlQXJyYXkkc29tZSA6IGZhbHNlO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdXRpbGl0aWVzL3ZhbHVlRnJvbUFTVFVudHlwZWQubWpzXG5mdW5jdGlvbiB2YWx1ZUZyb21BU1RVbnR5cGVkKHZhbHVlTm9kZSwgdmFyaWFibGVzKSB7XG4gIHN3aXRjaCAodmFsdWVOb2RlLmtpbmQpIHtcbiAgICBjYXNlIEtpbmQuTlVMTDpcbiAgICAgIHJldHVybiBudWxsO1xuICAgIGNhc2UgS2luZC5JTlQ6XG4gICAgICByZXR1cm4gcGFyc2VJbnQodmFsdWVOb2RlLnZhbHVlLCAxMCk7XG4gICAgY2FzZSBLaW5kLkZMT0FUOlxuICAgICAgcmV0dXJuIHBhcnNlRmxvYXQodmFsdWVOb2RlLnZhbHVlKTtcbiAgICBjYXNlIEtpbmQuU1RSSU5HOlxuICAgIGNhc2UgS2luZC5FTlVNOlxuICAgIGNhc2UgS2luZC5CT09MRUFOOlxuICAgICAgcmV0dXJuIHZhbHVlTm9kZS52YWx1ZTtcbiAgICBjYXNlIEtpbmQuTElTVDpcbiAgICAgIHJldHVybiB2YWx1ZU5vZGUudmFsdWVzLm1hcChcbiAgICAgICAgKG5vZGUpID0+IHZhbHVlRnJvbUFTVFVudHlwZWQobm9kZSwgdmFyaWFibGVzKVxuICAgICAgKTtcbiAgICBjYXNlIEtpbmQuT0JKRUNUOlxuICAgICAgcmV0dXJuIGtleVZhbE1hcChcbiAgICAgICAgdmFsdWVOb2RlLmZpZWxkcyxcbiAgICAgICAgKGZpZWxkKSA9PiBmaWVsZC5uYW1lLnZhbHVlLFxuICAgICAgICAoZmllbGQpID0+IHZhbHVlRnJvbUFTVFVudHlwZWQoZmllbGQudmFsdWUsIHZhcmlhYmxlcylcbiAgICAgICk7XG4gICAgY2FzZSBLaW5kLlZBUklBQkxFOlxuICAgICAgcmV0dXJuIHZhcmlhYmxlcyA9PT0gbnVsbCB8fCB2YXJpYWJsZXMgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHZhcmlhYmxlc1t2YWx1ZU5vZGUubmFtZS52YWx1ZV07XG4gIH1cbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL3R5cGUvYXNzZXJ0TmFtZS5tanNcbmZ1bmN0aW9uIGFzc2VydE5hbWUobmFtZSkge1xuICBuYW1lICE9IG51bGwgfHwgZGV2QXNzZXJ0KGZhbHNlLCBcIk11c3QgcHJvdmlkZSBuYW1lLlwiKTtcbiAgdHlwZW9mIG5hbWUgPT09IFwic3RyaW5nXCIgfHwgZGV2QXNzZXJ0KGZhbHNlLCBcIkV4cGVjdGVkIG5hbWUgdG8gYmUgYSBzdHJpbmcuXCIpO1xuICBpZiAobmFtZS5sZW5ndGggPT09IDApIHtcbiAgICB0aHJvdyBuZXcgR3JhcGhRTEVycm9yKFwiRXhwZWN0ZWQgbmFtZSB0byBiZSBhIG5vbi1lbXB0eSBzdHJpbmcuXCIpO1xuICB9XG4gIGZvciAobGV0IGkgPSAxOyBpIDwgbmFtZS5sZW5ndGg7ICsraSkge1xuICAgIGlmICghaXNOYW1lQ29udGludWUobmFtZS5jaGFyQ29kZUF0KGkpKSkge1xuICAgICAgdGhyb3cgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgYE5hbWVzIG11c3Qgb25seSBjb250YWluIFtfYS16QS1aMC05XSBidXQgXCIke25hbWV9XCIgZG9lcyBub3QuYFxuICAgICAgKTtcbiAgICB9XG4gIH1cbiAgaWYgKCFpc05hbWVTdGFydChuYW1lLmNoYXJDb2RlQXQoMCkpKSB7XG4gICAgdGhyb3cgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgIGBOYW1lcyBtdXN0IHN0YXJ0IHdpdGggW19hLXpBLVpdIGJ1dCBcIiR7bmFtZX1cIiBkb2VzIG5vdC5gXG4gICAgKTtcbiAgfVxuICByZXR1cm4gbmFtZTtcbn1cbmZ1bmN0aW9uIGFzc2VydEVudW1WYWx1ZU5hbWUobmFtZSkge1xuICBpZiAobmFtZSA9PT0gXCJ0cnVlXCIgfHwgbmFtZSA9PT0gXCJmYWxzZVwiIHx8IG5hbWUgPT09IFwibnVsbFwiKSB7XG4gICAgdGhyb3cgbmV3IEdyYXBoUUxFcnJvcihgRW51bSB2YWx1ZXMgY2Fubm90IGJlIG5hbWVkOiAke25hbWV9YCk7XG4gIH1cbiAgcmV0dXJuIGFzc2VydE5hbWUobmFtZSk7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC90eXBlL2RlZmluaXRpb24ubWpzXG5mdW5jdGlvbiBpc1R5cGUodHlwZSkge1xuICByZXR1cm4gaXNTY2FsYXJUeXBlKHR5cGUpIHx8IGlzT2JqZWN0VHlwZSh0eXBlKSB8fCBpc0ludGVyZmFjZVR5cGUodHlwZSkgfHwgaXNVbmlvblR5cGUodHlwZSkgfHwgaXNFbnVtVHlwZSh0eXBlKSB8fCBpc0lucHV0T2JqZWN0VHlwZSh0eXBlKSB8fCBpc0xpc3RUeXBlKHR5cGUpIHx8IGlzTm9uTnVsbFR5cGUodHlwZSk7XG59XG5mdW5jdGlvbiBpc1NjYWxhclR5cGUodHlwZSkge1xuICByZXR1cm4gaW5zdGFuY2VPZih0eXBlLCBHcmFwaFFMU2NhbGFyVHlwZSk7XG59XG5mdW5jdGlvbiBpc09iamVjdFR5cGUodHlwZSkge1xuICByZXR1cm4gaW5zdGFuY2VPZih0eXBlLCBHcmFwaFFMT2JqZWN0VHlwZSk7XG59XG5mdW5jdGlvbiBpc0ludGVyZmFjZVR5cGUodHlwZSkge1xuICByZXR1cm4gaW5zdGFuY2VPZih0eXBlLCBHcmFwaFFMSW50ZXJmYWNlVHlwZSk7XG59XG5mdW5jdGlvbiBpc1VuaW9uVHlwZSh0eXBlKSB7XG4gIHJldHVybiBpbnN0YW5jZU9mKHR5cGUsIEdyYXBoUUxVbmlvblR5cGUpO1xufVxuZnVuY3Rpb24gaXNFbnVtVHlwZSh0eXBlKSB7XG4gIHJldHVybiBpbnN0YW5jZU9mKHR5cGUsIEdyYXBoUUxFbnVtVHlwZSk7XG59XG5mdW5jdGlvbiBpc0lucHV0T2JqZWN0VHlwZSh0eXBlKSB7XG4gIHJldHVybiBpbnN0YW5jZU9mKHR5cGUsIEdyYXBoUUxJbnB1dE9iamVjdFR5cGUpO1xufVxuZnVuY3Rpb24gaXNMaXN0VHlwZSh0eXBlKSB7XG4gIHJldHVybiBpbnN0YW5jZU9mKHR5cGUsIEdyYXBoUUxMaXN0KTtcbn1cbmZ1bmN0aW9uIGlzTm9uTnVsbFR5cGUodHlwZSkge1xuICByZXR1cm4gaW5zdGFuY2VPZih0eXBlLCBHcmFwaFFMTm9uTnVsbCk7XG59XG5mdW5jdGlvbiBpc0lucHV0VHlwZSh0eXBlKSB7XG4gIHJldHVybiBpc1NjYWxhclR5cGUodHlwZSkgfHwgaXNFbnVtVHlwZSh0eXBlKSB8fCBpc0lucHV0T2JqZWN0VHlwZSh0eXBlKSB8fCBpc1dyYXBwaW5nVHlwZSh0eXBlKSAmJiBpc0lucHV0VHlwZSh0eXBlLm9mVHlwZSk7XG59XG5mdW5jdGlvbiBpc0xlYWZUeXBlKHR5cGUpIHtcbiAgcmV0dXJuIGlzU2NhbGFyVHlwZSh0eXBlKSB8fCBpc0VudW1UeXBlKHR5cGUpO1xufVxuZnVuY3Rpb24gaXNDb21wb3NpdGVUeXBlKHR5cGUpIHtcbiAgcmV0dXJuIGlzT2JqZWN0VHlwZSh0eXBlKSB8fCBpc0ludGVyZmFjZVR5cGUodHlwZSkgfHwgaXNVbmlvblR5cGUodHlwZSk7XG59XG5mdW5jdGlvbiBpc0Fic3RyYWN0VHlwZSh0eXBlKSB7XG4gIHJldHVybiBpc0ludGVyZmFjZVR5cGUodHlwZSkgfHwgaXNVbmlvblR5cGUodHlwZSk7XG59XG52YXIgR3JhcGhRTExpc3QgPSBjbGFzcyB7XG4gIGNvbnN0cnVjdG9yKG9mVHlwZSkge1xuICAgIGlzVHlwZShvZlR5cGUpIHx8IGRldkFzc2VydChmYWxzZSwgYEV4cGVjdGVkICR7aW5zcGVjdChvZlR5cGUpfSB0byBiZSBhIEdyYXBoUUwgdHlwZS5gKTtcbiAgICB0aGlzLm9mVHlwZSA9IG9mVHlwZTtcbiAgfVxuICBnZXQgW1N5bWJvbC50b1N0cmluZ1RhZ10oKSB7XG4gICAgcmV0dXJuIFwiR3JhcGhRTExpc3RcIjtcbiAgfVxuICB0b1N0cmluZygpIHtcbiAgICByZXR1cm4gXCJbXCIgKyBTdHJpbmcodGhpcy5vZlR5cGUpICsgXCJdXCI7XG4gIH1cbiAgdG9KU09OKCkge1xuICAgIHJldHVybiB0aGlzLnRvU3RyaW5nKCk7XG4gIH1cbn07XG52YXIgR3JhcGhRTE5vbk51bGwgPSBjbGFzcyB7XG4gIGNvbnN0cnVjdG9yKG9mVHlwZSkge1xuICAgIGlzTnVsbGFibGVUeXBlKG9mVHlwZSkgfHwgZGV2QXNzZXJ0KFxuICAgICAgZmFsc2UsXG4gICAgICBgRXhwZWN0ZWQgJHtpbnNwZWN0KG9mVHlwZSl9IHRvIGJlIGEgR3JhcGhRTCBudWxsYWJsZSB0eXBlLmBcbiAgICApO1xuICAgIHRoaXMub2ZUeXBlID0gb2ZUeXBlO1xuICB9XG4gIGdldCBbU3ltYm9sLnRvU3RyaW5nVGFnXSgpIHtcbiAgICByZXR1cm4gXCJHcmFwaFFMTm9uTnVsbFwiO1xuICB9XG4gIHRvU3RyaW5nKCkge1xuICAgIHJldHVybiBTdHJpbmcodGhpcy5vZlR5cGUpICsgXCIhXCI7XG4gIH1cbiAgdG9KU09OKCkge1xuICAgIHJldHVybiB0aGlzLnRvU3RyaW5nKCk7XG4gIH1cbn07XG5mdW5jdGlvbiBpc1dyYXBwaW5nVHlwZSh0eXBlKSB7XG4gIHJldHVybiBpc0xpc3RUeXBlKHR5cGUpIHx8IGlzTm9uTnVsbFR5cGUodHlwZSk7XG59XG5mdW5jdGlvbiBpc051bGxhYmxlVHlwZSh0eXBlKSB7XG4gIHJldHVybiBpc1R5cGUodHlwZSkgJiYgIWlzTm9uTnVsbFR5cGUodHlwZSk7XG59XG5mdW5jdGlvbiBnZXROdWxsYWJsZVR5cGUodHlwZSkge1xuICBpZiAodHlwZSkge1xuICAgIHJldHVybiBpc05vbk51bGxUeXBlKHR5cGUpID8gdHlwZS5vZlR5cGUgOiB0eXBlO1xuICB9XG59XG5mdW5jdGlvbiBnZXROYW1lZFR5cGUodHlwZSkge1xuICBpZiAodHlwZSkge1xuICAgIGxldCB1bndyYXBwZWRUeXBlID0gdHlwZTtcbiAgICB3aGlsZSAoaXNXcmFwcGluZ1R5cGUodW53cmFwcGVkVHlwZSkpIHtcbiAgICAgIHVud3JhcHBlZFR5cGUgPSB1bndyYXBwZWRUeXBlLm9mVHlwZTtcbiAgICB9XG4gICAgcmV0dXJuIHVud3JhcHBlZFR5cGU7XG4gIH1cbn1cbmZ1bmN0aW9uIHJlc29sdmVSZWFkb25seUFycmF5VGh1bmsodGh1bmspIHtcbiAgcmV0dXJuIHR5cGVvZiB0aHVuayA9PT0gXCJmdW5jdGlvblwiID8gdGh1bmsoKSA6IHRodW5rO1xufVxuZnVuY3Rpb24gcmVzb2x2ZU9iak1hcFRodW5rKHRodW5rKSB7XG4gIHJldHVybiB0eXBlb2YgdGh1bmsgPT09IFwiZnVuY3Rpb25cIiA/IHRodW5rKCkgOiB0aHVuaztcbn1cbnZhciBHcmFwaFFMU2NhbGFyVHlwZSA9IGNsYXNzIHtcbiAgY29uc3RydWN0b3IoY29uZmlnKSB7XG4gICAgdmFyIF9jb25maWckcGFyc2VWYWx1ZSwgX2NvbmZpZyRzZXJpYWxpemUsIF9jb25maWckcGFyc2VMaXRlcmFsLCBfY29uZmlnJGV4dGVuc2lvbkFTVE47XG4gICAgY29uc3QgcGFyc2VWYWx1ZTIgPSAoX2NvbmZpZyRwYXJzZVZhbHVlID0gY29uZmlnLnBhcnNlVmFsdWUpICE9PSBudWxsICYmIF9jb25maWckcGFyc2VWYWx1ZSAhPT0gdm9pZCAwID8gX2NvbmZpZyRwYXJzZVZhbHVlIDogaWRlbnRpdHlGdW5jO1xuICAgIHRoaXMubmFtZSA9IGFzc2VydE5hbWUoY29uZmlnLm5hbWUpO1xuICAgIHRoaXMuZGVzY3JpcHRpb24gPSBjb25maWcuZGVzY3JpcHRpb247XG4gICAgdGhpcy5zcGVjaWZpZWRCeVVSTCA9IGNvbmZpZy5zcGVjaWZpZWRCeVVSTDtcbiAgICB0aGlzLnNlcmlhbGl6ZSA9IChfY29uZmlnJHNlcmlhbGl6ZSA9IGNvbmZpZy5zZXJpYWxpemUpICE9PSBudWxsICYmIF9jb25maWckc2VyaWFsaXplICE9PSB2b2lkIDAgPyBfY29uZmlnJHNlcmlhbGl6ZSA6IGlkZW50aXR5RnVuYztcbiAgICB0aGlzLnBhcnNlVmFsdWUgPSBwYXJzZVZhbHVlMjtcbiAgICB0aGlzLnBhcnNlTGl0ZXJhbCA9IChfY29uZmlnJHBhcnNlTGl0ZXJhbCA9IGNvbmZpZy5wYXJzZUxpdGVyYWwpICE9PSBudWxsICYmIF9jb25maWckcGFyc2VMaXRlcmFsICE9PSB2b2lkIDAgPyBfY29uZmlnJHBhcnNlTGl0ZXJhbCA6IChub2RlLCB2YXJpYWJsZXMpID0+IHBhcnNlVmFsdWUyKHZhbHVlRnJvbUFTVFVudHlwZWQobm9kZSwgdmFyaWFibGVzKSk7XG4gICAgdGhpcy5leHRlbnNpb25zID0gdG9PYmpNYXAoY29uZmlnLmV4dGVuc2lvbnMpO1xuICAgIHRoaXMuYXN0Tm9kZSA9IGNvbmZpZy5hc3ROb2RlO1xuICAgIHRoaXMuZXh0ZW5zaW9uQVNUTm9kZXMgPSAoX2NvbmZpZyRleHRlbnNpb25BU1ROID0gY29uZmlnLmV4dGVuc2lvbkFTVE5vZGVzKSAhPT0gbnVsbCAmJiBfY29uZmlnJGV4dGVuc2lvbkFTVE4gIT09IHZvaWQgMCA/IF9jb25maWckZXh0ZW5zaW9uQVNUTiA6IFtdO1xuICAgIGNvbmZpZy5zcGVjaWZpZWRCeVVSTCA9PSBudWxsIHx8IHR5cGVvZiBjb25maWcuc3BlY2lmaWVkQnlVUkwgPT09IFwic3RyaW5nXCIgfHwgZGV2QXNzZXJ0KFxuICAgICAgZmFsc2UsXG4gICAgICBgJHt0aGlzLm5hbWV9IG11c3QgcHJvdmlkZSBcInNwZWNpZmllZEJ5VVJMXCIgYXMgYSBzdHJpbmcsIGJ1dCBnb3Q6ICR7aW5zcGVjdChjb25maWcuc3BlY2lmaWVkQnlVUkwpfS5gXG4gICAgKTtcbiAgICBjb25maWcuc2VyaWFsaXplID09IG51bGwgfHwgdHlwZW9mIGNvbmZpZy5zZXJpYWxpemUgPT09IFwiZnVuY3Rpb25cIiB8fCBkZXZBc3NlcnQoXG4gICAgICBmYWxzZSxcbiAgICAgIGAke3RoaXMubmFtZX0gbXVzdCBwcm92aWRlIFwic2VyaWFsaXplXCIgZnVuY3Rpb24uIElmIHRoaXMgY3VzdG9tIFNjYWxhciBpcyBhbHNvIHVzZWQgYXMgYW4gaW5wdXQgdHlwZSwgZW5zdXJlIFwicGFyc2VWYWx1ZVwiIGFuZCBcInBhcnNlTGl0ZXJhbFwiIGZ1bmN0aW9ucyBhcmUgYWxzbyBwcm92aWRlZC5gXG4gICAgKTtcbiAgICBpZiAoY29uZmlnLnBhcnNlTGl0ZXJhbCkge1xuICAgICAgdHlwZW9mIGNvbmZpZy5wYXJzZVZhbHVlID09PSBcImZ1bmN0aW9uXCIgJiYgdHlwZW9mIGNvbmZpZy5wYXJzZUxpdGVyYWwgPT09IFwiZnVuY3Rpb25cIiB8fCBkZXZBc3NlcnQoXG4gICAgICAgIGZhbHNlLFxuICAgICAgICBgJHt0aGlzLm5hbWV9IG11c3QgcHJvdmlkZSBib3RoIFwicGFyc2VWYWx1ZVwiIGFuZCBcInBhcnNlTGl0ZXJhbFwiIGZ1bmN0aW9ucy5gXG4gICAgICApO1xuICAgIH1cbiAgfVxuICBnZXQgW1N5bWJvbC50b1N0cmluZ1RhZ10oKSB7XG4gICAgcmV0dXJuIFwiR3JhcGhRTFNjYWxhclR5cGVcIjtcbiAgfVxuICB0b0NvbmZpZygpIHtcbiAgICByZXR1cm4ge1xuICAgICAgbmFtZTogdGhpcy5uYW1lLFxuICAgICAgZGVzY3JpcHRpb246IHRoaXMuZGVzY3JpcHRpb24sXG4gICAgICBzcGVjaWZpZWRCeVVSTDogdGhpcy5zcGVjaWZpZWRCeVVSTCxcbiAgICAgIHNlcmlhbGl6ZTogdGhpcy5zZXJpYWxpemUsXG4gICAgICBwYXJzZVZhbHVlOiB0aGlzLnBhcnNlVmFsdWUsXG4gICAgICBwYXJzZUxpdGVyYWw6IHRoaXMucGFyc2VMaXRlcmFsLFxuICAgICAgZXh0ZW5zaW9uczogdGhpcy5leHRlbnNpb25zLFxuICAgICAgYXN0Tm9kZTogdGhpcy5hc3ROb2RlLFxuICAgICAgZXh0ZW5zaW9uQVNUTm9kZXM6IHRoaXMuZXh0ZW5zaW9uQVNUTm9kZXNcbiAgICB9O1xuICB9XG4gIHRvU3RyaW5nKCkge1xuICAgIHJldHVybiB0aGlzLm5hbWU7XG4gIH1cbiAgdG9KU09OKCkge1xuICAgIHJldHVybiB0aGlzLnRvU3RyaW5nKCk7XG4gIH1cbn07XG52YXIgR3JhcGhRTE9iamVjdFR5cGUgPSBjbGFzcyB7XG4gIGNvbnN0cnVjdG9yKGNvbmZpZykge1xuICAgIHZhciBfY29uZmlnJGV4dGVuc2lvbkFTVE4yO1xuICAgIHRoaXMubmFtZSA9IGFzc2VydE5hbWUoY29uZmlnLm5hbWUpO1xuICAgIHRoaXMuZGVzY3JpcHRpb24gPSBjb25maWcuZGVzY3JpcHRpb247XG4gICAgdGhpcy5pc1R5cGVPZiA9IGNvbmZpZy5pc1R5cGVPZjtcbiAgICB0aGlzLmV4dGVuc2lvbnMgPSB0b09iak1hcChjb25maWcuZXh0ZW5zaW9ucyk7XG4gICAgdGhpcy5hc3ROb2RlID0gY29uZmlnLmFzdE5vZGU7XG4gICAgdGhpcy5leHRlbnNpb25BU1ROb2RlcyA9IChfY29uZmlnJGV4dGVuc2lvbkFTVE4yID0gY29uZmlnLmV4dGVuc2lvbkFTVE5vZGVzKSAhPT0gbnVsbCAmJiBfY29uZmlnJGV4dGVuc2lvbkFTVE4yICE9PSB2b2lkIDAgPyBfY29uZmlnJGV4dGVuc2lvbkFTVE4yIDogW107XG4gICAgdGhpcy5fZmllbGRzID0gKCkgPT4gZGVmaW5lRmllbGRNYXAoY29uZmlnKTtcbiAgICB0aGlzLl9pbnRlcmZhY2VzID0gKCkgPT4gZGVmaW5lSW50ZXJmYWNlcyhjb25maWcpO1xuICAgIGNvbmZpZy5pc1R5cGVPZiA9PSBudWxsIHx8IHR5cGVvZiBjb25maWcuaXNUeXBlT2YgPT09IFwiZnVuY3Rpb25cIiB8fCBkZXZBc3NlcnQoXG4gICAgICBmYWxzZSxcbiAgICAgIGAke3RoaXMubmFtZX0gbXVzdCBwcm92aWRlIFwiaXNUeXBlT2ZcIiBhcyBhIGZ1bmN0aW9uLCBidXQgZ290OiAke2luc3BlY3QoY29uZmlnLmlzVHlwZU9mKX0uYFxuICAgICk7XG4gIH1cbiAgZ2V0IFtTeW1ib2wudG9TdHJpbmdUYWddKCkge1xuICAgIHJldHVybiBcIkdyYXBoUUxPYmplY3RUeXBlXCI7XG4gIH1cbiAgZ2V0RmllbGRzKCkge1xuICAgIGlmICh0eXBlb2YgdGhpcy5fZmllbGRzID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgIHRoaXMuX2ZpZWxkcyA9IHRoaXMuX2ZpZWxkcygpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5fZmllbGRzO1xuICB9XG4gIGdldEludGVyZmFjZXMoKSB7XG4gICAgaWYgKHR5cGVvZiB0aGlzLl9pbnRlcmZhY2VzID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgIHRoaXMuX2ludGVyZmFjZXMgPSB0aGlzLl9pbnRlcmZhY2VzKCk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLl9pbnRlcmZhY2VzO1xuICB9XG4gIHRvQ29uZmlnKCkge1xuICAgIHJldHVybiB7XG4gICAgICBuYW1lOiB0aGlzLm5hbWUsXG4gICAgICBkZXNjcmlwdGlvbjogdGhpcy5kZXNjcmlwdGlvbixcbiAgICAgIGludGVyZmFjZXM6IHRoaXMuZ2V0SW50ZXJmYWNlcygpLFxuICAgICAgZmllbGRzOiBmaWVsZHNUb0ZpZWxkc0NvbmZpZyh0aGlzLmdldEZpZWxkcygpKSxcbiAgICAgIGlzVHlwZU9mOiB0aGlzLmlzVHlwZU9mLFxuICAgICAgZXh0ZW5zaW9uczogdGhpcy5leHRlbnNpb25zLFxuICAgICAgYXN0Tm9kZTogdGhpcy5hc3ROb2RlLFxuICAgICAgZXh0ZW5zaW9uQVNUTm9kZXM6IHRoaXMuZXh0ZW5zaW9uQVNUTm9kZXNcbiAgICB9O1xuICB9XG4gIHRvU3RyaW5nKCkge1xuICAgIHJldHVybiB0aGlzLm5hbWU7XG4gIH1cbiAgdG9KU09OKCkge1xuICAgIHJldHVybiB0aGlzLnRvU3RyaW5nKCk7XG4gIH1cbn07XG5mdW5jdGlvbiBkZWZpbmVJbnRlcmZhY2VzKGNvbmZpZykge1xuICB2YXIgX2NvbmZpZyRpbnRlcmZhY2VzO1xuICBjb25zdCBpbnRlcmZhY2VzID0gcmVzb2x2ZVJlYWRvbmx5QXJyYXlUaHVuayhcbiAgICAoX2NvbmZpZyRpbnRlcmZhY2VzID0gY29uZmlnLmludGVyZmFjZXMpICE9PSBudWxsICYmIF9jb25maWckaW50ZXJmYWNlcyAhPT0gdm9pZCAwID8gX2NvbmZpZyRpbnRlcmZhY2VzIDogW11cbiAgKTtcbiAgQXJyYXkuaXNBcnJheShpbnRlcmZhY2VzKSB8fCBkZXZBc3NlcnQoXG4gICAgZmFsc2UsXG4gICAgYCR7Y29uZmlnLm5hbWV9IGludGVyZmFjZXMgbXVzdCBiZSBhbiBBcnJheSBvciBhIGZ1bmN0aW9uIHdoaWNoIHJldHVybnMgYW4gQXJyYXkuYFxuICApO1xuICByZXR1cm4gaW50ZXJmYWNlcztcbn1cbmZ1bmN0aW9uIGRlZmluZUZpZWxkTWFwKGNvbmZpZykge1xuICBjb25zdCBmaWVsZE1hcCA9IHJlc29sdmVPYmpNYXBUaHVuayhjb25maWcuZmllbGRzKTtcbiAgaXNQbGFpbk9iaihmaWVsZE1hcCkgfHwgZGV2QXNzZXJ0KFxuICAgIGZhbHNlLFxuICAgIGAke2NvbmZpZy5uYW1lfSBmaWVsZHMgbXVzdCBiZSBhbiBvYmplY3Qgd2l0aCBmaWVsZCBuYW1lcyBhcyBrZXlzIG9yIGEgZnVuY3Rpb24gd2hpY2ggcmV0dXJucyBzdWNoIGFuIG9iamVjdC5gXG4gICk7XG4gIHJldHVybiBtYXBWYWx1ZShmaWVsZE1hcCwgKGZpZWxkQ29uZmlnLCBmaWVsZE5hbWUpID0+IHtcbiAgICB2YXIgX2ZpZWxkQ29uZmlnJGFyZ3M7XG4gICAgaXNQbGFpbk9iaihmaWVsZENvbmZpZykgfHwgZGV2QXNzZXJ0KFxuICAgICAgZmFsc2UsXG4gICAgICBgJHtjb25maWcubmFtZX0uJHtmaWVsZE5hbWV9IGZpZWxkIGNvbmZpZyBtdXN0IGJlIGFuIG9iamVjdC5gXG4gICAgKTtcbiAgICBmaWVsZENvbmZpZy5yZXNvbHZlID09IG51bGwgfHwgdHlwZW9mIGZpZWxkQ29uZmlnLnJlc29sdmUgPT09IFwiZnVuY3Rpb25cIiB8fCBkZXZBc3NlcnQoXG4gICAgICBmYWxzZSxcbiAgICAgIGAke2NvbmZpZy5uYW1lfS4ke2ZpZWxkTmFtZX0gZmllbGQgcmVzb2x2ZXIgbXVzdCBiZSBhIGZ1bmN0aW9uIGlmIHByb3ZpZGVkLCBidXQgZ290OiAke2luc3BlY3QoZmllbGRDb25maWcucmVzb2x2ZSl9LmBcbiAgICApO1xuICAgIGNvbnN0IGFyZ3NDb25maWcgPSAoX2ZpZWxkQ29uZmlnJGFyZ3MgPSBmaWVsZENvbmZpZy5hcmdzKSAhPT0gbnVsbCAmJiBfZmllbGRDb25maWckYXJncyAhPT0gdm9pZCAwID8gX2ZpZWxkQ29uZmlnJGFyZ3MgOiB7fTtcbiAgICBpc1BsYWluT2JqKGFyZ3NDb25maWcpIHx8IGRldkFzc2VydChcbiAgICAgIGZhbHNlLFxuICAgICAgYCR7Y29uZmlnLm5hbWV9LiR7ZmllbGROYW1lfSBhcmdzIG11c3QgYmUgYW4gb2JqZWN0IHdpdGggYXJndW1lbnQgbmFtZXMgYXMga2V5cy5gXG4gICAgKTtcbiAgICByZXR1cm4ge1xuICAgICAgbmFtZTogYXNzZXJ0TmFtZShmaWVsZE5hbWUpLFxuICAgICAgZGVzY3JpcHRpb246IGZpZWxkQ29uZmlnLmRlc2NyaXB0aW9uLFxuICAgICAgdHlwZTogZmllbGRDb25maWcudHlwZSxcbiAgICAgIGFyZ3M6IGRlZmluZUFyZ3VtZW50cyhhcmdzQ29uZmlnKSxcbiAgICAgIHJlc29sdmU6IGZpZWxkQ29uZmlnLnJlc29sdmUsXG4gICAgICBzdWJzY3JpYmU6IGZpZWxkQ29uZmlnLnN1YnNjcmliZSxcbiAgICAgIGRlcHJlY2F0aW9uUmVhc29uOiBmaWVsZENvbmZpZy5kZXByZWNhdGlvblJlYXNvbixcbiAgICAgIGV4dGVuc2lvbnM6IHRvT2JqTWFwKGZpZWxkQ29uZmlnLmV4dGVuc2lvbnMpLFxuICAgICAgYXN0Tm9kZTogZmllbGRDb25maWcuYXN0Tm9kZVxuICAgIH07XG4gIH0pO1xufVxuZnVuY3Rpb24gZGVmaW5lQXJndW1lbnRzKGNvbmZpZykge1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMoY29uZmlnKS5tYXAoKFthcmdOYW1lLCBhcmdDb25maWddKSA9PiAoe1xuICAgIG5hbWU6IGFzc2VydE5hbWUoYXJnTmFtZSksXG4gICAgZGVzY3JpcHRpb246IGFyZ0NvbmZpZy5kZXNjcmlwdGlvbixcbiAgICB0eXBlOiBhcmdDb25maWcudHlwZSxcbiAgICBkZWZhdWx0VmFsdWU6IGFyZ0NvbmZpZy5kZWZhdWx0VmFsdWUsXG4gICAgZGVwcmVjYXRpb25SZWFzb246IGFyZ0NvbmZpZy5kZXByZWNhdGlvblJlYXNvbixcbiAgICBleHRlbnNpb25zOiB0b09iak1hcChhcmdDb25maWcuZXh0ZW5zaW9ucyksXG4gICAgYXN0Tm9kZTogYXJnQ29uZmlnLmFzdE5vZGVcbiAgfSkpO1xufVxuZnVuY3Rpb24gaXNQbGFpbk9iaihvYmopIHtcbiAgcmV0dXJuIGlzT2JqZWN0TGlrZShvYmopICYmICFBcnJheS5pc0FycmF5KG9iaik7XG59XG5mdW5jdGlvbiBmaWVsZHNUb0ZpZWxkc0NvbmZpZyhmaWVsZHMpIHtcbiAgcmV0dXJuIG1hcFZhbHVlKGZpZWxkcywgKGZpZWxkKSA9PiAoe1xuICAgIGRlc2NyaXB0aW9uOiBmaWVsZC5kZXNjcmlwdGlvbixcbiAgICB0eXBlOiBmaWVsZC50eXBlLFxuICAgIGFyZ3M6IGFyZ3NUb0FyZ3NDb25maWcoZmllbGQuYXJncyksXG4gICAgcmVzb2x2ZTogZmllbGQucmVzb2x2ZSxcbiAgICBzdWJzY3JpYmU6IGZpZWxkLnN1YnNjcmliZSxcbiAgICBkZXByZWNhdGlvblJlYXNvbjogZmllbGQuZGVwcmVjYXRpb25SZWFzb24sXG4gICAgZXh0ZW5zaW9uczogZmllbGQuZXh0ZW5zaW9ucyxcbiAgICBhc3ROb2RlOiBmaWVsZC5hc3ROb2RlXG4gIH0pKTtcbn1cbmZ1bmN0aW9uIGFyZ3NUb0FyZ3NDb25maWcoYXJncykge1xuICByZXR1cm4ga2V5VmFsTWFwKFxuICAgIGFyZ3MsXG4gICAgKGFyZykgPT4gYXJnLm5hbWUsXG4gICAgKGFyZykgPT4gKHtcbiAgICAgIGRlc2NyaXB0aW9uOiBhcmcuZGVzY3JpcHRpb24sXG4gICAgICB0eXBlOiBhcmcudHlwZSxcbiAgICAgIGRlZmF1bHRWYWx1ZTogYXJnLmRlZmF1bHRWYWx1ZSxcbiAgICAgIGRlcHJlY2F0aW9uUmVhc29uOiBhcmcuZGVwcmVjYXRpb25SZWFzb24sXG4gICAgICBleHRlbnNpb25zOiBhcmcuZXh0ZW5zaW9ucyxcbiAgICAgIGFzdE5vZGU6IGFyZy5hc3ROb2RlXG4gICAgfSlcbiAgKTtcbn1cbmZ1bmN0aW9uIGlzUmVxdWlyZWRBcmd1bWVudChhcmcpIHtcbiAgcmV0dXJuIGlzTm9uTnVsbFR5cGUoYXJnLnR5cGUpICYmIGFyZy5kZWZhdWx0VmFsdWUgPT09IHZvaWQgMDtcbn1cbnZhciBHcmFwaFFMSW50ZXJmYWNlVHlwZSA9IGNsYXNzIHtcbiAgY29uc3RydWN0b3IoY29uZmlnKSB7XG4gICAgdmFyIF9jb25maWckZXh0ZW5zaW9uQVNUTjM7XG4gICAgdGhpcy5uYW1lID0gYXNzZXJ0TmFtZShjb25maWcubmFtZSk7XG4gICAgdGhpcy5kZXNjcmlwdGlvbiA9IGNvbmZpZy5kZXNjcmlwdGlvbjtcbiAgICB0aGlzLnJlc29sdmVUeXBlID0gY29uZmlnLnJlc29sdmVUeXBlO1xuICAgIHRoaXMuZXh0ZW5zaW9ucyA9IHRvT2JqTWFwKGNvbmZpZy5leHRlbnNpb25zKTtcbiAgICB0aGlzLmFzdE5vZGUgPSBjb25maWcuYXN0Tm9kZTtcbiAgICB0aGlzLmV4dGVuc2lvbkFTVE5vZGVzID0gKF9jb25maWckZXh0ZW5zaW9uQVNUTjMgPSBjb25maWcuZXh0ZW5zaW9uQVNUTm9kZXMpICE9PSBudWxsICYmIF9jb25maWckZXh0ZW5zaW9uQVNUTjMgIT09IHZvaWQgMCA/IF9jb25maWckZXh0ZW5zaW9uQVNUTjMgOiBbXTtcbiAgICB0aGlzLl9maWVsZHMgPSBkZWZpbmVGaWVsZE1hcC5iaW5kKHZvaWQgMCwgY29uZmlnKTtcbiAgICB0aGlzLl9pbnRlcmZhY2VzID0gZGVmaW5lSW50ZXJmYWNlcy5iaW5kKHZvaWQgMCwgY29uZmlnKTtcbiAgICBjb25maWcucmVzb2x2ZVR5cGUgPT0gbnVsbCB8fCB0eXBlb2YgY29uZmlnLnJlc29sdmVUeXBlID09PSBcImZ1bmN0aW9uXCIgfHwgZGV2QXNzZXJ0KFxuICAgICAgZmFsc2UsXG4gICAgICBgJHt0aGlzLm5hbWV9IG11c3QgcHJvdmlkZSBcInJlc29sdmVUeXBlXCIgYXMgYSBmdW5jdGlvbiwgYnV0IGdvdDogJHtpbnNwZWN0KGNvbmZpZy5yZXNvbHZlVHlwZSl9LmBcbiAgICApO1xuICB9XG4gIGdldCBbU3ltYm9sLnRvU3RyaW5nVGFnXSgpIHtcbiAgICByZXR1cm4gXCJHcmFwaFFMSW50ZXJmYWNlVHlwZVwiO1xuICB9XG4gIGdldEZpZWxkcygpIHtcbiAgICBpZiAodHlwZW9mIHRoaXMuX2ZpZWxkcyA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICB0aGlzLl9maWVsZHMgPSB0aGlzLl9maWVsZHMoKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuX2ZpZWxkcztcbiAgfVxuICBnZXRJbnRlcmZhY2VzKCkge1xuICAgIGlmICh0eXBlb2YgdGhpcy5faW50ZXJmYWNlcyA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICB0aGlzLl9pbnRlcmZhY2VzID0gdGhpcy5faW50ZXJmYWNlcygpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5faW50ZXJmYWNlcztcbiAgfVxuICB0b0NvbmZpZygpIHtcbiAgICByZXR1cm4ge1xuICAgICAgbmFtZTogdGhpcy5uYW1lLFxuICAgICAgZGVzY3JpcHRpb246IHRoaXMuZGVzY3JpcHRpb24sXG4gICAgICBpbnRlcmZhY2VzOiB0aGlzLmdldEludGVyZmFjZXMoKSxcbiAgICAgIGZpZWxkczogZmllbGRzVG9GaWVsZHNDb25maWcodGhpcy5nZXRGaWVsZHMoKSksXG4gICAgICByZXNvbHZlVHlwZTogdGhpcy5yZXNvbHZlVHlwZSxcbiAgICAgIGV4dGVuc2lvbnM6IHRoaXMuZXh0ZW5zaW9ucyxcbiAgICAgIGFzdE5vZGU6IHRoaXMuYXN0Tm9kZSxcbiAgICAgIGV4dGVuc2lvbkFTVE5vZGVzOiB0aGlzLmV4dGVuc2lvbkFTVE5vZGVzXG4gICAgfTtcbiAgfVxuICB0b1N0cmluZygpIHtcbiAgICByZXR1cm4gdGhpcy5uYW1lO1xuICB9XG4gIHRvSlNPTigpIHtcbiAgICByZXR1cm4gdGhpcy50b1N0cmluZygpO1xuICB9XG59O1xudmFyIEdyYXBoUUxVbmlvblR5cGUgPSBjbGFzcyB7XG4gIGNvbnN0cnVjdG9yKGNvbmZpZykge1xuICAgIHZhciBfY29uZmlnJGV4dGVuc2lvbkFTVE40O1xuICAgIHRoaXMubmFtZSA9IGFzc2VydE5hbWUoY29uZmlnLm5hbWUpO1xuICAgIHRoaXMuZGVzY3JpcHRpb24gPSBjb25maWcuZGVzY3JpcHRpb247XG4gICAgdGhpcy5yZXNvbHZlVHlwZSA9IGNvbmZpZy5yZXNvbHZlVHlwZTtcbiAgICB0aGlzLmV4dGVuc2lvbnMgPSB0b09iak1hcChjb25maWcuZXh0ZW5zaW9ucyk7XG4gICAgdGhpcy5hc3ROb2RlID0gY29uZmlnLmFzdE5vZGU7XG4gICAgdGhpcy5leHRlbnNpb25BU1ROb2RlcyA9IChfY29uZmlnJGV4dGVuc2lvbkFTVE40ID0gY29uZmlnLmV4dGVuc2lvbkFTVE5vZGVzKSAhPT0gbnVsbCAmJiBfY29uZmlnJGV4dGVuc2lvbkFTVE40ICE9PSB2b2lkIDAgPyBfY29uZmlnJGV4dGVuc2lvbkFTVE40IDogW107XG4gICAgdGhpcy5fdHlwZXMgPSBkZWZpbmVUeXBlcy5iaW5kKHZvaWQgMCwgY29uZmlnKTtcbiAgICBjb25maWcucmVzb2x2ZVR5cGUgPT0gbnVsbCB8fCB0eXBlb2YgY29uZmlnLnJlc29sdmVUeXBlID09PSBcImZ1bmN0aW9uXCIgfHwgZGV2QXNzZXJ0KFxuICAgICAgZmFsc2UsXG4gICAgICBgJHt0aGlzLm5hbWV9IG11c3QgcHJvdmlkZSBcInJlc29sdmVUeXBlXCIgYXMgYSBmdW5jdGlvbiwgYnV0IGdvdDogJHtpbnNwZWN0KGNvbmZpZy5yZXNvbHZlVHlwZSl9LmBcbiAgICApO1xuICB9XG4gIGdldCBbU3ltYm9sLnRvU3RyaW5nVGFnXSgpIHtcbiAgICByZXR1cm4gXCJHcmFwaFFMVW5pb25UeXBlXCI7XG4gIH1cbiAgZ2V0VHlwZXMoKSB7XG4gICAgaWYgKHR5cGVvZiB0aGlzLl90eXBlcyA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICB0aGlzLl90eXBlcyA9IHRoaXMuX3R5cGVzKCk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLl90eXBlcztcbiAgfVxuICB0b0NvbmZpZygpIHtcbiAgICByZXR1cm4ge1xuICAgICAgbmFtZTogdGhpcy5uYW1lLFxuICAgICAgZGVzY3JpcHRpb246IHRoaXMuZGVzY3JpcHRpb24sXG4gICAgICB0eXBlczogdGhpcy5nZXRUeXBlcygpLFxuICAgICAgcmVzb2x2ZVR5cGU6IHRoaXMucmVzb2x2ZVR5cGUsXG4gICAgICBleHRlbnNpb25zOiB0aGlzLmV4dGVuc2lvbnMsXG4gICAgICBhc3ROb2RlOiB0aGlzLmFzdE5vZGUsXG4gICAgICBleHRlbnNpb25BU1ROb2RlczogdGhpcy5leHRlbnNpb25BU1ROb2Rlc1xuICAgIH07XG4gIH1cbiAgdG9TdHJpbmcoKSB7XG4gICAgcmV0dXJuIHRoaXMubmFtZTtcbiAgfVxuICB0b0pTT04oKSB7XG4gICAgcmV0dXJuIHRoaXMudG9TdHJpbmcoKTtcbiAgfVxufTtcbmZ1bmN0aW9uIGRlZmluZVR5cGVzKGNvbmZpZykge1xuICBjb25zdCB0eXBlcyA9IHJlc29sdmVSZWFkb25seUFycmF5VGh1bmsoY29uZmlnLnR5cGVzKTtcbiAgQXJyYXkuaXNBcnJheSh0eXBlcykgfHwgZGV2QXNzZXJ0KFxuICAgIGZhbHNlLFxuICAgIGBNdXN0IHByb3ZpZGUgQXJyYXkgb2YgdHlwZXMgb3IgYSBmdW5jdGlvbiB3aGljaCByZXR1cm5zIHN1Y2ggYW4gYXJyYXkgZm9yIFVuaW9uICR7Y29uZmlnLm5hbWV9LmBcbiAgKTtcbiAgcmV0dXJuIHR5cGVzO1xufVxudmFyIEdyYXBoUUxFbnVtVHlwZSA9IGNsYXNzIHtcbiAgLyogPFQ+ICovXG4gIGNvbnN0cnVjdG9yKGNvbmZpZykge1xuICAgIHZhciBfY29uZmlnJGV4dGVuc2lvbkFTVE41O1xuICAgIHRoaXMubmFtZSA9IGFzc2VydE5hbWUoY29uZmlnLm5hbWUpO1xuICAgIHRoaXMuZGVzY3JpcHRpb24gPSBjb25maWcuZGVzY3JpcHRpb247XG4gICAgdGhpcy5leHRlbnNpb25zID0gdG9PYmpNYXAoY29uZmlnLmV4dGVuc2lvbnMpO1xuICAgIHRoaXMuYXN0Tm9kZSA9IGNvbmZpZy5hc3ROb2RlO1xuICAgIHRoaXMuZXh0ZW5zaW9uQVNUTm9kZXMgPSAoX2NvbmZpZyRleHRlbnNpb25BU1RONSA9IGNvbmZpZy5leHRlbnNpb25BU1ROb2RlcykgIT09IG51bGwgJiYgX2NvbmZpZyRleHRlbnNpb25BU1RONSAhPT0gdm9pZCAwID8gX2NvbmZpZyRleHRlbnNpb25BU1RONSA6IFtdO1xuICAgIHRoaXMuX3ZhbHVlcyA9IGRlZmluZUVudW1WYWx1ZXModGhpcy5uYW1lLCBjb25maWcudmFsdWVzKTtcbiAgICB0aGlzLl92YWx1ZUxvb2t1cCA9IG5ldyBNYXAoXG4gICAgICB0aGlzLl92YWx1ZXMubWFwKChlbnVtVmFsdWUpID0+IFtlbnVtVmFsdWUudmFsdWUsIGVudW1WYWx1ZV0pXG4gICAgKTtcbiAgICB0aGlzLl9uYW1lTG9va3VwID0ga2V5TWFwKHRoaXMuX3ZhbHVlcywgKHZhbHVlKSA9PiB2YWx1ZS5uYW1lKTtcbiAgfVxuICBnZXQgW1N5bWJvbC50b1N0cmluZ1RhZ10oKSB7XG4gICAgcmV0dXJuIFwiR3JhcGhRTEVudW1UeXBlXCI7XG4gIH1cbiAgZ2V0VmFsdWVzKCkge1xuICAgIHJldHVybiB0aGlzLl92YWx1ZXM7XG4gIH1cbiAgZ2V0VmFsdWUobmFtZSkge1xuICAgIHJldHVybiB0aGlzLl9uYW1lTG9va3VwW25hbWVdO1xuICB9XG4gIHNlcmlhbGl6ZShvdXRwdXRWYWx1ZSkge1xuICAgIGNvbnN0IGVudW1WYWx1ZSA9IHRoaXMuX3ZhbHVlTG9va3VwLmdldChvdXRwdXRWYWx1ZSk7XG4gICAgaWYgKGVudW1WYWx1ZSA9PT0gdm9pZCAwKSB7XG4gICAgICB0aHJvdyBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICBgRW51bSBcIiR7dGhpcy5uYW1lfVwiIGNhbm5vdCByZXByZXNlbnQgdmFsdWU6ICR7aW5zcGVjdChvdXRwdXRWYWx1ZSl9YFxuICAgICAgKTtcbiAgICB9XG4gICAgcmV0dXJuIGVudW1WYWx1ZS5uYW1lO1xuICB9XG4gIHBhcnNlVmFsdWUoaW5wdXRWYWx1ZSkge1xuICAgIGlmICh0eXBlb2YgaW5wdXRWYWx1ZSAhPT0gXCJzdHJpbmdcIikge1xuICAgICAgY29uc3QgdmFsdWVTdHIgPSBpbnNwZWN0KGlucHV0VmFsdWUpO1xuICAgICAgdGhyb3cgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgYEVudW0gXCIke3RoaXMubmFtZX1cIiBjYW5ub3QgcmVwcmVzZW50IG5vbi1zdHJpbmcgdmFsdWU6ICR7dmFsdWVTdHJ9LmAgKyBkaWRZb3VNZWFuRW51bVZhbHVlKHRoaXMsIHZhbHVlU3RyKVxuICAgICAgKTtcbiAgICB9XG4gICAgY29uc3QgZW51bVZhbHVlID0gdGhpcy5nZXRWYWx1ZShpbnB1dFZhbHVlKTtcbiAgICBpZiAoZW51bVZhbHVlID09IG51bGwpIHtcbiAgICAgIHRocm93IG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgIGBWYWx1ZSBcIiR7aW5wdXRWYWx1ZX1cIiBkb2VzIG5vdCBleGlzdCBpbiBcIiR7dGhpcy5uYW1lfVwiIGVudW0uYCArIGRpZFlvdU1lYW5FbnVtVmFsdWUodGhpcywgaW5wdXRWYWx1ZSlcbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiBlbnVtVmFsdWUudmFsdWU7XG4gIH1cbiAgcGFyc2VMaXRlcmFsKHZhbHVlTm9kZSwgX3ZhcmlhYmxlcykge1xuICAgIGlmICh2YWx1ZU5vZGUua2luZCAhPT0gS2luZC5FTlVNKSB7XG4gICAgICBjb25zdCB2YWx1ZVN0ciA9IHByaW50KHZhbHVlTm9kZSk7XG4gICAgICB0aHJvdyBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICBgRW51bSBcIiR7dGhpcy5uYW1lfVwiIGNhbm5vdCByZXByZXNlbnQgbm9uLWVudW0gdmFsdWU6ICR7dmFsdWVTdHJ9LmAgKyBkaWRZb3VNZWFuRW51bVZhbHVlKHRoaXMsIHZhbHVlU3RyKSxcbiAgICAgICAge1xuICAgICAgICAgIG5vZGVzOiB2YWx1ZU5vZGVcbiAgICAgICAgfVxuICAgICAgKTtcbiAgICB9XG4gICAgY29uc3QgZW51bVZhbHVlID0gdGhpcy5nZXRWYWx1ZSh2YWx1ZU5vZGUudmFsdWUpO1xuICAgIGlmIChlbnVtVmFsdWUgPT0gbnVsbCkge1xuICAgICAgY29uc3QgdmFsdWVTdHIgPSBwcmludCh2YWx1ZU5vZGUpO1xuICAgICAgdGhyb3cgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgYFZhbHVlIFwiJHt2YWx1ZVN0cn1cIiBkb2VzIG5vdCBleGlzdCBpbiBcIiR7dGhpcy5uYW1lfVwiIGVudW0uYCArIGRpZFlvdU1lYW5FbnVtVmFsdWUodGhpcywgdmFsdWVTdHIpLFxuICAgICAgICB7XG4gICAgICAgICAgbm9kZXM6IHZhbHVlTm9kZVxuICAgICAgICB9XG4gICAgICApO1xuICAgIH1cbiAgICByZXR1cm4gZW51bVZhbHVlLnZhbHVlO1xuICB9XG4gIHRvQ29uZmlnKCkge1xuICAgIGNvbnN0IHZhbHVlcyA9IGtleVZhbE1hcChcbiAgICAgIHRoaXMuZ2V0VmFsdWVzKCksXG4gICAgICAodmFsdWUpID0+IHZhbHVlLm5hbWUsXG4gICAgICAodmFsdWUpID0+ICh7XG4gICAgICAgIGRlc2NyaXB0aW9uOiB2YWx1ZS5kZXNjcmlwdGlvbixcbiAgICAgICAgdmFsdWU6IHZhbHVlLnZhbHVlLFxuICAgICAgICBkZXByZWNhdGlvblJlYXNvbjogdmFsdWUuZGVwcmVjYXRpb25SZWFzb24sXG4gICAgICAgIGV4dGVuc2lvbnM6IHZhbHVlLmV4dGVuc2lvbnMsXG4gICAgICAgIGFzdE5vZGU6IHZhbHVlLmFzdE5vZGVcbiAgICAgIH0pXG4gICAgKTtcbiAgICByZXR1cm4ge1xuICAgICAgbmFtZTogdGhpcy5uYW1lLFxuICAgICAgZGVzY3JpcHRpb246IHRoaXMuZGVzY3JpcHRpb24sXG4gICAgICB2YWx1ZXMsXG4gICAgICBleHRlbnNpb25zOiB0aGlzLmV4dGVuc2lvbnMsXG4gICAgICBhc3ROb2RlOiB0aGlzLmFzdE5vZGUsXG4gICAgICBleHRlbnNpb25BU1ROb2RlczogdGhpcy5leHRlbnNpb25BU1ROb2Rlc1xuICAgIH07XG4gIH1cbiAgdG9TdHJpbmcoKSB7XG4gICAgcmV0dXJuIHRoaXMubmFtZTtcbiAgfVxuICB0b0pTT04oKSB7XG4gICAgcmV0dXJuIHRoaXMudG9TdHJpbmcoKTtcbiAgfVxufTtcbmZ1bmN0aW9uIGRpZFlvdU1lYW5FbnVtVmFsdWUoZW51bVR5cGUsIHVua25vd25WYWx1ZVN0cikge1xuICBjb25zdCBhbGxOYW1lcyA9IGVudW1UeXBlLmdldFZhbHVlcygpLm1hcCgodmFsdWUpID0+IHZhbHVlLm5hbWUpO1xuICBjb25zdCBzdWdnZXN0ZWRWYWx1ZXMgPSBzdWdnZXN0aW9uTGlzdCh1bmtub3duVmFsdWVTdHIsIGFsbE5hbWVzKTtcbiAgcmV0dXJuIGRpZFlvdU1lYW4oXCJ0aGUgZW51bSB2YWx1ZVwiLCBzdWdnZXN0ZWRWYWx1ZXMpO1xufVxuZnVuY3Rpb24gZGVmaW5lRW51bVZhbHVlcyh0eXBlTmFtZSwgdmFsdWVNYXApIHtcbiAgaXNQbGFpbk9iaih2YWx1ZU1hcCkgfHwgZGV2QXNzZXJ0KFxuICAgIGZhbHNlLFxuICAgIGAke3R5cGVOYW1lfSB2YWx1ZXMgbXVzdCBiZSBhbiBvYmplY3Qgd2l0aCB2YWx1ZSBuYW1lcyBhcyBrZXlzLmBcbiAgKTtcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHZhbHVlTWFwKS5tYXAoKFt2YWx1ZU5hbWUsIHZhbHVlQ29uZmlnXSkgPT4ge1xuICAgIGlzUGxhaW5PYmoodmFsdWVDb25maWcpIHx8IGRldkFzc2VydChcbiAgICAgIGZhbHNlLFxuICAgICAgYCR7dHlwZU5hbWV9LiR7dmFsdWVOYW1lfSBtdXN0IHJlZmVyIHRvIGFuIG9iamVjdCB3aXRoIGEgXCJ2YWx1ZVwiIGtleSByZXByZXNlbnRpbmcgYW4gaW50ZXJuYWwgdmFsdWUgYnV0IGdvdDogJHtpbnNwZWN0KHZhbHVlQ29uZmlnKX0uYFxuICAgICk7XG4gICAgcmV0dXJuIHtcbiAgICAgIG5hbWU6IGFzc2VydEVudW1WYWx1ZU5hbWUodmFsdWVOYW1lKSxcbiAgICAgIGRlc2NyaXB0aW9uOiB2YWx1ZUNvbmZpZy5kZXNjcmlwdGlvbixcbiAgICAgIHZhbHVlOiB2YWx1ZUNvbmZpZy52YWx1ZSAhPT0gdm9pZCAwID8gdmFsdWVDb25maWcudmFsdWUgOiB2YWx1ZU5hbWUsXG4gICAgICBkZXByZWNhdGlvblJlYXNvbjogdmFsdWVDb25maWcuZGVwcmVjYXRpb25SZWFzb24sXG4gICAgICBleHRlbnNpb25zOiB0b09iak1hcCh2YWx1ZUNvbmZpZy5leHRlbnNpb25zKSxcbiAgICAgIGFzdE5vZGU6IHZhbHVlQ29uZmlnLmFzdE5vZGVcbiAgICB9O1xuICB9KTtcbn1cbnZhciBHcmFwaFFMSW5wdXRPYmplY3RUeXBlID0gY2xhc3Mge1xuICBjb25zdHJ1Y3Rvcihjb25maWcpIHtcbiAgICB2YXIgX2NvbmZpZyRleHRlbnNpb25BU1RONjtcbiAgICB0aGlzLm5hbWUgPSBhc3NlcnROYW1lKGNvbmZpZy5uYW1lKTtcbiAgICB0aGlzLmRlc2NyaXB0aW9uID0gY29uZmlnLmRlc2NyaXB0aW9uO1xuICAgIHRoaXMuZXh0ZW5zaW9ucyA9IHRvT2JqTWFwKGNvbmZpZy5leHRlbnNpb25zKTtcbiAgICB0aGlzLmFzdE5vZGUgPSBjb25maWcuYXN0Tm9kZTtcbiAgICB0aGlzLmV4dGVuc2lvbkFTVE5vZGVzID0gKF9jb25maWckZXh0ZW5zaW9uQVNUTjYgPSBjb25maWcuZXh0ZW5zaW9uQVNUTm9kZXMpICE9PSBudWxsICYmIF9jb25maWckZXh0ZW5zaW9uQVNUTjYgIT09IHZvaWQgMCA/IF9jb25maWckZXh0ZW5zaW9uQVNUTjYgOiBbXTtcbiAgICB0aGlzLl9maWVsZHMgPSBkZWZpbmVJbnB1dEZpZWxkTWFwLmJpbmQodm9pZCAwLCBjb25maWcpO1xuICB9XG4gIGdldCBbU3ltYm9sLnRvU3RyaW5nVGFnXSgpIHtcbiAgICByZXR1cm4gXCJHcmFwaFFMSW5wdXRPYmplY3RUeXBlXCI7XG4gIH1cbiAgZ2V0RmllbGRzKCkge1xuICAgIGlmICh0eXBlb2YgdGhpcy5fZmllbGRzID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgIHRoaXMuX2ZpZWxkcyA9IHRoaXMuX2ZpZWxkcygpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5fZmllbGRzO1xuICB9XG4gIHRvQ29uZmlnKCkge1xuICAgIGNvbnN0IGZpZWxkcyA9IG1hcFZhbHVlKHRoaXMuZ2V0RmllbGRzKCksIChmaWVsZCkgPT4gKHtcbiAgICAgIGRlc2NyaXB0aW9uOiBmaWVsZC5kZXNjcmlwdGlvbixcbiAgICAgIHR5cGU6IGZpZWxkLnR5cGUsXG4gICAgICBkZWZhdWx0VmFsdWU6IGZpZWxkLmRlZmF1bHRWYWx1ZSxcbiAgICAgIGRlcHJlY2F0aW9uUmVhc29uOiBmaWVsZC5kZXByZWNhdGlvblJlYXNvbixcbiAgICAgIGV4dGVuc2lvbnM6IGZpZWxkLmV4dGVuc2lvbnMsXG4gICAgICBhc3ROb2RlOiBmaWVsZC5hc3ROb2RlXG4gICAgfSkpO1xuICAgIHJldHVybiB7XG4gICAgICBuYW1lOiB0aGlzLm5hbWUsXG4gICAgICBkZXNjcmlwdGlvbjogdGhpcy5kZXNjcmlwdGlvbixcbiAgICAgIGZpZWxkcyxcbiAgICAgIGV4dGVuc2lvbnM6IHRoaXMuZXh0ZW5zaW9ucyxcbiAgICAgIGFzdE5vZGU6IHRoaXMuYXN0Tm9kZSxcbiAgICAgIGV4dGVuc2lvbkFTVE5vZGVzOiB0aGlzLmV4dGVuc2lvbkFTVE5vZGVzXG4gICAgfTtcbiAgfVxuICB0b1N0cmluZygpIHtcbiAgICByZXR1cm4gdGhpcy5uYW1lO1xuICB9XG4gIHRvSlNPTigpIHtcbiAgICByZXR1cm4gdGhpcy50b1N0cmluZygpO1xuICB9XG59O1xuZnVuY3Rpb24gZGVmaW5lSW5wdXRGaWVsZE1hcChjb25maWcpIHtcbiAgY29uc3QgZmllbGRNYXAgPSByZXNvbHZlT2JqTWFwVGh1bmsoY29uZmlnLmZpZWxkcyk7XG4gIGlzUGxhaW5PYmooZmllbGRNYXApIHx8IGRldkFzc2VydChcbiAgICBmYWxzZSxcbiAgICBgJHtjb25maWcubmFtZX0gZmllbGRzIG11c3QgYmUgYW4gb2JqZWN0IHdpdGggZmllbGQgbmFtZXMgYXMga2V5cyBvciBhIGZ1bmN0aW9uIHdoaWNoIHJldHVybnMgc3VjaCBhbiBvYmplY3QuYFxuICApO1xuICByZXR1cm4gbWFwVmFsdWUoZmllbGRNYXAsIChmaWVsZENvbmZpZywgZmllbGROYW1lKSA9PiB7XG4gICAgIShcInJlc29sdmVcIiBpbiBmaWVsZENvbmZpZykgfHwgZGV2QXNzZXJ0KFxuICAgICAgZmFsc2UsXG4gICAgICBgJHtjb25maWcubmFtZX0uJHtmaWVsZE5hbWV9IGZpZWxkIGhhcyBhIHJlc29sdmUgcHJvcGVydHksIGJ1dCBJbnB1dCBUeXBlcyBjYW5ub3QgZGVmaW5lIHJlc29sdmVycy5gXG4gICAgKTtcbiAgICByZXR1cm4ge1xuICAgICAgbmFtZTogYXNzZXJ0TmFtZShmaWVsZE5hbWUpLFxuICAgICAgZGVzY3JpcHRpb246IGZpZWxkQ29uZmlnLmRlc2NyaXB0aW9uLFxuICAgICAgdHlwZTogZmllbGRDb25maWcudHlwZSxcbiAgICAgIGRlZmF1bHRWYWx1ZTogZmllbGRDb25maWcuZGVmYXVsdFZhbHVlLFxuICAgICAgZGVwcmVjYXRpb25SZWFzb246IGZpZWxkQ29uZmlnLmRlcHJlY2F0aW9uUmVhc29uLFxuICAgICAgZXh0ZW5zaW9uczogdG9PYmpNYXAoZmllbGRDb25maWcuZXh0ZW5zaW9ucyksXG4gICAgICBhc3ROb2RlOiBmaWVsZENvbmZpZy5hc3ROb2RlXG4gICAgfTtcbiAgfSk7XG59XG5mdW5jdGlvbiBpc1JlcXVpcmVkSW5wdXRGaWVsZChmaWVsZCkge1xuICByZXR1cm4gaXNOb25OdWxsVHlwZShmaWVsZC50eXBlKSAmJiBmaWVsZC5kZWZhdWx0VmFsdWUgPT09IHZvaWQgMDtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL3V0aWxpdGllcy90eXBlQ29tcGFyYXRvcnMubWpzXG5mdW5jdGlvbiBpc1R5cGVTdWJUeXBlT2Yoc2NoZW1hLCBtYXliZVN1YlR5cGUsIHN1cGVyVHlwZSkge1xuICBpZiAobWF5YmVTdWJUeXBlID09PSBzdXBlclR5cGUpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBpZiAoaXNOb25OdWxsVHlwZShzdXBlclR5cGUpKSB7XG4gICAgaWYgKGlzTm9uTnVsbFR5cGUobWF5YmVTdWJUeXBlKSkge1xuICAgICAgcmV0dXJuIGlzVHlwZVN1YlR5cGVPZihzY2hlbWEsIG1heWJlU3ViVHlwZS5vZlR5cGUsIHN1cGVyVHlwZS5vZlR5cGUpO1xuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgaWYgKGlzTm9uTnVsbFR5cGUobWF5YmVTdWJUeXBlKSkge1xuICAgIHJldHVybiBpc1R5cGVTdWJUeXBlT2Yoc2NoZW1hLCBtYXliZVN1YlR5cGUub2ZUeXBlLCBzdXBlclR5cGUpO1xuICB9XG4gIGlmIChpc0xpc3RUeXBlKHN1cGVyVHlwZSkpIHtcbiAgICBpZiAoaXNMaXN0VHlwZShtYXliZVN1YlR5cGUpKSB7XG4gICAgICByZXR1cm4gaXNUeXBlU3ViVHlwZU9mKHNjaGVtYSwgbWF5YmVTdWJUeXBlLm9mVHlwZSwgc3VwZXJUeXBlLm9mVHlwZSk7XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBpZiAoaXNMaXN0VHlwZShtYXliZVN1YlR5cGUpKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIHJldHVybiBpc0Fic3RyYWN0VHlwZShzdXBlclR5cGUpICYmIChpc0ludGVyZmFjZVR5cGUobWF5YmVTdWJUeXBlKSB8fCBpc09iamVjdFR5cGUobWF5YmVTdWJUeXBlKSkgJiYgc2NoZW1hLmlzU3ViVHlwZShzdXBlclR5cGUsIG1heWJlU3ViVHlwZSk7XG59XG5mdW5jdGlvbiBkb1R5cGVzT3ZlcmxhcChzY2hlbWEsIHR5cGVBLCB0eXBlQikge1xuICBpZiAodHlwZUEgPT09IHR5cGVCKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgaWYgKGlzQWJzdHJhY3RUeXBlKHR5cGVBKSkge1xuICAgIGlmIChpc0Fic3RyYWN0VHlwZSh0eXBlQikpIHtcbiAgICAgIHJldHVybiBzY2hlbWEuZ2V0UG9zc2libGVUeXBlcyh0eXBlQSkuc29tZSgodHlwZSkgPT4gc2NoZW1hLmlzU3ViVHlwZSh0eXBlQiwgdHlwZSkpO1xuICAgIH1cbiAgICByZXR1cm4gc2NoZW1hLmlzU3ViVHlwZSh0eXBlQSwgdHlwZUIpO1xuICB9XG4gIGlmIChpc0Fic3RyYWN0VHlwZSh0eXBlQikpIHtcbiAgICByZXR1cm4gc2NoZW1hLmlzU3ViVHlwZSh0eXBlQiwgdHlwZUEpO1xuICB9XG4gIHJldHVybiBmYWxzZTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL3R5cGUvc2NhbGFycy5tanNcbnZhciBHUkFQSFFMX01BWF9JTlQgPSAyMTQ3NDgzNjQ3O1xudmFyIEdSQVBIUUxfTUlOX0lOVCA9IC0yMTQ3NDgzNjQ4O1xudmFyIEdyYXBoUUxJbnQgPSBuZXcgR3JhcGhRTFNjYWxhclR5cGUoe1xuICBuYW1lOiBcIkludFwiLFxuICBkZXNjcmlwdGlvbjogXCJUaGUgYEludGAgc2NhbGFyIHR5cGUgcmVwcmVzZW50cyBub24tZnJhY3Rpb25hbCBzaWduZWQgd2hvbGUgbnVtZXJpYyB2YWx1ZXMuIEludCBjYW4gcmVwcmVzZW50IHZhbHVlcyBiZXR3ZWVuIC0oMl4zMSkgYW5kIDJeMzEgLSAxLlwiLFxuICBzZXJpYWxpemUob3V0cHV0VmFsdWUpIHtcbiAgICBjb25zdCBjb2VyY2VkVmFsdWUgPSBzZXJpYWxpemVPYmplY3Qob3V0cHV0VmFsdWUpO1xuICAgIGlmICh0eXBlb2YgY29lcmNlZFZhbHVlID09PSBcImJvb2xlYW5cIikge1xuICAgICAgcmV0dXJuIGNvZXJjZWRWYWx1ZSA/IDEgOiAwO1xuICAgIH1cbiAgICBsZXQgbnVtID0gY29lcmNlZFZhbHVlO1xuICAgIGlmICh0eXBlb2YgY29lcmNlZFZhbHVlID09PSBcInN0cmluZ1wiICYmIGNvZXJjZWRWYWx1ZSAhPT0gXCJcIikge1xuICAgICAgbnVtID0gTnVtYmVyKGNvZXJjZWRWYWx1ZSk7XG4gICAgfVxuICAgIGlmICh0eXBlb2YgbnVtICE9PSBcIm51bWJlclwiIHx8ICFOdW1iZXIuaXNJbnRlZ2VyKG51bSkpIHtcbiAgICAgIHRocm93IG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgIGBJbnQgY2Fubm90IHJlcHJlc2VudCBub24taW50ZWdlciB2YWx1ZTogJHtpbnNwZWN0KGNvZXJjZWRWYWx1ZSl9YFxuICAgICAgKTtcbiAgICB9XG4gICAgaWYgKG51bSA+IEdSQVBIUUxfTUFYX0lOVCB8fCBudW0gPCBHUkFQSFFMX01JTl9JTlQpIHtcbiAgICAgIHRocm93IG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgIFwiSW50IGNhbm5vdCByZXByZXNlbnQgbm9uIDMyLWJpdCBzaWduZWQgaW50ZWdlciB2YWx1ZTogXCIgKyBpbnNwZWN0KGNvZXJjZWRWYWx1ZSlcbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiBudW07XG4gIH0sXG4gIHBhcnNlVmFsdWUoaW5wdXRWYWx1ZSkge1xuICAgIGlmICh0eXBlb2YgaW5wdXRWYWx1ZSAhPT0gXCJudW1iZXJcIiB8fCAhTnVtYmVyLmlzSW50ZWdlcihpbnB1dFZhbHVlKSkge1xuICAgICAgdGhyb3cgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgYEludCBjYW5ub3QgcmVwcmVzZW50IG5vbi1pbnRlZ2VyIHZhbHVlOiAke2luc3BlY3QoaW5wdXRWYWx1ZSl9YFxuICAgICAgKTtcbiAgICB9XG4gICAgaWYgKGlucHV0VmFsdWUgPiBHUkFQSFFMX01BWF9JTlQgfHwgaW5wdXRWYWx1ZSA8IEdSQVBIUUxfTUlOX0lOVCkge1xuICAgICAgdGhyb3cgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgYEludCBjYW5ub3QgcmVwcmVzZW50IG5vbiAzMi1iaXQgc2lnbmVkIGludGVnZXIgdmFsdWU6ICR7aW5wdXRWYWx1ZX1gXG4gICAgICApO1xuICAgIH1cbiAgICByZXR1cm4gaW5wdXRWYWx1ZTtcbiAgfSxcbiAgcGFyc2VMaXRlcmFsKHZhbHVlTm9kZSkge1xuICAgIGlmICh2YWx1ZU5vZGUua2luZCAhPT0gS2luZC5JTlQpIHtcbiAgICAgIHRocm93IG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgIGBJbnQgY2Fubm90IHJlcHJlc2VudCBub24taW50ZWdlciB2YWx1ZTogJHtwcmludCh2YWx1ZU5vZGUpfWAsXG4gICAgICAgIHtcbiAgICAgICAgICBub2RlczogdmFsdWVOb2RlXG4gICAgICAgIH1cbiAgICAgICk7XG4gICAgfVxuICAgIGNvbnN0IG51bSA9IHBhcnNlSW50KHZhbHVlTm9kZS52YWx1ZSwgMTApO1xuICAgIGlmIChudW0gPiBHUkFQSFFMX01BWF9JTlQgfHwgbnVtIDwgR1JBUEhRTF9NSU5fSU5UKSB7XG4gICAgICB0aHJvdyBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICBgSW50IGNhbm5vdCByZXByZXNlbnQgbm9uIDMyLWJpdCBzaWduZWQgaW50ZWdlciB2YWx1ZTogJHt2YWx1ZU5vZGUudmFsdWV9YCxcbiAgICAgICAge1xuICAgICAgICAgIG5vZGVzOiB2YWx1ZU5vZGVcbiAgICAgICAgfVxuICAgICAgKTtcbiAgICB9XG4gICAgcmV0dXJuIG51bTtcbiAgfVxufSk7XG52YXIgR3JhcGhRTEZsb2F0ID0gbmV3IEdyYXBoUUxTY2FsYXJUeXBlKHtcbiAgbmFtZTogXCJGbG9hdFwiLFxuICBkZXNjcmlwdGlvbjogXCJUaGUgYEZsb2F0YCBzY2FsYXIgdHlwZSByZXByZXNlbnRzIHNpZ25lZCBkb3VibGUtcHJlY2lzaW9uIGZyYWN0aW9uYWwgdmFsdWVzIGFzIHNwZWNpZmllZCBieSBbSUVFRSA3NTRdKGh0dHBzOi8vZW4ud2lraXBlZGlhLm9yZy93aWtpL0lFRUVfZmxvYXRpbmdfcG9pbnQpLlwiLFxuICBzZXJpYWxpemUob3V0cHV0VmFsdWUpIHtcbiAgICBjb25zdCBjb2VyY2VkVmFsdWUgPSBzZXJpYWxpemVPYmplY3Qob3V0cHV0VmFsdWUpO1xuICAgIGlmICh0eXBlb2YgY29lcmNlZFZhbHVlID09PSBcImJvb2xlYW5cIikge1xuICAgICAgcmV0dXJuIGNvZXJjZWRWYWx1ZSA/IDEgOiAwO1xuICAgIH1cbiAgICBsZXQgbnVtID0gY29lcmNlZFZhbHVlO1xuICAgIGlmICh0eXBlb2YgY29lcmNlZFZhbHVlID09PSBcInN0cmluZ1wiICYmIGNvZXJjZWRWYWx1ZSAhPT0gXCJcIikge1xuICAgICAgbnVtID0gTnVtYmVyKGNvZXJjZWRWYWx1ZSk7XG4gICAgfVxuICAgIGlmICh0eXBlb2YgbnVtICE9PSBcIm51bWJlclwiIHx8ICFOdW1iZXIuaXNGaW5pdGUobnVtKSkge1xuICAgICAgdGhyb3cgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgYEZsb2F0IGNhbm5vdCByZXByZXNlbnQgbm9uIG51bWVyaWMgdmFsdWU6ICR7aW5zcGVjdChjb2VyY2VkVmFsdWUpfWBcbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiBudW07XG4gIH0sXG4gIHBhcnNlVmFsdWUoaW5wdXRWYWx1ZSkge1xuICAgIGlmICh0eXBlb2YgaW5wdXRWYWx1ZSAhPT0gXCJudW1iZXJcIiB8fCAhTnVtYmVyLmlzRmluaXRlKGlucHV0VmFsdWUpKSB7XG4gICAgICB0aHJvdyBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICBgRmxvYXQgY2Fubm90IHJlcHJlc2VudCBub24gbnVtZXJpYyB2YWx1ZTogJHtpbnNwZWN0KGlucHV0VmFsdWUpfWBcbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiBpbnB1dFZhbHVlO1xuICB9LFxuICBwYXJzZUxpdGVyYWwodmFsdWVOb2RlKSB7XG4gICAgaWYgKHZhbHVlTm9kZS5raW5kICE9PSBLaW5kLkZMT0FUICYmIHZhbHVlTm9kZS5raW5kICE9PSBLaW5kLklOVCkge1xuICAgICAgdGhyb3cgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgYEZsb2F0IGNhbm5vdCByZXByZXNlbnQgbm9uIG51bWVyaWMgdmFsdWU6ICR7cHJpbnQodmFsdWVOb2RlKX1gLFxuICAgICAgICB2YWx1ZU5vZGVcbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiBwYXJzZUZsb2F0KHZhbHVlTm9kZS52YWx1ZSk7XG4gIH1cbn0pO1xudmFyIEdyYXBoUUxTdHJpbmcgPSBuZXcgR3JhcGhRTFNjYWxhclR5cGUoe1xuICBuYW1lOiBcIlN0cmluZ1wiLFxuICBkZXNjcmlwdGlvbjogXCJUaGUgYFN0cmluZ2Agc2NhbGFyIHR5cGUgcmVwcmVzZW50cyB0ZXh0dWFsIGRhdGEsIHJlcHJlc2VudGVkIGFzIFVURi04IGNoYXJhY3RlciBzZXF1ZW5jZXMuIFRoZSBTdHJpbmcgdHlwZSBpcyBtb3N0IG9mdGVuIHVzZWQgYnkgR3JhcGhRTCB0byByZXByZXNlbnQgZnJlZS1mb3JtIGh1bWFuLXJlYWRhYmxlIHRleHQuXCIsXG4gIHNlcmlhbGl6ZShvdXRwdXRWYWx1ZSkge1xuICAgIGNvbnN0IGNvZXJjZWRWYWx1ZSA9IHNlcmlhbGl6ZU9iamVjdChvdXRwdXRWYWx1ZSk7XG4gICAgaWYgKHR5cGVvZiBjb2VyY2VkVmFsdWUgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgIHJldHVybiBjb2VyY2VkVmFsdWU7XG4gICAgfVxuICAgIGlmICh0eXBlb2YgY29lcmNlZFZhbHVlID09PSBcImJvb2xlYW5cIikge1xuICAgICAgcmV0dXJuIGNvZXJjZWRWYWx1ZSA/IFwidHJ1ZVwiIDogXCJmYWxzZVwiO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIGNvZXJjZWRWYWx1ZSA9PT0gXCJudW1iZXJcIiAmJiBOdW1iZXIuaXNGaW5pdGUoY29lcmNlZFZhbHVlKSkge1xuICAgICAgcmV0dXJuIGNvZXJjZWRWYWx1ZS50b1N0cmluZygpO1xuICAgIH1cbiAgICB0aHJvdyBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgYFN0cmluZyBjYW5ub3QgcmVwcmVzZW50IHZhbHVlOiAke2luc3BlY3Qob3V0cHV0VmFsdWUpfWBcbiAgICApO1xuICB9LFxuICBwYXJzZVZhbHVlKGlucHV0VmFsdWUpIHtcbiAgICBpZiAodHlwZW9mIGlucHV0VmFsdWUgIT09IFwic3RyaW5nXCIpIHtcbiAgICAgIHRocm93IG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgIGBTdHJpbmcgY2Fubm90IHJlcHJlc2VudCBhIG5vbiBzdHJpbmcgdmFsdWU6ICR7aW5zcGVjdChpbnB1dFZhbHVlKX1gXG4gICAgICApO1xuICAgIH1cbiAgICByZXR1cm4gaW5wdXRWYWx1ZTtcbiAgfSxcbiAgcGFyc2VMaXRlcmFsKHZhbHVlTm9kZSkge1xuICAgIGlmICh2YWx1ZU5vZGUua2luZCAhPT0gS2luZC5TVFJJTkcpIHtcbiAgICAgIHRocm93IG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgIGBTdHJpbmcgY2Fubm90IHJlcHJlc2VudCBhIG5vbiBzdHJpbmcgdmFsdWU6ICR7cHJpbnQodmFsdWVOb2RlKX1gLFxuICAgICAgICB7XG4gICAgICAgICAgbm9kZXM6IHZhbHVlTm9kZVxuICAgICAgICB9XG4gICAgICApO1xuICAgIH1cbiAgICByZXR1cm4gdmFsdWVOb2RlLnZhbHVlO1xuICB9XG59KTtcbnZhciBHcmFwaFFMQm9vbGVhbiA9IG5ldyBHcmFwaFFMU2NhbGFyVHlwZSh7XG4gIG5hbWU6IFwiQm9vbGVhblwiLFxuICBkZXNjcmlwdGlvbjogXCJUaGUgYEJvb2xlYW5gIHNjYWxhciB0eXBlIHJlcHJlc2VudHMgYHRydWVgIG9yIGBmYWxzZWAuXCIsXG4gIHNlcmlhbGl6ZShvdXRwdXRWYWx1ZSkge1xuICAgIGNvbnN0IGNvZXJjZWRWYWx1ZSA9IHNlcmlhbGl6ZU9iamVjdChvdXRwdXRWYWx1ZSk7XG4gICAgaWYgKHR5cGVvZiBjb2VyY2VkVmFsdWUgPT09IFwiYm9vbGVhblwiKSB7XG4gICAgICByZXR1cm4gY29lcmNlZFZhbHVlO1xuICAgIH1cbiAgICBpZiAoTnVtYmVyLmlzRmluaXRlKGNvZXJjZWRWYWx1ZSkpIHtcbiAgICAgIHJldHVybiBjb2VyY2VkVmFsdWUgIT09IDA7XG4gICAgfVxuICAgIHRocm93IG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICBgQm9vbGVhbiBjYW5ub3QgcmVwcmVzZW50IGEgbm9uIGJvb2xlYW4gdmFsdWU6ICR7aW5zcGVjdChjb2VyY2VkVmFsdWUpfWBcbiAgICApO1xuICB9LFxuICBwYXJzZVZhbHVlKGlucHV0VmFsdWUpIHtcbiAgICBpZiAodHlwZW9mIGlucHV0VmFsdWUgIT09IFwiYm9vbGVhblwiKSB7XG4gICAgICB0aHJvdyBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICBgQm9vbGVhbiBjYW5ub3QgcmVwcmVzZW50IGEgbm9uIGJvb2xlYW4gdmFsdWU6ICR7aW5zcGVjdChpbnB1dFZhbHVlKX1gXG4gICAgICApO1xuICAgIH1cbiAgICByZXR1cm4gaW5wdXRWYWx1ZTtcbiAgfSxcbiAgcGFyc2VMaXRlcmFsKHZhbHVlTm9kZSkge1xuICAgIGlmICh2YWx1ZU5vZGUua2luZCAhPT0gS2luZC5CT09MRUFOKSB7XG4gICAgICB0aHJvdyBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICBgQm9vbGVhbiBjYW5ub3QgcmVwcmVzZW50IGEgbm9uIGJvb2xlYW4gdmFsdWU6ICR7cHJpbnQodmFsdWVOb2RlKX1gLFxuICAgICAgICB7XG4gICAgICAgICAgbm9kZXM6IHZhbHVlTm9kZVxuICAgICAgICB9XG4gICAgICApO1xuICAgIH1cbiAgICByZXR1cm4gdmFsdWVOb2RlLnZhbHVlO1xuICB9XG59KTtcbnZhciBHcmFwaFFMSUQgPSBuZXcgR3JhcGhRTFNjYWxhclR5cGUoe1xuICBuYW1lOiBcIklEXCIsXG4gIGRlc2NyaXB0aW9uOiAnVGhlIGBJRGAgc2NhbGFyIHR5cGUgcmVwcmVzZW50cyBhIHVuaXF1ZSBpZGVudGlmaWVyLCBvZnRlbiB1c2VkIHRvIHJlZmV0Y2ggYW4gb2JqZWN0IG9yIGFzIGtleSBmb3IgYSBjYWNoZS4gVGhlIElEIHR5cGUgYXBwZWFycyBpbiBhIEpTT04gcmVzcG9uc2UgYXMgYSBTdHJpbmc7IGhvd2V2ZXIsIGl0IGlzIG5vdCBpbnRlbmRlZCB0byBiZSBodW1hbi1yZWFkYWJsZS4gV2hlbiBleHBlY3RlZCBhcyBhbiBpbnB1dCB0eXBlLCBhbnkgc3RyaW5nIChzdWNoIGFzIGBcIjRcImApIG9yIGludGVnZXIgKHN1Y2ggYXMgYDRgKSBpbnB1dCB2YWx1ZSB3aWxsIGJlIGFjY2VwdGVkIGFzIGFuIElELicsXG4gIHNlcmlhbGl6ZShvdXRwdXRWYWx1ZSkge1xuICAgIGNvbnN0IGNvZXJjZWRWYWx1ZSA9IHNlcmlhbGl6ZU9iamVjdChvdXRwdXRWYWx1ZSk7XG4gICAgaWYgKHR5cGVvZiBjb2VyY2VkVmFsdWUgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgIHJldHVybiBjb2VyY2VkVmFsdWU7XG4gICAgfVxuICAgIGlmIChOdW1iZXIuaXNJbnRlZ2VyKGNvZXJjZWRWYWx1ZSkpIHtcbiAgICAgIHJldHVybiBTdHJpbmcoY29lcmNlZFZhbHVlKTtcbiAgICB9XG4gICAgdGhyb3cgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgIGBJRCBjYW5ub3QgcmVwcmVzZW50IHZhbHVlOiAke2luc3BlY3Qob3V0cHV0VmFsdWUpfWBcbiAgICApO1xuICB9LFxuICBwYXJzZVZhbHVlKGlucHV0VmFsdWUpIHtcbiAgICBpZiAodHlwZW9mIGlucHV0VmFsdWUgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgIHJldHVybiBpbnB1dFZhbHVlO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIGlucHV0VmFsdWUgPT09IFwibnVtYmVyXCIgJiYgTnVtYmVyLmlzSW50ZWdlcihpbnB1dFZhbHVlKSkge1xuICAgICAgcmV0dXJuIGlucHV0VmFsdWUudG9TdHJpbmcoKTtcbiAgICB9XG4gICAgdGhyb3cgbmV3IEdyYXBoUUxFcnJvcihgSUQgY2Fubm90IHJlcHJlc2VudCB2YWx1ZTogJHtpbnNwZWN0KGlucHV0VmFsdWUpfWApO1xuICB9LFxuICBwYXJzZUxpdGVyYWwodmFsdWVOb2RlKSB7XG4gICAgaWYgKHZhbHVlTm9kZS5raW5kICE9PSBLaW5kLlNUUklORyAmJiB2YWx1ZU5vZGUua2luZCAhPT0gS2luZC5JTlQpIHtcbiAgICAgIHRocm93IG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgIFwiSUQgY2Fubm90IHJlcHJlc2VudCBhIG5vbi1zdHJpbmcgYW5kIG5vbi1pbnRlZ2VyIHZhbHVlOiBcIiArIHByaW50KHZhbHVlTm9kZSksXG4gICAgICAgIHtcbiAgICAgICAgICBub2RlczogdmFsdWVOb2RlXG4gICAgICAgIH1cbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiB2YWx1ZU5vZGUudmFsdWU7XG4gIH1cbn0pO1xudmFyIHNwZWNpZmllZFNjYWxhclR5cGVzID0gT2JqZWN0LmZyZWV6ZShbXG4gIEdyYXBoUUxTdHJpbmcsXG4gIEdyYXBoUUxJbnQsXG4gIEdyYXBoUUxGbG9hdCxcbiAgR3JhcGhRTEJvb2xlYW4sXG4gIEdyYXBoUUxJRFxuXSk7XG5mdW5jdGlvbiBzZXJpYWxpemVPYmplY3Qob3V0cHV0VmFsdWUpIHtcbiAgaWYgKGlzT2JqZWN0TGlrZShvdXRwdXRWYWx1ZSkpIHtcbiAgICBpZiAodHlwZW9mIG91dHB1dFZhbHVlLnZhbHVlT2YgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgY29uc3QgdmFsdWVPZlJlc3VsdCA9IG91dHB1dFZhbHVlLnZhbHVlT2YoKTtcbiAgICAgIGlmICghaXNPYmplY3RMaWtlKHZhbHVlT2ZSZXN1bHQpKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZU9mUmVzdWx0O1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAodHlwZW9mIG91dHB1dFZhbHVlLnRvSlNPTiA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICByZXR1cm4gb3V0cHV0VmFsdWUudG9KU09OKCk7XG4gICAgfVxuICB9XG4gIHJldHVybiBvdXRwdXRWYWx1ZTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL3R5cGUvZGlyZWN0aXZlcy5tanNcbnZhciBHcmFwaFFMRGlyZWN0aXZlID0gY2xhc3Mge1xuICBjb25zdHJ1Y3Rvcihjb25maWcpIHtcbiAgICB2YXIgX2NvbmZpZyRpc1JlcGVhdGFibGUsIF9jb25maWckYXJncztcbiAgICB0aGlzLm5hbWUgPSBhc3NlcnROYW1lKGNvbmZpZy5uYW1lKTtcbiAgICB0aGlzLmRlc2NyaXB0aW9uID0gY29uZmlnLmRlc2NyaXB0aW9uO1xuICAgIHRoaXMubG9jYXRpb25zID0gY29uZmlnLmxvY2F0aW9ucztcbiAgICB0aGlzLmlzUmVwZWF0YWJsZSA9IChfY29uZmlnJGlzUmVwZWF0YWJsZSA9IGNvbmZpZy5pc1JlcGVhdGFibGUpICE9PSBudWxsICYmIF9jb25maWckaXNSZXBlYXRhYmxlICE9PSB2b2lkIDAgPyBfY29uZmlnJGlzUmVwZWF0YWJsZSA6IGZhbHNlO1xuICAgIHRoaXMuZXh0ZW5zaW9ucyA9IHRvT2JqTWFwKGNvbmZpZy5leHRlbnNpb25zKTtcbiAgICB0aGlzLmFzdE5vZGUgPSBjb25maWcuYXN0Tm9kZTtcbiAgICBBcnJheS5pc0FycmF5KGNvbmZpZy5sb2NhdGlvbnMpIHx8IGRldkFzc2VydChmYWxzZSwgYEAke2NvbmZpZy5uYW1lfSBsb2NhdGlvbnMgbXVzdCBiZSBhbiBBcnJheS5gKTtcbiAgICBjb25zdCBhcmdzID0gKF9jb25maWckYXJncyA9IGNvbmZpZy5hcmdzKSAhPT0gbnVsbCAmJiBfY29uZmlnJGFyZ3MgIT09IHZvaWQgMCA/IF9jb25maWckYXJncyA6IHt9O1xuICAgIGlzT2JqZWN0TGlrZShhcmdzKSAmJiAhQXJyYXkuaXNBcnJheShhcmdzKSB8fCBkZXZBc3NlcnQoXG4gICAgICBmYWxzZSxcbiAgICAgIGBAJHtjb25maWcubmFtZX0gYXJncyBtdXN0IGJlIGFuIG9iamVjdCB3aXRoIGFyZ3VtZW50IG5hbWVzIGFzIGtleXMuYFxuICAgICk7XG4gICAgdGhpcy5hcmdzID0gZGVmaW5lQXJndW1lbnRzKGFyZ3MpO1xuICB9XG4gIGdldCBbU3ltYm9sLnRvU3RyaW5nVGFnXSgpIHtcbiAgICByZXR1cm4gXCJHcmFwaFFMRGlyZWN0aXZlXCI7XG4gIH1cbiAgdG9Db25maWcoKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIG5hbWU6IHRoaXMubmFtZSxcbiAgICAgIGRlc2NyaXB0aW9uOiB0aGlzLmRlc2NyaXB0aW9uLFxuICAgICAgbG9jYXRpb25zOiB0aGlzLmxvY2F0aW9ucyxcbiAgICAgIGFyZ3M6IGFyZ3NUb0FyZ3NDb25maWcodGhpcy5hcmdzKSxcbiAgICAgIGlzUmVwZWF0YWJsZTogdGhpcy5pc1JlcGVhdGFibGUsXG4gICAgICBleHRlbnNpb25zOiB0aGlzLmV4dGVuc2lvbnMsXG4gICAgICBhc3ROb2RlOiB0aGlzLmFzdE5vZGVcbiAgICB9O1xuICB9XG4gIHRvU3RyaW5nKCkge1xuICAgIHJldHVybiBcIkBcIiArIHRoaXMubmFtZTtcbiAgfVxuICB0b0pTT04oKSB7XG4gICAgcmV0dXJuIHRoaXMudG9TdHJpbmcoKTtcbiAgfVxufTtcbnZhciBHcmFwaFFMSW5jbHVkZURpcmVjdGl2ZSA9IG5ldyBHcmFwaFFMRGlyZWN0aXZlKHtcbiAgbmFtZTogXCJpbmNsdWRlXCIsXG4gIGRlc2NyaXB0aW9uOiBcIkRpcmVjdHMgdGhlIGV4ZWN1dG9yIHRvIGluY2x1ZGUgdGhpcyBmaWVsZCBvciBmcmFnbWVudCBvbmx5IHdoZW4gdGhlIGBpZmAgYXJndW1lbnQgaXMgdHJ1ZS5cIixcbiAgbG9jYXRpb25zOiBbXG4gICAgRGlyZWN0aXZlTG9jYXRpb24uRklFTEQsXG4gICAgRGlyZWN0aXZlTG9jYXRpb24uRlJBR01FTlRfU1BSRUFELFxuICAgIERpcmVjdGl2ZUxvY2F0aW9uLklOTElORV9GUkFHTUVOVFxuICBdLFxuICBhcmdzOiB7XG4gICAgaWY6IHtcbiAgICAgIHR5cGU6IG5ldyBHcmFwaFFMTm9uTnVsbChHcmFwaFFMQm9vbGVhbiksXG4gICAgICBkZXNjcmlwdGlvbjogXCJJbmNsdWRlZCB3aGVuIHRydWUuXCJcbiAgICB9XG4gIH1cbn0pO1xudmFyIEdyYXBoUUxTa2lwRGlyZWN0aXZlID0gbmV3IEdyYXBoUUxEaXJlY3RpdmUoe1xuICBuYW1lOiBcInNraXBcIixcbiAgZGVzY3JpcHRpb246IFwiRGlyZWN0cyB0aGUgZXhlY3V0b3IgdG8gc2tpcCB0aGlzIGZpZWxkIG9yIGZyYWdtZW50IHdoZW4gdGhlIGBpZmAgYXJndW1lbnQgaXMgdHJ1ZS5cIixcbiAgbG9jYXRpb25zOiBbXG4gICAgRGlyZWN0aXZlTG9jYXRpb24uRklFTEQsXG4gICAgRGlyZWN0aXZlTG9jYXRpb24uRlJBR01FTlRfU1BSRUFELFxuICAgIERpcmVjdGl2ZUxvY2F0aW9uLklOTElORV9GUkFHTUVOVFxuICBdLFxuICBhcmdzOiB7XG4gICAgaWY6IHtcbiAgICAgIHR5cGU6IG5ldyBHcmFwaFFMTm9uTnVsbChHcmFwaFFMQm9vbGVhbiksXG4gICAgICBkZXNjcmlwdGlvbjogXCJTa2lwcGVkIHdoZW4gdHJ1ZS5cIlxuICAgIH1cbiAgfVxufSk7XG52YXIgREVGQVVMVF9ERVBSRUNBVElPTl9SRUFTT04gPSBcIk5vIGxvbmdlciBzdXBwb3J0ZWRcIjtcbnZhciBHcmFwaFFMRGVwcmVjYXRlZERpcmVjdGl2ZSA9IG5ldyBHcmFwaFFMRGlyZWN0aXZlKHtcbiAgbmFtZTogXCJkZXByZWNhdGVkXCIsXG4gIGRlc2NyaXB0aW9uOiBcIk1hcmtzIGFuIGVsZW1lbnQgb2YgYSBHcmFwaFFMIHNjaGVtYSBhcyBubyBsb25nZXIgc3VwcG9ydGVkLlwiLFxuICBsb2NhdGlvbnM6IFtcbiAgICBEaXJlY3RpdmVMb2NhdGlvbi5GSUVMRF9ERUZJTklUSU9OLFxuICAgIERpcmVjdGl2ZUxvY2F0aW9uLkFSR1VNRU5UX0RFRklOSVRJT04sXG4gICAgRGlyZWN0aXZlTG9jYXRpb24uSU5QVVRfRklFTERfREVGSU5JVElPTixcbiAgICBEaXJlY3RpdmVMb2NhdGlvbi5FTlVNX1ZBTFVFXG4gIF0sXG4gIGFyZ3M6IHtcbiAgICByZWFzb246IHtcbiAgICAgIHR5cGU6IEdyYXBoUUxTdHJpbmcsXG4gICAgICBkZXNjcmlwdGlvbjogXCJFeHBsYWlucyB3aHkgdGhpcyBlbGVtZW50IHdhcyBkZXByZWNhdGVkLCB1c3VhbGx5IGFsc28gaW5jbHVkaW5nIGEgc3VnZ2VzdGlvbiBmb3IgaG93IHRvIGFjY2VzcyBzdXBwb3J0ZWQgc2ltaWxhciBkYXRhLiBGb3JtYXR0ZWQgdXNpbmcgdGhlIE1hcmtkb3duIHN5bnRheCwgYXMgc3BlY2lmaWVkIGJ5IFtDb21tb25NYXJrXShodHRwczovL2NvbW1vbm1hcmsub3JnLykuXCIsXG4gICAgICBkZWZhdWx0VmFsdWU6IERFRkFVTFRfREVQUkVDQVRJT05fUkVBU09OXG4gICAgfVxuICB9XG59KTtcbnZhciBHcmFwaFFMU3BlY2lmaWVkQnlEaXJlY3RpdmUgPSBuZXcgR3JhcGhRTERpcmVjdGl2ZSh7XG4gIG5hbWU6IFwic3BlY2lmaWVkQnlcIixcbiAgZGVzY3JpcHRpb246IFwiRXhwb3NlcyBhIFVSTCB0aGF0IHNwZWNpZmllcyB0aGUgYmVoYXZpb3Igb2YgdGhpcyBzY2FsYXIuXCIsXG4gIGxvY2F0aW9uczogW0RpcmVjdGl2ZUxvY2F0aW9uLlNDQUxBUl0sXG4gIGFyZ3M6IHtcbiAgICB1cmw6IHtcbiAgICAgIHR5cGU6IG5ldyBHcmFwaFFMTm9uTnVsbChHcmFwaFFMU3RyaW5nKSxcbiAgICAgIGRlc2NyaXB0aW9uOiBcIlRoZSBVUkwgdGhhdCBzcGVjaWZpZXMgdGhlIGJlaGF2aW9yIG9mIHRoaXMgc2NhbGFyLlwiXG4gICAgfVxuICB9XG59KTtcbnZhciBzcGVjaWZpZWREaXJlY3RpdmVzID0gT2JqZWN0LmZyZWV6ZShbXG4gIEdyYXBoUUxJbmNsdWRlRGlyZWN0aXZlLFxuICBHcmFwaFFMU2tpcERpcmVjdGl2ZSxcbiAgR3JhcGhRTERlcHJlY2F0ZWREaXJlY3RpdmUsXG4gIEdyYXBoUUxTcGVjaWZpZWRCeURpcmVjdGl2ZVxuXSk7XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC9qc3V0aWxzL2lzSXRlcmFibGVPYmplY3QubWpzXG5mdW5jdGlvbiBpc0l0ZXJhYmxlT2JqZWN0KG1heWJlSXRlcmFibGUpIHtcbiAgcmV0dXJuIHR5cGVvZiBtYXliZUl0ZXJhYmxlID09PSBcIm9iamVjdFwiICYmIHR5cGVvZiAobWF5YmVJdGVyYWJsZSA9PT0gbnVsbCB8fCBtYXliZUl0ZXJhYmxlID09PSB2b2lkIDAgPyB2b2lkIDAgOiBtYXliZUl0ZXJhYmxlW1N5bWJvbC5pdGVyYXRvcl0pID09PSBcImZ1bmN0aW9uXCI7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC91dGlsaXRpZXMvYXN0RnJvbVZhbHVlLm1qc1xuZnVuY3Rpb24gYXN0RnJvbVZhbHVlKHZhbHVlLCB0eXBlKSB7XG4gIGlmIChpc05vbk51bGxUeXBlKHR5cGUpKSB7XG4gICAgY29uc3QgYXN0VmFsdWUgPSBhc3RGcm9tVmFsdWUodmFsdWUsIHR5cGUub2ZUeXBlKTtcbiAgICBpZiAoKGFzdFZhbHVlID09PSBudWxsIHx8IGFzdFZhbHVlID09PSB2b2lkIDAgPyB2b2lkIDAgOiBhc3RWYWx1ZS5raW5kKSA9PT0gS2luZC5OVUxMKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgcmV0dXJuIGFzdFZhbHVlO1xuICB9XG4gIGlmICh2YWx1ZSA9PT0gbnVsbCkge1xuICAgIHJldHVybiB7XG4gICAgICBraW5kOiBLaW5kLk5VTExcbiAgICB9O1xuICB9XG4gIGlmICh2YWx1ZSA9PT0gdm9pZCAwKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgaWYgKGlzTGlzdFR5cGUodHlwZSkpIHtcbiAgICBjb25zdCBpdGVtVHlwZSA9IHR5cGUub2ZUeXBlO1xuICAgIGlmIChpc0l0ZXJhYmxlT2JqZWN0KHZhbHVlKSkge1xuICAgICAgY29uc3QgdmFsdWVzTm9kZXMgPSBbXTtcbiAgICAgIGZvciAoY29uc3QgaXRlbSBvZiB2YWx1ZSkge1xuICAgICAgICBjb25zdCBpdGVtTm9kZSA9IGFzdEZyb21WYWx1ZShpdGVtLCBpdGVtVHlwZSk7XG4gICAgICAgIGlmIChpdGVtTm9kZSAhPSBudWxsKSB7XG4gICAgICAgICAgdmFsdWVzTm9kZXMucHVzaChpdGVtTm9kZSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiB7XG4gICAgICAgIGtpbmQ6IEtpbmQuTElTVCxcbiAgICAgICAgdmFsdWVzOiB2YWx1ZXNOb2Rlc1xuICAgICAgfTtcbiAgICB9XG4gICAgcmV0dXJuIGFzdEZyb21WYWx1ZSh2YWx1ZSwgaXRlbVR5cGUpO1xuICB9XG4gIGlmIChpc0lucHV0T2JqZWN0VHlwZSh0eXBlKSkge1xuICAgIGlmICghaXNPYmplY3RMaWtlKHZhbHVlKSkge1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIGNvbnN0IGZpZWxkTm9kZXMgPSBbXTtcbiAgICBmb3IgKGNvbnN0IGZpZWxkIG9mIE9iamVjdC52YWx1ZXModHlwZS5nZXRGaWVsZHMoKSkpIHtcbiAgICAgIGNvbnN0IGZpZWxkVmFsdWUgPSBhc3RGcm9tVmFsdWUodmFsdWVbZmllbGQubmFtZV0sIGZpZWxkLnR5cGUpO1xuICAgICAgaWYgKGZpZWxkVmFsdWUpIHtcbiAgICAgICAgZmllbGROb2Rlcy5wdXNoKHtcbiAgICAgICAgICBraW5kOiBLaW5kLk9CSkVDVF9GSUVMRCxcbiAgICAgICAgICBuYW1lOiB7XG4gICAgICAgICAgICBraW5kOiBLaW5kLk5BTUUsXG4gICAgICAgICAgICB2YWx1ZTogZmllbGQubmFtZVxuICAgICAgICAgIH0sXG4gICAgICAgICAgdmFsdWU6IGZpZWxkVmFsdWVcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICBraW5kOiBLaW5kLk9CSkVDVCxcbiAgICAgIGZpZWxkczogZmllbGROb2Rlc1xuICAgIH07XG4gIH1cbiAgaWYgKGlzTGVhZlR5cGUodHlwZSkpIHtcbiAgICBjb25zdCBzZXJpYWxpemVkID0gdHlwZS5zZXJpYWxpemUodmFsdWUpO1xuICAgIGlmIChzZXJpYWxpemVkID09IG51bGwpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIHNlcmlhbGl6ZWQgPT09IFwiYm9vbGVhblwiKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBraW5kOiBLaW5kLkJPT0xFQU4sXG4gICAgICAgIHZhbHVlOiBzZXJpYWxpemVkXG4gICAgICB9O1xuICAgIH1cbiAgICBpZiAodHlwZW9mIHNlcmlhbGl6ZWQgPT09IFwibnVtYmVyXCIgJiYgTnVtYmVyLmlzRmluaXRlKHNlcmlhbGl6ZWQpKSB7XG4gICAgICBjb25zdCBzdHJpbmdOdW0gPSBTdHJpbmcoc2VyaWFsaXplZCk7XG4gICAgICByZXR1cm4gaW50ZWdlclN0cmluZ1JlZ0V4cC50ZXN0KHN0cmluZ051bSkgPyB7XG4gICAgICAgIGtpbmQ6IEtpbmQuSU5ULFxuICAgICAgICB2YWx1ZTogc3RyaW5nTnVtXG4gICAgICB9IDoge1xuICAgICAgICBraW5kOiBLaW5kLkZMT0FULFxuICAgICAgICB2YWx1ZTogc3RyaW5nTnVtXG4gICAgICB9O1xuICAgIH1cbiAgICBpZiAodHlwZW9mIHNlcmlhbGl6ZWQgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgIGlmIChpc0VudW1UeXBlKHR5cGUpKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAga2luZDogS2luZC5FTlVNLFxuICAgICAgICAgIHZhbHVlOiBzZXJpYWxpemVkXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICBpZiAodHlwZSA9PT0gR3JhcGhRTElEICYmIGludGVnZXJTdHJpbmdSZWdFeHAudGVzdChzZXJpYWxpemVkKSkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIGtpbmQ6IEtpbmQuSU5ULFxuICAgICAgICAgIHZhbHVlOiBzZXJpYWxpemVkXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICByZXR1cm4ge1xuICAgICAgICBraW5kOiBLaW5kLlNUUklORyxcbiAgICAgICAgdmFsdWU6IHNlcmlhbGl6ZWRcbiAgICAgIH07XG4gICAgfVxuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoYENhbm5vdCBjb252ZXJ0IHZhbHVlIHRvIEFTVDogJHtpbnNwZWN0KHNlcmlhbGl6ZWQpfS5gKTtcbiAgfVxuICBpbnZhcmlhbnQyKGZhbHNlLCBcIlVuZXhwZWN0ZWQgaW5wdXQgdHlwZTogXCIgKyBpbnNwZWN0KHR5cGUpKTtcbn1cbnZhciBpbnRlZ2VyU3RyaW5nUmVnRXhwID0gL14tPyg/OjB8WzEtOV1bMC05XSopJC87XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC90eXBlL2ludHJvc3BlY3Rpb24ubWpzXG52YXIgX19TY2hlbWEgPSBuZXcgR3JhcGhRTE9iamVjdFR5cGUoe1xuICBuYW1lOiBcIl9fU2NoZW1hXCIsXG4gIGRlc2NyaXB0aW9uOiBcIkEgR3JhcGhRTCBTY2hlbWEgZGVmaW5lcyB0aGUgY2FwYWJpbGl0aWVzIG9mIGEgR3JhcGhRTCBzZXJ2ZXIuIEl0IGV4cG9zZXMgYWxsIGF2YWlsYWJsZSB0eXBlcyBhbmQgZGlyZWN0aXZlcyBvbiB0aGUgc2VydmVyLCBhcyB3ZWxsIGFzIHRoZSBlbnRyeSBwb2ludHMgZm9yIHF1ZXJ5LCBtdXRhdGlvbiwgYW5kIHN1YnNjcmlwdGlvbiBvcGVyYXRpb25zLlwiLFxuICBmaWVsZHM6ICgpID0+ICh7XG4gICAgZGVzY3JpcHRpb246IHtcbiAgICAgIHR5cGU6IEdyYXBoUUxTdHJpbmcsXG4gICAgICByZXNvbHZlOiAoc2NoZW1hKSA9PiBzY2hlbWEuZGVzY3JpcHRpb25cbiAgICB9LFxuICAgIHR5cGVzOiB7XG4gICAgICBkZXNjcmlwdGlvbjogXCJBIGxpc3Qgb2YgYWxsIHR5cGVzIHN1cHBvcnRlZCBieSB0aGlzIHNlcnZlci5cIixcbiAgICAgIHR5cGU6IG5ldyBHcmFwaFFMTm9uTnVsbChuZXcgR3JhcGhRTExpc3QobmV3IEdyYXBoUUxOb25OdWxsKF9fVHlwZSkpKSxcbiAgICAgIHJlc29sdmUoc2NoZW1hKSB7XG4gICAgICAgIHJldHVybiBPYmplY3QudmFsdWVzKHNjaGVtYS5nZXRUeXBlTWFwKCkpO1xuICAgICAgfVxuICAgIH0sXG4gICAgcXVlcnlUeXBlOiB7XG4gICAgICBkZXNjcmlwdGlvbjogXCJUaGUgdHlwZSB0aGF0IHF1ZXJ5IG9wZXJhdGlvbnMgd2lsbCBiZSByb290ZWQgYXQuXCIsXG4gICAgICB0eXBlOiBuZXcgR3JhcGhRTE5vbk51bGwoX19UeXBlKSxcbiAgICAgIHJlc29sdmU6IChzY2hlbWEpID0+IHNjaGVtYS5nZXRRdWVyeVR5cGUoKVxuICAgIH0sXG4gICAgbXV0YXRpb25UeXBlOiB7XG4gICAgICBkZXNjcmlwdGlvbjogXCJJZiB0aGlzIHNlcnZlciBzdXBwb3J0cyBtdXRhdGlvbiwgdGhlIHR5cGUgdGhhdCBtdXRhdGlvbiBvcGVyYXRpb25zIHdpbGwgYmUgcm9vdGVkIGF0LlwiLFxuICAgICAgdHlwZTogX19UeXBlLFxuICAgICAgcmVzb2x2ZTogKHNjaGVtYSkgPT4gc2NoZW1hLmdldE11dGF0aW9uVHlwZSgpXG4gICAgfSxcbiAgICBzdWJzY3JpcHRpb25UeXBlOiB7XG4gICAgICBkZXNjcmlwdGlvbjogXCJJZiB0aGlzIHNlcnZlciBzdXBwb3J0IHN1YnNjcmlwdGlvbiwgdGhlIHR5cGUgdGhhdCBzdWJzY3JpcHRpb24gb3BlcmF0aW9ucyB3aWxsIGJlIHJvb3RlZCBhdC5cIixcbiAgICAgIHR5cGU6IF9fVHlwZSxcbiAgICAgIHJlc29sdmU6IChzY2hlbWEpID0+IHNjaGVtYS5nZXRTdWJzY3JpcHRpb25UeXBlKClcbiAgICB9LFxuICAgIGRpcmVjdGl2ZXM6IHtcbiAgICAgIGRlc2NyaXB0aW9uOiBcIkEgbGlzdCBvZiBhbGwgZGlyZWN0aXZlcyBzdXBwb3J0ZWQgYnkgdGhpcyBzZXJ2ZXIuXCIsXG4gICAgICB0eXBlOiBuZXcgR3JhcGhRTE5vbk51bGwoXG4gICAgICAgIG5ldyBHcmFwaFFMTGlzdChuZXcgR3JhcGhRTE5vbk51bGwoX19EaXJlY3RpdmUpKVxuICAgICAgKSxcbiAgICAgIHJlc29sdmU6IChzY2hlbWEpID0+IHNjaGVtYS5nZXREaXJlY3RpdmVzKClcbiAgICB9XG4gIH0pXG59KTtcbnZhciBfX0RpcmVjdGl2ZSA9IG5ldyBHcmFwaFFMT2JqZWN0VHlwZSh7XG4gIG5hbWU6IFwiX19EaXJlY3RpdmVcIixcbiAgZGVzY3JpcHRpb246IFwiQSBEaXJlY3RpdmUgcHJvdmlkZXMgYSB3YXkgdG8gZGVzY3JpYmUgYWx0ZXJuYXRlIHJ1bnRpbWUgZXhlY3V0aW9uIGFuZCB0eXBlIHZhbGlkYXRpb24gYmVoYXZpb3IgaW4gYSBHcmFwaFFMIGRvY3VtZW50LlxcblxcbkluIHNvbWUgY2FzZXMsIHlvdSBuZWVkIHRvIHByb3ZpZGUgb3B0aW9ucyB0byBhbHRlciBHcmFwaFFMJ3MgZXhlY3V0aW9uIGJlaGF2aW9yIGluIHdheXMgZmllbGQgYXJndW1lbnRzIHdpbGwgbm90IHN1ZmZpY2UsIHN1Y2ggYXMgY29uZGl0aW9uYWxseSBpbmNsdWRpbmcgb3Igc2tpcHBpbmcgYSBmaWVsZC4gRGlyZWN0aXZlcyBwcm92aWRlIHRoaXMgYnkgZGVzY3JpYmluZyBhZGRpdGlvbmFsIGluZm9ybWF0aW9uIHRvIHRoZSBleGVjdXRvci5cIixcbiAgZmllbGRzOiAoKSA9PiAoe1xuICAgIG5hbWU6IHtcbiAgICAgIHR5cGU6IG5ldyBHcmFwaFFMTm9uTnVsbChHcmFwaFFMU3RyaW5nKSxcbiAgICAgIHJlc29sdmU6IChkaXJlY3RpdmUpID0+IGRpcmVjdGl2ZS5uYW1lXG4gICAgfSxcbiAgICBkZXNjcmlwdGlvbjoge1xuICAgICAgdHlwZTogR3JhcGhRTFN0cmluZyxcbiAgICAgIHJlc29sdmU6IChkaXJlY3RpdmUpID0+IGRpcmVjdGl2ZS5kZXNjcmlwdGlvblxuICAgIH0sXG4gICAgaXNSZXBlYXRhYmxlOiB7XG4gICAgICB0eXBlOiBuZXcgR3JhcGhRTE5vbk51bGwoR3JhcGhRTEJvb2xlYW4pLFxuICAgICAgcmVzb2x2ZTogKGRpcmVjdGl2ZSkgPT4gZGlyZWN0aXZlLmlzUmVwZWF0YWJsZVxuICAgIH0sXG4gICAgbG9jYXRpb25zOiB7XG4gICAgICB0eXBlOiBuZXcgR3JhcGhRTE5vbk51bGwoXG4gICAgICAgIG5ldyBHcmFwaFFMTGlzdChuZXcgR3JhcGhRTE5vbk51bGwoX19EaXJlY3RpdmVMb2NhdGlvbikpXG4gICAgICApLFxuICAgICAgcmVzb2x2ZTogKGRpcmVjdGl2ZSkgPT4gZGlyZWN0aXZlLmxvY2F0aW9uc1xuICAgIH0sXG4gICAgYXJnczoge1xuICAgICAgdHlwZTogbmV3IEdyYXBoUUxOb25OdWxsKFxuICAgICAgICBuZXcgR3JhcGhRTExpc3QobmV3IEdyYXBoUUxOb25OdWxsKF9fSW5wdXRWYWx1ZSkpXG4gICAgICApLFxuICAgICAgYXJnczoge1xuICAgICAgICBpbmNsdWRlRGVwcmVjYXRlZDoge1xuICAgICAgICAgIHR5cGU6IEdyYXBoUUxCb29sZWFuLFxuICAgICAgICAgIGRlZmF1bHRWYWx1ZTogZmFsc2VcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHJlc29sdmUoZmllbGQsIHsgaW5jbHVkZURlcHJlY2F0ZWQgfSkge1xuICAgICAgICByZXR1cm4gaW5jbHVkZURlcHJlY2F0ZWQgPyBmaWVsZC5hcmdzIDogZmllbGQuYXJncy5maWx0ZXIoKGFyZykgPT4gYXJnLmRlcHJlY2F0aW9uUmVhc29uID09IG51bGwpO1xuICAgICAgfVxuICAgIH1cbiAgfSlcbn0pO1xudmFyIF9fRGlyZWN0aXZlTG9jYXRpb24gPSBuZXcgR3JhcGhRTEVudW1UeXBlKHtcbiAgbmFtZTogXCJfX0RpcmVjdGl2ZUxvY2F0aW9uXCIsXG4gIGRlc2NyaXB0aW9uOiBcIkEgRGlyZWN0aXZlIGNhbiBiZSBhZGphY2VudCB0byBtYW55IHBhcnRzIG9mIHRoZSBHcmFwaFFMIGxhbmd1YWdlLCBhIF9fRGlyZWN0aXZlTG9jYXRpb24gZGVzY3JpYmVzIG9uZSBzdWNoIHBvc3NpYmxlIGFkamFjZW5jaWVzLlwiLFxuICB2YWx1ZXM6IHtcbiAgICBRVUVSWToge1xuICAgICAgdmFsdWU6IERpcmVjdGl2ZUxvY2F0aW9uLlFVRVJZLFxuICAgICAgZGVzY3JpcHRpb246IFwiTG9jYXRpb24gYWRqYWNlbnQgdG8gYSBxdWVyeSBvcGVyYXRpb24uXCJcbiAgICB9LFxuICAgIE1VVEFUSU9OOiB7XG4gICAgICB2YWx1ZTogRGlyZWN0aXZlTG9jYXRpb24uTVVUQVRJT04sXG4gICAgICBkZXNjcmlwdGlvbjogXCJMb2NhdGlvbiBhZGphY2VudCB0byBhIG11dGF0aW9uIG9wZXJhdGlvbi5cIlxuICAgIH0sXG4gICAgU1VCU0NSSVBUSU9OOiB7XG4gICAgICB2YWx1ZTogRGlyZWN0aXZlTG9jYXRpb24uU1VCU0NSSVBUSU9OLFxuICAgICAgZGVzY3JpcHRpb246IFwiTG9jYXRpb24gYWRqYWNlbnQgdG8gYSBzdWJzY3JpcHRpb24gb3BlcmF0aW9uLlwiXG4gICAgfSxcbiAgICBGSUVMRDoge1xuICAgICAgdmFsdWU6IERpcmVjdGl2ZUxvY2F0aW9uLkZJRUxELFxuICAgICAgZGVzY3JpcHRpb246IFwiTG9jYXRpb24gYWRqYWNlbnQgdG8gYSBmaWVsZC5cIlxuICAgIH0sXG4gICAgRlJBR01FTlRfREVGSU5JVElPTjoge1xuICAgICAgdmFsdWU6IERpcmVjdGl2ZUxvY2F0aW9uLkZSQUdNRU5UX0RFRklOSVRJT04sXG4gICAgICBkZXNjcmlwdGlvbjogXCJMb2NhdGlvbiBhZGphY2VudCB0byBhIGZyYWdtZW50IGRlZmluaXRpb24uXCJcbiAgICB9LFxuICAgIEZSQUdNRU5UX1NQUkVBRDoge1xuICAgICAgdmFsdWU6IERpcmVjdGl2ZUxvY2F0aW9uLkZSQUdNRU5UX1NQUkVBRCxcbiAgICAgIGRlc2NyaXB0aW9uOiBcIkxvY2F0aW9uIGFkamFjZW50IHRvIGEgZnJhZ21lbnQgc3ByZWFkLlwiXG4gICAgfSxcbiAgICBJTkxJTkVfRlJBR01FTlQ6IHtcbiAgICAgIHZhbHVlOiBEaXJlY3RpdmVMb2NhdGlvbi5JTkxJTkVfRlJBR01FTlQsXG4gICAgICBkZXNjcmlwdGlvbjogXCJMb2NhdGlvbiBhZGphY2VudCB0byBhbiBpbmxpbmUgZnJhZ21lbnQuXCJcbiAgICB9LFxuICAgIFZBUklBQkxFX0RFRklOSVRJT046IHtcbiAgICAgIHZhbHVlOiBEaXJlY3RpdmVMb2NhdGlvbi5WQVJJQUJMRV9ERUZJTklUSU9OLFxuICAgICAgZGVzY3JpcHRpb246IFwiTG9jYXRpb24gYWRqYWNlbnQgdG8gYSB2YXJpYWJsZSBkZWZpbml0aW9uLlwiXG4gICAgfSxcbiAgICBTQ0hFTUE6IHtcbiAgICAgIHZhbHVlOiBEaXJlY3RpdmVMb2NhdGlvbi5TQ0hFTUEsXG4gICAgICBkZXNjcmlwdGlvbjogXCJMb2NhdGlvbiBhZGphY2VudCB0byBhIHNjaGVtYSBkZWZpbml0aW9uLlwiXG4gICAgfSxcbiAgICBTQ0FMQVI6IHtcbiAgICAgIHZhbHVlOiBEaXJlY3RpdmVMb2NhdGlvbi5TQ0FMQVIsXG4gICAgICBkZXNjcmlwdGlvbjogXCJMb2NhdGlvbiBhZGphY2VudCB0byBhIHNjYWxhciBkZWZpbml0aW9uLlwiXG4gICAgfSxcbiAgICBPQkpFQ1Q6IHtcbiAgICAgIHZhbHVlOiBEaXJlY3RpdmVMb2NhdGlvbi5PQkpFQ1QsXG4gICAgICBkZXNjcmlwdGlvbjogXCJMb2NhdGlvbiBhZGphY2VudCB0byBhbiBvYmplY3QgdHlwZSBkZWZpbml0aW9uLlwiXG4gICAgfSxcbiAgICBGSUVMRF9ERUZJTklUSU9OOiB7XG4gICAgICB2YWx1ZTogRGlyZWN0aXZlTG9jYXRpb24uRklFTERfREVGSU5JVElPTixcbiAgICAgIGRlc2NyaXB0aW9uOiBcIkxvY2F0aW9uIGFkamFjZW50IHRvIGEgZmllbGQgZGVmaW5pdGlvbi5cIlxuICAgIH0sXG4gICAgQVJHVU1FTlRfREVGSU5JVElPTjoge1xuICAgICAgdmFsdWU6IERpcmVjdGl2ZUxvY2F0aW9uLkFSR1VNRU5UX0RFRklOSVRJT04sXG4gICAgICBkZXNjcmlwdGlvbjogXCJMb2NhdGlvbiBhZGphY2VudCB0byBhbiBhcmd1bWVudCBkZWZpbml0aW9uLlwiXG4gICAgfSxcbiAgICBJTlRFUkZBQ0U6IHtcbiAgICAgIHZhbHVlOiBEaXJlY3RpdmVMb2NhdGlvbi5JTlRFUkZBQ0UsXG4gICAgICBkZXNjcmlwdGlvbjogXCJMb2NhdGlvbiBhZGphY2VudCB0byBhbiBpbnRlcmZhY2UgZGVmaW5pdGlvbi5cIlxuICAgIH0sXG4gICAgVU5JT046IHtcbiAgICAgIHZhbHVlOiBEaXJlY3RpdmVMb2NhdGlvbi5VTklPTixcbiAgICAgIGRlc2NyaXB0aW9uOiBcIkxvY2F0aW9uIGFkamFjZW50IHRvIGEgdW5pb24gZGVmaW5pdGlvbi5cIlxuICAgIH0sXG4gICAgRU5VTToge1xuICAgICAgdmFsdWU6IERpcmVjdGl2ZUxvY2F0aW9uLkVOVU0sXG4gICAgICBkZXNjcmlwdGlvbjogXCJMb2NhdGlvbiBhZGphY2VudCB0byBhbiBlbnVtIGRlZmluaXRpb24uXCJcbiAgICB9LFxuICAgIEVOVU1fVkFMVUU6IHtcbiAgICAgIHZhbHVlOiBEaXJlY3RpdmVMb2NhdGlvbi5FTlVNX1ZBTFVFLFxuICAgICAgZGVzY3JpcHRpb246IFwiTG9jYXRpb24gYWRqYWNlbnQgdG8gYW4gZW51bSB2YWx1ZSBkZWZpbml0aW9uLlwiXG4gICAgfSxcbiAgICBJTlBVVF9PQkpFQ1Q6IHtcbiAgICAgIHZhbHVlOiBEaXJlY3RpdmVMb2NhdGlvbi5JTlBVVF9PQkpFQ1QsXG4gICAgICBkZXNjcmlwdGlvbjogXCJMb2NhdGlvbiBhZGphY2VudCB0byBhbiBpbnB1dCBvYmplY3QgdHlwZSBkZWZpbml0aW9uLlwiXG4gICAgfSxcbiAgICBJTlBVVF9GSUVMRF9ERUZJTklUSU9OOiB7XG4gICAgICB2YWx1ZTogRGlyZWN0aXZlTG9jYXRpb24uSU5QVVRfRklFTERfREVGSU5JVElPTixcbiAgICAgIGRlc2NyaXB0aW9uOiBcIkxvY2F0aW9uIGFkamFjZW50IHRvIGFuIGlucHV0IG9iamVjdCBmaWVsZCBkZWZpbml0aW9uLlwiXG4gICAgfVxuICB9XG59KTtcbnZhciBfX1R5cGUgPSBuZXcgR3JhcGhRTE9iamVjdFR5cGUoe1xuICBuYW1lOiBcIl9fVHlwZVwiLFxuICBkZXNjcmlwdGlvbjogXCJUaGUgZnVuZGFtZW50YWwgdW5pdCBvZiBhbnkgR3JhcGhRTCBTY2hlbWEgaXMgdGhlIHR5cGUuIFRoZXJlIGFyZSBtYW55IGtpbmRzIG9mIHR5cGVzIGluIEdyYXBoUUwgYXMgcmVwcmVzZW50ZWQgYnkgdGhlIGBfX1R5cGVLaW5kYCBlbnVtLlxcblxcbkRlcGVuZGluZyBvbiB0aGUga2luZCBvZiBhIHR5cGUsIGNlcnRhaW4gZmllbGRzIGRlc2NyaWJlIGluZm9ybWF0aW9uIGFib3V0IHRoYXQgdHlwZS4gU2NhbGFyIHR5cGVzIHByb3ZpZGUgbm8gaW5mb3JtYXRpb24gYmV5b25kIGEgbmFtZSwgZGVzY3JpcHRpb24gYW5kIG9wdGlvbmFsIGBzcGVjaWZpZWRCeVVSTGAsIHdoaWxlIEVudW0gdHlwZXMgcHJvdmlkZSB0aGVpciB2YWx1ZXMuIE9iamVjdCBhbmQgSW50ZXJmYWNlIHR5cGVzIHByb3ZpZGUgdGhlIGZpZWxkcyB0aGV5IGRlc2NyaWJlLiBBYnN0cmFjdCB0eXBlcywgVW5pb24gYW5kIEludGVyZmFjZSwgcHJvdmlkZSB0aGUgT2JqZWN0IHR5cGVzIHBvc3NpYmxlIGF0IHJ1bnRpbWUuIExpc3QgYW5kIE5vbk51bGwgdHlwZXMgY29tcG9zZSBvdGhlciB0eXBlcy5cIixcbiAgZmllbGRzOiAoKSA9PiAoe1xuICAgIGtpbmQ6IHtcbiAgICAgIHR5cGU6IG5ldyBHcmFwaFFMTm9uTnVsbChfX1R5cGVLaW5kKSxcbiAgICAgIHJlc29sdmUodHlwZSkge1xuICAgICAgICBpZiAoaXNTY2FsYXJUeXBlKHR5cGUpKSB7XG4gICAgICAgICAgcmV0dXJuIFR5cGVLaW5kLlNDQUxBUjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaXNPYmplY3RUeXBlKHR5cGUpKSB7XG4gICAgICAgICAgcmV0dXJuIFR5cGVLaW5kLk9CSkVDVDtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaXNJbnRlcmZhY2VUeXBlKHR5cGUpKSB7XG4gICAgICAgICAgcmV0dXJuIFR5cGVLaW5kLklOVEVSRkFDRTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaXNVbmlvblR5cGUodHlwZSkpIHtcbiAgICAgICAgICByZXR1cm4gVHlwZUtpbmQuVU5JT047XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGlzRW51bVR5cGUodHlwZSkpIHtcbiAgICAgICAgICByZXR1cm4gVHlwZUtpbmQuRU5VTTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaXNJbnB1dE9iamVjdFR5cGUodHlwZSkpIHtcbiAgICAgICAgICByZXR1cm4gVHlwZUtpbmQuSU5QVVRfT0JKRUNUO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc0xpc3RUeXBlKHR5cGUpKSB7XG4gICAgICAgICAgcmV0dXJuIFR5cGVLaW5kLkxJU1Q7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGlzTm9uTnVsbFR5cGUodHlwZSkpIHtcbiAgICAgICAgICByZXR1cm4gVHlwZUtpbmQuTk9OX05VTEw7XG4gICAgICAgIH1cbiAgICAgICAgaW52YXJpYW50MihmYWxzZSwgYFVuZXhwZWN0ZWQgdHlwZTogXCIke2luc3BlY3QodHlwZSl9XCIuYCk7XG4gICAgICB9XG4gICAgfSxcbiAgICBuYW1lOiB7XG4gICAgICB0eXBlOiBHcmFwaFFMU3RyaW5nLFxuICAgICAgcmVzb2x2ZTogKHR5cGUpID0+IFwibmFtZVwiIGluIHR5cGUgPyB0eXBlLm5hbWUgOiB2b2lkIDBcbiAgICB9LFxuICAgIGRlc2NyaXB0aW9uOiB7XG4gICAgICB0eXBlOiBHcmFwaFFMU3RyaW5nLFxuICAgICAgcmVzb2x2ZTogKHR5cGUpID0+IChcbiAgICAgICAgLyogYzggaWdub3JlIG5leHQgKi9cbiAgICAgICAgXCJkZXNjcmlwdGlvblwiIGluIHR5cGUgPyB0eXBlLmRlc2NyaXB0aW9uIDogdm9pZCAwXG4gICAgICApXG4gICAgfSxcbiAgICBzcGVjaWZpZWRCeVVSTDoge1xuICAgICAgdHlwZTogR3JhcGhRTFN0cmluZyxcbiAgICAgIHJlc29sdmU6IChvYmopID0+IFwic3BlY2lmaWVkQnlVUkxcIiBpbiBvYmogPyBvYmouc3BlY2lmaWVkQnlVUkwgOiB2b2lkIDBcbiAgICB9LFxuICAgIGZpZWxkczoge1xuICAgICAgdHlwZTogbmV3IEdyYXBoUUxMaXN0KG5ldyBHcmFwaFFMTm9uTnVsbChfX0ZpZWxkKSksXG4gICAgICBhcmdzOiB7XG4gICAgICAgIGluY2x1ZGVEZXByZWNhdGVkOiB7XG4gICAgICAgICAgdHlwZTogR3JhcGhRTEJvb2xlYW4sXG4gICAgICAgICAgZGVmYXVsdFZhbHVlOiBmYWxzZVxuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgcmVzb2x2ZSh0eXBlLCB7IGluY2x1ZGVEZXByZWNhdGVkIH0pIHtcbiAgICAgICAgaWYgKGlzT2JqZWN0VHlwZSh0eXBlKSB8fCBpc0ludGVyZmFjZVR5cGUodHlwZSkpIHtcbiAgICAgICAgICBjb25zdCBmaWVsZHMgPSBPYmplY3QudmFsdWVzKHR5cGUuZ2V0RmllbGRzKCkpO1xuICAgICAgICAgIHJldHVybiBpbmNsdWRlRGVwcmVjYXRlZCA/IGZpZWxkcyA6IGZpZWxkcy5maWx0ZXIoKGZpZWxkKSA9PiBmaWVsZC5kZXByZWNhdGlvblJlYXNvbiA9PSBudWxsKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gICAgaW50ZXJmYWNlczoge1xuICAgICAgdHlwZTogbmV3IEdyYXBoUUxMaXN0KG5ldyBHcmFwaFFMTm9uTnVsbChfX1R5cGUpKSxcbiAgICAgIHJlc29sdmUodHlwZSkge1xuICAgICAgICBpZiAoaXNPYmplY3RUeXBlKHR5cGUpIHx8IGlzSW50ZXJmYWNlVHlwZSh0eXBlKSkge1xuICAgICAgICAgIHJldHVybiB0eXBlLmdldEludGVyZmFjZXMoKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gICAgcG9zc2libGVUeXBlczoge1xuICAgICAgdHlwZTogbmV3IEdyYXBoUUxMaXN0KG5ldyBHcmFwaFFMTm9uTnVsbChfX1R5cGUpKSxcbiAgICAgIHJlc29sdmUodHlwZSwgX2FyZ3MsIF9jb250ZXh0LCB7IHNjaGVtYSB9KSB7XG4gICAgICAgIGlmIChpc0Fic3RyYWN0VHlwZSh0eXBlKSkge1xuICAgICAgICAgIHJldHVybiBzY2hlbWEuZ2V0UG9zc2libGVUeXBlcyh0eXBlKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gICAgZW51bVZhbHVlczoge1xuICAgICAgdHlwZTogbmV3IEdyYXBoUUxMaXN0KG5ldyBHcmFwaFFMTm9uTnVsbChfX0VudW1WYWx1ZSkpLFxuICAgICAgYXJnczoge1xuICAgICAgICBpbmNsdWRlRGVwcmVjYXRlZDoge1xuICAgICAgICAgIHR5cGU6IEdyYXBoUUxCb29sZWFuLFxuICAgICAgICAgIGRlZmF1bHRWYWx1ZTogZmFsc2VcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHJlc29sdmUodHlwZSwgeyBpbmNsdWRlRGVwcmVjYXRlZCB9KSB7XG4gICAgICAgIGlmIChpc0VudW1UeXBlKHR5cGUpKSB7XG4gICAgICAgICAgY29uc3QgdmFsdWVzID0gdHlwZS5nZXRWYWx1ZXMoKTtcbiAgICAgICAgICByZXR1cm4gaW5jbHVkZURlcHJlY2F0ZWQgPyB2YWx1ZXMgOiB2YWx1ZXMuZmlsdGVyKChmaWVsZCkgPT4gZmllbGQuZGVwcmVjYXRpb25SZWFzb24gPT0gbnVsbCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9LFxuICAgIGlucHV0RmllbGRzOiB7XG4gICAgICB0eXBlOiBuZXcgR3JhcGhRTExpc3QobmV3IEdyYXBoUUxOb25OdWxsKF9fSW5wdXRWYWx1ZSkpLFxuICAgICAgYXJnczoge1xuICAgICAgICBpbmNsdWRlRGVwcmVjYXRlZDoge1xuICAgICAgICAgIHR5cGU6IEdyYXBoUUxCb29sZWFuLFxuICAgICAgICAgIGRlZmF1bHRWYWx1ZTogZmFsc2VcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHJlc29sdmUodHlwZSwgeyBpbmNsdWRlRGVwcmVjYXRlZCB9KSB7XG4gICAgICAgIGlmIChpc0lucHV0T2JqZWN0VHlwZSh0eXBlKSkge1xuICAgICAgICAgIGNvbnN0IHZhbHVlcyA9IE9iamVjdC52YWx1ZXModHlwZS5nZXRGaWVsZHMoKSk7XG4gICAgICAgICAgcmV0dXJuIGluY2x1ZGVEZXByZWNhdGVkID8gdmFsdWVzIDogdmFsdWVzLmZpbHRlcigoZmllbGQpID0+IGZpZWxkLmRlcHJlY2F0aW9uUmVhc29uID09IG51bGwpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSxcbiAgICBvZlR5cGU6IHtcbiAgICAgIHR5cGU6IF9fVHlwZSxcbiAgICAgIHJlc29sdmU6ICh0eXBlKSA9PiBcIm9mVHlwZVwiIGluIHR5cGUgPyB0eXBlLm9mVHlwZSA6IHZvaWQgMFxuICAgIH1cbiAgfSlcbn0pO1xudmFyIF9fRmllbGQgPSBuZXcgR3JhcGhRTE9iamVjdFR5cGUoe1xuICBuYW1lOiBcIl9fRmllbGRcIixcbiAgZGVzY3JpcHRpb246IFwiT2JqZWN0IGFuZCBJbnRlcmZhY2UgdHlwZXMgYXJlIGRlc2NyaWJlZCBieSBhIGxpc3Qgb2YgRmllbGRzLCBlYWNoIG9mIHdoaWNoIGhhcyBhIG5hbWUsIHBvdGVudGlhbGx5IGEgbGlzdCBvZiBhcmd1bWVudHMsIGFuZCBhIHJldHVybiB0eXBlLlwiLFxuICBmaWVsZHM6ICgpID0+ICh7XG4gICAgbmFtZToge1xuICAgICAgdHlwZTogbmV3IEdyYXBoUUxOb25OdWxsKEdyYXBoUUxTdHJpbmcpLFxuICAgICAgcmVzb2x2ZTogKGZpZWxkKSA9PiBmaWVsZC5uYW1lXG4gICAgfSxcbiAgICBkZXNjcmlwdGlvbjoge1xuICAgICAgdHlwZTogR3JhcGhRTFN0cmluZyxcbiAgICAgIHJlc29sdmU6IChmaWVsZCkgPT4gZmllbGQuZGVzY3JpcHRpb25cbiAgICB9LFxuICAgIGFyZ3M6IHtcbiAgICAgIHR5cGU6IG5ldyBHcmFwaFFMTm9uTnVsbChcbiAgICAgICAgbmV3IEdyYXBoUUxMaXN0KG5ldyBHcmFwaFFMTm9uTnVsbChfX0lucHV0VmFsdWUpKVxuICAgICAgKSxcbiAgICAgIGFyZ3M6IHtcbiAgICAgICAgaW5jbHVkZURlcHJlY2F0ZWQ6IHtcbiAgICAgICAgICB0eXBlOiBHcmFwaFFMQm9vbGVhbixcbiAgICAgICAgICBkZWZhdWx0VmFsdWU6IGZhbHNlXG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICByZXNvbHZlKGZpZWxkLCB7IGluY2x1ZGVEZXByZWNhdGVkIH0pIHtcbiAgICAgICAgcmV0dXJuIGluY2x1ZGVEZXByZWNhdGVkID8gZmllbGQuYXJncyA6IGZpZWxkLmFyZ3MuZmlsdGVyKChhcmcpID0+IGFyZy5kZXByZWNhdGlvblJlYXNvbiA9PSBudWxsKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIHR5cGU6IHtcbiAgICAgIHR5cGU6IG5ldyBHcmFwaFFMTm9uTnVsbChfX1R5cGUpLFxuICAgICAgcmVzb2x2ZTogKGZpZWxkKSA9PiBmaWVsZC50eXBlXG4gICAgfSxcbiAgICBpc0RlcHJlY2F0ZWQ6IHtcbiAgICAgIHR5cGU6IG5ldyBHcmFwaFFMTm9uTnVsbChHcmFwaFFMQm9vbGVhbiksXG4gICAgICByZXNvbHZlOiAoZmllbGQpID0+IGZpZWxkLmRlcHJlY2F0aW9uUmVhc29uICE9IG51bGxcbiAgICB9LFxuICAgIGRlcHJlY2F0aW9uUmVhc29uOiB7XG4gICAgICB0eXBlOiBHcmFwaFFMU3RyaW5nLFxuICAgICAgcmVzb2x2ZTogKGZpZWxkKSA9PiBmaWVsZC5kZXByZWNhdGlvblJlYXNvblxuICAgIH1cbiAgfSlcbn0pO1xudmFyIF9fSW5wdXRWYWx1ZSA9IG5ldyBHcmFwaFFMT2JqZWN0VHlwZSh7XG4gIG5hbWU6IFwiX19JbnB1dFZhbHVlXCIsXG4gIGRlc2NyaXB0aW9uOiBcIkFyZ3VtZW50cyBwcm92aWRlZCB0byBGaWVsZHMgb3IgRGlyZWN0aXZlcyBhbmQgdGhlIGlucHV0IGZpZWxkcyBvZiBhbiBJbnB1dE9iamVjdCBhcmUgcmVwcmVzZW50ZWQgYXMgSW5wdXQgVmFsdWVzIHdoaWNoIGRlc2NyaWJlIHRoZWlyIHR5cGUgYW5kIG9wdGlvbmFsbHkgYSBkZWZhdWx0IHZhbHVlLlwiLFxuICBmaWVsZHM6ICgpID0+ICh7XG4gICAgbmFtZToge1xuICAgICAgdHlwZTogbmV3IEdyYXBoUUxOb25OdWxsKEdyYXBoUUxTdHJpbmcpLFxuICAgICAgcmVzb2x2ZTogKGlucHV0VmFsdWUpID0+IGlucHV0VmFsdWUubmFtZVxuICAgIH0sXG4gICAgZGVzY3JpcHRpb246IHtcbiAgICAgIHR5cGU6IEdyYXBoUUxTdHJpbmcsXG4gICAgICByZXNvbHZlOiAoaW5wdXRWYWx1ZSkgPT4gaW5wdXRWYWx1ZS5kZXNjcmlwdGlvblxuICAgIH0sXG4gICAgdHlwZToge1xuICAgICAgdHlwZTogbmV3IEdyYXBoUUxOb25OdWxsKF9fVHlwZSksXG4gICAgICByZXNvbHZlOiAoaW5wdXRWYWx1ZSkgPT4gaW5wdXRWYWx1ZS50eXBlXG4gICAgfSxcbiAgICBkZWZhdWx0VmFsdWU6IHtcbiAgICAgIHR5cGU6IEdyYXBoUUxTdHJpbmcsXG4gICAgICBkZXNjcmlwdGlvbjogXCJBIEdyYXBoUUwtZm9ybWF0dGVkIHN0cmluZyByZXByZXNlbnRpbmcgdGhlIGRlZmF1bHQgdmFsdWUgZm9yIHRoaXMgaW5wdXQgdmFsdWUuXCIsXG4gICAgICByZXNvbHZlKGlucHV0VmFsdWUpIHtcbiAgICAgICAgY29uc3QgeyB0eXBlLCBkZWZhdWx0VmFsdWUgfSA9IGlucHV0VmFsdWU7XG4gICAgICAgIGNvbnN0IHZhbHVlQVNUID0gYXN0RnJvbVZhbHVlKGRlZmF1bHRWYWx1ZSwgdHlwZSk7XG4gICAgICAgIHJldHVybiB2YWx1ZUFTVCA/IHByaW50KHZhbHVlQVNUKSA6IG51bGw7XG4gICAgICB9XG4gICAgfSxcbiAgICBpc0RlcHJlY2F0ZWQ6IHtcbiAgICAgIHR5cGU6IG5ldyBHcmFwaFFMTm9uTnVsbChHcmFwaFFMQm9vbGVhbiksXG4gICAgICByZXNvbHZlOiAoZmllbGQpID0+IGZpZWxkLmRlcHJlY2F0aW9uUmVhc29uICE9IG51bGxcbiAgICB9LFxuICAgIGRlcHJlY2F0aW9uUmVhc29uOiB7XG4gICAgICB0eXBlOiBHcmFwaFFMU3RyaW5nLFxuICAgICAgcmVzb2x2ZTogKG9iaikgPT4gb2JqLmRlcHJlY2F0aW9uUmVhc29uXG4gICAgfVxuICB9KVxufSk7XG52YXIgX19FbnVtVmFsdWUgPSBuZXcgR3JhcGhRTE9iamVjdFR5cGUoe1xuICBuYW1lOiBcIl9fRW51bVZhbHVlXCIsXG4gIGRlc2NyaXB0aW9uOiBcIk9uZSBwb3NzaWJsZSB2YWx1ZSBmb3IgYSBnaXZlbiBFbnVtLiBFbnVtIHZhbHVlcyBhcmUgdW5pcXVlIHZhbHVlcywgbm90IGEgcGxhY2Vob2xkZXIgZm9yIGEgc3RyaW5nIG9yIG51bWVyaWMgdmFsdWUuIEhvd2V2ZXIgYW4gRW51bSB2YWx1ZSBpcyByZXR1cm5lZCBpbiBhIEpTT04gcmVzcG9uc2UgYXMgYSBzdHJpbmcuXCIsXG4gIGZpZWxkczogKCkgPT4gKHtcbiAgICBuYW1lOiB7XG4gICAgICB0eXBlOiBuZXcgR3JhcGhRTE5vbk51bGwoR3JhcGhRTFN0cmluZyksXG4gICAgICByZXNvbHZlOiAoZW51bVZhbHVlKSA9PiBlbnVtVmFsdWUubmFtZVxuICAgIH0sXG4gICAgZGVzY3JpcHRpb246IHtcbiAgICAgIHR5cGU6IEdyYXBoUUxTdHJpbmcsXG4gICAgICByZXNvbHZlOiAoZW51bVZhbHVlKSA9PiBlbnVtVmFsdWUuZGVzY3JpcHRpb25cbiAgICB9LFxuICAgIGlzRGVwcmVjYXRlZDoge1xuICAgICAgdHlwZTogbmV3IEdyYXBoUUxOb25OdWxsKEdyYXBoUUxCb29sZWFuKSxcbiAgICAgIHJlc29sdmU6IChlbnVtVmFsdWUpID0+IGVudW1WYWx1ZS5kZXByZWNhdGlvblJlYXNvbiAhPSBudWxsXG4gICAgfSxcbiAgICBkZXByZWNhdGlvblJlYXNvbjoge1xuICAgICAgdHlwZTogR3JhcGhRTFN0cmluZyxcbiAgICAgIHJlc29sdmU6IChlbnVtVmFsdWUpID0+IGVudW1WYWx1ZS5kZXByZWNhdGlvblJlYXNvblxuICAgIH1cbiAgfSlcbn0pO1xudmFyIFR5cGVLaW5kO1xuKGZ1bmN0aW9uKFR5cGVLaW5kMikge1xuICBUeXBlS2luZDJbXCJTQ0FMQVJcIl0gPSBcIlNDQUxBUlwiO1xuICBUeXBlS2luZDJbXCJPQkpFQ1RcIl0gPSBcIk9CSkVDVFwiO1xuICBUeXBlS2luZDJbXCJJTlRFUkZBQ0VcIl0gPSBcIklOVEVSRkFDRVwiO1xuICBUeXBlS2luZDJbXCJVTklPTlwiXSA9IFwiVU5JT05cIjtcbiAgVHlwZUtpbmQyW1wiRU5VTVwiXSA9IFwiRU5VTVwiO1xuICBUeXBlS2luZDJbXCJJTlBVVF9PQkpFQ1RcIl0gPSBcIklOUFVUX09CSkVDVFwiO1xuICBUeXBlS2luZDJbXCJMSVNUXCJdID0gXCJMSVNUXCI7XG4gIFR5cGVLaW5kMltcIk5PTl9OVUxMXCJdID0gXCJOT05fTlVMTFwiO1xufSkoVHlwZUtpbmQgfHwgKFR5cGVLaW5kID0ge30pKTtcbnZhciBfX1R5cGVLaW5kID0gbmV3IEdyYXBoUUxFbnVtVHlwZSh7XG4gIG5hbWU6IFwiX19UeXBlS2luZFwiLFxuICBkZXNjcmlwdGlvbjogXCJBbiBlbnVtIGRlc2NyaWJpbmcgd2hhdCBraW5kIG9mIHR5cGUgYSBnaXZlbiBgX19UeXBlYCBpcy5cIixcbiAgdmFsdWVzOiB7XG4gICAgU0NBTEFSOiB7XG4gICAgICB2YWx1ZTogVHlwZUtpbmQuU0NBTEFSLFxuICAgICAgZGVzY3JpcHRpb246IFwiSW5kaWNhdGVzIHRoaXMgdHlwZSBpcyBhIHNjYWxhci5cIlxuICAgIH0sXG4gICAgT0JKRUNUOiB7XG4gICAgICB2YWx1ZTogVHlwZUtpbmQuT0JKRUNULFxuICAgICAgZGVzY3JpcHRpb246IFwiSW5kaWNhdGVzIHRoaXMgdHlwZSBpcyBhbiBvYmplY3QuIGBmaWVsZHNgIGFuZCBgaW50ZXJmYWNlc2AgYXJlIHZhbGlkIGZpZWxkcy5cIlxuICAgIH0sXG4gICAgSU5URVJGQUNFOiB7XG4gICAgICB2YWx1ZTogVHlwZUtpbmQuSU5URVJGQUNFLFxuICAgICAgZGVzY3JpcHRpb246IFwiSW5kaWNhdGVzIHRoaXMgdHlwZSBpcyBhbiBpbnRlcmZhY2UuIGBmaWVsZHNgLCBgaW50ZXJmYWNlc2AsIGFuZCBgcG9zc2libGVUeXBlc2AgYXJlIHZhbGlkIGZpZWxkcy5cIlxuICAgIH0sXG4gICAgVU5JT046IHtcbiAgICAgIHZhbHVlOiBUeXBlS2luZC5VTklPTixcbiAgICAgIGRlc2NyaXB0aW9uOiBcIkluZGljYXRlcyB0aGlzIHR5cGUgaXMgYSB1bmlvbi4gYHBvc3NpYmxlVHlwZXNgIGlzIGEgdmFsaWQgZmllbGQuXCJcbiAgICB9LFxuICAgIEVOVU06IHtcbiAgICAgIHZhbHVlOiBUeXBlS2luZC5FTlVNLFxuICAgICAgZGVzY3JpcHRpb246IFwiSW5kaWNhdGVzIHRoaXMgdHlwZSBpcyBhbiBlbnVtLiBgZW51bVZhbHVlc2AgaXMgYSB2YWxpZCBmaWVsZC5cIlxuICAgIH0sXG4gICAgSU5QVVRfT0JKRUNUOiB7XG4gICAgICB2YWx1ZTogVHlwZUtpbmQuSU5QVVRfT0JKRUNULFxuICAgICAgZGVzY3JpcHRpb246IFwiSW5kaWNhdGVzIHRoaXMgdHlwZSBpcyBhbiBpbnB1dCBvYmplY3QuIGBpbnB1dEZpZWxkc2AgaXMgYSB2YWxpZCBmaWVsZC5cIlxuICAgIH0sXG4gICAgTElTVDoge1xuICAgICAgdmFsdWU6IFR5cGVLaW5kLkxJU1QsXG4gICAgICBkZXNjcmlwdGlvbjogXCJJbmRpY2F0ZXMgdGhpcyB0eXBlIGlzIGEgbGlzdC4gYG9mVHlwZWAgaXMgYSB2YWxpZCBmaWVsZC5cIlxuICAgIH0sXG4gICAgTk9OX05VTEw6IHtcbiAgICAgIHZhbHVlOiBUeXBlS2luZC5OT05fTlVMTCxcbiAgICAgIGRlc2NyaXB0aW9uOiBcIkluZGljYXRlcyB0aGlzIHR5cGUgaXMgYSBub24tbnVsbC4gYG9mVHlwZWAgaXMgYSB2YWxpZCBmaWVsZC5cIlxuICAgIH1cbiAgfVxufSk7XG52YXIgU2NoZW1hTWV0YUZpZWxkRGVmID0ge1xuICBuYW1lOiBcIl9fc2NoZW1hXCIsXG4gIHR5cGU6IG5ldyBHcmFwaFFMTm9uTnVsbChfX1NjaGVtYSksXG4gIGRlc2NyaXB0aW9uOiBcIkFjY2VzcyB0aGUgY3VycmVudCB0eXBlIHNjaGVtYSBvZiB0aGlzIHNlcnZlci5cIixcbiAgYXJnczogW10sXG4gIHJlc29sdmU6IChfc291cmNlLCBfYXJncywgX2NvbnRleHQsIHsgc2NoZW1hIH0pID0+IHNjaGVtYSxcbiAgZGVwcmVjYXRpb25SZWFzb246IHZvaWQgMCxcbiAgZXh0ZW5zaW9uczogLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCksXG4gIGFzdE5vZGU6IHZvaWQgMFxufTtcbnZhciBUeXBlTWV0YUZpZWxkRGVmID0ge1xuICBuYW1lOiBcIl9fdHlwZVwiLFxuICB0eXBlOiBfX1R5cGUsXG4gIGRlc2NyaXB0aW9uOiBcIlJlcXVlc3QgdGhlIHR5cGUgaW5mb3JtYXRpb24gb2YgYSBzaW5nbGUgdHlwZS5cIixcbiAgYXJnczogW1xuICAgIHtcbiAgICAgIG5hbWU6IFwibmFtZVwiLFxuICAgICAgZGVzY3JpcHRpb246IHZvaWQgMCxcbiAgICAgIHR5cGU6IG5ldyBHcmFwaFFMTm9uTnVsbChHcmFwaFFMU3RyaW5nKSxcbiAgICAgIGRlZmF1bHRWYWx1ZTogdm9pZCAwLFxuICAgICAgZGVwcmVjYXRpb25SZWFzb246IHZvaWQgMCxcbiAgICAgIGV4dGVuc2lvbnM6IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpLFxuICAgICAgYXN0Tm9kZTogdm9pZCAwXG4gICAgfVxuICBdLFxuICByZXNvbHZlOiAoX3NvdXJjZSwgeyBuYW1lIH0sIF9jb250ZXh0LCB7IHNjaGVtYSB9KSA9PiBzY2hlbWEuZ2V0VHlwZShuYW1lKSxcbiAgZGVwcmVjYXRpb25SZWFzb246IHZvaWQgMCxcbiAgZXh0ZW5zaW9uczogLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCksXG4gIGFzdE5vZGU6IHZvaWQgMFxufTtcbnZhciBUeXBlTmFtZU1ldGFGaWVsZERlZiA9IHtcbiAgbmFtZTogXCJfX3R5cGVuYW1lXCIsXG4gIHR5cGU6IG5ldyBHcmFwaFFMTm9uTnVsbChHcmFwaFFMU3RyaW5nKSxcbiAgZGVzY3JpcHRpb246IFwiVGhlIG5hbWUgb2YgdGhlIGN1cnJlbnQgT2JqZWN0IHR5cGUgYXQgcnVudGltZS5cIixcbiAgYXJnczogW10sXG4gIHJlc29sdmU6IChfc291cmNlLCBfYXJncywgX2NvbnRleHQsIHsgcGFyZW50VHlwZSB9KSA9PiBwYXJlbnRUeXBlLm5hbWUsXG4gIGRlcHJlY2F0aW9uUmVhc29uOiB2b2lkIDAsXG4gIGV4dGVuc2lvbnM6IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpLFxuICBhc3ROb2RlOiB2b2lkIDBcbn07XG52YXIgaW50cm9zcGVjdGlvblR5cGVzID0gT2JqZWN0LmZyZWV6ZShbXG4gIF9fU2NoZW1hLFxuICBfX0RpcmVjdGl2ZSxcbiAgX19EaXJlY3RpdmVMb2NhdGlvbixcbiAgX19UeXBlLFxuICBfX0ZpZWxkLFxuICBfX0lucHV0VmFsdWUsXG4gIF9fRW51bVZhbHVlLFxuICBfX1R5cGVLaW5kXG5dKTtcblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL3V0aWxpdGllcy90eXBlRnJvbUFTVC5tanNcbmZ1bmN0aW9uIHR5cGVGcm9tQVNUKHNjaGVtYSwgdHlwZU5vZGUpIHtcbiAgc3dpdGNoICh0eXBlTm9kZS5raW5kKSB7XG4gICAgY2FzZSBLaW5kLkxJU1RfVFlQRToge1xuICAgICAgY29uc3QgaW5uZXJUeXBlID0gdHlwZUZyb21BU1Qoc2NoZW1hLCB0eXBlTm9kZS50eXBlKTtcbiAgICAgIHJldHVybiBpbm5lclR5cGUgJiYgbmV3IEdyYXBoUUxMaXN0KGlubmVyVHlwZSk7XG4gICAgfVxuICAgIGNhc2UgS2luZC5OT05fTlVMTF9UWVBFOiB7XG4gICAgICBjb25zdCBpbm5lclR5cGUgPSB0eXBlRnJvbUFTVChzY2hlbWEsIHR5cGVOb2RlLnR5cGUpO1xuICAgICAgcmV0dXJuIGlubmVyVHlwZSAmJiBuZXcgR3JhcGhRTE5vbk51bGwoaW5uZXJUeXBlKTtcbiAgICB9XG4gICAgY2FzZSBLaW5kLk5BTUVEX1RZUEU6XG4gICAgICByZXR1cm4gc2NoZW1hLmdldFR5cGUodHlwZU5vZGUubmFtZS52YWx1ZSk7XG4gIH1cbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL2xhbmd1YWdlL3ByZWRpY2F0ZXMubWpzXG5mdW5jdGlvbiBpc0V4ZWN1dGFibGVEZWZpbml0aW9uTm9kZShub2RlKSB7XG4gIHJldHVybiBub2RlLmtpbmQgPT09IEtpbmQuT1BFUkFUSU9OX0RFRklOSVRJT04gfHwgbm9kZS5raW5kID09PSBLaW5kLkZSQUdNRU5UX0RFRklOSVRJT047XG59XG5mdW5jdGlvbiBpc1R5cGVTeXN0ZW1EZWZpbml0aW9uTm9kZShub2RlKSB7XG4gIHJldHVybiBub2RlLmtpbmQgPT09IEtpbmQuU0NIRU1BX0RFRklOSVRJT04gfHwgaXNUeXBlRGVmaW5pdGlvbk5vZGUobm9kZSkgfHwgbm9kZS5raW5kID09PSBLaW5kLkRJUkVDVElWRV9ERUZJTklUSU9OO1xufVxuZnVuY3Rpb24gaXNUeXBlRGVmaW5pdGlvbk5vZGUobm9kZSkge1xuICByZXR1cm4gbm9kZS5raW5kID09PSBLaW5kLlNDQUxBUl9UWVBFX0RFRklOSVRJT04gfHwgbm9kZS5raW5kID09PSBLaW5kLk9CSkVDVF9UWVBFX0RFRklOSVRJT04gfHwgbm9kZS5raW5kID09PSBLaW5kLklOVEVSRkFDRV9UWVBFX0RFRklOSVRJT04gfHwgbm9kZS5raW5kID09PSBLaW5kLlVOSU9OX1RZUEVfREVGSU5JVElPTiB8fCBub2RlLmtpbmQgPT09IEtpbmQuRU5VTV9UWVBFX0RFRklOSVRJT04gfHwgbm9kZS5raW5kID09PSBLaW5kLklOUFVUX09CSkVDVF9UWVBFX0RFRklOSVRJT047XG59XG5mdW5jdGlvbiBpc1R5cGVTeXN0ZW1FeHRlbnNpb25Ob2RlKG5vZGUpIHtcbiAgcmV0dXJuIG5vZGUua2luZCA9PT0gS2luZC5TQ0hFTUFfRVhURU5TSU9OIHx8IGlzVHlwZUV4dGVuc2lvbk5vZGUobm9kZSk7XG59XG5mdW5jdGlvbiBpc1R5cGVFeHRlbnNpb25Ob2RlKG5vZGUpIHtcbiAgcmV0dXJuIG5vZGUua2luZCA9PT0gS2luZC5TQ0FMQVJfVFlQRV9FWFRFTlNJT04gfHwgbm9kZS5raW5kID09PSBLaW5kLk9CSkVDVF9UWVBFX0VYVEVOU0lPTiB8fCBub2RlLmtpbmQgPT09IEtpbmQuSU5URVJGQUNFX1RZUEVfRVhURU5TSU9OIHx8IG5vZGUua2luZCA9PT0gS2luZC5VTklPTl9UWVBFX0VYVEVOU0lPTiB8fCBub2RlLmtpbmQgPT09IEtpbmQuRU5VTV9UWVBFX0VYVEVOU0lPTiB8fCBub2RlLmtpbmQgPT09IEtpbmQuSU5QVVRfT0JKRUNUX1RZUEVfRVhURU5TSU9OO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdmFsaWRhdGlvbi9ydWxlcy9FeGVjdXRhYmxlRGVmaW5pdGlvbnNSdWxlLm1qc1xuZnVuY3Rpb24gRXhlY3V0YWJsZURlZmluaXRpb25zUnVsZShjb250ZXh0KSB7XG4gIHJldHVybiB7XG4gICAgRG9jdW1lbnQobm9kZSkge1xuICAgICAgZm9yIChjb25zdCBkZWZpbml0aW9uIG9mIG5vZGUuZGVmaW5pdGlvbnMpIHtcbiAgICAgICAgaWYgKCFpc0V4ZWN1dGFibGVEZWZpbml0aW9uTm9kZShkZWZpbml0aW9uKSkge1xuICAgICAgICAgIGNvbnN0IGRlZk5hbWUgPSBkZWZpbml0aW9uLmtpbmQgPT09IEtpbmQuU0NIRU1BX0RFRklOSVRJT04gfHwgZGVmaW5pdGlvbi5raW5kID09PSBLaW5kLlNDSEVNQV9FWFRFTlNJT04gPyBcInNjaGVtYVwiIDogJ1wiJyArIGRlZmluaXRpb24ubmFtZS52YWx1ZSArICdcIic7XG4gICAgICAgICAgY29udGV4dC5yZXBvcnRFcnJvcihcbiAgICAgICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoYFRoZSAke2RlZk5hbWV9IGRlZmluaXRpb24gaXMgbm90IGV4ZWN1dGFibGUuYCwge1xuICAgICAgICAgICAgICBub2RlczogZGVmaW5pdGlvblxuICAgICAgICAgICAgfSlcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICB9O1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdmFsaWRhdGlvbi9ydWxlcy9GaWVsZHNPbkNvcnJlY3RUeXBlUnVsZS5tanNcbmZ1bmN0aW9uIEZpZWxkc09uQ29ycmVjdFR5cGVSdWxlKGNvbnRleHQpIHtcbiAgcmV0dXJuIHtcbiAgICBGaWVsZChub2RlKSB7XG4gICAgICBjb25zdCB0eXBlID0gY29udGV4dC5nZXRQYXJlbnRUeXBlKCk7XG4gICAgICBpZiAodHlwZSkge1xuICAgICAgICBjb25zdCBmaWVsZERlZiA9IGNvbnRleHQuZ2V0RmllbGREZWYoKTtcbiAgICAgICAgaWYgKCFmaWVsZERlZikge1xuICAgICAgICAgIGNvbnN0IHNjaGVtYSA9IGNvbnRleHQuZ2V0U2NoZW1hKCk7XG4gICAgICAgICAgY29uc3QgZmllbGROYW1lID0gbm9kZS5uYW1lLnZhbHVlO1xuICAgICAgICAgIGxldCBzdWdnZXN0aW9uID0gZGlkWW91TWVhbihcbiAgICAgICAgICAgIFwidG8gdXNlIGFuIGlubGluZSBmcmFnbWVudCBvblwiLFxuICAgICAgICAgICAgZ2V0U3VnZ2VzdGVkVHlwZU5hbWVzKHNjaGVtYSwgdHlwZSwgZmllbGROYW1lKVxuICAgICAgICAgICk7XG4gICAgICAgICAgaWYgKHN1Z2dlc3Rpb24gPT09IFwiXCIpIHtcbiAgICAgICAgICAgIHN1Z2dlc3Rpb24gPSBkaWRZb3VNZWFuKGdldFN1Z2dlc3RlZEZpZWxkTmFtZXModHlwZSwgZmllbGROYW1lKSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgICAgICBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICAgICAgICBgQ2Fubm90IHF1ZXJ5IGZpZWxkIFwiJHtmaWVsZE5hbWV9XCIgb24gdHlwZSBcIiR7dHlwZS5uYW1lfVwiLmAgKyBzdWdnZXN0aW9uLFxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgbm9kZXM6IG5vZGVcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgKVxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH07XG59XG5mdW5jdGlvbiBnZXRTdWdnZXN0ZWRUeXBlTmFtZXMoc2NoZW1hLCB0eXBlLCBmaWVsZE5hbWUpIHtcbiAgaWYgKCFpc0Fic3RyYWN0VHlwZSh0eXBlKSkge1xuICAgIHJldHVybiBbXTtcbiAgfVxuICBjb25zdCBzdWdnZXN0ZWRUeXBlcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG4gIGNvbnN0IHVzYWdlQ291bnQgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgZm9yIChjb25zdCBwb3NzaWJsZVR5cGUgb2Ygc2NoZW1hLmdldFBvc3NpYmxlVHlwZXModHlwZSkpIHtcbiAgICBpZiAoIXBvc3NpYmxlVHlwZS5nZXRGaWVsZHMoKVtmaWVsZE5hbWVdKSB7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgc3VnZ2VzdGVkVHlwZXMuYWRkKHBvc3NpYmxlVHlwZSk7XG4gICAgdXNhZ2VDb3VudFtwb3NzaWJsZVR5cGUubmFtZV0gPSAxO1xuICAgIGZvciAoY29uc3QgcG9zc2libGVJbnRlcmZhY2Ugb2YgcG9zc2libGVUeXBlLmdldEludGVyZmFjZXMoKSkge1xuICAgICAgdmFyIF91c2FnZUNvdW50JHBvc3NpYmxlSTtcbiAgICAgIGlmICghcG9zc2libGVJbnRlcmZhY2UuZ2V0RmllbGRzKClbZmllbGROYW1lXSkge1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cbiAgICAgIHN1Z2dlc3RlZFR5cGVzLmFkZChwb3NzaWJsZUludGVyZmFjZSk7XG4gICAgICB1c2FnZUNvdW50W3Bvc3NpYmxlSW50ZXJmYWNlLm5hbWVdID0gKChfdXNhZ2VDb3VudCRwb3NzaWJsZUkgPSB1c2FnZUNvdW50W3Bvc3NpYmxlSW50ZXJmYWNlLm5hbWVdKSAhPT0gbnVsbCAmJiBfdXNhZ2VDb3VudCRwb3NzaWJsZUkgIT09IHZvaWQgMCA/IF91c2FnZUNvdW50JHBvc3NpYmxlSSA6IDApICsgMTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIFsuLi5zdWdnZXN0ZWRUeXBlc10uc29ydCgodHlwZUEsIHR5cGVCKSA9PiB7XG4gICAgY29uc3QgdXNhZ2VDb3VudERpZmYgPSB1c2FnZUNvdW50W3R5cGVCLm5hbWVdIC0gdXNhZ2VDb3VudFt0eXBlQS5uYW1lXTtcbiAgICBpZiAodXNhZ2VDb3VudERpZmYgIT09IDApIHtcbiAgICAgIHJldHVybiB1c2FnZUNvdW50RGlmZjtcbiAgICB9XG4gICAgaWYgKGlzSW50ZXJmYWNlVHlwZSh0eXBlQSkgJiYgc2NoZW1hLmlzU3ViVHlwZSh0eXBlQSwgdHlwZUIpKSB7XG4gICAgICByZXR1cm4gLTE7XG4gICAgfVxuICAgIGlmIChpc0ludGVyZmFjZVR5cGUodHlwZUIpICYmIHNjaGVtYS5pc1N1YlR5cGUodHlwZUIsIHR5cGVBKSkge1xuICAgICAgcmV0dXJuIDE7XG4gICAgfVxuICAgIHJldHVybiBuYXR1cmFsQ29tcGFyZSh0eXBlQS5uYW1lLCB0eXBlQi5uYW1lKTtcbiAgfSkubWFwKCh4KSA9PiB4Lm5hbWUpO1xufVxuZnVuY3Rpb24gZ2V0U3VnZ2VzdGVkRmllbGROYW1lcyh0eXBlLCBmaWVsZE5hbWUpIHtcbiAgaWYgKGlzT2JqZWN0VHlwZSh0eXBlKSB8fCBpc0ludGVyZmFjZVR5cGUodHlwZSkpIHtcbiAgICBjb25zdCBwb3NzaWJsZUZpZWxkTmFtZXMgPSBPYmplY3Qua2V5cyh0eXBlLmdldEZpZWxkcygpKTtcbiAgICByZXR1cm4gc3VnZ2VzdGlvbkxpc3QoZmllbGROYW1lLCBwb3NzaWJsZUZpZWxkTmFtZXMpO1xuICB9XG4gIHJldHVybiBbXTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL3ZhbGlkYXRpb24vcnVsZXMvRnJhZ21lbnRzT25Db21wb3NpdGVUeXBlc1J1bGUubWpzXG5mdW5jdGlvbiBGcmFnbWVudHNPbkNvbXBvc2l0ZVR5cGVzUnVsZShjb250ZXh0KSB7XG4gIHJldHVybiB7XG4gICAgSW5saW5lRnJhZ21lbnQobm9kZSkge1xuICAgICAgY29uc3QgdHlwZUNvbmRpdGlvbiA9IG5vZGUudHlwZUNvbmRpdGlvbjtcbiAgICAgIGlmICh0eXBlQ29uZGl0aW9uKSB7XG4gICAgICAgIGNvbnN0IHR5cGUgPSB0eXBlRnJvbUFTVChjb250ZXh0LmdldFNjaGVtYSgpLCB0eXBlQ29uZGl0aW9uKTtcbiAgICAgICAgaWYgKHR5cGUgJiYgIWlzQ29tcG9zaXRlVHlwZSh0eXBlKSkge1xuICAgICAgICAgIGNvbnN0IHR5cGVTdHIgPSBwcmludCh0eXBlQ29uZGl0aW9uKTtcbiAgICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgICAgICAgYEZyYWdtZW50IGNhbm5vdCBjb25kaXRpb24gb24gbm9uIGNvbXBvc2l0ZSB0eXBlIFwiJHt0eXBlU3RyfVwiLmAsXG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBub2RlczogdHlwZUNvbmRpdGlvblxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICApXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gICAgRnJhZ21lbnREZWZpbml0aW9uKG5vZGUpIHtcbiAgICAgIGNvbnN0IHR5cGUgPSB0eXBlRnJvbUFTVChjb250ZXh0LmdldFNjaGVtYSgpLCBub2RlLnR5cGVDb25kaXRpb24pO1xuICAgICAgaWYgKHR5cGUgJiYgIWlzQ29tcG9zaXRlVHlwZSh0eXBlKSkge1xuICAgICAgICBjb25zdCB0eXBlU3RyID0gcHJpbnQobm9kZS50eXBlQ29uZGl0aW9uKTtcbiAgICAgICAgY29udGV4dC5yZXBvcnRFcnJvcihcbiAgICAgICAgICBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICAgICAgYEZyYWdtZW50IFwiJHtub2RlLm5hbWUudmFsdWV9XCIgY2Fubm90IGNvbmRpdGlvbiBvbiBub24gY29tcG9zaXRlIHR5cGUgXCIke3R5cGVTdHJ9XCIuYCxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbm9kZXM6IG5vZGUudHlwZUNvbmRpdGlvblxuICAgICAgICAgICAgfVxuICAgICAgICAgIClcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG4gIH07XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC92YWxpZGF0aW9uL3J1bGVzL0tub3duQXJndW1lbnROYW1lc1J1bGUubWpzXG5mdW5jdGlvbiBLbm93bkFyZ3VtZW50TmFtZXNSdWxlKGNvbnRleHQpIHtcbiAgcmV0dXJuIHtcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbmV3LWNhcFxuICAgIC4uLktub3duQXJndW1lbnROYW1lc09uRGlyZWN0aXZlc1J1bGUoY29udGV4dCksXG4gICAgQXJndW1lbnQoYXJnTm9kZSkge1xuICAgICAgY29uc3QgYXJnRGVmID0gY29udGV4dC5nZXRBcmd1bWVudCgpO1xuICAgICAgY29uc3QgZmllbGREZWYgPSBjb250ZXh0LmdldEZpZWxkRGVmKCk7XG4gICAgICBjb25zdCBwYXJlbnRUeXBlID0gY29udGV4dC5nZXRQYXJlbnRUeXBlKCk7XG4gICAgICBpZiAoIWFyZ0RlZiAmJiBmaWVsZERlZiAmJiBwYXJlbnRUeXBlKSB7XG4gICAgICAgIGNvbnN0IGFyZ05hbWUgPSBhcmdOb2RlLm5hbWUudmFsdWU7XG4gICAgICAgIGNvbnN0IGtub3duQXJnc05hbWVzID0gZmllbGREZWYuYXJncy5tYXAoKGFyZykgPT4gYXJnLm5hbWUpO1xuICAgICAgICBjb25zdCBzdWdnZXN0aW9ucyA9IHN1Z2dlc3Rpb25MaXN0KGFyZ05hbWUsIGtub3duQXJnc05hbWVzKTtcbiAgICAgICAgY29udGV4dC5yZXBvcnRFcnJvcihcbiAgICAgICAgICBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICAgICAgYFVua25vd24gYXJndW1lbnQgXCIke2FyZ05hbWV9XCIgb24gZmllbGQgXCIke3BhcmVudFR5cGUubmFtZX0uJHtmaWVsZERlZi5uYW1lfVwiLmAgKyBkaWRZb3VNZWFuKHN1Z2dlc3Rpb25zKSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbm9kZXM6IGFyZ05vZGVcbiAgICAgICAgICAgIH1cbiAgICAgICAgICApXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuICB9O1xufVxuZnVuY3Rpb24gS25vd25Bcmd1bWVudE5hbWVzT25EaXJlY3RpdmVzUnVsZShjb250ZXh0KSB7XG4gIGNvbnN0IGRpcmVjdGl2ZUFyZ3MgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgY29uc3Qgc2NoZW1hID0gY29udGV4dC5nZXRTY2hlbWEoKTtcbiAgY29uc3QgZGVmaW5lZERpcmVjdGl2ZXMgPSBzY2hlbWEgPyBzY2hlbWEuZ2V0RGlyZWN0aXZlcygpIDogc3BlY2lmaWVkRGlyZWN0aXZlcztcbiAgZm9yIChjb25zdCBkaXJlY3RpdmUgb2YgZGVmaW5lZERpcmVjdGl2ZXMpIHtcbiAgICBkaXJlY3RpdmVBcmdzW2RpcmVjdGl2ZS5uYW1lXSA9IGRpcmVjdGl2ZS5hcmdzLm1hcCgoYXJnKSA9PiBhcmcubmFtZSk7XG4gIH1cbiAgY29uc3QgYXN0RGVmaW5pdGlvbnMgPSBjb250ZXh0LmdldERvY3VtZW50KCkuZGVmaW5pdGlvbnM7XG4gIGZvciAoY29uc3QgZGVmIG9mIGFzdERlZmluaXRpb25zKSB7XG4gICAgaWYgKGRlZi5raW5kID09PSBLaW5kLkRJUkVDVElWRV9ERUZJTklUSU9OKSB7XG4gICAgICB2YXIgX2RlZiRhcmd1bWVudHM7XG4gICAgICBjb25zdCBhcmdzTm9kZXMgPSAoX2RlZiRhcmd1bWVudHMgPSBkZWYuYXJndW1lbnRzKSAhPT0gbnVsbCAmJiBfZGVmJGFyZ3VtZW50cyAhPT0gdm9pZCAwID8gX2RlZiRhcmd1bWVudHMgOiBbXTtcbiAgICAgIGRpcmVjdGl2ZUFyZ3NbZGVmLm5hbWUudmFsdWVdID0gYXJnc05vZGVzLm1hcCgoYXJnKSA9PiBhcmcubmFtZS52YWx1ZSk7XG4gICAgfVxuICB9XG4gIHJldHVybiB7XG4gICAgRGlyZWN0aXZlKGRpcmVjdGl2ZU5vZGUpIHtcbiAgICAgIGNvbnN0IGRpcmVjdGl2ZU5hbWUgPSBkaXJlY3RpdmVOb2RlLm5hbWUudmFsdWU7XG4gICAgICBjb25zdCBrbm93bkFyZ3MgPSBkaXJlY3RpdmVBcmdzW2RpcmVjdGl2ZU5hbWVdO1xuICAgICAgaWYgKGRpcmVjdGl2ZU5vZGUuYXJndW1lbnRzICYmIGtub3duQXJncykge1xuICAgICAgICBmb3IgKGNvbnN0IGFyZ05vZGUgb2YgZGlyZWN0aXZlTm9kZS5hcmd1bWVudHMpIHtcbiAgICAgICAgICBjb25zdCBhcmdOYW1lID0gYXJnTm9kZS5uYW1lLnZhbHVlO1xuICAgICAgICAgIGlmICgha25vd25BcmdzLmluY2x1ZGVzKGFyZ05hbWUpKSB7XG4gICAgICAgICAgICBjb25zdCBzdWdnZXN0aW9ucyA9IHN1Z2dlc3Rpb25MaXN0KGFyZ05hbWUsIGtub3duQXJncyk7XG4gICAgICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgICAgICBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICAgICAgICAgIGBVbmtub3duIGFyZ3VtZW50IFwiJHthcmdOYW1lfVwiIG9uIGRpcmVjdGl2ZSBcIkAke2RpcmVjdGl2ZU5hbWV9XCIuYCArIGRpZFlvdU1lYW4oc3VnZ2VzdGlvbnMpLFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgIG5vZGVzOiBhcmdOb2RlXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICApXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgfTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL3ZhbGlkYXRpb24vcnVsZXMvS25vd25EaXJlY3RpdmVzUnVsZS5tanNcbmZ1bmN0aW9uIEtub3duRGlyZWN0aXZlc1J1bGUoY29udGV4dCkge1xuICBjb25zdCBsb2NhdGlvbnNNYXAgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgY29uc3Qgc2NoZW1hID0gY29udGV4dC5nZXRTY2hlbWEoKTtcbiAgY29uc3QgZGVmaW5lZERpcmVjdGl2ZXMgPSBzY2hlbWEgPyBzY2hlbWEuZ2V0RGlyZWN0aXZlcygpIDogc3BlY2lmaWVkRGlyZWN0aXZlcztcbiAgZm9yIChjb25zdCBkaXJlY3RpdmUgb2YgZGVmaW5lZERpcmVjdGl2ZXMpIHtcbiAgICBsb2NhdGlvbnNNYXBbZGlyZWN0aXZlLm5hbWVdID0gZGlyZWN0aXZlLmxvY2F0aW9ucztcbiAgfVxuICBjb25zdCBhc3REZWZpbml0aW9ucyA9IGNvbnRleHQuZ2V0RG9jdW1lbnQoKS5kZWZpbml0aW9ucztcbiAgZm9yIChjb25zdCBkZWYgb2YgYXN0RGVmaW5pdGlvbnMpIHtcbiAgICBpZiAoZGVmLmtpbmQgPT09IEtpbmQuRElSRUNUSVZFX0RFRklOSVRJT04pIHtcbiAgICAgIGxvY2F0aW9uc01hcFtkZWYubmFtZS52YWx1ZV0gPSBkZWYubG9jYXRpb25zLm1hcCgobmFtZSkgPT4gbmFtZS52YWx1ZSk7XG4gICAgfVxuICB9XG4gIHJldHVybiB7XG4gICAgRGlyZWN0aXZlKG5vZGUsIF9rZXksIF9wYXJlbnQsIF9wYXRoLCBhbmNlc3RvcnMpIHtcbiAgICAgIGNvbnN0IG5hbWUgPSBub2RlLm5hbWUudmFsdWU7XG4gICAgICBjb25zdCBsb2NhdGlvbnMgPSBsb2NhdGlvbnNNYXBbbmFtZV07XG4gICAgICBpZiAoIWxvY2F0aW9ucykge1xuICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoYFVua25vd24gZGlyZWN0aXZlIFwiQCR7bmFtZX1cIi5gLCB7XG4gICAgICAgICAgICBub2Rlczogbm9kZVxuICAgICAgICAgIH0pXG4gICAgICAgICk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGNhbmRpZGF0ZUxvY2F0aW9uID0gZ2V0RGlyZWN0aXZlTG9jYXRpb25Gb3JBU1RQYXRoKGFuY2VzdG9ycyk7XG4gICAgICBpZiAoY2FuZGlkYXRlTG9jYXRpb24gJiYgIWxvY2F0aW9ucy5pbmNsdWRlcyhjYW5kaWRhdGVMb2NhdGlvbikpIHtcbiAgICAgICAgY29udGV4dC5yZXBvcnRFcnJvcihcbiAgICAgICAgICBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICAgICAgYERpcmVjdGl2ZSBcIkAke25hbWV9XCIgbWF5IG5vdCBiZSB1c2VkIG9uICR7Y2FuZGlkYXRlTG9jYXRpb259LmAsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5vZGVzOiBub2RlXG4gICAgICAgICAgICB9XG4gICAgICAgICAgKVxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cbiAgfTtcbn1cbmZ1bmN0aW9uIGdldERpcmVjdGl2ZUxvY2F0aW9uRm9yQVNUUGF0aChhbmNlc3RvcnMpIHtcbiAgY29uc3QgYXBwbGllZFRvID0gYW5jZXN0b3JzW2FuY2VzdG9ycy5sZW5ndGggLSAxXTtcbiAgXCJraW5kXCIgaW4gYXBwbGllZFRvIHx8IGludmFyaWFudDIoZmFsc2UpO1xuICBzd2l0Y2ggKGFwcGxpZWRUby5raW5kKSB7XG4gICAgY2FzZSBLaW5kLk9QRVJBVElPTl9ERUZJTklUSU9OOlxuICAgICAgcmV0dXJuIGdldERpcmVjdGl2ZUxvY2F0aW9uRm9yT3BlcmF0aW9uKGFwcGxpZWRUby5vcGVyYXRpb24pO1xuICAgIGNhc2UgS2luZC5GSUVMRDpcbiAgICAgIHJldHVybiBEaXJlY3RpdmVMb2NhdGlvbi5GSUVMRDtcbiAgICBjYXNlIEtpbmQuRlJBR01FTlRfU1BSRUFEOlxuICAgICAgcmV0dXJuIERpcmVjdGl2ZUxvY2F0aW9uLkZSQUdNRU5UX1NQUkVBRDtcbiAgICBjYXNlIEtpbmQuSU5MSU5FX0ZSQUdNRU5UOlxuICAgICAgcmV0dXJuIERpcmVjdGl2ZUxvY2F0aW9uLklOTElORV9GUkFHTUVOVDtcbiAgICBjYXNlIEtpbmQuRlJBR01FTlRfREVGSU5JVElPTjpcbiAgICAgIHJldHVybiBEaXJlY3RpdmVMb2NhdGlvbi5GUkFHTUVOVF9ERUZJTklUSU9OO1xuICAgIGNhc2UgS2luZC5WQVJJQUJMRV9ERUZJTklUSU9OOlxuICAgICAgcmV0dXJuIERpcmVjdGl2ZUxvY2F0aW9uLlZBUklBQkxFX0RFRklOSVRJT047XG4gICAgY2FzZSBLaW5kLlNDSEVNQV9ERUZJTklUSU9OOlxuICAgIGNhc2UgS2luZC5TQ0hFTUFfRVhURU5TSU9OOlxuICAgICAgcmV0dXJuIERpcmVjdGl2ZUxvY2F0aW9uLlNDSEVNQTtcbiAgICBjYXNlIEtpbmQuU0NBTEFSX1RZUEVfREVGSU5JVElPTjpcbiAgICBjYXNlIEtpbmQuU0NBTEFSX1RZUEVfRVhURU5TSU9OOlxuICAgICAgcmV0dXJuIERpcmVjdGl2ZUxvY2F0aW9uLlNDQUxBUjtcbiAgICBjYXNlIEtpbmQuT0JKRUNUX1RZUEVfREVGSU5JVElPTjpcbiAgICBjYXNlIEtpbmQuT0JKRUNUX1RZUEVfRVhURU5TSU9OOlxuICAgICAgcmV0dXJuIERpcmVjdGl2ZUxvY2F0aW9uLk9CSkVDVDtcbiAgICBjYXNlIEtpbmQuRklFTERfREVGSU5JVElPTjpcbiAgICAgIHJldHVybiBEaXJlY3RpdmVMb2NhdGlvbi5GSUVMRF9ERUZJTklUSU9OO1xuICAgIGNhc2UgS2luZC5JTlRFUkZBQ0VfVFlQRV9ERUZJTklUSU9OOlxuICAgIGNhc2UgS2luZC5JTlRFUkZBQ0VfVFlQRV9FWFRFTlNJT046XG4gICAgICByZXR1cm4gRGlyZWN0aXZlTG9jYXRpb24uSU5URVJGQUNFO1xuICAgIGNhc2UgS2luZC5VTklPTl9UWVBFX0RFRklOSVRJT046XG4gICAgY2FzZSBLaW5kLlVOSU9OX1RZUEVfRVhURU5TSU9OOlxuICAgICAgcmV0dXJuIERpcmVjdGl2ZUxvY2F0aW9uLlVOSU9OO1xuICAgIGNhc2UgS2luZC5FTlVNX1RZUEVfREVGSU5JVElPTjpcbiAgICBjYXNlIEtpbmQuRU5VTV9UWVBFX0VYVEVOU0lPTjpcbiAgICAgIHJldHVybiBEaXJlY3RpdmVMb2NhdGlvbi5FTlVNO1xuICAgIGNhc2UgS2luZC5FTlVNX1ZBTFVFX0RFRklOSVRJT046XG4gICAgICByZXR1cm4gRGlyZWN0aXZlTG9jYXRpb24uRU5VTV9WQUxVRTtcbiAgICBjYXNlIEtpbmQuSU5QVVRfT0JKRUNUX1RZUEVfREVGSU5JVElPTjpcbiAgICBjYXNlIEtpbmQuSU5QVVRfT0JKRUNUX1RZUEVfRVhURU5TSU9OOlxuICAgICAgcmV0dXJuIERpcmVjdGl2ZUxvY2F0aW9uLklOUFVUX09CSkVDVDtcbiAgICBjYXNlIEtpbmQuSU5QVVRfVkFMVUVfREVGSU5JVElPTjoge1xuICAgICAgY29uc3QgcGFyZW50Tm9kZSA9IGFuY2VzdG9yc1thbmNlc3RvcnMubGVuZ3RoIC0gM107XG4gICAgICBcImtpbmRcIiBpbiBwYXJlbnROb2RlIHx8IGludmFyaWFudDIoZmFsc2UpO1xuICAgICAgcmV0dXJuIHBhcmVudE5vZGUua2luZCA9PT0gS2luZC5JTlBVVF9PQkpFQ1RfVFlQRV9ERUZJTklUSU9OID8gRGlyZWN0aXZlTG9jYXRpb24uSU5QVVRfRklFTERfREVGSU5JVElPTiA6IERpcmVjdGl2ZUxvY2F0aW9uLkFSR1VNRU5UX0RFRklOSVRJT047XG4gICAgfVxuICAgIGRlZmF1bHQ6XG4gICAgICBpbnZhcmlhbnQyKGZhbHNlLCBcIlVuZXhwZWN0ZWQga2luZDogXCIgKyBpbnNwZWN0KGFwcGxpZWRUby5raW5kKSk7XG4gIH1cbn1cbmZ1bmN0aW9uIGdldERpcmVjdGl2ZUxvY2F0aW9uRm9yT3BlcmF0aW9uKG9wZXJhdGlvbikge1xuICBzd2l0Y2ggKG9wZXJhdGlvbikge1xuICAgIGNhc2UgT3BlcmF0aW9uVHlwZU5vZGUuUVVFUlk6XG4gICAgICByZXR1cm4gRGlyZWN0aXZlTG9jYXRpb24uUVVFUlk7XG4gICAgY2FzZSBPcGVyYXRpb25UeXBlTm9kZS5NVVRBVElPTjpcbiAgICAgIHJldHVybiBEaXJlY3RpdmVMb2NhdGlvbi5NVVRBVElPTjtcbiAgICBjYXNlIE9wZXJhdGlvblR5cGVOb2RlLlNVQlNDUklQVElPTjpcbiAgICAgIHJldHVybiBEaXJlY3RpdmVMb2NhdGlvbi5TVUJTQ1JJUFRJT047XG4gIH1cbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL3ZhbGlkYXRpb24vcnVsZXMvS25vd25GcmFnbWVudE5hbWVzUnVsZS5tanNcbmZ1bmN0aW9uIEtub3duRnJhZ21lbnROYW1lc1J1bGUoY29udGV4dCkge1xuICByZXR1cm4ge1xuICAgIEZyYWdtZW50U3ByZWFkKG5vZGUpIHtcbiAgICAgIGNvbnN0IGZyYWdtZW50TmFtZSA9IG5vZGUubmFtZS52YWx1ZTtcbiAgICAgIGNvbnN0IGZyYWdtZW50ID0gY29udGV4dC5nZXRGcmFnbWVudChmcmFnbWVudE5hbWUpO1xuICAgICAgaWYgKCFmcmFnbWVudCkge1xuICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoYFVua25vd24gZnJhZ21lbnQgXCIke2ZyYWdtZW50TmFtZX1cIi5gLCB7XG4gICAgICAgICAgICBub2Rlczogbm9kZS5uYW1lXG4gICAgICAgICAgfSlcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG4gIH07XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC92YWxpZGF0aW9uL3J1bGVzL0tub3duVHlwZU5hbWVzUnVsZS5tanNcbmZ1bmN0aW9uIEtub3duVHlwZU5hbWVzUnVsZShjb250ZXh0KSB7XG4gIGNvbnN0IHNjaGVtYSA9IGNvbnRleHQuZ2V0U2NoZW1hKCk7XG4gIGNvbnN0IGV4aXN0aW5nVHlwZXNNYXAgPSBzY2hlbWEgPyBzY2hlbWEuZ2V0VHlwZU1hcCgpIDogLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIGNvbnN0IGRlZmluZWRUeXBlcyA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICBmb3IgKGNvbnN0IGRlZiBvZiBjb250ZXh0LmdldERvY3VtZW50KCkuZGVmaW5pdGlvbnMpIHtcbiAgICBpZiAoaXNUeXBlRGVmaW5pdGlvbk5vZGUoZGVmKSkge1xuICAgICAgZGVmaW5lZFR5cGVzW2RlZi5uYW1lLnZhbHVlXSA9IHRydWU7XG4gICAgfVxuICB9XG4gIGNvbnN0IHR5cGVOYW1lcyA9IFtcbiAgICAuLi5PYmplY3Qua2V5cyhleGlzdGluZ1R5cGVzTWFwKSxcbiAgICAuLi5PYmplY3Qua2V5cyhkZWZpbmVkVHlwZXMpXG4gIF07XG4gIHJldHVybiB7XG4gICAgTmFtZWRUeXBlKG5vZGUsIF8xLCBwYXJlbnQsIF8yLCBhbmNlc3RvcnMpIHtcbiAgICAgIGNvbnN0IHR5cGVOYW1lID0gbm9kZS5uYW1lLnZhbHVlO1xuICAgICAgaWYgKCFleGlzdGluZ1R5cGVzTWFwW3R5cGVOYW1lXSAmJiAhZGVmaW5lZFR5cGVzW3R5cGVOYW1lXSkge1xuICAgICAgICB2YXIgX2FuY2VzdG9ycyQ7XG4gICAgICAgIGNvbnN0IGRlZmluaXRpb25Ob2RlID0gKF9hbmNlc3RvcnMkID0gYW5jZXN0b3JzWzJdKSAhPT0gbnVsbCAmJiBfYW5jZXN0b3JzJCAhPT0gdm9pZCAwID8gX2FuY2VzdG9ycyQgOiBwYXJlbnQ7XG4gICAgICAgIGNvbnN0IGlzU0RMID0gZGVmaW5pdGlvbk5vZGUgIT0gbnVsbCAmJiBpc1NETE5vZGUoZGVmaW5pdGlvbk5vZGUpO1xuICAgICAgICBpZiAoaXNTREwgJiYgc3RhbmRhcmRUeXBlTmFtZXMuaW5jbHVkZXModHlwZU5hbWUpKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHN1Z2dlc3RlZFR5cGVzID0gc3VnZ2VzdGlvbkxpc3QoXG4gICAgICAgICAgdHlwZU5hbWUsXG4gICAgICAgICAgaXNTREwgPyBzdGFuZGFyZFR5cGVOYW1lcy5jb25jYXQodHlwZU5hbWVzKSA6IHR5cGVOYW1lc1xuICAgICAgICApO1xuICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgICAgICBgVW5rbm93biB0eXBlIFwiJHt0eXBlTmFtZX1cIi5gICsgZGlkWW91TWVhbihzdWdnZXN0ZWRUeXBlcyksXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5vZGVzOiBub2RlXG4gICAgICAgICAgICB9XG4gICAgICAgICAgKVxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cbiAgfTtcbn1cbnZhciBzdGFuZGFyZFR5cGVOYW1lcyA9IFsuLi5zcGVjaWZpZWRTY2FsYXJUeXBlcywgLi4uaW50cm9zcGVjdGlvblR5cGVzXS5tYXAoXG4gICh0eXBlKSA9PiB0eXBlLm5hbWVcbik7XG5mdW5jdGlvbiBpc1NETE5vZGUodmFsdWUpIHtcbiAgcmV0dXJuIFwia2luZFwiIGluIHZhbHVlICYmIChpc1R5cGVTeXN0ZW1EZWZpbml0aW9uTm9kZSh2YWx1ZSkgfHwgaXNUeXBlU3lzdGVtRXh0ZW5zaW9uTm9kZSh2YWx1ZSkpO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdmFsaWRhdGlvbi9ydWxlcy9Mb25lQW5vbnltb3VzT3BlcmF0aW9uUnVsZS5tanNcbmZ1bmN0aW9uIExvbmVBbm9ueW1vdXNPcGVyYXRpb25SdWxlKGNvbnRleHQpIHtcbiAgbGV0IG9wZXJhdGlvbkNvdW50ID0gMDtcbiAgcmV0dXJuIHtcbiAgICBEb2N1bWVudChub2RlKSB7XG4gICAgICBvcGVyYXRpb25Db3VudCA9IG5vZGUuZGVmaW5pdGlvbnMuZmlsdGVyKFxuICAgICAgICAoZGVmaW5pdGlvbikgPT4gZGVmaW5pdGlvbi5raW5kID09PSBLaW5kLk9QRVJBVElPTl9ERUZJTklUSU9OXG4gICAgICApLmxlbmd0aDtcbiAgICB9LFxuICAgIE9wZXJhdGlvbkRlZmluaXRpb24obm9kZSkge1xuICAgICAgaWYgKCFub2RlLm5hbWUgJiYgb3BlcmF0aW9uQ291bnQgPiAxKSB7XG4gICAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgICAgIFwiVGhpcyBhbm9ueW1vdXMgb3BlcmF0aW9uIG11c3QgYmUgdGhlIG9ubHkgZGVmaW5lZCBvcGVyYXRpb24uXCIsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5vZGVzOiBub2RlXG4gICAgICAgICAgICB9XG4gICAgICAgICAgKVxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cbiAgfTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL3ZhbGlkYXRpb24vcnVsZXMvTG9uZVNjaGVtYURlZmluaXRpb25SdWxlLm1qc1xuZnVuY3Rpb24gTG9uZVNjaGVtYURlZmluaXRpb25SdWxlKGNvbnRleHQpIHtcbiAgdmFyIF9yZWYsIF9yZWYyLCBfb2xkU2NoZW1hJGFzdE5vZGU7XG4gIGNvbnN0IG9sZFNjaGVtYSA9IGNvbnRleHQuZ2V0U2NoZW1hKCk7XG4gIGNvbnN0IGFscmVhZHlEZWZpbmVkID0gKF9yZWYgPSAoX3JlZjIgPSAoX29sZFNjaGVtYSRhc3ROb2RlID0gb2xkU2NoZW1hID09PSBudWxsIHx8IG9sZFNjaGVtYSA9PT0gdm9pZCAwID8gdm9pZCAwIDogb2xkU2NoZW1hLmFzdE5vZGUpICE9PSBudWxsICYmIF9vbGRTY2hlbWEkYXN0Tm9kZSAhPT0gdm9pZCAwID8gX29sZFNjaGVtYSRhc3ROb2RlIDogb2xkU2NoZW1hID09PSBudWxsIHx8IG9sZFNjaGVtYSA9PT0gdm9pZCAwID8gdm9pZCAwIDogb2xkU2NoZW1hLmdldFF1ZXJ5VHlwZSgpKSAhPT0gbnVsbCAmJiBfcmVmMiAhPT0gdm9pZCAwID8gX3JlZjIgOiBvbGRTY2hlbWEgPT09IG51bGwgfHwgb2xkU2NoZW1hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBvbGRTY2hlbWEuZ2V0TXV0YXRpb25UeXBlKCkpICE9PSBudWxsICYmIF9yZWYgIT09IHZvaWQgMCA/IF9yZWYgOiBvbGRTY2hlbWEgPT09IG51bGwgfHwgb2xkU2NoZW1hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBvbGRTY2hlbWEuZ2V0U3Vic2NyaXB0aW9uVHlwZSgpO1xuICBsZXQgc2NoZW1hRGVmaW5pdGlvbnNDb3VudCA9IDA7XG4gIHJldHVybiB7XG4gICAgU2NoZW1hRGVmaW5pdGlvbihub2RlKSB7XG4gICAgICBpZiAoYWxyZWFkeURlZmluZWQpIHtcbiAgICAgICAgY29udGV4dC5yZXBvcnRFcnJvcihcbiAgICAgICAgICBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICAgICAgXCJDYW5ub3QgZGVmaW5lIGEgbmV3IHNjaGVtYSB3aXRoaW4gYSBzY2hlbWEgZXh0ZW5zaW9uLlwiLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBub2Rlczogbm9kZVxuICAgICAgICAgICAgfVxuICAgICAgICAgIClcbiAgICAgICAgKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKHNjaGVtYURlZmluaXRpb25zQ291bnQgPiAwKSB7XG4gICAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihcIk11c3QgcHJvdmlkZSBvbmx5IG9uZSBzY2hlbWEgZGVmaW5pdGlvbi5cIiwge1xuICAgICAgICAgICAgbm9kZXM6IG5vZGVcbiAgICAgICAgICB9KVxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgKytzY2hlbWFEZWZpbml0aW9uc0NvdW50O1xuICAgIH1cbiAgfTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL3ZhbGlkYXRpb24vcnVsZXMvTm9GcmFnbWVudEN5Y2xlc1J1bGUubWpzXG5mdW5jdGlvbiBOb0ZyYWdtZW50Q3ljbGVzUnVsZShjb250ZXh0KSB7XG4gIGNvbnN0IHZpc2l0ZWRGcmFncyA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICBjb25zdCBzcHJlYWRQYXRoID0gW107XG4gIGNvbnN0IHNwcmVhZFBhdGhJbmRleEJ5TmFtZSA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICByZXR1cm4ge1xuICAgIE9wZXJhdGlvbkRlZmluaXRpb246ICgpID0+IGZhbHNlLFxuICAgIEZyYWdtZW50RGVmaW5pdGlvbihub2RlKSB7XG4gICAgICBkZXRlY3RDeWNsZVJlY3Vyc2l2ZShub2RlKTtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH07XG4gIGZ1bmN0aW9uIGRldGVjdEN5Y2xlUmVjdXJzaXZlKGZyYWdtZW50KSB7XG4gICAgaWYgKHZpc2l0ZWRGcmFnc1tmcmFnbWVudC5uYW1lLnZhbHVlXSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBmcmFnbWVudE5hbWUgPSBmcmFnbWVudC5uYW1lLnZhbHVlO1xuICAgIHZpc2l0ZWRGcmFnc1tmcmFnbWVudE5hbWVdID0gdHJ1ZTtcbiAgICBjb25zdCBzcHJlYWROb2RlcyA9IGNvbnRleHQuZ2V0RnJhZ21lbnRTcHJlYWRzKGZyYWdtZW50LnNlbGVjdGlvblNldCk7XG4gICAgaWYgKHNwcmVhZE5vZGVzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBzcHJlYWRQYXRoSW5kZXhCeU5hbWVbZnJhZ21lbnROYW1lXSA9IHNwcmVhZFBhdGgubGVuZ3RoO1xuICAgIGZvciAoY29uc3Qgc3ByZWFkTm9kZSBvZiBzcHJlYWROb2Rlcykge1xuICAgICAgY29uc3Qgc3ByZWFkTmFtZSA9IHNwcmVhZE5vZGUubmFtZS52YWx1ZTtcbiAgICAgIGNvbnN0IGN5Y2xlSW5kZXggPSBzcHJlYWRQYXRoSW5kZXhCeU5hbWVbc3ByZWFkTmFtZV07XG4gICAgICBzcHJlYWRQYXRoLnB1c2goc3ByZWFkTm9kZSk7XG4gICAgICBpZiAoY3ljbGVJbmRleCA9PT0gdm9pZCAwKSB7XG4gICAgICAgIGNvbnN0IHNwcmVhZEZyYWdtZW50ID0gY29udGV4dC5nZXRGcmFnbWVudChzcHJlYWROYW1lKTtcbiAgICAgICAgaWYgKHNwcmVhZEZyYWdtZW50KSB7XG4gICAgICAgICAgZGV0ZWN0Q3ljbGVSZWN1cnNpdmUoc3ByZWFkRnJhZ21lbnQpO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zdCBjeWNsZVBhdGggPSBzcHJlYWRQYXRoLnNsaWNlKGN5Y2xlSW5kZXgpO1xuICAgICAgICBjb25zdCB2aWFQYXRoID0gY3ljbGVQYXRoLnNsaWNlKDAsIC0xKS5tYXAoKHMpID0+ICdcIicgKyBzLm5hbWUudmFsdWUgKyAnXCInKS5qb2luKFwiLCBcIik7XG4gICAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgICAgIGBDYW5ub3Qgc3ByZWFkIGZyYWdtZW50IFwiJHtzcHJlYWROYW1lfVwiIHdpdGhpbiBpdHNlbGZgICsgKHZpYVBhdGggIT09IFwiXCIgPyBgIHZpYSAke3ZpYVBhdGh9LmAgOiBcIi5cIiksXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5vZGVzOiBjeWNsZVBhdGhcbiAgICAgICAgICAgIH1cbiAgICAgICAgICApXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBzcHJlYWRQYXRoLnBvcCgpO1xuICAgIH1cbiAgICBzcHJlYWRQYXRoSW5kZXhCeU5hbWVbZnJhZ21lbnROYW1lXSA9IHZvaWQgMDtcbiAgfVxufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdmFsaWRhdGlvbi9ydWxlcy9Ob1VuZGVmaW5lZFZhcmlhYmxlc1J1bGUubWpzXG5mdW5jdGlvbiBOb1VuZGVmaW5lZFZhcmlhYmxlc1J1bGUoY29udGV4dCkge1xuICBsZXQgdmFyaWFibGVOYW1lRGVmaW5lZCA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICByZXR1cm4ge1xuICAgIE9wZXJhdGlvbkRlZmluaXRpb246IHtcbiAgICAgIGVudGVyKCkge1xuICAgICAgICB2YXJpYWJsZU5hbWVEZWZpbmVkID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgICB9LFxuICAgICAgbGVhdmUob3BlcmF0aW9uKSB7XG4gICAgICAgIGNvbnN0IHVzYWdlcyA9IGNvbnRleHQuZ2V0UmVjdXJzaXZlVmFyaWFibGVVc2FnZXMob3BlcmF0aW9uKTtcbiAgICAgICAgZm9yIChjb25zdCB7IG5vZGUgfSBvZiB1c2FnZXMpIHtcbiAgICAgICAgICBjb25zdCB2YXJOYW1lID0gbm9kZS5uYW1lLnZhbHVlO1xuICAgICAgICAgIGlmICh2YXJpYWJsZU5hbWVEZWZpbmVkW3Zhck5hbWVdICE9PSB0cnVlKSB7XG4gICAgICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgICAgICBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICAgICAgICAgIG9wZXJhdGlvbi5uYW1lID8gYFZhcmlhYmxlIFwiJCR7dmFyTmFtZX1cIiBpcyBub3QgZGVmaW5lZCBieSBvcGVyYXRpb24gXCIke29wZXJhdGlvbi5uYW1lLnZhbHVlfVwiLmAgOiBgVmFyaWFibGUgXCIkJHt2YXJOYW1lfVwiIGlzIG5vdCBkZWZpbmVkLmAsXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgbm9kZXM6IFtub2RlLCBvcGVyYXRpb25dXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICApXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gICAgVmFyaWFibGVEZWZpbml0aW9uKG5vZGUpIHtcbiAgICAgIHZhcmlhYmxlTmFtZURlZmluZWRbbm9kZS52YXJpYWJsZS5uYW1lLnZhbHVlXSA9IHRydWU7XG4gICAgfVxuICB9O1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdmFsaWRhdGlvbi9ydWxlcy9Ob1VudXNlZEZyYWdtZW50c1J1bGUubWpzXG5mdW5jdGlvbiBOb1VudXNlZEZyYWdtZW50c1J1bGUoY29udGV4dCkge1xuICBjb25zdCBvcGVyYXRpb25EZWZzID0gW107XG4gIGNvbnN0IGZyYWdtZW50RGVmcyA9IFtdO1xuICByZXR1cm4ge1xuICAgIE9wZXJhdGlvbkRlZmluaXRpb24obm9kZSkge1xuICAgICAgb3BlcmF0aW9uRGVmcy5wdXNoKG5vZGUpO1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH0sXG4gICAgRnJhZ21lbnREZWZpbml0aW9uKG5vZGUpIHtcbiAgICAgIGZyYWdtZW50RGVmcy5wdXNoKG5vZGUpO1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH0sXG4gICAgRG9jdW1lbnQ6IHtcbiAgICAgIGxlYXZlKCkge1xuICAgICAgICBjb25zdCBmcmFnbWVudE5hbWVVc2VkID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgICAgIGZvciAoY29uc3Qgb3BlcmF0aW9uIG9mIG9wZXJhdGlvbkRlZnMpIHtcbiAgICAgICAgICBmb3IgKGNvbnN0IGZyYWdtZW50IG9mIGNvbnRleHQuZ2V0UmVjdXJzaXZlbHlSZWZlcmVuY2VkRnJhZ21lbnRzKFxuICAgICAgICAgICAgb3BlcmF0aW9uXG4gICAgICAgICAgKSkge1xuICAgICAgICAgICAgZnJhZ21lbnROYW1lVXNlZFtmcmFnbWVudC5uYW1lLnZhbHVlXSA9IHRydWU7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGZvciAoY29uc3QgZnJhZ21lbnREZWYgb2YgZnJhZ21lbnREZWZzKSB7XG4gICAgICAgICAgY29uc3QgZnJhZ05hbWUgPSBmcmFnbWVudERlZi5uYW1lLnZhbHVlO1xuICAgICAgICAgIGlmIChmcmFnbWVudE5hbWVVc2VkW2ZyYWdOYW1lXSAhPT0gdHJ1ZSkge1xuICAgICAgICAgICAgY29udGV4dC5yZXBvcnRFcnJvcihcbiAgICAgICAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihgRnJhZ21lbnQgXCIke2ZyYWdOYW1lfVwiIGlzIG5ldmVyIHVzZWQuYCwge1xuICAgICAgICAgICAgICAgIG5vZGVzOiBmcmFnbWVudERlZlxuICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH07XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC92YWxpZGF0aW9uL3J1bGVzL05vVW51c2VkVmFyaWFibGVzUnVsZS5tanNcbmZ1bmN0aW9uIE5vVW51c2VkVmFyaWFibGVzUnVsZShjb250ZXh0KSB7XG4gIGxldCB2YXJpYWJsZURlZnMgPSBbXTtcbiAgcmV0dXJuIHtcbiAgICBPcGVyYXRpb25EZWZpbml0aW9uOiB7XG4gICAgICBlbnRlcigpIHtcbiAgICAgICAgdmFyaWFibGVEZWZzID0gW107XG4gICAgICB9LFxuICAgICAgbGVhdmUob3BlcmF0aW9uKSB7XG4gICAgICAgIGNvbnN0IHZhcmlhYmxlTmFtZVVzZWQgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICAgICAgY29uc3QgdXNhZ2VzID0gY29udGV4dC5nZXRSZWN1cnNpdmVWYXJpYWJsZVVzYWdlcyhvcGVyYXRpb24pO1xuICAgICAgICBmb3IgKGNvbnN0IHsgbm9kZSB9IG9mIHVzYWdlcykge1xuICAgICAgICAgIHZhcmlhYmxlTmFtZVVzZWRbbm9kZS5uYW1lLnZhbHVlXSA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChjb25zdCB2YXJpYWJsZURlZiBvZiB2YXJpYWJsZURlZnMpIHtcbiAgICAgICAgICBjb25zdCB2YXJpYWJsZU5hbWUgPSB2YXJpYWJsZURlZi52YXJpYWJsZS5uYW1lLnZhbHVlO1xuICAgICAgICAgIGlmICh2YXJpYWJsZU5hbWVVc2VkW3ZhcmlhYmxlTmFtZV0gIT09IHRydWUpIHtcbiAgICAgICAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgICAgICAgICAgb3BlcmF0aW9uLm5hbWUgPyBgVmFyaWFibGUgXCIkJHt2YXJpYWJsZU5hbWV9XCIgaXMgbmV2ZXIgdXNlZCBpbiBvcGVyYXRpb24gXCIke29wZXJhdGlvbi5uYW1lLnZhbHVlfVwiLmAgOiBgVmFyaWFibGUgXCIkJHt2YXJpYWJsZU5hbWV9XCIgaXMgbmV2ZXIgdXNlZC5gLFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgIG5vZGVzOiB2YXJpYWJsZURlZlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9LFxuICAgIFZhcmlhYmxlRGVmaW5pdGlvbihkZWYpIHtcbiAgICAgIHZhcmlhYmxlRGVmcy5wdXNoKGRlZik7XG4gICAgfVxuICB9O1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdXRpbGl0aWVzL3NvcnRWYWx1ZU5vZGUubWpzXG5mdW5jdGlvbiBzb3J0VmFsdWVOb2RlKHZhbHVlTm9kZSkge1xuICBzd2l0Y2ggKHZhbHVlTm9kZS5raW5kKSB7XG4gICAgY2FzZSBLaW5kLk9CSkVDVDpcbiAgICAgIHJldHVybiB7IC4uLnZhbHVlTm9kZSwgZmllbGRzOiBzb3J0RmllbGRzKHZhbHVlTm9kZS5maWVsZHMpIH07XG4gICAgY2FzZSBLaW5kLkxJU1Q6XG4gICAgICByZXR1cm4geyAuLi52YWx1ZU5vZGUsIHZhbHVlczogdmFsdWVOb2RlLnZhbHVlcy5tYXAoc29ydFZhbHVlTm9kZSkgfTtcbiAgICBjYXNlIEtpbmQuSU5UOlxuICAgIGNhc2UgS2luZC5GTE9BVDpcbiAgICBjYXNlIEtpbmQuU1RSSU5HOlxuICAgIGNhc2UgS2luZC5CT09MRUFOOlxuICAgIGNhc2UgS2luZC5OVUxMOlxuICAgIGNhc2UgS2luZC5FTlVNOlxuICAgIGNhc2UgS2luZC5WQVJJQUJMRTpcbiAgICAgIHJldHVybiB2YWx1ZU5vZGU7XG4gIH1cbn1cbmZ1bmN0aW9uIHNvcnRGaWVsZHMoZmllbGRzKSB7XG4gIHJldHVybiBmaWVsZHMubWFwKChmaWVsZE5vZGUpID0+ICh7XG4gICAgLi4uZmllbGROb2RlLFxuICAgIHZhbHVlOiBzb3J0VmFsdWVOb2RlKGZpZWxkTm9kZS52YWx1ZSlcbiAgfSkpLnNvcnQoXG4gICAgKGZpZWxkQSwgZmllbGRCKSA9PiBuYXR1cmFsQ29tcGFyZShmaWVsZEEubmFtZS52YWx1ZSwgZmllbGRCLm5hbWUudmFsdWUpXG4gICk7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC92YWxpZGF0aW9uL3J1bGVzL092ZXJsYXBwaW5nRmllbGRzQ2FuQmVNZXJnZWRSdWxlLm1qc1xuZnVuY3Rpb24gcmVhc29uTWVzc2FnZShyZWFzb24pIHtcbiAgaWYgKEFycmF5LmlzQXJyYXkocmVhc29uKSkge1xuICAgIHJldHVybiByZWFzb24ubWFwKFxuICAgICAgKFtyZXNwb25zZU5hbWUsIHN1YlJlYXNvbl0pID0+IGBzdWJmaWVsZHMgXCIke3Jlc3BvbnNlTmFtZX1cIiBjb25mbGljdCBiZWNhdXNlIGAgKyByZWFzb25NZXNzYWdlKHN1YlJlYXNvbilcbiAgICApLmpvaW4oXCIgYW5kIFwiKTtcbiAgfVxuICByZXR1cm4gcmVhc29uO1xufVxuZnVuY3Rpb24gT3ZlcmxhcHBpbmdGaWVsZHNDYW5CZU1lcmdlZFJ1bGUoY29udGV4dCkge1xuICBjb25zdCBjb21wYXJlZEZyYWdtZW50UGFpcnMgPSBuZXcgUGFpclNldCgpO1xuICBjb25zdCBjYWNoZWRGaWVsZHNBbmRGcmFnbWVudE5hbWVzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcbiAgcmV0dXJuIHtcbiAgICBTZWxlY3Rpb25TZXQoc2VsZWN0aW9uU2V0KSB7XG4gICAgICBjb25zdCBjb25mbGljdHMgPSBmaW5kQ29uZmxpY3RzV2l0aGluU2VsZWN0aW9uU2V0KFxuICAgICAgICBjb250ZXh0LFxuICAgICAgICBjYWNoZWRGaWVsZHNBbmRGcmFnbWVudE5hbWVzLFxuICAgICAgICBjb21wYXJlZEZyYWdtZW50UGFpcnMsXG4gICAgICAgIGNvbnRleHQuZ2V0UGFyZW50VHlwZSgpLFxuICAgICAgICBzZWxlY3Rpb25TZXRcbiAgICAgICk7XG4gICAgICBmb3IgKGNvbnN0IFtbcmVzcG9uc2VOYW1lLCByZWFzb25dLCBmaWVsZHMxLCBmaWVsZHMyXSBvZiBjb25mbGljdHMpIHtcbiAgICAgICAgY29uc3QgcmVhc29uTXNnID0gcmVhc29uTWVzc2FnZShyZWFzb24pO1xuICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgICAgICBgRmllbGRzIFwiJHtyZXNwb25zZU5hbWV9XCIgY29uZmxpY3QgYmVjYXVzZSAke3JlYXNvbk1zZ30uIFVzZSBkaWZmZXJlbnQgYWxpYXNlcyBvbiB0aGUgZmllbGRzIHRvIGZldGNoIGJvdGggaWYgdGhpcyB3YXMgaW50ZW50aW9uYWwuYCxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbm9kZXM6IGZpZWxkczEuY29uY2F0KGZpZWxkczIpXG4gICAgICAgICAgICB9XG4gICAgICAgICAgKVxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cbiAgfTtcbn1cbmZ1bmN0aW9uIGZpbmRDb25mbGljdHNXaXRoaW5TZWxlY3Rpb25TZXQoY29udGV4dCwgY2FjaGVkRmllbGRzQW5kRnJhZ21lbnROYW1lcywgY29tcGFyZWRGcmFnbWVudFBhaXJzLCBwYXJlbnRUeXBlLCBzZWxlY3Rpb25TZXQpIHtcbiAgY29uc3QgY29uZmxpY3RzID0gW107XG4gIGNvbnN0IFtmaWVsZE1hcCwgZnJhZ21lbnROYW1lc10gPSBnZXRGaWVsZHNBbmRGcmFnbWVudE5hbWVzKFxuICAgIGNvbnRleHQsXG4gICAgY2FjaGVkRmllbGRzQW5kRnJhZ21lbnROYW1lcyxcbiAgICBwYXJlbnRUeXBlLFxuICAgIHNlbGVjdGlvblNldFxuICApO1xuICBjb2xsZWN0Q29uZmxpY3RzV2l0aGluKFxuICAgIGNvbnRleHQsXG4gICAgY29uZmxpY3RzLFxuICAgIGNhY2hlZEZpZWxkc0FuZEZyYWdtZW50TmFtZXMsXG4gICAgY29tcGFyZWRGcmFnbWVudFBhaXJzLFxuICAgIGZpZWxkTWFwXG4gICk7XG4gIGlmIChmcmFnbWVudE5hbWVzLmxlbmd0aCAhPT0gMCkge1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZnJhZ21lbnROYW1lcy5sZW5ndGg7IGkrKykge1xuICAgICAgY29sbGVjdENvbmZsaWN0c0JldHdlZW5GaWVsZHNBbmRGcmFnbWVudChcbiAgICAgICAgY29udGV4dCxcbiAgICAgICAgY29uZmxpY3RzLFxuICAgICAgICBjYWNoZWRGaWVsZHNBbmRGcmFnbWVudE5hbWVzLFxuICAgICAgICBjb21wYXJlZEZyYWdtZW50UGFpcnMsXG4gICAgICAgIGZhbHNlLFxuICAgICAgICBmaWVsZE1hcCxcbiAgICAgICAgZnJhZ21lbnROYW1lc1tpXVxuICAgICAgKTtcbiAgICAgIGZvciAobGV0IGogPSBpICsgMTsgaiA8IGZyYWdtZW50TmFtZXMubGVuZ3RoOyBqKyspIHtcbiAgICAgICAgY29sbGVjdENvbmZsaWN0c0JldHdlZW5GcmFnbWVudHMoXG4gICAgICAgICAgY29udGV4dCxcbiAgICAgICAgICBjb25mbGljdHMsXG4gICAgICAgICAgY2FjaGVkRmllbGRzQW5kRnJhZ21lbnROYW1lcyxcbiAgICAgICAgICBjb21wYXJlZEZyYWdtZW50UGFpcnMsXG4gICAgICAgICAgZmFsc2UsXG4gICAgICAgICAgZnJhZ21lbnROYW1lc1tpXSxcbiAgICAgICAgICBmcmFnbWVudE5hbWVzW2pdXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHJldHVybiBjb25mbGljdHM7XG59XG5mdW5jdGlvbiBjb2xsZWN0Q29uZmxpY3RzQmV0d2VlbkZpZWxkc0FuZEZyYWdtZW50KGNvbnRleHQsIGNvbmZsaWN0cywgY2FjaGVkRmllbGRzQW5kRnJhZ21lbnROYW1lcywgY29tcGFyZWRGcmFnbWVudFBhaXJzLCBhcmVNdXR1YWxseUV4Y2x1c2l2ZSwgZmllbGRNYXAsIGZyYWdtZW50TmFtZSkge1xuICBjb25zdCBmcmFnbWVudCA9IGNvbnRleHQuZ2V0RnJhZ21lbnQoZnJhZ21lbnROYW1lKTtcbiAgaWYgKCFmcmFnbWVudCkge1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCBbZmllbGRNYXAyLCByZWZlcmVuY2VkRnJhZ21lbnROYW1lc10gPSBnZXRSZWZlcmVuY2VkRmllbGRzQW5kRnJhZ21lbnROYW1lcyhcbiAgICBjb250ZXh0LFxuICAgIGNhY2hlZEZpZWxkc0FuZEZyYWdtZW50TmFtZXMsXG4gICAgZnJhZ21lbnRcbiAgKTtcbiAgaWYgKGZpZWxkTWFwID09PSBmaWVsZE1hcDIpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgY29sbGVjdENvbmZsaWN0c0JldHdlZW4oXG4gICAgY29udGV4dCxcbiAgICBjb25mbGljdHMsXG4gICAgY2FjaGVkRmllbGRzQW5kRnJhZ21lbnROYW1lcyxcbiAgICBjb21wYXJlZEZyYWdtZW50UGFpcnMsXG4gICAgYXJlTXV0dWFsbHlFeGNsdXNpdmUsXG4gICAgZmllbGRNYXAsXG4gICAgZmllbGRNYXAyXG4gICk7XG4gIGZvciAoY29uc3QgcmVmZXJlbmNlZEZyYWdtZW50TmFtZSBvZiByZWZlcmVuY2VkRnJhZ21lbnROYW1lcykge1xuICAgIGlmIChjb21wYXJlZEZyYWdtZW50UGFpcnMuaGFzKFxuICAgICAgcmVmZXJlbmNlZEZyYWdtZW50TmFtZSxcbiAgICAgIGZyYWdtZW50TmFtZSxcbiAgICAgIGFyZU11dHVhbGx5RXhjbHVzaXZlXG4gICAgKSkge1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGNvbXBhcmVkRnJhZ21lbnRQYWlycy5hZGQoXG4gICAgICByZWZlcmVuY2VkRnJhZ21lbnROYW1lLFxuICAgICAgZnJhZ21lbnROYW1lLFxuICAgICAgYXJlTXV0dWFsbHlFeGNsdXNpdmVcbiAgICApO1xuICAgIGNvbGxlY3RDb25mbGljdHNCZXR3ZWVuRmllbGRzQW5kRnJhZ21lbnQoXG4gICAgICBjb250ZXh0LFxuICAgICAgY29uZmxpY3RzLFxuICAgICAgY2FjaGVkRmllbGRzQW5kRnJhZ21lbnROYW1lcyxcbiAgICAgIGNvbXBhcmVkRnJhZ21lbnRQYWlycyxcbiAgICAgIGFyZU11dHVhbGx5RXhjbHVzaXZlLFxuICAgICAgZmllbGRNYXAsXG4gICAgICByZWZlcmVuY2VkRnJhZ21lbnROYW1lXG4gICAgKTtcbiAgfVxufVxuZnVuY3Rpb24gY29sbGVjdENvbmZsaWN0c0JldHdlZW5GcmFnbWVudHMoY29udGV4dCwgY29uZmxpY3RzLCBjYWNoZWRGaWVsZHNBbmRGcmFnbWVudE5hbWVzLCBjb21wYXJlZEZyYWdtZW50UGFpcnMsIGFyZU11dHVhbGx5RXhjbHVzaXZlLCBmcmFnbWVudE5hbWUxLCBmcmFnbWVudE5hbWUyKSB7XG4gIGlmIChmcmFnbWVudE5hbWUxID09PSBmcmFnbWVudE5hbWUyKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmIChjb21wYXJlZEZyYWdtZW50UGFpcnMuaGFzKFxuICAgIGZyYWdtZW50TmFtZTEsXG4gICAgZnJhZ21lbnROYW1lMixcbiAgICBhcmVNdXR1YWxseUV4Y2x1c2l2ZVxuICApKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbXBhcmVkRnJhZ21lbnRQYWlycy5hZGQoZnJhZ21lbnROYW1lMSwgZnJhZ21lbnROYW1lMiwgYXJlTXV0dWFsbHlFeGNsdXNpdmUpO1xuICBjb25zdCBmcmFnbWVudDEgPSBjb250ZXh0LmdldEZyYWdtZW50KGZyYWdtZW50TmFtZTEpO1xuICBjb25zdCBmcmFnbWVudDIgPSBjb250ZXh0LmdldEZyYWdtZW50KGZyYWdtZW50TmFtZTIpO1xuICBpZiAoIWZyYWdtZW50MSB8fCAhZnJhZ21lbnQyKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IFtmaWVsZE1hcDEsIHJlZmVyZW5jZWRGcmFnbWVudE5hbWVzMV0gPSBnZXRSZWZlcmVuY2VkRmllbGRzQW5kRnJhZ21lbnROYW1lcyhcbiAgICBjb250ZXh0LFxuICAgIGNhY2hlZEZpZWxkc0FuZEZyYWdtZW50TmFtZXMsXG4gICAgZnJhZ21lbnQxXG4gICk7XG4gIGNvbnN0IFtmaWVsZE1hcDIsIHJlZmVyZW5jZWRGcmFnbWVudE5hbWVzMl0gPSBnZXRSZWZlcmVuY2VkRmllbGRzQW5kRnJhZ21lbnROYW1lcyhcbiAgICBjb250ZXh0LFxuICAgIGNhY2hlZEZpZWxkc0FuZEZyYWdtZW50TmFtZXMsXG4gICAgZnJhZ21lbnQyXG4gICk7XG4gIGNvbGxlY3RDb25mbGljdHNCZXR3ZWVuKFxuICAgIGNvbnRleHQsXG4gICAgY29uZmxpY3RzLFxuICAgIGNhY2hlZEZpZWxkc0FuZEZyYWdtZW50TmFtZXMsXG4gICAgY29tcGFyZWRGcmFnbWVudFBhaXJzLFxuICAgIGFyZU11dHVhbGx5RXhjbHVzaXZlLFxuICAgIGZpZWxkTWFwMSxcbiAgICBmaWVsZE1hcDJcbiAgKTtcbiAgZm9yIChjb25zdCByZWZlcmVuY2VkRnJhZ21lbnROYW1lMiBvZiByZWZlcmVuY2VkRnJhZ21lbnROYW1lczIpIHtcbiAgICBjb2xsZWN0Q29uZmxpY3RzQmV0d2VlbkZyYWdtZW50cyhcbiAgICAgIGNvbnRleHQsXG4gICAgICBjb25mbGljdHMsXG4gICAgICBjYWNoZWRGaWVsZHNBbmRGcmFnbWVudE5hbWVzLFxuICAgICAgY29tcGFyZWRGcmFnbWVudFBhaXJzLFxuICAgICAgYXJlTXV0dWFsbHlFeGNsdXNpdmUsXG4gICAgICBmcmFnbWVudE5hbWUxLFxuICAgICAgcmVmZXJlbmNlZEZyYWdtZW50TmFtZTJcbiAgICApO1xuICB9XG4gIGZvciAoY29uc3QgcmVmZXJlbmNlZEZyYWdtZW50TmFtZTEgb2YgcmVmZXJlbmNlZEZyYWdtZW50TmFtZXMxKSB7XG4gICAgY29sbGVjdENvbmZsaWN0c0JldHdlZW5GcmFnbWVudHMoXG4gICAgICBjb250ZXh0LFxuICAgICAgY29uZmxpY3RzLFxuICAgICAgY2FjaGVkRmllbGRzQW5kRnJhZ21lbnROYW1lcyxcbiAgICAgIGNvbXBhcmVkRnJhZ21lbnRQYWlycyxcbiAgICAgIGFyZU11dHVhbGx5RXhjbHVzaXZlLFxuICAgICAgcmVmZXJlbmNlZEZyYWdtZW50TmFtZTEsXG4gICAgICBmcmFnbWVudE5hbWUyXG4gICAgKTtcbiAgfVxufVxuZnVuY3Rpb24gZmluZENvbmZsaWN0c0JldHdlZW5TdWJTZWxlY3Rpb25TZXRzKGNvbnRleHQsIGNhY2hlZEZpZWxkc0FuZEZyYWdtZW50TmFtZXMsIGNvbXBhcmVkRnJhZ21lbnRQYWlycywgYXJlTXV0dWFsbHlFeGNsdXNpdmUsIHBhcmVudFR5cGUxLCBzZWxlY3Rpb25TZXQxLCBwYXJlbnRUeXBlMiwgc2VsZWN0aW9uU2V0Mikge1xuICBjb25zdCBjb25mbGljdHMgPSBbXTtcbiAgY29uc3QgW2ZpZWxkTWFwMSwgZnJhZ21lbnROYW1lczFdID0gZ2V0RmllbGRzQW5kRnJhZ21lbnROYW1lcyhcbiAgICBjb250ZXh0LFxuICAgIGNhY2hlZEZpZWxkc0FuZEZyYWdtZW50TmFtZXMsXG4gICAgcGFyZW50VHlwZTEsXG4gICAgc2VsZWN0aW9uU2V0MVxuICApO1xuICBjb25zdCBbZmllbGRNYXAyLCBmcmFnbWVudE5hbWVzMl0gPSBnZXRGaWVsZHNBbmRGcmFnbWVudE5hbWVzKFxuICAgIGNvbnRleHQsXG4gICAgY2FjaGVkRmllbGRzQW5kRnJhZ21lbnROYW1lcyxcbiAgICBwYXJlbnRUeXBlMixcbiAgICBzZWxlY3Rpb25TZXQyXG4gICk7XG4gIGNvbGxlY3RDb25mbGljdHNCZXR3ZWVuKFxuICAgIGNvbnRleHQsXG4gICAgY29uZmxpY3RzLFxuICAgIGNhY2hlZEZpZWxkc0FuZEZyYWdtZW50TmFtZXMsXG4gICAgY29tcGFyZWRGcmFnbWVudFBhaXJzLFxuICAgIGFyZU11dHVhbGx5RXhjbHVzaXZlLFxuICAgIGZpZWxkTWFwMSxcbiAgICBmaWVsZE1hcDJcbiAgKTtcbiAgZm9yIChjb25zdCBmcmFnbWVudE5hbWUyIG9mIGZyYWdtZW50TmFtZXMyKSB7XG4gICAgY29sbGVjdENvbmZsaWN0c0JldHdlZW5GaWVsZHNBbmRGcmFnbWVudChcbiAgICAgIGNvbnRleHQsXG4gICAgICBjb25mbGljdHMsXG4gICAgICBjYWNoZWRGaWVsZHNBbmRGcmFnbWVudE5hbWVzLFxuICAgICAgY29tcGFyZWRGcmFnbWVudFBhaXJzLFxuICAgICAgYXJlTXV0dWFsbHlFeGNsdXNpdmUsXG4gICAgICBmaWVsZE1hcDEsXG4gICAgICBmcmFnbWVudE5hbWUyXG4gICAgKTtcbiAgfVxuICBmb3IgKGNvbnN0IGZyYWdtZW50TmFtZTEgb2YgZnJhZ21lbnROYW1lczEpIHtcbiAgICBjb2xsZWN0Q29uZmxpY3RzQmV0d2VlbkZpZWxkc0FuZEZyYWdtZW50KFxuICAgICAgY29udGV4dCxcbiAgICAgIGNvbmZsaWN0cyxcbiAgICAgIGNhY2hlZEZpZWxkc0FuZEZyYWdtZW50TmFtZXMsXG4gICAgICBjb21wYXJlZEZyYWdtZW50UGFpcnMsXG4gICAgICBhcmVNdXR1YWxseUV4Y2x1c2l2ZSxcbiAgICAgIGZpZWxkTWFwMixcbiAgICAgIGZyYWdtZW50TmFtZTFcbiAgICApO1xuICB9XG4gIGZvciAoY29uc3QgZnJhZ21lbnROYW1lMSBvZiBmcmFnbWVudE5hbWVzMSkge1xuICAgIGZvciAoY29uc3QgZnJhZ21lbnROYW1lMiBvZiBmcmFnbWVudE5hbWVzMikge1xuICAgICAgY29sbGVjdENvbmZsaWN0c0JldHdlZW5GcmFnbWVudHMoXG4gICAgICAgIGNvbnRleHQsXG4gICAgICAgIGNvbmZsaWN0cyxcbiAgICAgICAgY2FjaGVkRmllbGRzQW5kRnJhZ21lbnROYW1lcyxcbiAgICAgICAgY29tcGFyZWRGcmFnbWVudFBhaXJzLFxuICAgICAgICBhcmVNdXR1YWxseUV4Y2x1c2l2ZSxcbiAgICAgICAgZnJhZ21lbnROYW1lMSxcbiAgICAgICAgZnJhZ21lbnROYW1lMlxuICAgICAgKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGNvbmZsaWN0cztcbn1cbmZ1bmN0aW9uIGNvbGxlY3RDb25mbGljdHNXaXRoaW4oY29udGV4dCwgY29uZmxpY3RzLCBjYWNoZWRGaWVsZHNBbmRGcmFnbWVudE5hbWVzLCBjb21wYXJlZEZyYWdtZW50UGFpcnMsIGZpZWxkTWFwKSB7XG4gIGZvciAoY29uc3QgW3Jlc3BvbnNlTmFtZSwgZmllbGRzXSBvZiBPYmplY3QuZW50cmllcyhmaWVsZE1hcCkpIHtcbiAgICBpZiAoZmllbGRzLmxlbmd0aCA+IDEpIHtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZmllbGRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGZvciAobGV0IGogPSBpICsgMTsgaiA8IGZpZWxkcy5sZW5ndGg7IGorKykge1xuICAgICAgICAgIGNvbnN0IGNvbmZsaWN0ID0gZmluZENvbmZsaWN0KFxuICAgICAgICAgICAgY29udGV4dCxcbiAgICAgICAgICAgIGNhY2hlZEZpZWxkc0FuZEZyYWdtZW50TmFtZXMsXG4gICAgICAgICAgICBjb21wYXJlZEZyYWdtZW50UGFpcnMsXG4gICAgICAgICAgICBmYWxzZSxcbiAgICAgICAgICAgIC8vIHdpdGhpbiBvbmUgY29sbGVjdGlvbiBpcyBuZXZlciBtdXR1YWxseSBleGNsdXNpdmVcbiAgICAgICAgICAgIHJlc3BvbnNlTmFtZSxcbiAgICAgICAgICAgIGZpZWxkc1tpXSxcbiAgICAgICAgICAgIGZpZWxkc1tqXVxuICAgICAgICAgICk7XG4gICAgICAgICAgaWYgKGNvbmZsaWN0KSB7XG4gICAgICAgICAgICBjb25mbGljdHMucHVzaChjb25mbGljdCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG59XG5mdW5jdGlvbiBjb2xsZWN0Q29uZmxpY3RzQmV0d2Vlbihjb250ZXh0LCBjb25mbGljdHMsIGNhY2hlZEZpZWxkc0FuZEZyYWdtZW50TmFtZXMsIGNvbXBhcmVkRnJhZ21lbnRQYWlycywgcGFyZW50RmllbGRzQXJlTXV0dWFsbHlFeGNsdXNpdmUsIGZpZWxkTWFwMSwgZmllbGRNYXAyKSB7XG4gIGZvciAoY29uc3QgW3Jlc3BvbnNlTmFtZSwgZmllbGRzMV0gb2YgT2JqZWN0LmVudHJpZXMoZmllbGRNYXAxKSkge1xuICAgIGNvbnN0IGZpZWxkczIgPSBmaWVsZE1hcDJbcmVzcG9uc2VOYW1lXTtcbiAgICBpZiAoZmllbGRzMikge1xuICAgICAgZm9yIChjb25zdCBmaWVsZDEgb2YgZmllbGRzMSkge1xuICAgICAgICBmb3IgKGNvbnN0IGZpZWxkMiBvZiBmaWVsZHMyKSB7XG4gICAgICAgICAgY29uc3QgY29uZmxpY3QgPSBmaW5kQ29uZmxpY3QoXG4gICAgICAgICAgICBjb250ZXh0LFxuICAgICAgICAgICAgY2FjaGVkRmllbGRzQW5kRnJhZ21lbnROYW1lcyxcbiAgICAgICAgICAgIGNvbXBhcmVkRnJhZ21lbnRQYWlycyxcbiAgICAgICAgICAgIHBhcmVudEZpZWxkc0FyZU11dHVhbGx5RXhjbHVzaXZlLFxuICAgICAgICAgICAgcmVzcG9uc2VOYW1lLFxuICAgICAgICAgICAgZmllbGQxLFxuICAgICAgICAgICAgZmllbGQyXG4gICAgICAgICAgKTtcbiAgICAgICAgICBpZiAoY29uZmxpY3QpIHtcbiAgICAgICAgICAgIGNvbmZsaWN0cy5wdXNoKGNvbmZsaWN0KTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cbmZ1bmN0aW9uIGZpbmRDb25mbGljdChjb250ZXh0LCBjYWNoZWRGaWVsZHNBbmRGcmFnbWVudE5hbWVzLCBjb21wYXJlZEZyYWdtZW50UGFpcnMsIHBhcmVudEZpZWxkc0FyZU11dHVhbGx5RXhjbHVzaXZlLCByZXNwb25zZU5hbWUsIGZpZWxkMSwgZmllbGQyKSB7XG4gIGNvbnN0IFtwYXJlbnRUeXBlMSwgbm9kZTEsIGRlZjFdID0gZmllbGQxO1xuICBjb25zdCBbcGFyZW50VHlwZTIsIG5vZGUyLCBkZWYyXSA9IGZpZWxkMjtcbiAgY29uc3QgYXJlTXV0dWFsbHlFeGNsdXNpdmUgPSBwYXJlbnRGaWVsZHNBcmVNdXR1YWxseUV4Y2x1c2l2ZSB8fCBwYXJlbnRUeXBlMSAhPT0gcGFyZW50VHlwZTIgJiYgaXNPYmplY3RUeXBlKHBhcmVudFR5cGUxKSAmJiBpc09iamVjdFR5cGUocGFyZW50VHlwZTIpO1xuICBpZiAoIWFyZU11dHVhbGx5RXhjbHVzaXZlKSB7XG4gICAgY29uc3QgbmFtZTEgPSBub2RlMS5uYW1lLnZhbHVlO1xuICAgIGNvbnN0IG5hbWUyID0gbm9kZTIubmFtZS52YWx1ZTtcbiAgICBpZiAobmFtZTEgIT09IG5hbWUyKSB7XG4gICAgICByZXR1cm4gW1xuICAgICAgICBbcmVzcG9uc2VOYW1lLCBgXCIke25hbWUxfVwiIGFuZCBcIiR7bmFtZTJ9XCIgYXJlIGRpZmZlcmVudCBmaWVsZHNgXSxcbiAgICAgICAgW25vZGUxXSxcbiAgICAgICAgW25vZGUyXVxuICAgICAgXTtcbiAgICB9XG4gICAgaWYgKCFzYW1lQXJndW1lbnRzKG5vZGUxLCBub2RlMikpIHtcbiAgICAgIHJldHVybiBbXG4gICAgICAgIFtyZXNwb25zZU5hbWUsIFwidGhleSBoYXZlIGRpZmZlcmluZyBhcmd1bWVudHNcIl0sXG4gICAgICAgIFtub2RlMV0sXG4gICAgICAgIFtub2RlMl1cbiAgICAgIF07XG4gICAgfVxuICB9XG4gIGNvbnN0IHR5cGUxID0gZGVmMSA9PT0gbnVsbCB8fCBkZWYxID09PSB2b2lkIDAgPyB2b2lkIDAgOiBkZWYxLnR5cGU7XG4gIGNvbnN0IHR5cGUyID0gZGVmMiA9PT0gbnVsbCB8fCBkZWYyID09PSB2b2lkIDAgPyB2b2lkIDAgOiBkZWYyLnR5cGU7XG4gIGlmICh0eXBlMSAmJiB0eXBlMiAmJiBkb1R5cGVzQ29uZmxpY3QodHlwZTEsIHR5cGUyKSkge1xuICAgIHJldHVybiBbXG4gICAgICBbXG4gICAgICAgIHJlc3BvbnNlTmFtZSxcbiAgICAgICAgYHRoZXkgcmV0dXJuIGNvbmZsaWN0aW5nIHR5cGVzIFwiJHtpbnNwZWN0KHR5cGUxKX1cIiBhbmQgXCIke2luc3BlY3QoXG4gICAgICAgICAgdHlwZTJcbiAgICAgICAgKX1cImBcbiAgICAgIF0sXG4gICAgICBbbm9kZTFdLFxuICAgICAgW25vZGUyXVxuICAgIF07XG4gIH1cbiAgY29uc3Qgc2VsZWN0aW9uU2V0MSA9IG5vZGUxLnNlbGVjdGlvblNldDtcbiAgY29uc3Qgc2VsZWN0aW9uU2V0MiA9IG5vZGUyLnNlbGVjdGlvblNldDtcbiAgaWYgKHNlbGVjdGlvblNldDEgJiYgc2VsZWN0aW9uU2V0Mikge1xuICAgIGNvbnN0IGNvbmZsaWN0cyA9IGZpbmRDb25mbGljdHNCZXR3ZWVuU3ViU2VsZWN0aW9uU2V0cyhcbiAgICAgIGNvbnRleHQsXG4gICAgICBjYWNoZWRGaWVsZHNBbmRGcmFnbWVudE5hbWVzLFxuICAgICAgY29tcGFyZWRGcmFnbWVudFBhaXJzLFxuICAgICAgYXJlTXV0dWFsbHlFeGNsdXNpdmUsXG4gICAgICBnZXROYW1lZFR5cGUodHlwZTEpLFxuICAgICAgc2VsZWN0aW9uU2V0MSxcbiAgICAgIGdldE5hbWVkVHlwZSh0eXBlMiksXG4gICAgICBzZWxlY3Rpb25TZXQyXG4gICAgKTtcbiAgICByZXR1cm4gc3ViZmllbGRDb25mbGljdHMoY29uZmxpY3RzLCByZXNwb25zZU5hbWUsIG5vZGUxLCBub2RlMik7XG4gIH1cbn1cbmZ1bmN0aW9uIHNhbWVBcmd1bWVudHMobm9kZTEsIG5vZGUyKSB7XG4gIGNvbnN0IGFyZ3MxID0gbm9kZTEuYXJndW1lbnRzO1xuICBjb25zdCBhcmdzMiA9IG5vZGUyLmFyZ3VtZW50cztcbiAgaWYgKGFyZ3MxID09PSB2b2lkIDAgfHwgYXJnczEubGVuZ3RoID09PSAwKSB7XG4gICAgcmV0dXJuIGFyZ3MyID09PSB2b2lkIDAgfHwgYXJnczIubGVuZ3RoID09PSAwO1xuICB9XG4gIGlmIChhcmdzMiA9PT0gdm9pZCAwIHx8IGFyZ3MyLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBpZiAoYXJnczEubGVuZ3RoICE9PSBhcmdzMi5sZW5ndGgpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgY29uc3QgdmFsdWVzMiA9IG5ldyBNYXAoYXJnczIubWFwKCh7IG5hbWUsIHZhbHVlIH0pID0+IFtuYW1lLnZhbHVlLCB2YWx1ZV0pKTtcbiAgcmV0dXJuIGFyZ3MxLmV2ZXJ5KChhcmcxKSA9PiB7XG4gICAgY29uc3QgdmFsdWUxID0gYXJnMS52YWx1ZTtcbiAgICBjb25zdCB2YWx1ZTIgPSB2YWx1ZXMyLmdldChhcmcxLm5hbWUudmFsdWUpO1xuICAgIGlmICh2YWx1ZTIgPT09IHZvaWQgMCkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICByZXR1cm4gc3RyaW5naWZ5VmFsdWUodmFsdWUxKSA9PT0gc3RyaW5naWZ5VmFsdWUodmFsdWUyKTtcbiAgfSk7XG59XG5mdW5jdGlvbiBzdHJpbmdpZnlWYWx1ZSh2YWx1ZSkge1xuICByZXR1cm4gcHJpbnQoc29ydFZhbHVlTm9kZSh2YWx1ZSkpO1xufVxuZnVuY3Rpb24gZG9UeXBlc0NvbmZsaWN0KHR5cGUxLCB0eXBlMikge1xuICBpZiAoaXNMaXN0VHlwZSh0eXBlMSkpIHtcbiAgICByZXR1cm4gaXNMaXN0VHlwZSh0eXBlMikgPyBkb1R5cGVzQ29uZmxpY3QodHlwZTEub2ZUeXBlLCB0eXBlMi5vZlR5cGUpIDogdHJ1ZTtcbiAgfVxuICBpZiAoaXNMaXN0VHlwZSh0eXBlMikpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBpZiAoaXNOb25OdWxsVHlwZSh0eXBlMSkpIHtcbiAgICByZXR1cm4gaXNOb25OdWxsVHlwZSh0eXBlMikgPyBkb1R5cGVzQ29uZmxpY3QodHlwZTEub2ZUeXBlLCB0eXBlMi5vZlR5cGUpIDogdHJ1ZTtcbiAgfVxuICBpZiAoaXNOb25OdWxsVHlwZSh0eXBlMikpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBpZiAoaXNMZWFmVHlwZSh0eXBlMSkgfHwgaXNMZWFmVHlwZSh0eXBlMikpIHtcbiAgICByZXR1cm4gdHlwZTEgIT09IHR5cGUyO1xuICB9XG4gIHJldHVybiBmYWxzZTtcbn1cbmZ1bmN0aW9uIGdldEZpZWxkc0FuZEZyYWdtZW50TmFtZXMoY29udGV4dCwgY2FjaGVkRmllbGRzQW5kRnJhZ21lbnROYW1lcywgcGFyZW50VHlwZSwgc2VsZWN0aW9uU2V0KSB7XG4gIGNvbnN0IGNhY2hlZCA9IGNhY2hlZEZpZWxkc0FuZEZyYWdtZW50TmFtZXMuZ2V0KHNlbGVjdGlvblNldCk7XG4gIGlmIChjYWNoZWQpIHtcbiAgICByZXR1cm4gY2FjaGVkO1xuICB9XG4gIGNvbnN0IG5vZGVBbmREZWZzID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIGNvbnN0IGZyYWdtZW50TmFtZXMgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgX2NvbGxlY3RGaWVsZHNBbmRGcmFnbWVudE5hbWVzKFxuICAgIGNvbnRleHQsXG4gICAgcGFyZW50VHlwZSxcbiAgICBzZWxlY3Rpb25TZXQsXG4gICAgbm9kZUFuZERlZnMsXG4gICAgZnJhZ21lbnROYW1lc1xuICApO1xuICBjb25zdCByZXN1bHQgPSBbbm9kZUFuZERlZnMsIE9iamVjdC5rZXlzKGZyYWdtZW50TmFtZXMpXTtcbiAgY2FjaGVkRmllbGRzQW5kRnJhZ21lbnROYW1lcy5zZXQoc2VsZWN0aW9uU2V0LCByZXN1bHQpO1xuICByZXR1cm4gcmVzdWx0O1xufVxuZnVuY3Rpb24gZ2V0UmVmZXJlbmNlZEZpZWxkc0FuZEZyYWdtZW50TmFtZXMoY29udGV4dCwgY2FjaGVkRmllbGRzQW5kRnJhZ21lbnROYW1lcywgZnJhZ21lbnQpIHtcbiAgY29uc3QgY2FjaGVkID0gY2FjaGVkRmllbGRzQW5kRnJhZ21lbnROYW1lcy5nZXQoZnJhZ21lbnQuc2VsZWN0aW9uU2V0KTtcbiAgaWYgKGNhY2hlZCkge1xuICAgIHJldHVybiBjYWNoZWQ7XG4gIH1cbiAgY29uc3QgZnJhZ21lbnRUeXBlID0gdHlwZUZyb21BU1QoY29udGV4dC5nZXRTY2hlbWEoKSwgZnJhZ21lbnQudHlwZUNvbmRpdGlvbik7XG4gIHJldHVybiBnZXRGaWVsZHNBbmRGcmFnbWVudE5hbWVzKFxuICAgIGNvbnRleHQsXG4gICAgY2FjaGVkRmllbGRzQW5kRnJhZ21lbnROYW1lcyxcbiAgICBmcmFnbWVudFR5cGUsXG4gICAgZnJhZ21lbnQuc2VsZWN0aW9uU2V0XG4gICk7XG59XG5mdW5jdGlvbiBfY29sbGVjdEZpZWxkc0FuZEZyYWdtZW50TmFtZXMoY29udGV4dCwgcGFyZW50VHlwZSwgc2VsZWN0aW9uU2V0LCBub2RlQW5kRGVmcywgZnJhZ21lbnROYW1lcykge1xuICBmb3IgKGNvbnN0IHNlbGVjdGlvbiBvZiBzZWxlY3Rpb25TZXQuc2VsZWN0aW9ucykge1xuICAgIHN3aXRjaCAoc2VsZWN0aW9uLmtpbmQpIHtcbiAgICAgIGNhc2UgS2luZC5GSUVMRDoge1xuICAgICAgICBjb25zdCBmaWVsZE5hbWUgPSBzZWxlY3Rpb24ubmFtZS52YWx1ZTtcbiAgICAgICAgbGV0IGZpZWxkRGVmO1xuICAgICAgICBpZiAoaXNPYmplY3RUeXBlKHBhcmVudFR5cGUpIHx8IGlzSW50ZXJmYWNlVHlwZShwYXJlbnRUeXBlKSkge1xuICAgICAgICAgIGZpZWxkRGVmID0gcGFyZW50VHlwZS5nZXRGaWVsZHMoKVtmaWVsZE5hbWVdO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlTmFtZSA9IHNlbGVjdGlvbi5hbGlhcyA/IHNlbGVjdGlvbi5hbGlhcy52YWx1ZSA6IGZpZWxkTmFtZTtcbiAgICAgICAgaWYgKCFub2RlQW5kRGVmc1tyZXNwb25zZU5hbWVdKSB7XG4gICAgICAgICAgbm9kZUFuZERlZnNbcmVzcG9uc2VOYW1lXSA9IFtdO1xuICAgICAgICB9XG4gICAgICAgIG5vZGVBbmREZWZzW3Jlc3BvbnNlTmFtZV0ucHVzaChbcGFyZW50VHlwZSwgc2VsZWN0aW9uLCBmaWVsZERlZl0pO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICAgIGNhc2UgS2luZC5GUkFHTUVOVF9TUFJFQUQ6XG4gICAgICAgIGZyYWdtZW50TmFtZXNbc2VsZWN0aW9uLm5hbWUudmFsdWVdID0gdHJ1ZTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIEtpbmQuSU5MSU5FX0ZSQUdNRU5UOiB7XG4gICAgICAgIGNvbnN0IHR5cGVDb25kaXRpb24gPSBzZWxlY3Rpb24udHlwZUNvbmRpdGlvbjtcbiAgICAgICAgY29uc3QgaW5saW5lRnJhZ21lbnRUeXBlID0gdHlwZUNvbmRpdGlvbiA/IHR5cGVGcm9tQVNUKGNvbnRleHQuZ2V0U2NoZW1hKCksIHR5cGVDb25kaXRpb24pIDogcGFyZW50VHlwZTtcbiAgICAgICAgX2NvbGxlY3RGaWVsZHNBbmRGcmFnbWVudE5hbWVzKFxuICAgICAgICAgIGNvbnRleHQsXG4gICAgICAgICAgaW5saW5lRnJhZ21lbnRUeXBlLFxuICAgICAgICAgIHNlbGVjdGlvbi5zZWxlY3Rpb25TZXQsXG4gICAgICAgICAgbm9kZUFuZERlZnMsXG4gICAgICAgICAgZnJhZ21lbnROYW1lc1xuICAgICAgICApO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cbmZ1bmN0aW9uIHN1YmZpZWxkQ29uZmxpY3RzKGNvbmZsaWN0cywgcmVzcG9uc2VOYW1lLCBub2RlMSwgbm9kZTIpIHtcbiAgaWYgKGNvbmZsaWN0cy5sZW5ndGggPiAwKSB7XG4gICAgcmV0dXJuIFtcbiAgICAgIFtyZXNwb25zZU5hbWUsIGNvbmZsaWN0cy5tYXAoKFtyZWFzb25dKSA9PiByZWFzb24pXSxcbiAgICAgIFtub2RlMSwgLi4uY29uZmxpY3RzLm1hcCgoWywgZmllbGRzMV0pID0+IGZpZWxkczEpLmZsYXQoKV0sXG4gICAgICBbbm9kZTIsIC4uLmNvbmZsaWN0cy5tYXAoKFssICwgZmllbGRzMl0pID0+IGZpZWxkczIpLmZsYXQoKV1cbiAgICBdO1xuICB9XG59XG52YXIgUGFpclNldCA9IGNsYXNzIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgdGhpcy5fZGF0YSA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG4gIH1cbiAgaGFzKGEsIGIsIGFyZU11dHVhbGx5RXhjbHVzaXZlKSB7XG4gICAgdmFyIF90aGlzJF9kYXRhJGdldDtcbiAgICBjb25zdCBba2V5MSwga2V5Ml0gPSBhIDwgYiA/IFthLCBiXSA6IFtiLCBhXTtcbiAgICBjb25zdCByZXN1bHQgPSAoX3RoaXMkX2RhdGEkZ2V0ID0gdGhpcy5fZGF0YS5nZXQoa2V5MSkpID09PSBudWxsIHx8IF90aGlzJF9kYXRhJGdldCA9PT0gdm9pZCAwID8gdm9pZCAwIDogX3RoaXMkX2RhdGEkZ2V0LmdldChrZXkyKTtcbiAgICBpZiAocmVzdWx0ID09PSB2b2lkIDApIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgcmV0dXJuIGFyZU11dHVhbGx5RXhjbHVzaXZlID8gdHJ1ZSA6IGFyZU11dHVhbGx5RXhjbHVzaXZlID09PSByZXN1bHQ7XG4gIH1cbiAgYWRkKGEsIGIsIGFyZU11dHVhbGx5RXhjbHVzaXZlKSB7XG4gICAgY29uc3QgW2tleTEsIGtleTJdID0gYSA8IGIgPyBbYSwgYl0gOiBbYiwgYV07XG4gICAgY29uc3QgbWFwID0gdGhpcy5fZGF0YS5nZXQoa2V5MSk7XG4gICAgaWYgKG1hcCA9PT0gdm9pZCAwKSB7XG4gICAgICB0aGlzLl9kYXRhLnNldChrZXkxLCAvKiBAX19QVVJFX18gKi8gbmV3IE1hcChbW2tleTIsIGFyZU11dHVhbGx5RXhjbHVzaXZlXV0pKTtcbiAgICB9IGVsc2Uge1xuICAgICAgbWFwLnNldChrZXkyLCBhcmVNdXR1YWxseUV4Y2x1c2l2ZSk7XG4gICAgfVxuICB9XG59O1xuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdmFsaWRhdGlvbi9ydWxlcy9Qb3NzaWJsZUZyYWdtZW50U3ByZWFkc1J1bGUubWpzXG5mdW5jdGlvbiBQb3NzaWJsZUZyYWdtZW50U3ByZWFkc1J1bGUoY29udGV4dCkge1xuICByZXR1cm4ge1xuICAgIElubGluZUZyYWdtZW50KG5vZGUpIHtcbiAgICAgIGNvbnN0IGZyYWdUeXBlID0gY29udGV4dC5nZXRUeXBlKCk7XG4gICAgICBjb25zdCBwYXJlbnRUeXBlID0gY29udGV4dC5nZXRQYXJlbnRUeXBlKCk7XG4gICAgICBpZiAoaXNDb21wb3NpdGVUeXBlKGZyYWdUeXBlKSAmJiBpc0NvbXBvc2l0ZVR5cGUocGFyZW50VHlwZSkgJiYgIWRvVHlwZXNPdmVybGFwKGNvbnRleHQuZ2V0U2NoZW1hKCksIGZyYWdUeXBlLCBwYXJlbnRUeXBlKSkge1xuICAgICAgICBjb25zdCBwYXJlbnRUeXBlU3RyID0gaW5zcGVjdChwYXJlbnRUeXBlKTtcbiAgICAgICAgY29uc3QgZnJhZ1R5cGVTdHIgPSBpbnNwZWN0KGZyYWdUeXBlKTtcbiAgICAgICAgY29udGV4dC5yZXBvcnRFcnJvcihcbiAgICAgICAgICBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICAgICAgYEZyYWdtZW50IGNhbm5vdCBiZSBzcHJlYWQgaGVyZSBhcyBvYmplY3RzIG9mIHR5cGUgXCIke3BhcmVudFR5cGVTdHJ9XCIgY2FuIG5ldmVyIGJlIG9mIHR5cGUgXCIke2ZyYWdUeXBlU3RyfVwiLmAsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5vZGVzOiBub2RlXG4gICAgICAgICAgICB9XG4gICAgICAgICAgKVxuICAgICAgICApO1xuICAgICAgfVxuICAgIH0sXG4gICAgRnJhZ21lbnRTcHJlYWQobm9kZSkge1xuICAgICAgY29uc3QgZnJhZ05hbWUgPSBub2RlLm5hbWUudmFsdWU7XG4gICAgICBjb25zdCBmcmFnVHlwZSA9IGdldEZyYWdtZW50VHlwZShjb250ZXh0LCBmcmFnTmFtZSk7XG4gICAgICBjb25zdCBwYXJlbnRUeXBlID0gY29udGV4dC5nZXRQYXJlbnRUeXBlKCk7XG4gICAgICBpZiAoZnJhZ1R5cGUgJiYgcGFyZW50VHlwZSAmJiAhZG9UeXBlc092ZXJsYXAoY29udGV4dC5nZXRTY2hlbWEoKSwgZnJhZ1R5cGUsIHBhcmVudFR5cGUpKSB7XG4gICAgICAgIGNvbnN0IHBhcmVudFR5cGVTdHIgPSBpbnNwZWN0KHBhcmVudFR5cGUpO1xuICAgICAgICBjb25zdCBmcmFnVHlwZVN0ciA9IGluc3BlY3QoZnJhZ1R5cGUpO1xuICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgICAgICBgRnJhZ21lbnQgXCIke2ZyYWdOYW1lfVwiIGNhbm5vdCBiZSBzcHJlYWQgaGVyZSBhcyBvYmplY3RzIG9mIHR5cGUgXCIke3BhcmVudFR5cGVTdHJ9XCIgY2FuIG5ldmVyIGJlIG9mIHR5cGUgXCIke2ZyYWdUeXBlU3RyfVwiLmAsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5vZGVzOiBub2RlXG4gICAgICAgICAgICB9XG4gICAgICAgICAgKVxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cbiAgfTtcbn1cbmZ1bmN0aW9uIGdldEZyYWdtZW50VHlwZShjb250ZXh0LCBuYW1lKSB7XG4gIGNvbnN0IGZyYWcgPSBjb250ZXh0LmdldEZyYWdtZW50KG5hbWUpO1xuICBpZiAoZnJhZykge1xuICAgIGNvbnN0IHR5cGUgPSB0eXBlRnJvbUFTVChjb250ZXh0LmdldFNjaGVtYSgpLCBmcmFnLnR5cGVDb25kaXRpb24pO1xuICAgIGlmIChpc0NvbXBvc2l0ZVR5cGUodHlwZSkpIHtcbiAgICAgIHJldHVybiB0eXBlO1xuICAgIH1cbiAgfVxufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdmFsaWRhdGlvbi9ydWxlcy9Qb3NzaWJsZVR5cGVFeHRlbnNpb25zUnVsZS5tanNcbmZ1bmN0aW9uIFBvc3NpYmxlVHlwZUV4dGVuc2lvbnNSdWxlKGNvbnRleHQpIHtcbiAgY29uc3Qgc2NoZW1hID0gY29udGV4dC5nZXRTY2hlbWEoKTtcbiAgY29uc3QgZGVmaW5lZFR5cGVzID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIGZvciAoY29uc3QgZGVmIG9mIGNvbnRleHQuZ2V0RG9jdW1lbnQoKS5kZWZpbml0aW9ucykge1xuICAgIGlmIChpc1R5cGVEZWZpbml0aW9uTm9kZShkZWYpKSB7XG4gICAgICBkZWZpbmVkVHlwZXNbZGVmLm5hbWUudmFsdWVdID0gZGVmO1xuICAgIH1cbiAgfVxuICByZXR1cm4ge1xuICAgIFNjYWxhclR5cGVFeHRlbnNpb246IGNoZWNrRXh0ZW5zaW9uLFxuICAgIE9iamVjdFR5cGVFeHRlbnNpb246IGNoZWNrRXh0ZW5zaW9uLFxuICAgIEludGVyZmFjZVR5cGVFeHRlbnNpb246IGNoZWNrRXh0ZW5zaW9uLFxuICAgIFVuaW9uVHlwZUV4dGVuc2lvbjogY2hlY2tFeHRlbnNpb24sXG4gICAgRW51bVR5cGVFeHRlbnNpb246IGNoZWNrRXh0ZW5zaW9uLFxuICAgIElucHV0T2JqZWN0VHlwZUV4dGVuc2lvbjogY2hlY2tFeHRlbnNpb25cbiAgfTtcbiAgZnVuY3Rpb24gY2hlY2tFeHRlbnNpb24obm9kZSkge1xuICAgIGNvbnN0IHR5cGVOYW1lID0gbm9kZS5uYW1lLnZhbHVlO1xuICAgIGNvbnN0IGRlZk5vZGUgPSBkZWZpbmVkVHlwZXNbdHlwZU5hbWVdO1xuICAgIGNvbnN0IGV4aXN0aW5nVHlwZSA9IHNjaGVtYSA9PT0gbnVsbCB8fCBzY2hlbWEgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHNjaGVtYS5nZXRUeXBlKHR5cGVOYW1lKTtcbiAgICBsZXQgZXhwZWN0ZWRLaW5kO1xuICAgIGlmIChkZWZOb2RlKSB7XG4gICAgICBleHBlY3RlZEtpbmQgPSBkZWZLaW5kVG9FeHRLaW5kW2RlZk5vZGUua2luZF07XG4gICAgfSBlbHNlIGlmIChleGlzdGluZ1R5cGUpIHtcbiAgICAgIGV4cGVjdGVkS2luZCA9IHR5cGVUb0V4dEtpbmQoZXhpc3RpbmdUeXBlKTtcbiAgICB9XG4gICAgaWYgKGV4cGVjdGVkS2luZCkge1xuICAgICAgaWYgKGV4cGVjdGVkS2luZCAhPT0gbm9kZS5raW5kKSB7XG4gICAgICAgIGNvbnN0IGtpbmRTdHIgPSBleHRlbnNpb25LaW5kVG9UeXBlTmFtZShub2RlLmtpbmQpO1xuICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoYENhbm5vdCBleHRlbmQgbm9uLSR7a2luZFN0cn0gdHlwZSBcIiR7dHlwZU5hbWV9XCIuYCwge1xuICAgICAgICAgICAgbm9kZXM6IGRlZk5vZGUgPyBbZGVmTm9kZSwgbm9kZV0gOiBub2RlXG4gICAgICAgICAgfSlcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3QgYWxsVHlwZU5hbWVzID0gT2JqZWN0LmtleXMoe1xuICAgICAgICAuLi5kZWZpbmVkVHlwZXMsXG4gICAgICAgIC4uLnNjaGVtYSA9PT0gbnVsbCB8fCBzY2hlbWEgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHNjaGVtYS5nZXRUeXBlTWFwKClcbiAgICAgIH0pO1xuICAgICAgY29uc3Qgc3VnZ2VzdGVkVHlwZXMgPSBzdWdnZXN0aW9uTGlzdCh0eXBlTmFtZSwgYWxsVHlwZU5hbWVzKTtcbiAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgICAgYENhbm5vdCBleHRlbmQgdHlwZSBcIiR7dHlwZU5hbWV9XCIgYmVjYXVzZSBpdCBpcyBub3QgZGVmaW5lZC5gICsgZGlkWW91TWVhbihzdWdnZXN0ZWRUeXBlcyksXG4gICAgICAgICAge1xuICAgICAgICAgICAgbm9kZXM6IG5vZGUubmFtZVxuICAgICAgICAgIH1cbiAgICAgICAgKVxuICAgICAgKTtcbiAgICB9XG4gIH1cbn1cbnZhciBkZWZLaW5kVG9FeHRLaW5kID0ge1xuICBbS2luZC5TQ0FMQVJfVFlQRV9ERUZJTklUSU9OXTogS2luZC5TQ0FMQVJfVFlQRV9FWFRFTlNJT04sXG4gIFtLaW5kLk9CSkVDVF9UWVBFX0RFRklOSVRJT05dOiBLaW5kLk9CSkVDVF9UWVBFX0VYVEVOU0lPTixcbiAgW0tpbmQuSU5URVJGQUNFX1RZUEVfREVGSU5JVElPTl06IEtpbmQuSU5URVJGQUNFX1RZUEVfRVhURU5TSU9OLFxuICBbS2luZC5VTklPTl9UWVBFX0RFRklOSVRJT05dOiBLaW5kLlVOSU9OX1RZUEVfRVhURU5TSU9OLFxuICBbS2luZC5FTlVNX1RZUEVfREVGSU5JVElPTl06IEtpbmQuRU5VTV9UWVBFX0VYVEVOU0lPTixcbiAgW0tpbmQuSU5QVVRfT0JKRUNUX1RZUEVfREVGSU5JVElPTl06IEtpbmQuSU5QVVRfT0JKRUNUX1RZUEVfRVhURU5TSU9OXG59O1xuZnVuY3Rpb24gdHlwZVRvRXh0S2luZCh0eXBlKSB7XG4gIGlmIChpc1NjYWxhclR5cGUodHlwZSkpIHtcbiAgICByZXR1cm4gS2luZC5TQ0FMQVJfVFlQRV9FWFRFTlNJT047XG4gIH1cbiAgaWYgKGlzT2JqZWN0VHlwZSh0eXBlKSkge1xuICAgIHJldHVybiBLaW5kLk9CSkVDVF9UWVBFX0VYVEVOU0lPTjtcbiAgfVxuICBpZiAoaXNJbnRlcmZhY2VUeXBlKHR5cGUpKSB7XG4gICAgcmV0dXJuIEtpbmQuSU5URVJGQUNFX1RZUEVfRVhURU5TSU9OO1xuICB9XG4gIGlmIChpc1VuaW9uVHlwZSh0eXBlKSkge1xuICAgIHJldHVybiBLaW5kLlVOSU9OX1RZUEVfRVhURU5TSU9OO1xuICB9XG4gIGlmIChpc0VudW1UeXBlKHR5cGUpKSB7XG4gICAgcmV0dXJuIEtpbmQuRU5VTV9UWVBFX0VYVEVOU0lPTjtcbiAgfVxuICBpZiAoaXNJbnB1dE9iamVjdFR5cGUodHlwZSkpIHtcbiAgICByZXR1cm4gS2luZC5JTlBVVF9PQkpFQ1RfVFlQRV9FWFRFTlNJT047XG4gIH1cbiAgaW52YXJpYW50MihmYWxzZSwgXCJVbmV4cGVjdGVkIHR5cGU6IFwiICsgaW5zcGVjdCh0eXBlKSk7XG59XG5mdW5jdGlvbiBleHRlbnNpb25LaW5kVG9UeXBlTmFtZShraW5kKSB7XG4gIHN3aXRjaCAoa2luZCkge1xuICAgIGNhc2UgS2luZC5TQ0FMQVJfVFlQRV9FWFRFTlNJT046XG4gICAgICByZXR1cm4gXCJzY2FsYXJcIjtcbiAgICBjYXNlIEtpbmQuT0JKRUNUX1RZUEVfRVhURU5TSU9OOlxuICAgICAgcmV0dXJuIFwib2JqZWN0XCI7XG4gICAgY2FzZSBLaW5kLklOVEVSRkFDRV9UWVBFX0VYVEVOU0lPTjpcbiAgICAgIHJldHVybiBcImludGVyZmFjZVwiO1xuICAgIGNhc2UgS2luZC5VTklPTl9UWVBFX0VYVEVOU0lPTjpcbiAgICAgIHJldHVybiBcInVuaW9uXCI7XG4gICAgY2FzZSBLaW5kLkVOVU1fVFlQRV9FWFRFTlNJT046XG4gICAgICByZXR1cm4gXCJlbnVtXCI7XG4gICAgY2FzZSBLaW5kLklOUFVUX09CSkVDVF9UWVBFX0VYVEVOU0lPTjpcbiAgICAgIHJldHVybiBcImlucHV0IG9iamVjdFwiO1xuICAgIGRlZmF1bHQ6XG4gICAgICBpbnZhcmlhbnQyKGZhbHNlLCBcIlVuZXhwZWN0ZWQga2luZDogXCIgKyBpbnNwZWN0KGtpbmQpKTtcbiAgfVxufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdmFsaWRhdGlvbi9ydWxlcy9Qcm92aWRlZFJlcXVpcmVkQXJndW1lbnRzUnVsZS5tanNcbmZ1bmN0aW9uIFByb3ZpZGVkUmVxdWlyZWRBcmd1bWVudHNSdWxlKGNvbnRleHQpIHtcbiAgcmV0dXJuIHtcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbmV3LWNhcFxuICAgIC4uLlByb3ZpZGVkUmVxdWlyZWRBcmd1bWVudHNPbkRpcmVjdGl2ZXNSdWxlKGNvbnRleHQpLFxuICAgIEZpZWxkOiB7XG4gICAgICAvLyBWYWxpZGF0ZSBvbiBsZWF2ZSB0byBhbGxvdyBmb3IgZGVlcGVyIGVycm9ycyB0byBhcHBlYXIgZmlyc3QuXG4gICAgICBsZWF2ZShmaWVsZE5vZGUpIHtcbiAgICAgICAgdmFyIF9maWVsZE5vZGUkYXJndW1lbnRzO1xuICAgICAgICBjb25zdCBmaWVsZERlZiA9IGNvbnRleHQuZ2V0RmllbGREZWYoKTtcbiAgICAgICAgaWYgKCFmaWVsZERlZikge1xuICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBwcm92aWRlZEFyZ3MgPSBuZXcgU2V0KFxuICAgICAgICAgIC8vIEZJWE1FOiBodHRwczovL2dpdGh1Yi5jb20vZ3JhcGhxbC9ncmFwaHFsLWpzL2lzc3Vlcy8yMjAzXG4gICAgICAgICAgLyogYzggaWdub3JlIG5leHQgKi9cbiAgICAgICAgICAoX2ZpZWxkTm9kZSRhcmd1bWVudHMgPSBmaWVsZE5vZGUuYXJndW1lbnRzKSA9PT0gbnVsbCB8fCBfZmllbGROb2RlJGFyZ3VtZW50cyA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2ZpZWxkTm9kZSRhcmd1bWVudHMubWFwKChhcmcpID0+IGFyZy5uYW1lLnZhbHVlKVxuICAgICAgICApO1xuICAgICAgICBmb3IgKGNvbnN0IGFyZ0RlZiBvZiBmaWVsZERlZi5hcmdzKSB7XG4gICAgICAgICAgaWYgKCFwcm92aWRlZEFyZ3MuaGFzKGFyZ0RlZi5uYW1lKSAmJiBpc1JlcXVpcmVkQXJndW1lbnQoYXJnRGVmKSkge1xuICAgICAgICAgICAgY29uc3QgYXJnVHlwZVN0ciA9IGluc3BlY3QoYXJnRGVmLnR5cGUpO1xuICAgICAgICAgICAgY29udGV4dC5yZXBvcnRFcnJvcihcbiAgICAgICAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgICAgICAgICBgRmllbGQgXCIke2ZpZWxkRGVmLm5hbWV9XCIgYXJndW1lbnQgXCIke2FyZ0RlZi5uYW1lfVwiIG9mIHR5cGUgXCIke2FyZ1R5cGVTdHJ9XCIgaXMgcmVxdWlyZWQsIGJ1dCBpdCB3YXMgbm90IHByb3ZpZGVkLmAsXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgbm9kZXM6IGZpZWxkTm9kZVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH07XG59XG5mdW5jdGlvbiBQcm92aWRlZFJlcXVpcmVkQXJndW1lbnRzT25EaXJlY3RpdmVzUnVsZShjb250ZXh0KSB7XG4gIHZhciBfc2NoZW1hJGdldERpcmVjdGl2ZXM7XG4gIGNvbnN0IHJlcXVpcmVkQXJnc01hcCA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICBjb25zdCBzY2hlbWEgPSBjb250ZXh0LmdldFNjaGVtYSgpO1xuICBjb25zdCBkZWZpbmVkRGlyZWN0aXZlcyA9IChfc2NoZW1hJGdldERpcmVjdGl2ZXMgPSBzY2hlbWEgPT09IG51bGwgfHwgc2NoZW1hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBzY2hlbWEuZ2V0RGlyZWN0aXZlcygpKSAhPT0gbnVsbCAmJiBfc2NoZW1hJGdldERpcmVjdGl2ZXMgIT09IHZvaWQgMCA/IF9zY2hlbWEkZ2V0RGlyZWN0aXZlcyA6IHNwZWNpZmllZERpcmVjdGl2ZXM7XG4gIGZvciAoY29uc3QgZGlyZWN0aXZlIG9mIGRlZmluZWREaXJlY3RpdmVzKSB7XG4gICAgcmVxdWlyZWRBcmdzTWFwW2RpcmVjdGl2ZS5uYW1lXSA9IGtleU1hcChcbiAgICAgIGRpcmVjdGl2ZS5hcmdzLmZpbHRlcihpc1JlcXVpcmVkQXJndW1lbnQpLFxuICAgICAgKGFyZykgPT4gYXJnLm5hbWVcbiAgICApO1xuICB9XG4gIGNvbnN0IGFzdERlZmluaXRpb25zID0gY29udGV4dC5nZXREb2N1bWVudCgpLmRlZmluaXRpb25zO1xuICBmb3IgKGNvbnN0IGRlZiBvZiBhc3REZWZpbml0aW9ucykge1xuICAgIGlmIChkZWYua2luZCA9PT0gS2luZC5ESVJFQ1RJVkVfREVGSU5JVElPTikge1xuICAgICAgdmFyIF9kZWYkYXJndW1lbnRzO1xuICAgICAgY29uc3QgYXJnTm9kZXMgPSAoX2RlZiRhcmd1bWVudHMgPSBkZWYuYXJndW1lbnRzKSAhPT0gbnVsbCAmJiBfZGVmJGFyZ3VtZW50cyAhPT0gdm9pZCAwID8gX2RlZiRhcmd1bWVudHMgOiBbXTtcbiAgICAgIHJlcXVpcmVkQXJnc01hcFtkZWYubmFtZS52YWx1ZV0gPSBrZXlNYXAoXG4gICAgICAgIGFyZ05vZGVzLmZpbHRlcihpc1JlcXVpcmVkQXJndW1lbnROb2RlKSxcbiAgICAgICAgKGFyZykgPT4gYXJnLm5hbWUudmFsdWVcbiAgICAgICk7XG4gICAgfVxuICB9XG4gIHJldHVybiB7XG4gICAgRGlyZWN0aXZlOiB7XG4gICAgICAvLyBWYWxpZGF0ZSBvbiBsZWF2ZSB0byBhbGxvdyBmb3IgZGVlcGVyIGVycm9ycyB0byBhcHBlYXIgZmlyc3QuXG4gICAgICBsZWF2ZShkaXJlY3RpdmVOb2RlKSB7XG4gICAgICAgIGNvbnN0IGRpcmVjdGl2ZU5hbWUgPSBkaXJlY3RpdmVOb2RlLm5hbWUudmFsdWU7XG4gICAgICAgIGNvbnN0IHJlcXVpcmVkQXJncyA9IHJlcXVpcmVkQXJnc01hcFtkaXJlY3RpdmVOYW1lXTtcbiAgICAgICAgaWYgKHJlcXVpcmVkQXJncykge1xuICAgICAgICAgIHZhciBfZGlyZWN0aXZlTm9kZSRhcmd1bWU7XG4gICAgICAgICAgY29uc3QgYXJnTm9kZXMgPSAoX2RpcmVjdGl2ZU5vZGUkYXJndW1lID0gZGlyZWN0aXZlTm9kZS5hcmd1bWVudHMpICE9PSBudWxsICYmIF9kaXJlY3RpdmVOb2RlJGFyZ3VtZSAhPT0gdm9pZCAwID8gX2RpcmVjdGl2ZU5vZGUkYXJndW1lIDogW107XG4gICAgICAgICAgY29uc3QgYXJnTm9kZU1hcCA9IG5ldyBTZXQoYXJnTm9kZXMubWFwKChhcmcpID0+IGFyZy5uYW1lLnZhbHVlKSk7XG4gICAgICAgICAgZm9yIChjb25zdCBbYXJnTmFtZSwgYXJnRGVmXSBvZiBPYmplY3QuZW50cmllcyhyZXF1aXJlZEFyZ3MpKSB7XG4gICAgICAgICAgICBpZiAoIWFyZ05vZGVNYXAuaGFzKGFyZ05hbWUpKSB7XG4gICAgICAgICAgICAgIGNvbnN0IGFyZ1R5cGUgPSBpc1R5cGUoYXJnRGVmLnR5cGUpID8gaW5zcGVjdChhcmdEZWYudHlwZSkgOiBwcmludChhcmdEZWYudHlwZSk7XG4gICAgICAgICAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgICAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgICAgICAgICAgIGBEaXJlY3RpdmUgXCJAJHtkaXJlY3RpdmVOYW1lfVwiIGFyZ3VtZW50IFwiJHthcmdOYW1lfVwiIG9mIHR5cGUgXCIke2FyZ1R5cGV9XCIgaXMgcmVxdWlyZWQsIGJ1dCBpdCB3YXMgbm90IHByb3ZpZGVkLmAsXG4gICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIG5vZGVzOiBkaXJlY3RpdmVOb2RlXG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfTtcbn1cbmZ1bmN0aW9uIGlzUmVxdWlyZWRBcmd1bWVudE5vZGUoYXJnKSB7XG4gIHJldHVybiBhcmcudHlwZS5raW5kID09PSBLaW5kLk5PTl9OVUxMX1RZUEUgJiYgYXJnLmRlZmF1bHRWYWx1ZSA9PSBudWxsO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdmFsaWRhdGlvbi9ydWxlcy9TY2FsYXJMZWFmc1J1bGUubWpzXG5mdW5jdGlvbiBTY2FsYXJMZWFmc1J1bGUoY29udGV4dCkge1xuICByZXR1cm4ge1xuICAgIEZpZWxkKG5vZGUpIHtcbiAgICAgIGNvbnN0IHR5cGUgPSBjb250ZXh0LmdldFR5cGUoKTtcbiAgICAgIGNvbnN0IHNlbGVjdGlvblNldCA9IG5vZGUuc2VsZWN0aW9uU2V0O1xuICAgICAgaWYgKHR5cGUpIHtcbiAgICAgICAgaWYgKGlzTGVhZlR5cGUoZ2V0TmFtZWRUeXBlKHR5cGUpKSkge1xuICAgICAgICAgIGlmIChzZWxlY3Rpb25TZXQpIHtcbiAgICAgICAgICAgIGNvbnN0IGZpZWxkTmFtZSA9IG5vZGUubmFtZS52YWx1ZTtcbiAgICAgICAgICAgIGNvbnN0IHR5cGVTdHIgPSBpbnNwZWN0KHR5cGUpO1xuICAgICAgICAgICAgY29udGV4dC5yZXBvcnRFcnJvcihcbiAgICAgICAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgICAgICAgICBgRmllbGQgXCIke2ZpZWxkTmFtZX1cIiBtdXN0IG5vdCBoYXZlIGEgc2VsZWN0aW9uIHNpbmNlIHR5cGUgXCIke3R5cGVTdHJ9XCIgaGFzIG5vIHN1YmZpZWxkcy5gLFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgIG5vZGVzOiBzZWxlY3Rpb25TZXRcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIClcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2UgaWYgKCFzZWxlY3Rpb25TZXQpIHtcbiAgICAgICAgICBjb25zdCBmaWVsZE5hbWUgPSBub2RlLm5hbWUudmFsdWU7XG4gICAgICAgICAgY29uc3QgdHlwZVN0ciA9IGluc3BlY3QodHlwZSk7XG4gICAgICAgICAgY29udGV4dC5yZXBvcnRFcnJvcihcbiAgICAgICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgICAgICAgIGBGaWVsZCBcIiR7ZmllbGROYW1lfVwiIG9mIHR5cGUgXCIke3R5cGVTdHJ9XCIgbXVzdCBoYXZlIGEgc2VsZWN0aW9uIG9mIHN1YmZpZWxkcy4gRGlkIHlvdSBtZWFuIFwiJHtmaWVsZE5hbWV9IHsgLi4uIH1cIj9gLFxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgbm9kZXM6IG5vZGVcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgKVxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH07XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC91dGlsaXRpZXMvdmFsdWVGcm9tQVNULm1qc1xuZnVuY3Rpb24gdmFsdWVGcm9tQVNUKHZhbHVlTm9kZSwgdHlwZSwgdmFyaWFibGVzKSB7XG4gIGlmICghdmFsdWVOb2RlKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmICh2YWx1ZU5vZGUua2luZCA9PT0gS2luZC5WQVJJQUJMRSkge1xuICAgIGNvbnN0IHZhcmlhYmxlTmFtZSA9IHZhbHVlTm9kZS5uYW1lLnZhbHVlO1xuICAgIGlmICh2YXJpYWJsZXMgPT0gbnVsbCB8fCB2YXJpYWJsZXNbdmFyaWFibGVOYW1lXSA9PT0gdm9pZCAwKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHZhcmlhYmxlVmFsdWUgPSB2YXJpYWJsZXNbdmFyaWFibGVOYW1lXTtcbiAgICBpZiAodmFyaWFibGVWYWx1ZSA9PT0gbnVsbCAmJiBpc05vbk51bGxUeXBlKHR5cGUpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHJldHVybiB2YXJpYWJsZVZhbHVlO1xuICB9XG4gIGlmIChpc05vbk51bGxUeXBlKHR5cGUpKSB7XG4gICAgaWYgKHZhbHVlTm9kZS5raW5kID09PSBLaW5kLk5VTEwpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgcmV0dXJuIHZhbHVlRnJvbUFTVCh2YWx1ZU5vZGUsIHR5cGUub2ZUeXBlLCB2YXJpYWJsZXMpO1xuICB9XG4gIGlmICh2YWx1ZU5vZGUua2luZCA9PT0gS2luZC5OVUxMKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgaWYgKGlzTGlzdFR5cGUodHlwZSkpIHtcbiAgICBjb25zdCBpdGVtVHlwZSA9IHR5cGUub2ZUeXBlO1xuICAgIGlmICh2YWx1ZU5vZGUua2luZCA9PT0gS2luZC5MSVNUKSB7XG4gICAgICBjb25zdCBjb2VyY2VkVmFsdWVzID0gW107XG4gICAgICBmb3IgKGNvbnN0IGl0ZW1Ob2RlIG9mIHZhbHVlTm9kZS52YWx1ZXMpIHtcbiAgICAgICAgaWYgKGlzTWlzc2luZ1ZhcmlhYmxlKGl0ZW1Ob2RlLCB2YXJpYWJsZXMpKSB7XG4gICAgICAgICAgaWYgKGlzTm9uTnVsbFR5cGUoaXRlbVR5cGUpKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICAgIGNvZXJjZWRWYWx1ZXMucHVzaChudWxsKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjb25zdCBpdGVtVmFsdWUgPSB2YWx1ZUZyb21BU1QoaXRlbU5vZGUsIGl0ZW1UeXBlLCB2YXJpYWJsZXMpO1xuICAgICAgICAgIGlmIChpdGVtVmFsdWUgPT09IHZvaWQgMCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cbiAgICAgICAgICBjb2VyY2VkVmFsdWVzLnB1c2goaXRlbVZhbHVlKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIGNvZXJjZWRWYWx1ZXM7XG4gICAgfVxuICAgIGNvbnN0IGNvZXJjZWRWYWx1ZSA9IHZhbHVlRnJvbUFTVCh2YWx1ZU5vZGUsIGl0ZW1UeXBlLCB2YXJpYWJsZXMpO1xuICAgIGlmIChjb2VyY2VkVmFsdWUgPT09IHZvaWQgMCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICByZXR1cm4gW2NvZXJjZWRWYWx1ZV07XG4gIH1cbiAgaWYgKGlzSW5wdXRPYmplY3RUeXBlKHR5cGUpKSB7XG4gICAgaWYgKHZhbHVlTm9kZS5raW5kICE9PSBLaW5kLk9CSkVDVCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBjb2VyY2VkT2JqID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgY29uc3QgZmllbGROb2RlcyA9IGtleU1hcCh2YWx1ZU5vZGUuZmllbGRzLCAoZmllbGQpID0+IGZpZWxkLm5hbWUudmFsdWUpO1xuICAgIGZvciAoY29uc3QgZmllbGQgb2YgT2JqZWN0LnZhbHVlcyh0eXBlLmdldEZpZWxkcygpKSkge1xuICAgICAgY29uc3QgZmllbGROb2RlID0gZmllbGROb2Rlc1tmaWVsZC5uYW1lXTtcbiAgICAgIGlmICghZmllbGROb2RlIHx8IGlzTWlzc2luZ1ZhcmlhYmxlKGZpZWxkTm9kZS52YWx1ZSwgdmFyaWFibGVzKSkge1xuICAgICAgICBpZiAoZmllbGQuZGVmYXVsdFZhbHVlICE9PSB2b2lkIDApIHtcbiAgICAgICAgICBjb2VyY2VkT2JqW2ZpZWxkLm5hbWVdID0gZmllbGQuZGVmYXVsdFZhbHVlO1xuICAgICAgICB9IGVsc2UgaWYgKGlzTm9uTnVsbFR5cGUoZmllbGQudHlwZSkpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG4gICAgICBjb25zdCBmaWVsZFZhbHVlID0gdmFsdWVGcm9tQVNUKGZpZWxkTm9kZS52YWx1ZSwgZmllbGQudHlwZSwgdmFyaWFibGVzKTtcbiAgICAgIGlmIChmaWVsZFZhbHVlID09PSB2b2lkIDApIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29lcmNlZE9ialtmaWVsZC5uYW1lXSA9IGZpZWxkVmFsdWU7XG4gICAgfVxuICAgIHJldHVybiBjb2VyY2VkT2JqO1xuICB9XG4gIGlmIChpc0xlYWZUeXBlKHR5cGUpKSB7XG4gICAgbGV0IHJlc3VsdDtcbiAgICB0cnkge1xuICAgICAgcmVzdWx0ID0gdHlwZS5wYXJzZUxpdGVyYWwodmFsdWVOb2RlLCB2YXJpYWJsZXMpO1xuICAgIH0gY2F0Y2ggKF9lcnJvcikge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAocmVzdWx0ID09PSB2b2lkIDApIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfVxuICBpbnZhcmlhbnQyKGZhbHNlLCBcIlVuZXhwZWN0ZWQgaW5wdXQgdHlwZTogXCIgKyBpbnNwZWN0KHR5cGUpKTtcbn1cbmZ1bmN0aW9uIGlzTWlzc2luZ1ZhcmlhYmxlKHZhbHVlTm9kZSwgdmFyaWFibGVzKSB7XG4gIHJldHVybiB2YWx1ZU5vZGUua2luZCA9PT0gS2luZC5WQVJJQUJMRSAmJiAodmFyaWFibGVzID09IG51bGwgfHwgdmFyaWFibGVzW3ZhbHVlTm9kZS5uYW1lLnZhbHVlXSA9PT0gdm9pZCAwKTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL2V4ZWN1dGlvbi92YWx1ZXMubWpzXG5mdW5jdGlvbiBnZXRBcmd1bWVudFZhbHVlcyhkZWYsIG5vZGUsIHZhcmlhYmxlVmFsdWVzKSB7XG4gIHZhciBfbm9kZSRhcmd1bWVudHM7XG4gIGNvbnN0IGNvZXJjZWRWYWx1ZXMgPSB7fTtcbiAgY29uc3QgYXJndW1lbnROb2RlcyA9IChfbm9kZSRhcmd1bWVudHMgPSBub2RlLmFyZ3VtZW50cykgIT09IG51bGwgJiYgX25vZGUkYXJndW1lbnRzICE9PSB2b2lkIDAgPyBfbm9kZSRhcmd1bWVudHMgOiBbXTtcbiAgY29uc3QgYXJnTm9kZU1hcCA9IGtleU1hcChhcmd1bWVudE5vZGVzLCAoYXJnKSA9PiBhcmcubmFtZS52YWx1ZSk7XG4gIGZvciAoY29uc3QgYXJnRGVmIG9mIGRlZi5hcmdzKSB7XG4gICAgY29uc3QgbmFtZSA9IGFyZ0RlZi5uYW1lO1xuICAgIGNvbnN0IGFyZ1R5cGUgPSBhcmdEZWYudHlwZTtcbiAgICBjb25zdCBhcmd1bWVudE5vZGUgPSBhcmdOb2RlTWFwW25hbWVdO1xuICAgIGlmICghYXJndW1lbnROb2RlKSB7XG4gICAgICBpZiAoYXJnRGVmLmRlZmF1bHRWYWx1ZSAhPT0gdm9pZCAwKSB7XG4gICAgICAgIGNvZXJjZWRWYWx1ZXNbbmFtZV0gPSBhcmdEZWYuZGVmYXVsdFZhbHVlO1xuICAgICAgfSBlbHNlIGlmIChpc05vbk51bGxUeXBlKGFyZ1R5cGUpKSB7XG4gICAgICAgIHRocm93IG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgICAgYEFyZ3VtZW50IFwiJHtuYW1lfVwiIG9mIHJlcXVpcmVkIHR5cGUgXCIke2luc3BlY3QoYXJnVHlwZSl9XCIgd2FzIG5vdCBwcm92aWRlZC5gLFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIG5vZGVzOiBub2RlXG4gICAgICAgICAgfVxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGNvbnN0IHZhbHVlTm9kZSA9IGFyZ3VtZW50Tm9kZS52YWx1ZTtcbiAgICBsZXQgaXNOdWxsID0gdmFsdWVOb2RlLmtpbmQgPT09IEtpbmQuTlVMTDtcbiAgICBpZiAodmFsdWVOb2RlLmtpbmQgPT09IEtpbmQuVkFSSUFCTEUpIHtcbiAgICAgIGNvbnN0IHZhcmlhYmxlTmFtZSA9IHZhbHVlTm9kZS5uYW1lLnZhbHVlO1xuICAgICAgaWYgKHZhcmlhYmxlVmFsdWVzID09IG51bGwgfHwgIWhhc093blByb3BlcnR5KHZhcmlhYmxlVmFsdWVzLCB2YXJpYWJsZU5hbWUpKSB7XG4gICAgICAgIGlmIChhcmdEZWYuZGVmYXVsdFZhbHVlICE9PSB2b2lkIDApIHtcbiAgICAgICAgICBjb2VyY2VkVmFsdWVzW25hbWVdID0gYXJnRGVmLmRlZmF1bHRWYWx1ZTtcbiAgICAgICAgfSBlbHNlIGlmIChpc05vbk51bGxUeXBlKGFyZ1R5cGUpKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgICAgIGBBcmd1bWVudCBcIiR7bmFtZX1cIiBvZiByZXF1aXJlZCB0eXBlIFwiJHtpbnNwZWN0KGFyZ1R5cGUpfVwiIHdhcyBwcm92aWRlZCB0aGUgdmFyaWFibGUgXCIkJHt2YXJpYWJsZU5hbWV9XCIgd2hpY2ggd2FzIG5vdCBwcm92aWRlZCBhIHJ1bnRpbWUgdmFsdWUuYCxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbm9kZXM6IHZhbHVlTm9kZVxuICAgICAgICAgICAgfVxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG4gICAgICBpc051bGwgPSB2YXJpYWJsZVZhbHVlc1t2YXJpYWJsZU5hbWVdID09IG51bGw7XG4gICAgfVxuICAgIGlmIChpc051bGwgJiYgaXNOb25OdWxsVHlwZShhcmdUeXBlKSkge1xuICAgICAgdGhyb3cgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgYEFyZ3VtZW50IFwiJHtuYW1lfVwiIG9mIG5vbi1udWxsIHR5cGUgXCIke2luc3BlY3QoYXJnVHlwZSl9XCIgbXVzdCBub3QgYmUgbnVsbC5gLFxuICAgICAgICB7XG4gICAgICAgICAgbm9kZXM6IHZhbHVlTm9kZVxuICAgICAgICB9XG4gICAgICApO1xuICAgIH1cbiAgICBjb25zdCBjb2VyY2VkVmFsdWUgPSB2YWx1ZUZyb21BU1QodmFsdWVOb2RlLCBhcmdUeXBlLCB2YXJpYWJsZVZhbHVlcyk7XG4gICAgaWYgKGNvZXJjZWRWYWx1ZSA9PT0gdm9pZCAwKSB7XG4gICAgICB0aHJvdyBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICBgQXJndW1lbnQgXCIke25hbWV9XCIgaGFzIGludmFsaWQgdmFsdWUgJHtwcmludCh2YWx1ZU5vZGUpfS5gLFxuICAgICAgICB7XG4gICAgICAgICAgbm9kZXM6IHZhbHVlTm9kZVxuICAgICAgICB9XG4gICAgICApO1xuICAgIH1cbiAgICBjb2VyY2VkVmFsdWVzW25hbWVdID0gY29lcmNlZFZhbHVlO1xuICB9XG4gIHJldHVybiBjb2VyY2VkVmFsdWVzO1xufVxuZnVuY3Rpb24gZ2V0RGlyZWN0aXZlVmFsdWVzKGRpcmVjdGl2ZURlZiwgbm9kZSwgdmFyaWFibGVWYWx1ZXMpIHtcbiAgdmFyIF9ub2RlJGRpcmVjdGl2ZXM7XG4gIGNvbnN0IGRpcmVjdGl2ZU5vZGUgPSAoX25vZGUkZGlyZWN0aXZlcyA9IG5vZGUuZGlyZWN0aXZlcykgPT09IG51bGwgfHwgX25vZGUkZGlyZWN0aXZlcyA9PT0gdm9pZCAwID8gdm9pZCAwIDogX25vZGUkZGlyZWN0aXZlcy5maW5kKFxuICAgIChkaXJlY3RpdmUpID0+IGRpcmVjdGl2ZS5uYW1lLnZhbHVlID09PSBkaXJlY3RpdmVEZWYubmFtZVxuICApO1xuICBpZiAoZGlyZWN0aXZlTm9kZSkge1xuICAgIHJldHVybiBnZXRBcmd1bWVudFZhbHVlcyhkaXJlY3RpdmVEZWYsIGRpcmVjdGl2ZU5vZGUsIHZhcmlhYmxlVmFsdWVzKTtcbiAgfVxufVxuZnVuY3Rpb24gaGFzT3duUHJvcGVydHkob2JqLCBwcm9wKSB7XG4gIHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBwcm9wKTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL2V4ZWN1dGlvbi9jb2xsZWN0RmllbGRzLm1qc1xuZnVuY3Rpb24gY29sbGVjdEZpZWxkcyhzY2hlbWEsIGZyYWdtZW50cywgdmFyaWFibGVWYWx1ZXMsIHJ1bnRpbWVUeXBlLCBzZWxlY3Rpb25TZXQpIHtcbiAgY29uc3QgZmllbGRzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcbiAgY29sbGVjdEZpZWxkc0ltcGwoXG4gICAgc2NoZW1hLFxuICAgIGZyYWdtZW50cyxcbiAgICB2YXJpYWJsZVZhbHVlcyxcbiAgICBydW50aW1lVHlwZSxcbiAgICBzZWxlY3Rpb25TZXQsXG4gICAgZmllbGRzLFxuICAgIC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KClcbiAgKTtcbiAgcmV0dXJuIGZpZWxkcztcbn1cbmZ1bmN0aW9uIGNvbGxlY3RTdWJmaWVsZHMoc2NoZW1hLCBmcmFnbWVudHMsIHZhcmlhYmxlVmFsdWVzLCByZXR1cm5UeXBlLCBmaWVsZE5vZGVzKSB7XG4gIGNvbnN0IHN1YkZpZWxkTm9kZXMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuICBjb25zdCB2aXNpdGVkRnJhZ21lbnROYW1lcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG4gIGZvciAoY29uc3Qgbm9kZSBvZiBmaWVsZE5vZGVzKSB7XG4gICAgaWYgKG5vZGUuc2VsZWN0aW9uU2V0KSB7XG4gICAgICBjb2xsZWN0RmllbGRzSW1wbChcbiAgICAgICAgc2NoZW1hLFxuICAgICAgICBmcmFnbWVudHMsXG4gICAgICAgIHZhcmlhYmxlVmFsdWVzLFxuICAgICAgICByZXR1cm5UeXBlLFxuICAgICAgICBub2RlLnNlbGVjdGlvblNldCxcbiAgICAgICAgc3ViRmllbGROb2RlcyxcbiAgICAgICAgdmlzaXRlZEZyYWdtZW50TmFtZXNcbiAgICAgICk7XG4gICAgfVxuICB9XG4gIHJldHVybiBzdWJGaWVsZE5vZGVzO1xufVxuZnVuY3Rpb24gY29sbGVjdEZpZWxkc0ltcGwoc2NoZW1hLCBmcmFnbWVudHMsIHZhcmlhYmxlVmFsdWVzLCBydW50aW1lVHlwZSwgc2VsZWN0aW9uU2V0LCBmaWVsZHMsIHZpc2l0ZWRGcmFnbWVudE5hbWVzKSB7XG4gIGZvciAoY29uc3Qgc2VsZWN0aW9uIG9mIHNlbGVjdGlvblNldC5zZWxlY3Rpb25zKSB7XG4gICAgc3dpdGNoIChzZWxlY3Rpb24ua2luZCkge1xuICAgICAgY2FzZSBLaW5kLkZJRUxEOiB7XG4gICAgICAgIGlmICghc2hvdWxkSW5jbHVkZU5vZGUodmFyaWFibGVWYWx1ZXMsIHNlbGVjdGlvbikpIHtcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBuYW1lID0gZ2V0RmllbGRFbnRyeUtleShzZWxlY3Rpb24pO1xuICAgICAgICBjb25zdCBmaWVsZExpc3QgPSBmaWVsZHMuZ2V0KG5hbWUpO1xuICAgICAgICBpZiAoZmllbGRMaXN0ICE9PSB2b2lkIDApIHtcbiAgICAgICAgICBmaWVsZExpc3QucHVzaChzZWxlY3Rpb24pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGZpZWxkcy5zZXQobmFtZSwgW3NlbGVjdGlvbl0pO1xuICAgICAgICB9XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgY2FzZSBLaW5kLklOTElORV9GUkFHTUVOVDoge1xuICAgICAgICBpZiAoIXNob3VsZEluY2x1ZGVOb2RlKHZhcmlhYmxlVmFsdWVzLCBzZWxlY3Rpb24pIHx8ICFkb2VzRnJhZ21lbnRDb25kaXRpb25NYXRjaChzY2hlbWEsIHNlbGVjdGlvbiwgcnVudGltZVR5cGUpKSB7XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgY29sbGVjdEZpZWxkc0ltcGwoXG4gICAgICAgICAgc2NoZW1hLFxuICAgICAgICAgIGZyYWdtZW50cyxcbiAgICAgICAgICB2YXJpYWJsZVZhbHVlcyxcbiAgICAgICAgICBydW50aW1lVHlwZSxcbiAgICAgICAgICBzZWxlY3Rpb24uc2VsZWN0aW9uU2V0LFxuICAgICAgICAgIGZpZWxkcyxcbiAgICAgICAgICB2aXNpdGVkRnJhZ21lbnROYW1lc1xuICAgICAgICApO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICAgIGNhc2UgS2luZC5GUkFHTUVOVF9TUFJFQUQ6IHtcbiAgICAgICAgY29uc3QgZnJhZ05hbWUgPSBzZWxlY3Rpb24ubmFtZS52YWx1ZTtcbiAgICAgICAgaWYgKHZpc2l0ZWRGcmFnbWVudE5hbWVzLmhhcyhmcmFnTmFtZSkgfHwgIXNob3VsZEluY2x1ZGVOb2RlKHZhcmlhYmxlVmFsdWVzLCBzZWxlY3Rpb24pKSB7XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgdmlzaXRlZEZyYWdtZW50TmFtZXMuYWRkKGZyYWdOYW1lKTtcbiAgICAgICAgY29uc3QgZnJhZ21lbnQgPSBmcmFnbWVudHNbZnJhZ05hbWVdO1xuICAgICAgICBpZiAoIWZyYWdtZW50IHx8ICFkb2VzRnJhZ21lbnRDb25kaXRpb25NYXRjaChzY2hlbWEsIGZyYWdtZW50LCBydW50aW1lVHlwZSkpIHtcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBjb2xsZWN0RmllbGRzSW1wbChcbiAgICAgICAgICBzY2hlbWEsXG4gICAgICAgICAgZnJhZ21lbnRzLFxuICAgICAgICAgIHZhcmlhYmxlVmFsdWVzLFxuICAgICAgICAgIHJ1bnRpbWVUeXBlLFxuICAgICAgICAgIGZyYWdtZW50LnNlbGVjdGlvblNldCxcbiAgICAgICAgICBmaWVsZHMsXG4gICAgICAgICAgdmlzaXRlZEZyYWdtZW50TmFtZXNcbiAgICAgICAgKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG5mdW5jdGlvbiBzaG91bGRJbmNsdWRlTm9kZSh2YXJpYWJsZVZhbHVlcywgbm9kZSkge1xuICBjb25zdCBza2lwID0gZ2V0RGlyZWN0aXZlVmFsdWVzKEdyYXBoUUxTa2lwRGlyZWN0aXZlLCBub2RlLCB2YXJpYWJsZVZhbHVlcyk7XG4gIGlmICgoc2tpcCA9PT0gbnVsbCB8fCBza2lwID09PSB2b2lkIDAgPyB2b2lkIDAgOiBza2lwLmlmKSA9PT0gdHJ1ZSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBjb25zdCBpbmNsdWRlID0gZ2V0RGlyZWN0aXZlVmFsdWVzKFxuICAgIEdyYXBoUUxJbmNsdWRlRGlyZWN0aXZlLFxuICAgIG5vZGUsXG4gICAgdmFyaWFibGVWYWx1ZXNcbiAgKTtcbiAgaWYgKChpbmNsdWRlID09PSBudWxsIHx8IGluY2x1ZGUgPT09IHZvaWQgMCA/IHZvaWQgMCA6IGluY2x1ZGUuaWYpID09PSBmYWxzZSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICByZXR1cm4gdHJ1ZTtcbn1cbmZ1bmN0aW9uIGRvZXNGcmFnbWVudENvbmRpdGlvbk1hdGNoKHNjaGVtYSwgZnJhZ21lbnQsIHR5cGUpIHtcbiAgY29uc3QgdHlwZUNvbmRpdGlvbk5vZGUgPSBmcmFnbWVudC50eXBlQ29uZGl0aW9uO1xuICBpZiAoIXR5cGVDb25kaXRpb25Ob2RlKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgY29uc3QgY29uZGl0aW9uYWxUeXBlID0gdHlwZUZyb21BU1Qoc2NoZW1hLCB0eXBlQ29uZGl0aW9uTm9kZSk7XG4gIGlmIChjb25kaXRpb25hbFR5cGUgPT09IHR5cGUpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBpZiAoaXNBYnN0cmFjdFR5cGUoY29uZGl0aW9uYWxUeXBlKSkge1xuICAgIHJldHVybiBzY2hlbWEuaXNTdWJUeXBlKGNvbmRpdGlvbmFsVHlwZSwgdHlwZSk7XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufVxuZnVuY3Rpb24gZ2V0RmllbGRFbnRyeUtleShub2RlKSB7XG4gIHJldHVybiBub2RlLmFsaWFzID8gbm9kZS5hbGlhcy52YWx1ZSA6IG5vZGUubmFtZS52YWx1ZTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL3ZhbGlkYXRpb24vcnVsZXMvU2luZ2xlRmllbGRTdWJzY3JpcHRpb25zUnVsZS5tanNcbmZ1bmN0aW9uIFNpbmdsZUZpZWxkU3Vic2NyaXB0aW9uc1J1bGUoY29udGV4dCkge1xuICByZXR1cm4ge1xuICAgIE9wZXJhdGlvbkRlZmluaXRpb24obm9kZSkge1xuICAgICAgaWYgKG5vZGUub3BlcmF0aW9uID09PSBcInN1YnNjcmlwdGlvblwiKSB7XG4gICAgICAgIGNvbnN0IHNjaGVtYSA9IGNvbnRleHQuZ2V0U2NoZW1hKCk7XG4gICAgICAgIGNvbnN0IHN1YnNjcmlwdGlvblR5cGUgPSBzY2hlbWEuZ2V0U3Vic2NyaXB0aW9uVHlwZSgpO1xuICAgICAgICBpZiAoc3Vic2NyaXB0aW9uVHlwZSkge1xuICAgICAgICAgIGNvbnN0IG9wZXJhdGlvbk5hbWUgPSBub2RlLm5hbWUgPyBub2RlLm5hbWUudmFsdWUgOiBudWxsO1xuICAgICAgICAgIGNvbnN0IHZhcmlhYmxlVmFsdWVzID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgICAgICAgY29uc3QgZG9jdW1lbnQyID0gY29udGV4dC5nZXREb2N1bWVudCgpO1xuICAgICAgICAgIGNvbnN0IGZyYWdtZW50cyA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgICAgICAgIGZvciAoY29uc3QgZGVmaW5pdGlvbiBvZiBkb2N1bWVudDIuZGVmaW5pdGlvbnMpIHtcbiAgICAgICAgICAgIGlmIChkZWZpbml0aW9uLmtpbmQgPT09IEtpbmQuRlJBR01FTlRfREVGSU5JVElPTikge1xuICAgICAgICAgICAgICBmcmFnbWVudHNbZGVmaW5pdGlvbi5uYW1lLnZhbHVlXSA9IGRlZmluaXRpb247XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIGNvbnN0IGZpZWxkcyA9IGNvbGxlY3RGaWVsZHMoXG4gICAgICAgICAgICBzY2hlbWEsXG4gICAgICAgICAgICBmcmFnbWVudHMsXG4gICAgICAgICAgICB2YXJpYWJsZVZhbHVlcyxcbiAgICAgICAgICAgIHN1YnNjcmlwdGlvblR5cGUsXG4gICAgICAgICAgICBub2RlLnNlbGVjdGlvblNldFxuICAgICAgICAgICk7XG4gICAgICAgICAgaWYgKGZpZWxkcy5zaXplID4gMSkge1xuICAgICAgICAgICAgY29uc3QgZmllbGRTZWxlY3Rpb25MaXN0cyA9IFsuLi5maWVsZHMudmFsdWVzKCldO1xuICAgICAgICAgICAgY29uc3QgZXh0cmFGaWVsZFNlbGVjdGlvbkxpc3RzID0gZmllbGRTZWxlY3Rpb25MaXN0cy5zbGljZSgxKTtcbiAgICAgICAgICAgIGNvbnN0IGV4dHJhRmllbGRTZWxlY3Rpb25zID0gZXh0cmFGaWVsZFNlbGVjdGlvbkxpc3RzLmZsYXQoKTtcbiAgICAgICAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgICAgICAgICAgb3BlcmF0aW9uTmFtZSAhPSBudWxsID8gYFN1YnNjcmlwdGlvbiBcIiR7b3BlcmF0aW9uTmFtZX1cIiBtdXN0IHNlbGVjdCBvbmx5IG9uZSB0b3AgbGV2ZWwgZmllbGQuYCA6IFwiQW5vbnltb3VzIFN1YnNjcmlwdGlvbiBtdXN0IHNlbGVjdCBvbmx5IG9uZSB0b3AgbGV2ZWwgZmllbGQuXCIsXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgbm9kZXM6IGV4dHJhRmllbGRTZWxlY3Rpb25zXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICApXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgICBmb3IgKGNvbnN0IGZpZWxkTm9kZXMgb2YgZmllbGRzLnZhbHVlcygpKSB7XG4gICAgICAgICAgICBjb25zdCBmaWVsZCA9IGZpZWxkTm9kZXNbMF07XG4gICAgICAgICAgICBjb25zdCBmaWVsZE5hbWUgPSBmaWVsZC5uYW1lLnZhbHVlO1xuICAgICAgICAgICAgaWYgKGZpZWxkTmFtZS5zdGFydHNXaXRoKFwiX19cIikpIHtcbiAgICAgICAgICAgICAgY29udGV4dC5yZXBvcnRFcnJvcihcbiAgICAgICAgICAgICAgICBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICAgICAgICAgICAgb3BlcmF0aW9uTmFtZSAhPSBudWxsID8gYFN1YnNjcmlwdGlvbiBcIiR7b3BlcmF0aW9uTmFtZX1cIiBtdXN0IG5vdCBzZWxlY3QgYW4gaW50cm9zcGVjdGlvbiB0b3AgbGV2ZWwgZmllbGQuYCA6IFwiQW5vbnltb3VzIFN1YnNjcmlwdGlvbiBtdXN0IG5vdCBzZWxlY3QgYW4gaW50cm9zcGVjdGlvbiB0b3AgbGV2ZWwgZmllbGQuXCIsXG4gICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIG5vZGVzOiBmaWVsZE5vZGVzXG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL2pzdXRpbHMvZ3JvdXBCeS5tanNcbmZ1bmN0aW9uIGdyb3VwQnkobGlzdCwga2V5Rm4pIHtcbiAgY29uc3QgcmVzdWx0ID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcbiAgZm9yIChjb25zdCBpdGVtIG9mIGxpc3QpIHtcbiAgICBjb25zdCBrZXkgPSBrZXlGbihpdGVtKTtcbiAgICBjb25zdCBncm91cCA9IHJlc3VsdC5nZXQoa2V5KTtcbiAgICBpZiAoZ3JvdXAgPT09IHZvaWQgMCkge1xuICAgICAgcmVzdWx0LnNldChrZXksIFtpdGVtXSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGdyb3VwLnB1c2goaXRlbSk7XG4gICAgfVxuICB9XG4gIHJldHVybiByZXN1bHQ7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC92YWxpZGF0aW9uL3J1bGVzL1VuaXF1ZUFyZ3VtZW50RGVmaW5pdGlvbk5hbWVzUnVsZS5tanNcbmZ1bmN0aW9uIFVuaXF1ZUFyZ3VtZW50RGVmaW5pdGlvbk5hbWVzUnVsZShjb250ZXh0KSB7XG4gIHJldHVybiB7XG4gICAgRGlyZWN0aXZlRGVmaW5pdGlvbihkaXJlY3RpdmVOb2RlKSB7XG4gICAgICB2YXIgX2RpcmVjdGl2ZU5vZGUkYXJndW1lO1xuICAgICAgY29uc3QgYXJndW1lbnROb2RlcyA9IChfZGlyZWN0aXZlTm9kZSRhcmd1bWUgPSBkaXJlY3RpdmVOb2RlLmFyZ3VtZW50cykgIT09IG51bGwgJiYgX2RpcmVjdGl2ZU5vZGUkYXJndW1lICE9PSB2b2lkIDAgPyBfZGlyZWN0aXZlTm9kZSRhcmd1bWUgOiBbXTtcbiAgICAgIHJldHVybiBjaGVja0FyZ1VuaXF1ZW5lc3MoYEAke2RpcmVjdGl2ZU5vZGUubmFtZS52YWx1ZX1gLCBhcmd1bWVudE5vZGVzKTtcbiAgICB9LFxuICAgIEludGVyZmFjZVR5cGVEZWZpbml0aW9uOiBjaGVja0FyZ1VuaXF1ZW5lc3NQZXJGaWVsZCxcbiAgICBJbnRlcmZhY2VUeXBlRXh0ZW5zaW9uOiBjaGVja0FyZ1VuaXF1ZW5lc3NQZXJGaWVsZCxcbiAgICBPYmplY3RUeXBlRGVmaW5pdGlvbjogY2hlY2tBcmdVbmlxdWVuZXNzUGVyRmllbGQsXG4gICAgT2JqZWN0VHlwZUV4dGVuc2lvbjogY2hlY2tBcmdVbmlxdWVuZXNzUGVyRmllbGRcbiAgfTtcbiAgZnVuY3Rpb24gY2hlY2tBcmdVbmlxdWVuZXNzUGVyRmllbGQodHlwZU5vZGUpIHtcbiAgICB2YXIgX3R5cGVOb2RlJGZpZWxkcztcbiAgICBjb25zdCB0eXBlTmFtZSA9IHR5cGVOb2RlLm5hbWUudmFsdWU7XG4gICAgY29uc3QgZmllbGROb2RlcyA9IChfdHlwZU5vZGUkZmllbGRzID0gdHlwZU5vZGUuZmllbGRzKSAhPT0gbnVsbCAmJiBfdHlwZU5vZGUkZmllbGRzICE9PSB2b2lkIDAgPyBfdHlwZU5vZGUkZmllbGRzIDogW107XG4gICAgZm9yIChjb25zdCBmaWVsZERlZiBvZiBmaWVsZE5vZGVzKSB7XG4gICAgICB2YXIgX2ZpZWxkRGVmJGFyZ3VtZW50cztcbiAgICAgIGNvbnN0IGZpZWxkTmFtZSA9IGZpZWxkRGVmLm5hbWUudmFsdWU7XG4gICAgICBjb25zdCBhcmd1bWVudE5vZGVzID0gKF9maWVsZERlZiRhcmd1bWVudHMgPSBmaWVsZERlZi5hcmd1bWVudHMpICE9PSBudWxsICYmIF9maWVsZERlZiRhcmd1bWVudHMgIT09IHZvaWQgMCA/IF9maWVsZERlZiRhcmd1bWVudHMgOiBbXTtcbiAgICAgIGNoZWNrQXJnVW5pcXVlbmVzcyhgJHt0eXBlTmFtZX0uJHtmaWVsZE5hbWV9YCwgYXJndW1lbnROb2Rlcyk7XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBmdW5jdGlvbiBjaGVja0FyZ1VuaXF1ZW5lc3MocGFyZW50TmFtZSwgYXJndW1lbnROb2Rlcykge1xuICAgIGNvbnN0IHNlZW5BcmdzID0gZ3JvdXBCeShhcmd1bWVudE5vZGVzLCAoYXJnKSA9PiBhcmcubmFtZS52YWx1ZSk7XG4gICAgZm9yIChjb25zdCBbYXJnTmFtZSwgYXJnTm9kZXNdIG9mIHNlZW5BcmdzKSB7XG4gICAgICBpZiAoYXJnTm9kZXMubGVuZ3RoID4gMSkge1xuICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgICAgICBgQXJndW1lbnQgXCIke3BhcmVudE5hbWV9KCR7YXJnTmFtZX06KVwiIGNhbiBvbmx5IGJlIGRlZmluZWQgb25jZS5gLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBub2RlczogYXJnTm9kZXMubWFwKChub2RlKSA9PiBub2RlLm5hbWUpXG4gICAgICAgICAgICB9XG4gICAgICAgICAgKVxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL3ZhbGlkYXRpb24vcnVsZXMvVW5pcXVlQXJndW1lbnROYW1lc1J1bGUubWpzXG5mdW5jdGlvbiBVbmlxdWVBcmd1bWVudE5hbWVzUnVsZShjb250ZXh0KSB7XG4gIHJldHVybiB7XG4gICAgRmllbGQ6IGNoZWNrQXJnVW5pcXVlbmVzcyxcbiAgICBEaXJlY3RpdmU6IGNoZWNrQXJnVW5pcXVlbmVzc1xuICB9O1xuICBmdW5jdGlvbiBjaGVja0FyZ1VuaXF1ZW5lc3MocGFyZW50Tm9kZSkge1xuICAgIHZhciBfcGFyZW50Tm9kZSRhcmd1bWVudHM7XG4gICAgY29uc3QgYXJndW1lbnROb2RlcyA9IChfcGFyZW50Tm9kZSRhcmd1bWVudHMgPSBwYXJlbnROb2RlLmFyZ3VtZW50cykgIT09IG51bGwgJiYgX3BhcmVudE5vZGUkYXJndW1lbnRzICE9PSB2b2lkIDAgPyBfcGFyZW50Tm9kZSRhcmd1bWVudHMgOiBbXTtcbiAgICBjb25zdCBzZWVuQXJncyA9IGdyb3VwQnkoYXJndW1lbnROb2RlcywgKGFyZykgPT4gYXJnLm5hbWUudmFsdWUpO1xuICAgIGZvciAoY29uc3QgW2FyZ05hbWUsIGFyZ05vZGVzXSBvZiBzZWVuQXJncykge1xuICAgICAgaWYgKGFyZ05vZGVzLmxlbmd0aCA+IDEpIHtcbiAgICAgICAgY29udGV4dC5yZXBvcnRFcnJvcihcbiAgICAgICAgICBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICAgICAgYFRoZXJlIGNhbiBiZSBvbmx5IG9uZSBhcmd1bWVudCBuYW1lZCBcIiR7YXJnTmFtZX1cIi5gLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBub2RlczogYXJnTm9kZXMubWFwKChub2RlKSA9PiBub2RlLm5hbWUpXG4gICAgICAgICAgICB9XG4gICAgICAgICAgKVxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cbiAgfVxufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdmFsaWRhdGlvbi9ydWxlcy9VbmlxdWVEaXJlY3RpdmVOYW1lc1J1bGUubWpzXG5mdW5jdGlvbiBVbmlxdWVEaXJlY3RpdmVOYW1lc1J1bGUoY29udGV4dCkge1xuICBjb25zdCBrbm93bkRpcmVjdGl2ZU5hbWVzID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIGNvbnN0IHNjaGVtYSA9IGNvbnRleHQuZ2V0U2NoZW1hKCk7XG4gIHJldHVybiB7XG4gICAgRGlyZWN0aXZlRGVmaW5pdGlvbihub2RlKSB7XG4gICAgICBjb25zdCBkaXJlY3RpdmVOYW1lID0gbm9kZS5uYW1lLnZhbHVlO1xuICAgICAgaWYgKHNjaGVtYSAhPT0gbnVsbCAmJiBzY2hlbWEgIT09IHZvaWQgMCAmJiBzY2hlbWEuZ2V0RGlyZWN0aXZlKGRpcmVjdGl2ZU5hbWUpKSB7XG4gICAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgICAgIGBEaXJlY3RpdmUgXCJAJHtkaXJlY3RpdmVOYW1lfVwiIGFscmVhZHkgZXhpc3RzIGluIHRoZSBzY2hlbWEuIEl0IGNhbm5vdCBiZSByZWRlZmluZWQuYCxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbm9kZXM6IG5vZGUubmFtZVxuICAgICAgICAgICAgfVxuICAgICAgICAgIClcbiAgICAgICAgKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKGtub3duRGlyZWN0aXZlTmFtZXNbZGlyZWN0aXZlTmFtZV0pIHtcbiAgICAgICAgY29udGV4dC5yZXBvcnRFcnJvcihcbiAgICAgICAgICBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICAgICAgYFRoZXJlIGNhbiBiZSBvbmx5IG9uZSBkaXJlY3RpdmUgbmFtZWQgXCJAJHtkaXJlY3RpdmVOYW1lfVwiLmAsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5vZGVzOiBba25vd25EaXJlY3RpdmVOYW1lc1tkaXJlY3RpdmVOYW1lXSwgbm9kZS5uYW1lXVxuICAgICAgICAgICAgfVxuICAgICAgICAgIClcbiAgICAgICAgKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGtub3duRGlyZWN0aXZlTmFtZXNbZGlyZWN0aXZlTmFtZV0gPSBub2RlLm5hbWU7XG4gICAgICB9XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICB9O1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdmFsaWRhdGlvbi9ydWxlcy9VbmlxdWVEaXJlY3RpdmVzUGVyTG9jYXRpb25SdWxlLm1qc1xuZnVuY3Rpb24gVW5pcXVlRGlyZWN0aXZlc1BlckxvY2F0aW9uUnVsZShjb250ZXh0KSB7XG4gIGNvbnN0IHVuaXF1ZURpcmVjdGl2ZU1hcCA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICBjb25zdCBzY2hlbWEgPSBjb250ZXh0LmdldFNjaGVtYSgpO1xuICBjb25zdCBkZWZpbmVkRGlyZWN0aXZlcyA9IHNjaGVtYSA/IHNjaGVtYS5nZXREaXJlY3RpdmVzKCkgOiBzcGVjaWZpZWREaXJlY3RpdmVzO1xuICBmb3IgKGNvbnN0IGRpcmVjdGl2ZSBvZiBkZWZpbmVkRGlyZWN0aXZlcykge1xuICAgIHVuaXF1ZURpcmVjdGl2ZU1hcFtkaXJlY3RpdmUubmFtZV0gPSAhZGlyZWN0aXZlLmlzUmVwZWF0YWJsZTtcbiAgfVxuICBjb25zdCBhc3REZWZpbml0aW9ucyA9IGNvbnRleHQuZ2V0RG9jdW1lbnQoKS5kZWZpbml0aW9ucztcbiAgZm9yIChjb25zdCBkZWYgb2YgYXN0RGVmaW5pdGlvbnMpIHtcbiAgICBpZiAoZGVmLmtpbmQgPT09IEtpbmQuRElSRUNUSVZFX0RFRklOSVRJT04pIHtcbiAgICAgIHVuaXF1ZURpcmVjdGl2ZU1hcFtkZWYubmFtZS52YWx1ZV0gPSAhZGVmLnJlcGVhdGFibGU7XG4gICAgfVxuICB9XG4gIGNvbnN0IHNjaGVtYURpcmVjdGl2ZXMgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgY29uc3QgdHlwZURpcmVjdGl2ZXNNYXAgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgcmV0dXJuIHtcbiAgICAvLyBNYW55IGRpZmZlcmVudCBBU1Qgbm9kZXMgbWF5IGNvbnRhaW4gZGlyZWN0aXZlcy4gUmF0aGVyIHRoYW4gbGlzdGluZ1xuICAgIC8vIHRoZW0gYWxsLCBqdXN0IGxpc3RlbiBmb3IgZW50ZXJpbmcgYW55IG5vZGUsIGFuZCBjaGVjayB0byBzZWUgaWYgaXRcbiAgICAvLyBkZWZpbmVzIGFueSBkaXJlY3RpdmVzLlxuICAgIGVudGVyKG5vZGUpIHtcbiAgICAgIGlmICghKFwiZGlyZWN0aXZlc1wiIGluIG5vZGUpIHx8ICFub2RlLmRpcmVjdGl2ZXMpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgbGV0IHNlZW5EaXJlY3RpdmVzO1xuICAgICAgaWYgKG5vZGUua2luZCA9PT0gS2luZC5TQ0hFTUFfREVGSU5JVElPTiB8fCBub2RlLmtpbmQgPT09IEtpbmQuU0NIRU1BX0VYVEVOU0lPTikge1xuICAgICAgICBzZWVuRGlyZWN0aXZlcyA9IHNjaGVtYURpcmVjdGl2ZXM7XG4gICAgICB9IGVsc2UgaWYgKGlzVHlwZURlZmluaXRpb25Ob2RlKG5vZGUpIHx8IGlzVHlwZUV4dGVuc2lvbk5vZGUobm9kZSkpIHtcbiAgICAgICAgY29uc3QgdHlwZU5hbWUgPSBub2RlLm5hbWUudmFsdWU7XG4gICAgICAgIHNlZW5EaXJlY3RpdmVzID0gdHlwZURpcmVjdGl2ZXNNYXBbdHlwZU5hbWVdO1xuICAgICAgICBpZiAoc2VlbkRpcmVjdGl2ZXMgPT09IHZvaWQgMCkge1xuICAgICAgICAgIHR5cGVEaXJlY3RpdmVzTWFwW3R5cGVOYW1lXSA9IHNlZW5EaXJlY3RpdmVzID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHNlZW5EaXJlY3RpdmVzID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgICB9XG4gICAgICBmb3IgKGNvbnN0IGRpcmVjdGl2ZSBvZiBub2RlLmRpcmVjdGl2ZXMpIHtcbiAgICAgICAgY29uc3QgZGlyZWN0aXZlTmFtZSA9IGRpcmVjdGl2ZS5uYW1lLnZhbHVlO1xuICAgICAgICBpZiAodW5pcXVlRGlyZWN0aXZlTWFwW2RpcmVjdGl2ZU5hbWVdKSB7XG4gICAgICAgICAgaWYgKHNlZW5EaXJlY3RpdmVzW2RpcmVjdGl2ZU5hbWVdKSB7XG4gICAgICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgICAgICBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICAgICAgICAgIGBUaGUgZGlyZWN0aXZlIFwiQCR7ZGlyZWN0aXZlTmFtZX1cIiBjYW4gb25seSBiZSB1c2VkIG9uY2UgYXQgdGhpcyBsb2NhdGlvbi5gLFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgIG5vZGVzOiBbc2VlbkRpcmVjdGl2ZXNbZGlyZWN0aXZlTmFtZV0sIGRpcmVjdGl2ZV1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIClcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHNlZW5EaXJlY3RpdmVzW2RpcmVjdGl2ZU5hbWVdID0gZGlyZWN0aXZlO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL3ZhbGlkYXRpb24vcnVsZXMvVW5pcXVlRW51bVZhbHVlTmFtZXNSdWxlLm1qc1xuZnVuY3Rpb24gVW5pcXVlRW51bVZhbHVlTmFtZXNSdWxlKGNvbnRleHQpIHtcbiAgY29uc3Qgc2NoZW1hID0gY29udGV4dC5nZXRTY2hlbWEoKTtcbiAgY29uc3QgZXhpc3RpbmdUeXBlTWFwID0gc2NoZW1hID8gc2NoZW1hLmdldFR5cGVNYXAoKSA6IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICBjb25zdCBrbm93blZhbHVlTmFtZXMgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgcmV0dXJuIHtcbiAgICBFbnVtVHlwZURlZmluaXRpb246IGNoZWNrVmFsdWVVbmlxdWVuZXNzLFxuICAgIEVudW1UeXBlRXh0ZW5zaW9uOiBjaGVja1ZhbHVlVW5pcXVlbmVzc1xuICB9O1xuICBmdW5jdGlvbiBjaGVja1ZhbHVlVW5pcXVlbmVzcyhub2RlKSB7XG4gICAgdmFyIF9ub2RlJHZhbHVlcztcbiAgICBjb25zdCB0eXBlTmFtZSA9IG5vZGUubmFtZS52YWx1ZTtcbiAgICBpZiAoIWtub3duVmFsdWVOYW1lc1t0eXBlTmFtZV0pIHtcbiAgICAgIGtub3duVmFsdWVOYW1lc1t0eXBlTmFtZV0gPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICB9XG4gICAgY29uc3QgdmFsdWVOb2RlcyA9IChfbm9kZSR2YWx1ZXMgPSBub2RlLnZhbHVlcykgIT09IG51bGwgJiYgX25vZGUkdmFsdWVzICE9PSB2b2lkIDAgPyBfbm9kZSR2YWx1ZXMgOiBbXTtcbiAgICBjb25zdCB2YWx1ZU5hbWVzID0ga25vd25WYWx1ZU5hbWVzW3R5cGVOYW1lXTtcbiAgICBmb3IgKGNvbnN0IHZhbHVlRGVmIG9mIHZhbHVlTm9kZXMpIHtcbiAgICAgIGNvbnN0IHZhbHVlTmFtZSA9IHZhbHVlRGVmLm5hbWUudmFsdWU7XG4gICAgICBjb25zdCBleGlzdGluZ1R5cGUgPSBleGlzdGluZ1R5cGVNYXBbdHlwZU5hbWVdO1xuICAgICAgaWYgKGlzRW51bVR5cGUoZXhpc3RpbmdUeXBlKSAmJiBleGlzdGluZ1R5cGUuZ2V0VmFsdWUodmFsdWVOYW1lKSkge1xuICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgICAgICBgRW51bSB2YWx1ZSBcIiR7dHlwZU5hbWV9LiR7dmFsdWVOYW1lfVwiIGFscmVhZHkgZXhpc3RzIGluIHRoZSBzY2hlbWEuIEl0IGNhbm5vdCBhbHNvIGJlIGRlZmluZWQgaW4gdGhpcyB0eXBlIGV4dGVuc2lvbi5gLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBub2RlczogdmFsdWVEZWYubmFtZVxuICAgICAgICAgICAgfVxuICAgICAgICAgIClcbiAgICAgICAgKTtcbiAgICAgIH0gZWxzZSBpZiAodmFsdWVOYW1lc1t2YWx1ZU5hbWVdKSB7XG4gICAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgICAgIGBFbnVtIHZhbHVlIFwiJHt0eXBlTmFtZX0uJHt2YWx1ZU5hbWV9XCIgY2FuIG9ubHkgYmUgZGVmaW5lZCBvbmNlLmAsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5vZGVzOiBbdmFsdWVOYW1lc1t2YWx1ZU5hbWVdLCB2YWx1ZURlZi5uYW1lXVxuICAgICAgICAgICAgfVxuICAgICAgICAgIClcbiAgICAgICAgKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHZhbHVlTmFtZXNbdmFsdWVOYW1lXSA9IHZhbHVlRGVmLm5hbWU7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdmFsaWRhdGlvbi9ydWxlcy9VbmlxdWVGaWVsZERlZmluaXRpb25OYW1lc1J1bGUubWpzXG5mdW5jdGlvbiBVbmlxdWVGaWVsZERlZmluaXRpb25OYW1lc1J1bGUoY29udGV4dCkge1xuICBjb25zdCBzY2hlbWEgPSBjb250ZXh0LmdldFNjaGVtYSgpO1xuICBjb25zdCBleGlzdGluZ1R5cGVNYXAgPSBzY2hlbWEgPyBzY2hlbWEuZ2V0VHlwZU1hcCgpIDogLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIGNvbnN0IGtub3duRmllbGROYW1lcyA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICByZXR1cm4ge1xuICAgIElucHV0T2JqZWN0VHlwZURlZmluaXRpb246IGNoZWNrRmllbGRVbmlxdWVuZXNzLFxuICAgIElucHV0T2JqZWN0VHlwZUV4dGVuc2lvbjogY2hlY2tGaWVsZFVuaXF1ZW5lc3MsXG4gICAgSW50ZXJmYWNlVHlwZURlZmluaXRpb246IGNoZWNrRmllbGRVbmlxdWVuZXNzLFxuICAgIEludGVyZmFjZVR5cGVFeHRlbnNpb246IGNoZWNrRmllbGRVbmlxdWVuZXNzLFxuICAgIE9iamVjdFR5cGVEZWZpbml0aW9uOiBjaGVja0ZpZWxkVW5pcXVlbmVzcyxcbiAgICBPYmplY3RUeXBlRXh0ZW5zaW9uOiBjaGVja0ZpZWxkVW5pcXVlbmVzc1xuICB9O1xuICBmdW5jdGlvbiBjaGVja0ZpZWxkVW5pcXVlbmVzcyhub2RlKSB7XG4gICAgdmFyIF9ub2RlJGZpZWxkcztcbiAgICBjb25zdCB0eXBlTmFtZSA9IG5vZGUubmFtZS52YWx1ZTtcbiAgICBpZiAoIWtub3duRmllbGROYW1lc1t0eXBlTmFtZV0pIHtcbiAgICAgIGtub3duRmllbGROYW1lc1t0eXBlTmFtZV0gPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICB9XG4gICAgY29uc3QgZmllbGROb2RlcyA9IChfbm9kZSRmaWVsZHMgPSBub2RlLmZpZWxkcykgIT09IG51bGwgJiYgX25vZGUkZmllbGRzICE9PSB2b2lkIDAgPyBfbm9kZSRmaWVsZHMgOiBbXTtcbiAgICBjb25zdCBmaWVsZE5hbWVzID0ga25vd25GaWVsZE5hbWVzW3R5cGVOYW1lXTtcbiAgICBmb3IgKGNvbnN0IGZpZWxkRGVmIG9mIGZpZWxkTm9kZXMpIHtcbiAgICAgIGNvbnN0IGZpZWxkTmFtZSA9IGZpZWxkRGVmLm5hbWUudmFsdWU7XG4gICAgICBpZiAoaGFzRmllbGQoZXhpc3RpbmdUeXBlTWFwW3R5cGVOYW1lXSwgZmllbGROYW1lKSkge1xuICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgICAgICBgRmllbGQgXCIke3R5cGVOYW1lfS4ke2ZpZWxkTmFtZX1cIiBhbHJlYWR5IGV4aXN0cyBpbiB0aGUgc2NoZW1hLiBJdCBjYW5ub3QgYWxzbyBiZSBkZWZpbmVkIGluIHRoaXMgdHlwZSBleHRlbnNpb24uYCxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbm9kZXM6IGZpZWxkRGVmLm5hbWVcbiAgICAgICAgICAgIH1cbiAgICAgICAgICApXG4gICAgICAgICk7XG4gICAgICB9IGVsc2UgaWYgKGZpZWxkTmFtZXNbZmllbGROYW1lXSkge1xuICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgICAgICBgRmllbGQgXCIke3R5cGVOYW1lfS4ke2ZpZWxkTmFtZX1cIiBjYW4gb25seSBiZSBkZWZpbmVkIG9uY2UuYCxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbm9kZXM6IFtmaWVsZE5hbWVzW2ZpZWxkTmFtZV0sIGZpZWxkRGVmLm5hbWVdXG4gICAgICAgICAgICB9XG4gICAgICAgICAgKVxuICAgICAgICApO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZmllbGROYW1lc1tmaWVsZE5hbWVdID0gZmllbGREZWYubmFtZTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG59XG5mdW5jdGlvbiBoYXNGaWVsZCh0eXBlLCBmaWVsZE5hbWUpIHtcbiAgaWYgKGlzT2JqZWN0VHlwZSh0eXBlKSB8fCBpc0ludGVyZmFjZVR5cGUodHlwZSkgfHwgaXNJbnB1dE9iamVjdFR5cGUodHlwZSkpIHtcbiAgICByZXR1cm4gdHlwZS5nZXRGaWVsZHMoKVtmaWVsZE5hbWVdICE9IG51bGw7XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdmFsaWRhdGlvbi9ydWxlcy9VbmlxdWVGcmFnbWVudE5hbWVzUnVsZS5tanNcbmZ1bmN0aW9uIFVuaXF1ZUZyYWdtZW50TmFtZXNSdWxlKGNvbnRleHQpIHtcbiAgY29uc3Qga25vd25GcmFnbWVudE5hbWVzID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIHJldHVybiB7XG4gICAgT3BlcmF0aW9uRGVmaW5pdGlvbjogKCkgPT4gZmFsc2UsXG4gICAgRnJhZ21lbnREZWZpbml0aW9uKG5vZGUpIHtcbiAgICAgIGNvbnN0IGZyYWdtZW50TmFtZSA9IG5vZGUubmFtZS52YWx1ZTtcbiAgICAgIGlmIChrbm93bkZyYWdtZW50TmFtZXNbZnJhZ21lbnROYW1lXSkge1xuICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgICAgICBgVGhlcmUgY2FuIGJlIG9ubHkgb25lIGZyYWdtZW50IG5hbWVkIFwiJHtmcmFnbWVudE5hbWV9XCIuYCxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbm9kZXM6IFtrbm93bkZyYWdtZW50TmFtZXNbZnJhZ21lbnROYW1lXSwgbm9kZS5uYW1lXVxuICAgICAgICAgICAgfVxuICAgICAgICAgIClcbiAgICAgICAgKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGtub3duRnJhZ21lbnROYW1lc1tmcmFnbWVudE5hbWVdID0gbm9kZS5uYW1lO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgfTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL3ZhbGlkYXRpb24vcnVsZXMvVW5pcXVlSW5wdXRGaWVsZE5hbWVzUnVsZS5tanNcbmZ1bmN0aW9uIFVuaXF1ZUlucHV0RmllbGROYW1lc1J1bGUoY29udGV4dCkge1xuICBjb25zdCBrbm93bk5hbWVTdGFjayA9IFtdO1xuICBsZXQga25vd25OYW1lcyA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICByZXR1cm4ge1xuICAgIE9iamVjdFZhbHVlOiB7XG4gICAgICBlbnRlcigpIHtcbiAgICAgICAga25vd25OYW1lU3RhY2sucHVzaChrbm93bk5hbWVzKTtcbiAgICAgICAga25vd25OYW1lcyA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgICAgfSxcbiAgICAgIGxlYXZlKCkge1xuICAgICAgICBjb25zdCBwcmV2S25vd25OYW1lcyA9IGtub3duTmFtZVN0YWNrLnBvcCgpO1xuICAgICAgICBwcmV2S25vd25OYW1lcyB8fCBpbnZhcmlhbnQyKGZhbHNlKTtcbiAgICAgICAga25vd25OYW1lcyA9IHByZXZLbm93bk5hbWVzO1xuICAgICAgfVxuICAgIH0sXG4gICAgT2JqZWN0RmllbGQobm9kZSkge1xuICAgICAgY29uc3QgZmllbGROYW1lID0gbm9kZS5uYW1lLnZhbHVlO1xuICAgICAgaWYgKGtub3duTmFtZXNbZmllbGROYW1lXSkge1xuICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgICAgICBgVGhlcmUgY2FuIGJlIG9ubHkgb25lIGlucHV0IGZpZWxkIG5hbWVkIFwiJHtmaWVsZE5hbWV9XCIuYCxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbm9kZXM6IFtrbm93bk5hbWVzW2ZpZWxkTmFtZV0sIG5vZGUubmFtZV1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICApXG4gICAgICAgICk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBrbm93bk5hbWVzW2ZpZWxkTmFtZV0gPSBub2RlLm5hbWU7XG4gICAgICB9XG4gICAgfVxuICB9O1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdmFsaWRhdGlvbi9ydWxlcy9VbmlxdWVPcGVyYXRpb25OYW1lc1J1bGUubWpzXG5mdW5jdGlvbiBVbmlxdWVPcGVyYXRpb25OYW1lc1J1bGUoY29udGV4dCkge1xuICBjb25zdCBrbm93bk9wZXJhdGlvbk5hbWVzID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIHJldHVybiB7XG4gICAgT3BlcmF0aW9uRGVmaW5pdGlvbihub2RlKSB7XG4gICAgICBjb25zdCBvcGVyYXRpb25OYW1lID0gbm9kZS5uYW1lO1xuICAgICAgaWYgKG9wZXJhdGlvbk5hbWUpIHtcbiAgICAgICAgaWYgKGtub3duT3BlcmF0aW9uTmFtZXNbb3BlcmF0aW9uTmFtZS52YWx1ZV0pIHtcbiAgICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgICAgICAgYFRoZXJlIGNhbiBiZSBvbmx5IG9uZSBvcGVyYXRpb24gbmFtZWQgXCIke29wZXJhdGlvbk5hbWUudmFsdWV9XCIuYCxcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIG5vZGVzOiBbXG4gICAgICAgICAgICAgICAgICBrbm93bk9wZXJhdGlvbk5hbWVzW29wZXJhdGlvbk5hbWUudmFsdWVdLFxuICAgICAgICAgICAgICAgICAgb3BlcmF0aW9uTmFtZVxuICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgKVxuICAgICAgICAgICk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAga25vd25PcGVyYXRpb25OYW1lc1tvcGVyYXRpb25OYW1lLnZhbHVlXSA9IG9wZXJhdGlvbk5hbWU7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9LFxuICAgIEZyYWdtZW50RGVmaW5pdGlvbjogKCkgPT4gZmFsc2VcbiAgfTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL3ZhbGlkYXRpb24vcnVsZXMvVW5pcXVlT3BlcmF0aW9uVHlwZXNSdWxlLm1qc1xuZnVuY3Rpb24gVW5pcXVlT3BlcmF0aW9uVHlwZXNSdWxlKGNvbnRleHQpIHtcbiAgY29uc3Qgc2NoZW1hID0gY29udGV4dC5nZXRTY2hlbWEoKTtcbiAgY29uc3QgZGVmaW5lZE9wZXJhdGlvblR5cGVzID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIGNvbnN0IGV4aXN0aW5nT3BlcmF0aW9uVHlwZXMgPSBzY2hlbWEgPyB7XG4gICAgcXVlcnk6IHNjaGVtYS5nZXRRdWVyeVR5cGUoKSxcbiAgICBtdXRhdGlvbjogc2NoZW1hLmdldE11dGF0aW9uVHlwZSgpLFxuICAgIHN1YnNjcmlwdGlvbjogc2NoZW1hLmdldFN1YnNjcmlwdGlvblR5cGUoKVxuICB9IDoge307XG4gIHJldHVybiB7XG4gICAgU2NoZW1hRGVmaW5pdGlvbjogY2hlY2tPcGVyYXRpb25UeXBlcyxcbiAgICBTY2hlbWFFeHRlbnNpb246IGNoZWNrT3BlcmF0aW9uVHlwZXNcbiAgfTtcbiAgZnVuY3Rpb24gY2hlY2tPcGVyYXRpb25UeXBlcyhub2RlKSB7XG4gICAgdmFyIF9ub2RlJG9wZXJhdGlvblR5cGVzO1xuICAgIGNvbnN0IG9wZXJhdGlvblR5cGVzTm9kZXMgPSAoX25vZGUkb3BlcmF0aW9uVHlwZXMgPSBub2RlLm9wZXJhdGlvblR5cGVzKSAhPT0gbnVsbCAmJiBfbm9kZSRvcGVyYXRpb25UeXBlcyAhPT0gdm9pZCAwID8gX25vZGUkb3BlcmF0aW9uVHlwZXMgOiBbXTtcbiAgICBmb3IgKGNvbnN0IG9wZXJhdGlvblR5cGUgb2Ygb3BlcmF0aW9uVHlwZXNOb2Rlcykge1xuICAgICAgY29uc3Qgb3BlcmF0aW9uID0gb3BlcmF0aW9uVHlwZS5vcGVyYXRpb247XG4gICAgICBjb25zdCBhbHJlYWR5RGVmaW5lZE9wZXJhdGlvblR5cGUgPSBkZWZpbmVkT3BlcmF0aW9uVHlwZXNbb3BlcmF0aW9uXTtcbiAgICAgIGlmIChleGlzdGluZ09wZXJhdGlvblR5cGVzW29wZXJhdGlvbl0pIHtcbiAgICAgICAgY29udGV4dC5yZXBvcnRFcnJvcihcbiAgICAgICAgICBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICAgICAgYFR5cGUgZm9yICR7b3BlcmF0aW9ufSBhbHJlYWR5IGRlZmluZWQgaW4gdGhlIHNjaGVtYS4gSXQgY2Fubm90IGJlIHJlZGVmaW5lZC5gLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBub2Rlczogb3BlcmF0aW9uVHlwZVxuICAgICAgICAgICAgfVxuICAgICAgICAgIClcbiAgICAgICAgKTtcbiAgICAgIH0gZWxzZSBpZiAoYWxyZWFkeURlZmluZWRPcGVyYXRpb25UeXBlKSB7XG4gICAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgICAgIGBUaGVyZSBjYW4gYmUgb25seSBvbmUgJHtvcGVyYXRpb259IHR5cGUgaW4gc2NoZW1hLmAsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5vZGVzOiBbYWxyZWFkeURlZmluZWRPcGVyYXRpb25UeXBlLCBvcGVyYXRpb25UeXBlXVxuICAgICAgICAgICAgfVxuICAgICAgICAgIClcbiAgICAgICAgKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGRlZmluZWRPcGVyYXRpb25UeXBlc1tvcGVyYXRpb25dID0gb3BlcmF0aW9uVHlwZTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC92YWxpZGF0aW9uL3J1bGVzL1VuaXF1ZVR5cGVOYW1lc1J1bGUubWpzXG5mdW5jdGlvbiBVbmlxdWVUeXBlTmFtZXNSdWxlKGNvbnRleHQpIHtcbiAgY29uc3Qga25vd25UeXBlTmFtZXMgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgY29uc3Qgc2NoZW1hID0gY29udGV4dC5nZXRTY2hlbWEoKTtcbiAgcmV0dXJuIHtcbiAgICBTY2FsYXJUeXBlRGVmaW5pdGlvbjogY2hlY2tUeXBlTmFtZSxcbiAgICBPYmplY3RUeXBlRGVmaW5pdGlvbjogY2hlY2tUeXBlTmFtZSxcbiAgICBJbnRlcmZhY2VUeXBlRGVmaW5pdGlvbjogY2hlY2tUeXBlTmFtZSxcbiAgICBVbmlvblR5cGVEZWZpbml0aW9uOiBjaGVja1R5cGVOYW1lLFxuICAgIEVudW1UeXBlRGVmaW5pdGlvbjogY2hlY2tUeXBlTmFtZSxcbiAgICBJbnB1dE9iamVjdFR5cGVEZWZpbml0aW9uOiBjaGVja1R5cGVOYW1lXG4gIH07XG4gIGZ1bmN0aW9uIGNoZWNrVHlwZU5hbWUobm9kZSkge1xuICAgIGNvbnN0IHR5cGVOYW1lID0gbm9kZS5uYW1lLnZhbHVlO1xuICAgIGlmIChzY2hlbWEgIT09IG51bGwgJiYgc2NoZW1hICE9PSB2b2lkIDAgJiYgc2NoZW1hLmdldFR5cGUodHlwZU5hbWUpKSB7XG4gICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICAgIGBUeXBlIFwiJHt0eXBlTmFtZX1cIiBhbHJlYWR5IGV4aXN0cyBpbiB0aGUgc2NoZW1hLiBJdCBjYW5ub3QgYWxzbyBiZSBkZWZpbmVkIGluIHRoaXMgdHlwZSBkZWZpbml0aW9uLmAsXG4gICAgICAgICAge1xuICAgICAgICAgICAgbm9kZXM6IG5vZGUubmFtZVxuICAgICAgICAgIH1cbiAgICAgICAgKVxuICAgICAgKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKGtub3duVHlwZU5hbWVzW3R5cGVOYW1lXSkge1xuICAgICAgY29udGV4dC5yZXBvcnRFcnJvcihcbiAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihgVGhlcmUgY2FuIGJlIG9ubHkgb25lIHR5cGUgbmFtZWQgXCIke3R5cGVOYW1lfVwiLmAsIHtcbiAgICAgICAgICBub2RlczogW2tub3duVHlwZU5hbWVzW3R5cGVOYW1lXSwgbm9kZS5uYW1lXVxuICAgICAgICB9KVxuICAgICAgKTtcbiAgICB9IGVsc2Uge1xuICAgICAga25vd25UeXBlTmFtZXNbdHlwZU5hbWVdID0gbm9kZS5uYW1lO1xuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL3ZhbGlkYXRpb24vcnVsZXMvVW5pcXVlVmFyaWFibGVOYW1lc1J1bGUubWpzXG5mdW5jdGlvbiBVbmlxdWVWYXJpYWJsZU5hbWVzUnVsZShjb250ZXh0KSB7XG4gIHJldHVybiB7XG4gICAgT3BlcmF0aW9uRGVmaW5pdGlvbihvcGVyYXRpb25Ob2RlKSB7XG4gICAgICB2YXIgX29wZXJhdGlvbk5vZGUkdmFyaWFiO1xuICAgICAgY29uc3QgdmFyaWFibGVEZWZpbml0aW9ucyA9IChfb3BlcmF0aW9uTm9kZSR2YXJpYWIgPSBvcGVyYXRpb25Ob2RlLnZhcmlhYmxlRGVmaW5pdGlvbnMpICE9PSBudWxsICYmIF9vcGVyYXRpb25Ob2RlJHZhcmlhYiAhPT0gdm9pZCAwID8gX29wZXJhdGlvbk5vZGUkdmFyaWFiIDogW107XG4gICAgICBjb25zdCBzZWVuVmFyaWFibGVEZWZpbml0aW9ucyA9IGdyb3VwQnkoXG4gICAgICAgIHZhcmlhYmxlRGVmaW5pdGlvbnMsXG4gICAgICAgIChub2RlKSA9PiBub2RlLnZhcmlhYmxlLm5hbWUudmFsdWVcbiAgICAgICk7XG4gICAgICBmb3IgKGNvbnN0IFt2YXJpYWJsZU5hbWUsIHZhcmlhYmxlTm9kZXNdIG9mIHNlZW5WYXJpYWJsZURlZmluaXRpb25zKSB7XG4gICAgICAgIGlmICh2YXJpYWJsZU5vZGVzLmxlbmd0aCA+IDEpIHtcbiAgICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgICAgICAgYFRoZXJlIGNhbiBiZSBvbmx5IG9uZSB2YXJpYWJsZSBuYW1lZCBcIiQke3ZhcmlhYmxlTmFtZX1cIi5gLFxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgbm9kZXM6IHZhcmlhYmxlTm9kZXMubWFwKChub2RlKSA9PiBub2RlLnZhcmlhYmxlLm5hbWUpXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIClcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9O1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdmFsaWRhdGlvbi9ydWxlcy9WYWx1ZXNPZkNvcnJlY3RUeXBlUnVsZS5tanNcbmZ1bmN0aW9uIFZhbHVlc09mQ29ycmVjdFR5cGVSdWxlKGNvbnRleHQpIHtcbiAgcmV0dXJuIHtcbiAgICBMaXN0VmFsdWUobm9kZSkge1xuICAgICAgY29uc3QgdHlwZSA9IGdldE51bGxhYmxlVHlwZShjb250ZXh0LmdldFBhcmVudElucHV0VHlwZSgpKTtcbiAgICAgIGlmICghaXNMaXN0VHlwZSh0eXBlKSkge1xuICAgICAgICBpc1ZhbGlkVmFsdWVOb2RlKGNvbnRleHQsIG5vZGUpO1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgfSxcbiAgICBPYmplY3RWYWx1ZShub2RlKSB7XG4gICAgICBjb25zdCB0eXBlID0gZ2V0TmFtZWRUeXBlKGNvbnRleHQuZ2V0SW5wdXRUeXBlKCkpO1xuICAgICAgaWYgKCFpc0lucHV0T2JqZWN0VHlwZSh0eXBlKSkge1xuICAgICAgICBpc1ZhbGlkVmFsdWVOb2RlKGNvbnRleHQsIG5vZGUpO1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgICBjb25zdCBmaWVsZE5vZGVNYXAgPSBrZXlNYXAobm9kZS5maWVsZHMsIChmaWVsZCkgPT4gZmllbGQubmFtZS52YWx1ZSk7XG4gICAgICBmb3IgKGNvbnN0IGZpZWxkRGVmIG9mIE9iamVjdC52YWx1ZXModHlwZS5nZXRGaWVsZHMoKSkpIHtcbiAgICAgICAgY29uc3QgZmllbGROb2RlID0gZmllbGROb2RlTWFwW2ZpZWxkRGVmLm5hbWVdO1xuICAgICAgICBpZiAoIWZpZWxkTm9kZSAmJiBpc1JlcXVpcmVkSW5wdXRGaWVsZChmaWVsZERlZikpIHtcbiAgICAgICAgICBjb25zdCB0eXBlU3RyID0gaW5zcGVjdChmaWVsZERlZi50eXBlKTtcbiAgICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgICAgICAgYEZpZWxkIFwiJHt0eXBlLm5hbWV9LiR7ZmllbGREZWYubmFtZX1cIiBvZiByZXF1aXJlZCB0eXBlIFwiJHt0eXBlU3RyfVwiIHdhcyBub3QgcHJvdmlkZWQuYCxcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIG5vZGVzOiBub2RlXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIClcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSxcbiAgICBPYmplY3RGaWVsZChub2RlKSB7XG4gICAgICBjb25zdCBwYXJlbnRUeXBlID0gZ2V0TmFtZWRUeXBlKGNvbnRleHQuZ2V0UGFyZW50SW5wdXRUeXBlKCkpO1xuICAgICAgY29uc3QgZmllbGRUeXBlID0gY29udGV4dC5nZXRJbnB1dFR5cGUoKTtcbiAgICAgIGlmICghZmllbGRUeXBlICYmIGlzSW5wdXRPYmplY3RUeXBlKHBhcmVudFR5cGUpKSB7XG4gICAgICAgIGNvbnN0IHN1Z2dlc3Rpb25zID0gc3VnZ2VzdGlvbkxpc3QoXG4gICAgICAgICAgbm9kZS5uYW1lLnZhbHVlLFxuICAgICAgICAgIE9iamVjdC5rZXlzKHBhcmVudFR5cGUuZ2V0RmllbGRzKCkpXG4gICAgICAgICk7XG4gICAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgICAgIGBGaWVsZCBcIiR7bm9kZS5uYW1lLnZhbHVlfVwiIGlzIG5vdCBkZWZpbmVkIGJ5IHR5cGUgXCIke3BhcmVudFR5cGUubmFtZX1cIi5gICsgZGlkWW91TWVhbihzdWdnZXN0aW9ucyksXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5vZGVzOiBub2RlXG4gICAgICAgICAgICB9XG4gICAgICAgICAgKVxuICAgICAgICApO1xuICAgICAgfVxuICAgIH0sXG4gICAgTnVsbFZhbHVlKG5vZGUpIHtcbiAgICAgIGNvbnN0IHR5cGUgPSBjb250ZXh0LmdldElucHV0VHlwZSgpO1xuICAgICAgaWYgKGlzTm9uTnVsbFR5cGUodHlwZSkpIHtcbiAgICAgICAgY29udGV4dC5yZXBvcnRFcnJvcihcbiAgICAgICAgICBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICAgICAgYEV4cGVjdGVkIHZhbHVlIG9mIHR5cGUgXCIke2luc3BlY3QodHlwZSl9XCIsIGZvdW5kICR7cHJpbnQobm9kZSl9LmAsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5vZGVzOiBub2RlXG4gICAgICAgICAgICB9XG4gICAgICAgICAgKVxuICAgICAgICApO1xuICAgICAgfVxuICAgIH0sXG4gICAgRW51bVZhbHVlOiAobm9kZSkgPT4gaXNWYWxpZFZhbHVlTm9kZShjb250ZXh0LCBub2RlKSxcbiAgICBJbnRWYWx1ZTogKG5vZGUpID0+IGlzVmFsaWRWYWx1ZU5vZGUoY29udGV4dCwgbm9kZSksXG4gICAgRmxvYXRWYWx1ZTogKG5vZGUpID0+IGlzVmFsaWRWYWx1ZU5vZGUoY29udGV4dCwgbm9kZSksXG4gICAgU3RyaW5nVmFsdWU6IChub2RlKSA9PiBpc1ZhbGlkVmFsdWVOb2RlKGNvbnRleHQsIG5vZGUpLFxuICAgIEJvb2xlYW5WYWx1ZTogKG5vZGUpID0+IGlzVmFsaWRWYWx1ZU5vZGUoY29udGV4dCwgbm9kZSlcbiAgfTtcbn1cbmZ1bmN0aW9uIGlzVmFsaWRWYWx1ZU5vZGUoY29udGV4dCwgbm9kZSkge1xuICBjb25zdCBsb2NhdGlvblR5cGUgPSBjb250ZXh0LmdldElucHV0VHlwZSgpO1xuICBpZiAoIWxvY2F0aW9uVHlwZSkge1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCB0eXBlID0gZ2V0TmFtZWRUeXBlKGxvY2F0aW9uVHlwZSk7XG4gIGlmICghaXNMZWFmVHlwZSh0eXBlKSkge1xuICAgIGNvbnN0IHR5cGVTdHIgPSBpbnNwZWN0KGxvY2F0aW9uVHlwZSk7XG4gICAgY29udGV4dC5yZXBvcnRFcnJvcihcbiAgICAgIG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgIGBFeHBlY3RlZCB2YWx1ZSBvZiB0eXBlIFwiJHt0eXBlU3RyfVwiLCBmb3VuZCAke3ByaW50KG5vZGUpfS5gLFxuICAgICAgICB7XG4gICAgICAgICAgbm9kZXM6IG5vZGVcbiAgICAgICAgfVxuICAgICAgKVxuICAgICk7XG4gICAgcmV0dXJuO1xuICB9XG4gIHRyeSB7XG4gICAgY29uc3QgcGFyc2VSZXN1bHQgPSB0eXBlLnBhcnNlTGl0ZXJhbChcbiAgICAgIG5vZGUsXG4gICAgICB2b2lkIDBcbiAgICAgIC8qIHZhcmlhYmxlcyAqL1xuICAgICk7XG4gICAgaWYgKHBhcnNlUmVzdWx0ID09PSB2b2lkIDApIHtcbiAgICAgIGNvbnN0IHR5cGVTdHIgPSBpbnNwZWN0KGxvY2F0aW9uVHlwZSk7XG4gICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICAgIGBFeHBlY3RlZCB2YWx1ZSBvZiB0eXBlIFwiJHt0eXBlU3RyfVwiLCBmb3VuZCAke3ByaW50KG5vZGUpfS5gLFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIG5vZGVzOiBub2RlXG4gICAgICAgICAgfVxuICAgICAgICApXG4gICAgICApO1xuICAgIH1cbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zdCB0eXBlU3RyID0gaW5zcGVjdChsb2NhdGlvblR5cGUpO1xuICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIEdyYXBoUUxFcnJvcikge1xuICAgICAgY29udGV4dC5yZXBvcnRFcnJvcihlcnJvcik7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgICAgYEV4cGVjdGVkIHZhbHVlIG9mIHR5cGUgXCIke3R5cGVTdHJ9XCIsIGZvdW5kICR7cHJpbnQobm9kZSl9OyBgICsgZXJyb3IubWVzc2FnZSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBub2Rlczogbm9kZSxcbiAgICAgICAgICAgIG9yaWdpbmFsRXJyb3I6IGVycm9yXG4gICAgICAgICAgfVxuICAgICAgICApXG4gICAgICApO1xuICAgIH1cbiAgfVxufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdmFsaWRhdGlvbi9ydWxlcy9WYXJpYWJsZXNBcmVJbnB1dFR5cGVzUnVsZS5tanNcbmZ1bmN0aW9uIFZhcmlhYmxlc0FyZUlucHV0VHlwZXNSdWxlKGNvbnRleHQpIHtcbiAgcmV0dXJuIHtcbiAgICBWYXJpYWJsZURlZmluaXRpb24obm9kZSkge1xuICAgICAgY29uc3QgdHlwZSA9IHR5cGVGcm9tQVNUKGNvbnRleHQuZ2V0U2NoZW1hKCksIG5vZGUudHlwZSk7XG4gICAgICBpZiAodHlwZSAhPT0gdm9pZCAwICYmICFpc0lucHV0VHlwZSh0eXBlKSkge1xuICAgICAgICBjb25zdCB2YXJpYWJsZU5hbWUgPSBub2RlLnZhcmlhYmxlLm5hbWUudmFsdWU7XG4gICAgICAgIGNvbnN0IHR5cGVOYW1lID0gcHJpbnQobm9kZS50eXBlKTtcbiAgICAgICAgY29udGV4dC5yZXBvcnRFcnJvcihcbiAgICAgICAgICBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICAgICAgYFZhcmlhYmxlIFwiJCR7dmFyaWFibGVOYW1lfVwiIGNhbm5vdCBiZSBub24taW5wdXQgdHlwZSBcIiR7dHlwZU5hbWV9XCIuYCxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbm9kZXM6IG5vZGUudHlwZVxuICAgICAgICAgICAgfVxuICAgICAgICAgIClcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG4gIH07XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC92YWxpZGF0aW9uL3J1bGVzL1ZhcmlhYmxlc0luQWxsb3dlZFBvc2l0aW9uUnVsZS5tanNcbmZ1bmN0aW9uIFZhcmlhYmxlc0luQWxsb3dlZFBvc2l0aW9uUnVsZShjb250ZXh0KSB7XG4gIGxldCB2YXJEZWZNYXAgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgcmV0dXJuIHtcbiAgICBPcGVyYXRpb25EZWZpbml0aW9uOiB7XG4gICAgICBlbnRlcigpIHtcbiAgICAgICAgdmFyRGVmTWFwID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgICB9LFxuICAgICAgbGVhdmUob3BlcmF0aW9uKSB7XG4gICAgICAgIGNvbnN0IHVzYWdlcyA9IGNvbnRleHQuZ2V0UmVjdXJzaXZlVmFyaWFibGVVc2FnZXMob3BlcmF0aW9uKTtcbiAgICAgICAgZm9yIChjb25zdCB7IG5vZGUsIHR5cGUsIGRlZmF1bHRWYWx1ZSB9IG9mIHVzYWdlcykge1xuICAgICAgICAgIGNvbnN0IHZhck5hbWUgPSBub2RlLm5hbWUudmFsdWU7XG4gICAgICAgICAgY29uc3QgdmFyRGVmID0gdmFyRGVmTWFwW3Zhck5hbWVdO1xuICAgICAgICAgIGlmICh2YXJEZWYgJiYgdHlwZSkge1xuICAgICAgICAgICAgY29uc3Qgc2NoZW1hID0gY29udGV4dC5nZXRTY2hlbWEoKTtcbiAgICAgICAgICAgIGNvbnN0IHZhclR5cGUgPSB0eXBlRnJvbUFTVChzY2hlbWEsIHZhckRlZi50eXBlKTtcbiAgICAgICAgICAgIGlmICh2YXJUeXBlICYmICFhbGxvd2VkVmFyaWFibGVVc2FnZShcbiAgICAgICAgICAgICAgc2NoZW1hLFxuICAgICAgICAgICAgICB2YXJUeXBlLFxuICAgICAgICAgICAgICB2YXJEZWYuZGVmYXVsdFZhbHVlLFxuICAgICAgICAgICAgICB0eXBlLFxuICAgICAgICAgICAgICBkZWZhdWx0VmFsdWVcbiAgICAgICAgICAgICkpIHtcbiAgICAgICAgICAgICAgY29uc3QgdmFyVHlwZVN0ciA9IGluc3BlY3QodmFyVHlwZSk7XG4gICAgICAgICAgICAgIGNvbnN0IHR5cGVTdHIgPSBpbnNwZWN0KHR5cGUpO1xuICAgICAgICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgICAgICAgICAgICBgVmFyaWFibGUgXCIkJHt2YXJOYW1lfVwiIG9mIHR5cGUgXCIke3ZhclR5cGVTdHJ9XCIgdXNlZCBpbiBwb3NpdGlvbiBleHBlY3RpbmcgdHlwZSBcIiR7dHlwZVN0cn1cIi5gLFxuICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBub2RlczogW3ZhckRlZiwgbm9kZV1cbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSxcbiAgICBWYXJpYWJsZURlZmluaXRpb24obm9kZSkge1xuICAgICAgdmFyRGVmTWFwW25vZGUudmFyaWFibGUubmFtZS52YWx1ZV0gPSBub2RlO1xuICAgIH1cbiAgfTtcbn1cbmZ1bmN0aW9uIGFsbG93ZWRWYXJpYWJsZVVzYWdlKHNjaGVtYSwgdmFyVHlwZSwgdmFyRGVmYXVsdFZhbHVlLCBsb2NhdGlvblR5cGUsIGxvY2F0aW9uRGVmYXVsdFZhbHVlKSB7XG4gIGlmIChpc05vbk51bGxUeXBlKGxvY2F0aW9uVHlwZSkgJiYgIWlzTm9uTnVsbFR5cGUodmFyVHlwZSkpIHtcbiAgICBjb25zdCBoYXNOb25OdWxsVmFyaWFibGVEZWZhdWx0VmFsdWUgPSB2YXJEZWZhdWx0VmFsdWUgIT0gbnVsbCAmJiB2YXJEZWZhdWx0VmFsdWUua2luZCAhPT0gS2luZC5OVUxMO1xuICAgIGNvbnN0IGhhc0xvY2F0aW9uRGVmYXVsdFZhbHVlID0gbG9jYXRpb25EZWZhdWx0VmFsdWUgIT09IHZvaWQgMDtcbiAgICBpZiAoIWhhc05vbk51bGxWYXJpYWJsZURlZmF1bHRWYWx1ZSAmJiAhaGFzTG9jYXRpb25EZWZhdWx0VmFsdWUpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgY29uc3QgbnVsbGFibGVMb2NhdGlvblR5cGUgPSBsb2NhdGlvblR5cGUub2ZUeXBlO1xuICAgIHJldHVybiBpc1R5cGVTdWJUeXBlT2Yoc2NoZW1hLCB2YXJUeXBlLCBudWxsYWJsZUxvY2F0aW9uVHlwZSk7XG4gIH1cbiAgcmV0dXJuIGlzVHlwZVN1YlR5cGVPZihzY2hlbWEsIHZhclR5cGUsIGxvY2F0aW9uVHlwZSk7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC92YWxpZGF0aW9uL3NwZWNpZmllZFJ1bGVzLm1qc1xudmFyIHNwZWNpZmllZFJ1bGVzID0gT2JqZWN0LmZyZWV6ZShbXG4gIEV4ZWN1dGFibGVEZWZpbml0aW9uc1J1bGUsXG4gIFVuaXF1ZU9wZXJhdGlvbk5hbWVzUnVsZSxcbiAgTG9uZUFub255bW91c09wZXJhdGlvblJ1bGUsXG4gIFNpbmdsZUZpZWxkU3Vic2NyaXB0aW9uc1J1bGUsXG4gIEtub3duVHlwZU5hbWVzUnVsZSxcbiAgRnJhZ21lbnRzT25Db21wb3NpdGVUeXBlc1J1bGUsXG4gIFZhcmlhYmxlc0FyZUlucHV0VHlwZXNSdWxlLFxuICBTY2FsYXJMZWFmc1J1bGUsXG4gIEZpZWxkc09uQ29ycmVjdFR5cGVSdWxlLFxuICBVbmlxdWVGcmFnbWVudE5hbWVzUnVsZSxcbiAgS25vd25GcmFnbWVudE5hbWVzUnVsZSxcbiAgTm9VbnVzZWRGcmFnbWVudHNSdWxlLFxuICBQb3NzaWJsZUZyYWdtZW50U3ByZWFkc1J1bGUsXG4gIE5vRnJhZ21lbnRDeWNsZXNSdWxlLFxuICBVbmlxdWVWYXJpYWJsZU5hbWVzUnVsZSxcbiAgTm9VbmRlZmluZWRWYXJpYWJsZXNSdWxlLFxuICBOb1VudXNlZFZhcmlhYmxlc1J1bGUsXG4gIEtub3duRGlyZWN0aXZlc1J1bGUsXG4gIFVuaXF1ZURpcmVjdGl2ZXNQZXJMb2NhdGlvblJ1bGUsXG4gIEtub3duQXJndW1lbnROYW1lc1J1bGUsXG4gIFVuaXF1ZUFyZ3VtZW50TmFtZXNSdWxlLFxuICBWYWx1ZXNPZkNvcnJlY3RUeXBlUnVsZSxcbiAgUHJvdmlkZWRSZXF1aXJlZEFyZ3VtZW50c1J1bGUsXG4gIFZhcmlhYmxlc0luQWxsb3dlZFBvc2l0aW9uUnVsZSxcbiAgT3ZlcmxhcHBpbmdGaWVsZHNDYW5CZU1lcmdlZFJ1bGUsXG4gIFVuaXF1ZUlucHV0RmllbGROYW1lc1J1bGVcbl0pO1xudmFyIHNwZWNpZmllZFNETFJ1bGVzID0gT2JqZWN0LmZyZWV6ZShbXG4gIExvbmVTY2hlbWFEZWZpbml0aW9uUnVsZSxcbiAgVW5pcXVlT3BlcmF0aW9uVHlwZXNSdWxlLFxuICBVbmlxdWVUeXBlTmFtZXNSdWxlLFxuICBVbmlxdWVFbnVtVmFsdWVOYW1lc1J1bGUsXG4gIFVuaXF1ZUZpZWxkRGVmaW5pdGlvbk5hbWVzUnVsZSxcbiAgVW5pcXVlQXJndW1lbnREZWZpbml0aW9uTmFtZXNSdWxlLFxuICBVbmlxdWVEaXJlY3RpdmVOYW1lc1J1bGUsXG4gIEtub3duVHlwZU5hbWVzUnVsZSxcbiAgS25vd25EaXJlY3RpdmVzUnVsZSxcbiAgVW5pcXVlRGlyZWN0aXZlc1BlckxvY2F0aW9uUnVsZSxcbiAgUG9zc2libGVUeXBlRXh0ZW5zaW9uc1J1bGUsXG4gIEtub3duQXJndW1lbnROYW1lc09uRGlyZWN0aXZlc1J1bGUsXG4gIFVuaXF1ZUFyZ3VtZW50TmFtZXNSdWxlLFxuICBVbmlxdWVJbnB1dEZpZWxkTmFtZXNSdWxlLFxuICBQcm92aWRlZFJlcXVpcmVkQXJndW1lbnRzT25EaXJlY3RpdmVzUnVsZVxuXSk7XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC9qc3V0aWxzL21lbW9pemUzLm1qc1xuZnVuY3Rpb24gbWVtb2l6ZTMoZm4pIHtcbiAgbGV0IGNhY2hlMDtcbiAgcmV0dXJuIGZ1bmN0aW9uIG1lbW9pemVkKGExLCBhMiwgYTMpIHtcbiAgICBpZiAoY2FjaGUwID09PSB2b2lkIDApIHtcbiAgICAgIGNhY2hlMCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha01hcCgpO1xuICAgIH1cbiAgICBsZXQgY2FjaGUxID0gY2FjaGUwLmdldChhMSk7XG4gICAgaWYgKGNhY2hlMSA9PT0gdm9pZCAwKSB7XG4gICAgICBjYWNoZTEgPSAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKTtcbiAgICAgIGNhY2hlMC5zZXQoYTEsIGNhY2hlMSk7XG4gICAgfVxuICAgIGxldCBjYWNoZTIgPSBjYWNoZTEuZ2V0KGEyKTtcbiAgICBpZiAoY2FjaGUyID09PSB2b2lkIDApIHtcbiAgICAgIGNhY2hlMiA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha01hcCgpO1xuICAgICAgY2FjaGUxLnNldChhMiwgY2FjaGUyKTtcbiAgICB9XG4gICAgbGV0IGZuUmVzdWx0ID0gY2FjaGUyLmdldChhMyk7XG4gICAgaWYgKGZuUmVzdWx0ID09PSB2b2lkIDApIHtcbiAgICAgIGZuUmVzdWx0ID0gZm4oYTEsIGEyLCBhMyk7XG4gICAgICBjYWNoZTIuc2V0KGEzLCBmblJlc3VsdCk7XG4gICAgfVxuICAgIHJldHVybiBmblJlc3VsdDtcbiAgfTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL2V4ZWN1dGlvbi9leGVjdXRlLm1qc1xudmFyIGNvbGxlY3RTdWJmaWVsZHMyID0gbWVtb2l6ZTMoXG4gIChleGVDb250ZXh0LCByZXR1cm5UeXBlLCBmaWVsZE5vZGVzKSA9PiBjb2xsZWN0U3ViZmllbGRzKFxuICAgIGV4ZUNvbnRleHQuc2NoZW1hLFxuICAgIGV4ZUNvbnRleHQuZnJhZ21lbnRzLFxuICAgIGV4ZUNvbnRleHQudmFyaWFibGVWYWx1ZXMsXG4gICAgcmV0dXJuVHlwZSxcbiAgICBmaWVsZE5vZGVzXG4gIClcbik7XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC91dGlsaXRpZXMvZXh0ZW5kU2NoZW1hLm1qc1xudmFyIHN0ZFR5cGVNYXAgPSBrZXlNYXAoXG4gIFsuLi5zcGVjaWZpZWRTY2FsYXJUeXBlcywgLi4uaW50cm9zcGVjdGlvblR5cGVzXSxcbiAgKHR5cGUpID0+IHR5cGUubmFtZVxuKTtcblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL3V0aWxpdGllcy9maW5kQnJlYWtpbmdDaGFuZ2VzLm1qc1xudmFyIEJyZWFraW5nQ2hhbmdlVHlwZTtcbihmdW5jdGlvbihCcmVha2luZ0NoYW5nZVR5cGUyKSB7XG4gIEJyZWFraW5nQ2hhbmdlVHlwZTJbXCJUWVBFX1JFTU9WRURcIl0gPSBcIlRZUEVfUkVNT1ZFRFwiO1xuICBCcmVha2luZ0NoYW5nZVR5cGUyW1wiVFlQRV9DSEFOR0VEX0tJTkRcIl0gPSBcIlRZUEVfQ0hBTkdFRF9LSU5EXCI7XG4gIEJyZWFraW5nQ2hhbmdlVHlwZTJbXCJUWVBFX1JFTU9WRURfRlJPTV9VTklPTlwiXSA9IFwiVFlQRV9SRU1PVkVEX0ZST01fVU5JT05cIjtcbiAgQnJlYWtpbmdDaGFuZ2VUeXBlMltcIlZBTFVFX1JFTU9WRURfRlJPTV9FTlVNXCJdID0gXCJWQUxVRV9SRU1PVkVEX0ZST01fRU5VTVwiO1xuICBCcmVha2luZ0NoYW5nZVR5cGUyW1wiUkVRVUlSRURfSU5QVVRfRklFTERfQURERURcIl0gPSBcIlJFUVVJUkVEX0lOUFVUX0ZJRUxEX0FEREVEXCI7XG4gIEJyZWFraW5nQ2hhbmdlVHlwZTJbXCJJTVBMRU1FTlRFRF9JTlRFUkZBQ0VfUkVNT1ZFRFwiXSA9IFwiSU1QTEVNRU5URURfSU5URVJGQUNFX1JFTU9WRURcIjtcbiAgQnJlYWtpbmdDaGFuZ2VUeXBlMltcIkZJRUxEX1JFTU9WRURcIl0gPSBcIkZJRUxEX1JFTU9WRURcIjtcbiAgQnJlYWtpbmdDaGFuZ2VUeXBlMltcIkZJRUxEX0NIQU5HRURfS0lORFwiXSA9IFwiRklFTERfQ0hBTkdFRF9LSU5EXCI7XG4gIEJyZWFraW5nQ2hhbmdlVHlwZTJbXCJSRVFVSVJFRF9BUkdfQURERURcIl0gPSBcIlJFUVVJUkVEX0FSR19BRERFRFwiO1xuICBCcmVha2luZ0NoYW5nZVR5cGUyW1wiQVJHX1JFTU9WRURcIl0gPSBcIkFSR19SRU1PVkVEXCI7XG4gIEJyZWFraW5nQ2hhbmdlVHlwZTJbXCJBUkdfQ0hBTkdFRF9LSU5EXCJdID0gXCJBUkdfQ0hBTkdFRF9LSU5EXCI7XG4gIEJyZWFraW5nQ2hhbmdlVHlwZTJbXCJESVJFQ1RJVkVfUkVNT1ZFRFwiXSA9IFwiRElSRUNUSVZFX1JFTU9WRURcIjtcbiAgQnJlYWtpbmdDaGFuZ2VUeXBlMltcIkRJUkVDVElWRV9BUkdfUkVNT1ZFRFwiXSA9IFwiRElSRUNUSVZFX0FSR19SRU1PVkVEXCI7XG4gIEJyZWFraW5nQ2hhbmdlVHlwZTJbXCJSRVFVSVJFRF9ESVJFQ1RJVkVfQVJHX0FEREVEXCJdID0gXCJSRVFVSVJFRF9ESVJFQ1RJVkVfQVJHX0FEREVEXCI7XG4gIEJyZWFraW5nQ2hhbmdlVHlwZTJbXCJESVJFQ1RJVkVfUkVQRUFUQUJMRV9SRU1PVkVEXCJdID0gXCJESVJFQ1RJVkVfUkVQRUFUQUJMRV9SRU1PVkVEXCI7XG4gIEJyZWFraW5nQ2hhbmdlVHlwZTJbXCJESVJFQ1RJVkVfTE9DQVRJT05fUkVNT1ZFRFwiXSA9IFwiRElSRUNUSVZFX0xPQ0FUSU9OX1JFTU9WRURcIjtcbn0pKEJyZWFraW5nQ2hhbmdlVHlwZSB8fCAoQnJlYWtpbmdDaGFuZ2VUeXBlID0ge30pKTtcbnZhciBEYW5nZXJvdXNDaGFuZ2VUeXBlO1xuKGZ1bmN0aW9uKERhbmdlcm91c0NoYW5nZVR5cGUyKSB7XG4gIERhbmdlcm91c0NoYW5nZVR5cGUyW1wiVkFMVUVfQURERURfVE9fRU5VTVwiXSA9IFwiVkFMVUVfQURERURfVE9fRU5VTVwiO1xuICBEYW5nZXJvdXNDaGFuZ2VUeXBlMltcIlRZUEVfQURERURfVE9fVU5JT05cIl0gPSBcIlRZUEVfQURERURfVE9fVU5JT05cIjtcbiAgRGFuZ2Vyb3VzQ2hhbmdlVHlwZTJbXCJPUFRJT05BTF9JTlBVVF9GSUVMRF9BRERFRFwiXSA9IFwiT1BUSU9OQUxfSU5QVVRfRklFTERfQURERURcIjtcbiAgRGFuZ2Vyb3VzQ2hhbmdlVHlwZTJbXCJPUFRJT05BTF9BUkdfQURERURcIl0gPSBcIk9QVElPTkFMX0FSR19BRERFRFwiO1xuICBEYW5nZXJvdXNDaGFuZ2VUeXBlMltcIklNUExFTUVOVEVEX0lOVEVSRkFDRV9BRERFRFwiXSA9IFwiSU1QTEVNRU5URURfSU5URVJGQUNFX0FEREVEXCI7XG4gIERhbmdlcm91c0NoYW5nZVR5cGUyW1wiQVJHX0RFRkFVTFRfVkFMVUVfQ0hBTkdFXCJdID0gXCJBUkdfREVGQVVMVF9WQUxVRV9DSEFOR0VcIjtcbn0pKERhbmdlcm91c0NoYW5nZVR5cGUgfHwgKERhbmdlcm91c0NoYW5nZVR5cGUgPSB7fSkpO1xuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vbXN3QDIuMi4xX3R5cGVzY3JpcHRANS4zLjMvbm9kZV9tb2R1bGVzL21zdy9saWIvY29yZS91dGlscy9pbnRlcm5hbC9qc29uUGFyc2UubWpzXG5mdW5jdGlvbiBqc29uUGFyc2UodmFsdWUpIHtcbiAgdHJ5IHtcbiAgICByZXR1cm4gSlNPTi5wYXJzZSh2YWx1ZSk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgcmV0dXJuIHZvaWQgMDtcbiAgfVxufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vaGVhZGVycy1wb2x5ZmlsbEA0LjAuMi9ub2RlX21vZHVsZXMvaGVhZGVycy1wb2x5ZmlsbC9saWIvaW5kZXgubWpzXG52YXIgX19jcmVhdGUzID0gT2JqZWN0LmNyZWF0ZTtcbnZhciBfX2RlZlByb3A0ID0gT2JqZWN0LmRlZmluZVByb3BlcnR5O1xudmFyIF9fZ2V0T3duUHJvcERlc2MzID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcjtcbnZhciBfX2dldE93blByb3BOYW1lczMgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcztcbnZhciBfX2dldFByb3RvT2YzID0gT2JqZWN0LmdldFByb3RvdHlwZU9mO1xudmFyIF9faGFzT3duUHJvcDMgPSBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5O1xudmFyIF9fY29tbW9uSlMzID0gKGNiLCBtb2QpID0+IGZ1bmN0aW9uIF9fcmVxdWlyZSgpIHtcbiAgcmV0dXJuIG1vZCB8fCAoMCwgY2JbX19nZXRPd25Qcm9wTmFtZXMzKGNiKVswXV0pKChtb2QgPSB7IGV4cG9ydHM6IHt9IH0pLmV4cG9ydHMsIG1vZCksIG1vZC5leHBvcnRzO1xufTtcbnZhciBfX2NvcHlQcm9wczMgPSAodG8sIGZyb20sIGV4Y2VwdCwgZGVzYykgPT4ge1xuICBpZiAoZnJvbSAmJiB0eXBlb2YgZnJvbSA9PT0gXCJvYmplY3RcIiB8fCB0eXBlb2YgZnJvbSA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgZm9yIChsZXQga2V5IG9mIF9fZ2V0T3duUHJvcE5hbWVzMyhmcm9tKSlcbiAgICAgIGlmICghX19oYXNPd25Qcm9wMy5jYWxsKHRvLCBrZXkpICYmIGtleSAhPT0gZXhjZXB0KVxuICAgICAgICBfX2RlZlByb3A0KHRvLCBrZXksIHsgZ2V0OiAoKSA9PiBmcm9tW2tleV0sIGVudW1lcmFibGU6ICEoZGVzYyA9IF9fZ2V0T3duUHJvcERlc2MzKGZyb20sIGtleSkpIHx8IGRlc2MuZW51bWVyYWJsZSB9KTtcbiAgfVxuICByZXR1cm4gdG87XG59O1xudmFyIF9fdG9FU00zID0gKG1vZCwgaXNOb2RlTW9kZSwgdGFyZ2V0KSA9PiAodGFyZ2V0ID0gbW9kICE9IG51bGwgPyBfX2NyZWF0ZTMoX19nZXRQcm90b09mMyhtb2QpKSA6IHt9LCBfX2NvcHlQcm9wczMoXG4gIC8vIElmIHRoZSBpbXBvcnRlciBpcyBpbiBub2RlIGNvbXBhdGliaWxpdHkgbW9kZSBvciB0aGlzIGlzIG5vdCBhbiBFU01cbiAgLy8gZmlsZSB0aGF0IGhhcyBiZWVuIGNvbnZlcnRlZCB0byBhIENvbW1vbkpTIGZpbGUgdXNpbmcgYSBCYWJlbC1cbiAgLy8gY29tcGF0aWJsZSB0cmFuc2Zvcm0gKGkuZS4gXCJfX2VzTW9kdWxlXCIgaGFzIG5vdCBiZWVuIHNldCksIHRoZW4gc2V0XG4gIC8vIFwiZGVmYXVsdFwiIHRvIHRoZSBDb21tb25KUyBcIm1vZHVsZS5leHBvcnRzXCIgZm9yIG5vZGUgY29tcGF0aWJpbGl0eS5cbiAgaXNOb2RlTW9kZSB8fCAhbW9kIHx8ICFtb2QuX19lc01vZHVsZSA/IF9fZGVmUHJvcDQodGFyZ2V0LCBcImRlZmF1bHRcIiwgeyB2YWx1ZTogbW9kLCBlbnVtZXJhYmxlOiB0cnVlIH0pIDogdGFyZ2V0LFxuICBtb2RcbikpO1xudmFyIHJlcXVpcmVfc2V0X2Nvb2tpZSA9IF9fY29tbW9uSlMzKHtcbiAgXCJub2RlX21vZHVsZXMvc2V0LWNvb2tpZS1wYXJzZXIvbGliL3NldC1jb29raWUuanNcIihleHBvcnRzLCBtb2R1bGUpIHtcbiAgICBcInVzZSBzdHJpY3RcIjtcbiAgICB2YXIgZGVmYXVsdFBhcnNlT3B0aW9ucyA9IHtcbiAgICAgIGRlY29kZVZhbHVlczogdHJ1ZSxcbiAgICAgIG1hcDogZmFsc2UsXG4gICAgICBzaWxlbnQ6IGZhbHNlXG4gICAgfTtcbiAgICBmdW5jdGlvbiBpc05vbkVtcHR5U3RyaW5nKHN0cikge1xuICAgICAgcmV0dXJuIHR5cGVvZiBzdHIgPT09IFwic3RyaW5nXCIgJiYgISFzdHIudHJpbSgpO1xuICAgIH1cbiAgICBmdW5jdGlvbiBwYXJzZVN0cmluZyhzZXRDb29raWVWYWx1ZSwgb3B0aW9ucykge1xuICAgICAgdmFyIHBhcnRzID0gc2V0Q29va2llVmFsdWUuc3BsaXQoXCI7XCIpLmZpbHRlcihpc05vbkVtcHR5U3RyaW5nKTtcbiAgICAgIHZhciBuYW1lVmFsdWVQYWlyU3RyID0gcGFydHMuc2hpZnQoKTtcbiAgICAgIHZhciBwYXJzZWQgPSBwYXJzZU5hbWVWYWx1ZVBhaXIobmFtZVZhbHVlUGFpclN0cik7XG4gICAgICB2YXIgbmFtZSA9IHBhcnNlZC5uYW1lO1xuICAgICAgdmFyIHZhbHVlID0gcGFyc2VkLnZhbHVlO1xuICAgICAgb3B0aW9ucyA9IG9wdGlvbnMgPyBPYmplY3QuYXNzaWduKHt9LCBkZWZhdWx0UGFyc2VPcHRpb25zLCBvcHRpb25zKSA6IGRlZmF1bHRQYXJzZU9wdGlvbnM7XG4gICAgICB0cnkge1xuICAgICAgICB2YWx1ZSA9IG9wdGlvbnMuZGVjb2RlVmFsdWVzID8gZGVjb2RlVVJJQ29tcG9uZW50KHZhbHVlKSA6IHZhbHVlO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICAgIFwic2V0LWNvb2tpZS1wYXJzZXIgZW5jb3VudGVyZWQgYW4gZXJyb3Igd2hpbGUgZGVjb2RpbmcgYSBjb29raWUgd2l0aCB2YWx1ZSAnXCIgKyB2YWx1ZSArIFwiJy4gU2V0IG9wdGlvbnMuZGVjb2RlVmFsdWVzIHRvIGZhbHNlIHRvIGRpc2FibGUgdGhpcyBmZWF0dXJlLlwiLFxuICAgICAgICAgIGVcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIHZhciBjb29raWUgPSB7XG4gICAgICAgIG5hbWUsXG4gICAgICAgIHZhbHVlXG4gICAgICB9O1xuICAgICAgcGFydHMuZm9yRWFjaChmdW5jdGlvbihwYXJ0KSB7XG4gICAgICAgIHZhciBzaWRlcyA9IHBhcnQuc3BsaXQoXCI9XCIpO1xuICAgICAgICB2YXIga2V5ID0gc2lkZXMuc2hpZnQoKS50cmltTGVmdCgpLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgIHZhciB2YWx1ZTIgPSBzaWRlcy5qb2luKFwiPVwiKTtcbiAgICAgICAgaWYgKGtleSA9PT0gXCJleHBpcmVzXCIpIHtcbiAgICAgICAgICBjb29raWUuZXhwaXJlcyA9IG5ldyBEYXRlKHZhbHVlMik7XG4gICAgICAgIH0gZWxzZSBpZiAoa2V5ID09PSBcIm1heC1hZ2VcIikge1xuICAgICAgICAgIGNvb2tpZS5tYXhBZ2UgPSBwYXJzZUludCh2YWx1ZTIsIDEwKTtcbiAgICAgICAgfSBlbHNlIGlmIChrZXkgPT09IFwic2VjdXJlXCIpIHtcbiAgICAgICAgICBjb29raWUuc2VjdXJlID0gdHJ1ZTtcbiAgICAgICAgfSBlbHNlIGlmIChrZXkgPT09IFwiaHR0cG9ubHlcIikge1xuICAgICAgICAgIGNvb2tpZS5odHRwT25seSA9IHRydWU7XG4gICAgICAgIH0gZWxzZSBpZiAoa2V5ID09PSBcInNhbWVzaXRlXCIpIHtcbiAgICAgICAgICBjb29raWUuc2FtZVNpdGUgPSB2YWx1ZTI7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY29va2llW2tleV0gPSB2YWx1ZTI7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIGNvb2tpZTtcbiAgICB9XG4gICAgZnVuY3Rpb24gcGFyc2VOYW1lVmFsdWVQYWlyKG5hbWVWYWx1ZVBhaXJTdHIpIHtcbiAgICAgIHZhciBuYW1lID0gXCJcIjtcbiAgICAgIHZhciB2YWx1ZSA9IFwiXCI7XG4gICAgICB2YXIgbmFtZVZhbHVlQXJyID0gbmFtZVZhbHVlUGFpclN0ci5zcGxpdChcIj1cIik7XG4gICAgICBpZiAobmFtZVZhbHVlQXJyLmxlbmd0aCA+IDEpIHtcbiAgICAgICAgbmFtZSA9IG5hbWVWYWx1ZUFyci5zaGlmdCgpO1xuICAgICAgICB2YWx1ZSA9IG5hbWVWYWx1ZUFyci5qb2luKFwiPVwiKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHZhbHVlID0gbmFtZVZhbHVlUGFpclN0cjtcbiAgICAgIH1cbiAgICAgIHJldHVybiB7IG5hbWUsIHZhbHVlIH07XG4gICAgfVxuICAgIGZ1bmN0aW9uIHBhcnNlMyhpbnB1dCwgb3B0aW9ucykge1xuICAgICAgb3B0aW9ucyA9IG9wdGlvbnMgPyBPYmplY3QuYXNzaWduKHt9LCBkZWZhdWx0UGFyc2VPcHRpb25zLCBvcHRpb25zKSA6IGRlZmF1bHRQYXJzZU9wdGlvbnM7XG4gICAgICBpZiAoIWlucHV0KSB7XG4gICAgICAgIGlmICghb3B0aW9ucy5tYXApIHtcbiAgICAgICAgICByZXR1cm4gW107XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmV0dXJuIHt9O1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAoaW5wdXQuaGVhZGVycykge1xuICAgICAgICBpZiAodHlwZW9mIGlucHV0LmhlYWRlcnMuZ2V0U2V0Q29va2llID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgICAgICBpbnB1dCA9IGlucHV0LmhlYWRlcnMuZ2V0U2V0Q29va2llKCk7XG4gICAgICAgIH0gZWxzZSBpZiAoaW5wdXQuaGVhZGVyc1tcInNldC1jb29raWVcIl0pIHtcbiAgICAgICAgICBpbnB1dCA9IGlucHV0LmhlYWRlcnNbXCJzZXQtY29va2llXCJdO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHZhciBzY2ggPSBpbnB1dC5oZWFkZXJzW09iamVjdC5rZXlzKGlucHV0LmhlYWRlcnMpLmZpbmQoZnVuY3Rpb24oa2V5KSB7XG4gICAgICAgICAgICByZXR1cm4ga2V5LnRvTG93ZXJDYXNlKCkgPT09IFwic2V0LWNvb2tpZVwiO1xuICAgICAgICAgIH0pXTtcbiAgICAgICAgICBpZiAoIXNjaCAmJiBpbnB1dC5oZWFkZXJzLmNvb2tpZSAmJiAhb3B0aW9ucy5zaWxlbnQpIHtcbiAgICAgICAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgICAgICAgXCJXYXJuaW5nOiBzZXQtY29va2llLXBhcnNlciBhcHBlYXJzIHRvIGhhdmUgYmVlbiBjYWxsZWQgb24gYSByZXF1ZXN0IG9iamVjdC4gSXQgaXMgZGVzaWduZWQgdG8gcGFyc2UgU2V0LUNvb2tpZSBoZWFkZXJzIGZyb20gcmVzcG9uc2VzLCBub3QgQ29va2llIGhlYWRlcnMgZnJvbSByZXF1ZXN0cy4gU2V0IHRoZSBvcHRpb24ge3NpbGVudDogdHJ1ZX0gdG8gc3VwcHJlc3MgdGhpcyB3YXJuaW5nLlwiXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpbnB1dCA9IHNjaDtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKCFBcnJheS5pc0FycmF5KGlucHV0KSkge1xuICAgICAgICBpbnB1dCA9IFtpbnB1dF07XG4gICAgICB9XG4gICAgICBvcHRpb25zID0gb3B0aW9ucyA/IE9iamVjdC5hc3NpZ24oe30sIGRlZmF1bHRQYXJzZU9wdGlvbnMsIG9wdGlvbnMpIDogZGVmYXVsdFBhcnNlT3B0aW9ucztcbiAgICAgIGlmICghb3B0aW9ucy5tYXApIHtcbiAgICAgICAgcmV0dXJuIGlucHV0LmZpbHRlcihpc05vbkVtcHR5U3RyaW5nKS5tYXAoZnVuY3Rpb24oc3RyKSB7XG4gICAgICAgICAgcmV0dXJuIHBhcnNlU3RyaW5nKHN0ciwgb3B0aW9ucyk7XG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdmFyIGNvb2tpZXMgPSB7fTtcbiAgICAgICAgcmV0dXJuIGlucHV0LmZpbHRlcihpc05vbkVtcHR5U3RyaW5nKS5yZWR1Y2UoZnVuY3Rpb24oY29va2llczIsIHN0cikge1xuICAgICAgICAgIHZhciBjb29raWUgPSBwYXJzZVN0cmluZyhzdHIsIG9wdGlvbnMpO1xuICAgICAgICAgIGNvb2tpZXMyW2Nvb2tpZS5uYW1lXSA9IGNvb2tpZTtcbiAgICAgICAgICByZXR1cm4gY29va2llczI7XG4gICAgICAgIH0sIGNvb2tpZXMpO1xuICAgICAgfVxuICAgIH1cbiAgICBmdW5jdGlvbiBzcGxpdENvb2tpZXNTdHJpbmcyKGNvb2tpZXNTdHJpbmcpIHtcbiAgICAgIGlmIChBcnJheS5pc0FycmF5KGNvb2tpZXNTdHJpbmcpKSB7XG4gICAgICAgIHJldHVybiBjb29raWVzU3RyaW5nO1xuICAgICAgfVxuICAgICAgaWYgKHR5cGVvZiBjb29raWVzU3RyaW5nICE9PSBcInN0cmluZ1wiKSB7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICAgIH1cbiAgICAgIHZhciBjb29raWVzU3RyaW5ncyA9IFtdO1xuICAgICAgdmFyIHBvcyA9IDA7XG4gICAgICB2YXIgc3RhcnQ7XG4gICAgICB2YXIgY2g7XG4gICAgICB2YXIgbGFzdENvbW1hO1xuICAgICAgdmFyIG5leHRTdGFydDtcbiAgICAgIHZhciBjb29raWVzU2VwYXJhdG9yRm91bmQ7XG4gICAgICBmdW5jdGlvbiBza2lwV2hpdGVzcGFjZSgpIHtcbiAgICAgICAgd2hpbGUgKHBvcyA8IGNvb2tpZXNTdHJpbmcubGVuZ3RoICYmIC9cXHMvLnRlc3QoY29va2llc1N0cmluZy5jaGFyQXQocG9zKSkpIHtcbiAgICAgICAgICBwb3MgKz0gMTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcG9zIDwgY29va2llc1N0cmluZy5sZW5ndGg7XG4gICAgICB9XG4gICAgICBmdW5jdGlvbiBub3RTcGVjaWFsQ2hhcigpIHtcbiAgICAgICAgY2ggPSBjb29raWVzU3RyaW5nLmNoYXJBdChwb3MpO1xuICAgICAgICByZXR1cm4gY2ggIT09IFwiPVwiICYmIGNoICE9PSBcIjtcIiAmJiBjaCAhPT0gXCIsXCI7XG4gICAgICB9XG4gICAgICB3aGlsZSAocG9zIDwgY29va2llc1N0cmluZy5sZW5ndGgpIHtcbiAgICAgICAgc3RhcnQgPSBwb3M7XG4gICAgICAgIGNvb2tpZXNTZXBhcmF0b3JGb3VuZCA9IGZhbHNlO1xuICAgICAgICB3aGlsZSAoc2tpcFdoaXRlc3BhY2UoKSkge1xuICAgICAgICAgIGNoID0gY29va2llc1N0cmluZy5jaGFyQXQocG9zKTtcbiAgICAgICAgICBpZiAoY2ggPT09IFwiLFwiKSB7XG4gICAgICAgICAgICBsYXN0Q29tbWEgPSBwb3M7XG4gICAgICAgICAgICBwb3MgKz0gMTtcbiAgICAgICAgICAgIHNraXBXaGl0ZXNwYWNlKCk7XG4gICAgICAgICAgICBuZXh0U3RhcnQgPSBwb3M7XG4gICAgICAgICAgICB3aGlsZSAocG9zIDwgY29va2llc1N0cmluZy5sZW5ndGggJiYgbm90U3BlY2lhbENoYXIoKSkge1xuICAgICAgICAgICAgICBwb3MgKz0gMTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChwb3MgPCBjb29raWVzU3RyaW5nLmxlbmd0aCAmJiBjb29raWVzU3RyaW5nLmNoYXJBdChwb3MpID09PSBcIj1cIikge1xuICAgICAgICAgICAgICBjb29raWVzU2VwYXJhdG9yRm91bmQgPSB0cnVlO1xuICAgICAgICAgICAgICBwb3MgPSBuZXh0U3RhcnQ7XG4gICAgICAgICAgICAgIGNvb2tpZXNTdHJpbmdzLnB1c2goY29va2llc1N0cmluZy5zdWJzdHJpbmcoc3RhcnQsIGxhc3RDb21tYSkpO1xuICAgICAgICAgICAgICBzdGFydCA9IHBvcztcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIHBvcyA9IGxhc3RDb21tYSArIDE7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHBvcyArPSAxO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoIWNvb2tpZXNTZXBhcmF0b3JGb3VuZCB8fCBwb3MgPj0gY29va2llc1N0cmluZy5sZW5ndGgpIHtcbiAgICAgICAgICBjb29raWVzU3RyaW5ncy5wdXNoKGNvb2tpZXNTdHJpbmcuc3Vic3RyaW5nKHN0YXJ0LCBjb29raWVzU3RyaW5nLmxlbmd0aCkpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gY29va2llc1N0cmluZ3M7XG4gICAgfVxuICAgIG1vZHVsZS5leHBvcnRzID0gcGFyc2UzO1xuICAgIG1vZHVsZS5leHBvcnRzLnBhcnNlID0gcGFyc2UzO1xuICAgIG1vZHVsZS5leHBvcnRzLnBhcnNlU3RyaW5nID0gcGFyc2VTdHJpbmc7XG4gICAgbW9kdWxlLmV4cG9ydHMuc3BsaXRDb29raWVzU3RyaW5nID0gc3BsaXRDb29raWVzU3RyaW5nMjtcbiAgfVxufSk7XG52YXIgaW1wb3J0X3NldF9jb29raWVfcGFyc2VyID0gX190b0VTTTMocmVxdWlyZV9zZXRfY29va2llKCkpO1xudmFyIEhFQURFUlNfSU5WQUxJRF9DSEFSQUNURVJTID0gL1teYS16MC05XFwtIyQlJicqKy5eX2B8fl0vaTtcbmZ1bmN0aW9uIG5vcm1hbGl6ZUhlYWRlck5hbWUobmFtZSkge1xuICBpZiAoSEVBREVSU19JTlZBTElEX0NIQVJBQ1RFUlMudGVzdChuYW1lKSB8fCBuYW1lLnRyaW0oKSA9PT0gXCJcIikge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJJbnZhbGlkIGNoYXJhY3RlciBpbiBoZWFkZXIgZmllbGQgbmFtZVwiKTtcbiAgfVxuICByZXR1cm4gbmFtZS50cmltKCkudG9Mb3dlckNhc2UoKTtcbn1cbnZhciBjaGFyQ29kZXNUb1JlbW92ZSA9IFtcbiAgU3RyaW5nLmZyb21DaGFyQ29kZSgxMCksXG4gIFN0cmluZy5mcm9tQ2hhckNvZGUoMTMpLFxuICBTdHJpbmcuZnJvbUNoYXJDb2RlKDkpLFxuICBTdHJpbmcuZnJvbUNoYXJDb2RlKDMyKVxuXTtcbnZhciBIRUFERVJfVkFMVUVfUkVNT1ZFX1JFR0VYUCA9IG5ldyBSZWdFeHAoXG4gIGAoXlske2NoYXJDb2Rlc1RvUmVtb3ZlLmpvaW4oXCJcIil9XXwkWyR7Y2hhckNvZGVzVG9SZW1vdmUuam9pbihcIlwiKX1dKWAsXG4gIFwiZ1wiXG4pO1xuZnVuY3Rpb24gbm9ybWFsaXplSGVhZGVyVmFsdWUodmFsdWUpIHtcbiAgY29uc3QgbmV4dFZhbHVlID0gdmFsdWUucmVwbGFjZShIRUFERVJfVkFMVUVfUkVNT1ZFX1JFR0VYUCwgXCJcIik7XG4gIHJldHVybiBuZXh0VmFsdWU7XG59XG5mdW5jdGlvbiBpc1ZhbGlkSGVhZGVyTmFtZSh2YWx1ZSkge1xuICBpZiAodHlwZW9mIHZhbHVlICE9PSBcInN0cmluZ1wiKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGlmICh2YWx1ZS5sZW5ndGggPT09IDApIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgZm9yIChsZXQgaSA9IDA7IGkgPCB2YWx1ZS5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IGNoYXJhY3RlciA9IHZhbHVlLmNoYXJDb2RlQXQoaSk7XG4gICAgaWYgKGNoYXJhY3RlciA+IDEyNyB8fCAhaXNUb2tlbihjaGFyYWN0ZXIpKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICB9XG4gIHJldHVybiB0cnVlO1xufVxuZnVuY3Rpb24gaXNUb2tlbih2YWx1ZSkge1xuICByZXR1cm4gIVtcbiAgICAxMjcsXG4gICAgMzIsXG4gICAgXCIoXCIsXG4gICAgXCIpXCIsXG4gICAgXCI8XCIsXG4gICAgXCI+XCIsXG4gICAgXCJAXCIsXG4gICAgXCIsXCIsXG4gICAgXCI7XCIsXG4gICAgXCI6XCIsXG4gICAgXCJcXFxcXCIsXG4gICAgJ1wiJyxcbiAgICBcIi9cIixcbiAgICBcIltcIixcbiAgICBcIl1cIixcbiAgICBcIj9cIixcbiAgICBcIj1cIixcbiAgICBcIntcIixcbiAgICBcIn1cIlxuICBdLmluY2x1ZGVzKHZhbHVlKTtcbn1cbmZ1bmN0aW9uIGlzVmFsaWRIZWFkZXJWYWx1ZSh2YWx1ZSkge1xuICBpZiAodHlwZW9mIHZhbHVlICE9PSBcInN0cmluZ1wiKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGlmICh2YWx1ZS50cmltKCkgIT09IHZhbHVlKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgdmFsdWUubGVuZ3RoOyBpKyspIHtcbiAgICBjb25zdCBjaGFyYWN0ZXIgPSB2YWx1ZS5jaGFyQ29kZUF0KGkpO1xuICAgIGlmIChcbiAgICAgIC8vIE5VTC5cbiAgICAgIGNoYXJhY3RlciA9PT0gMCB8fCAvLyBIVFRQIG5ld2xpbmUgYnl0ZXMuXG4gICAgICBjaGFyYWN0ZXIgPT09IDEwIHx8IGNoYXJhY3RlciA9PT0gMTNcbiAgICApIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHRydWU7XG59XG52YXIgTk9STUFMSVpFRF9IRUFERVJTID0gU3ltYm9sKFwibm9ybWFsaXplZEhlYWRlcnNcIik7XG52YXIgUkFXX0hFQURFUl9OQU1FUyA9IFN5bWJvbChcInJhd0hlYWRlck5hbWVzXCIpO1xudmFyIEhFQURFUl9WQUxVRV9ERUxJTUlURVIgPSBcIiwgXCI7XG52YXIgX2E7XG52YXIgX2I7XG52YXIgSGVhZGVyczIgPSBjbGFzcyBfSGVhZGVycyB7XG4gIGNvbnN0cnVjdG9yKGluaXQpIHtcbiAgICB0aGlzW19hXSA9IHt9O1xuICAgIHRoaXNbX2JdID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcbiAgICBpZiAoW1wiSGVhZGVyc1wiLCBcIkhlYWRlcnNQb2x5ZmlsbFwiXS5pbmNsdWRlcyhpbml0ID09IG51bGwgPyB2b2lkIDAgOiBpbml0LmNvbnN0cnVjdG9yLm5hbWUpIHx8IGluaXQgaW5zdGFuY2VvZiBfSGVhZGVycyB8fCB0eXBlb2YgZ2xvYmFsVGhpcy5IZWFkZXJzICE9PSBcInVuZGVmaW5lZFwiICYmIGluaXQgaW5zdGFuY2VvZiBnbG9iYWxUaGlzLkhlYWRlcnMpIHtcbiAgICAgIGNvbnN0IGluaXRpYWxIZWFkZXJzID0gaW5pdDtcbiAgICAgIGluaXRpYWxIZWFkZXJzLmZvckVhY2goKHZhbHVlLCBuYW1lKSA9PiB7XG4gICAgICAgIHRoaXMuYXBwZW5kKG5hbWUsIHZhbHVlKTtcbiAgICAgIH0sIHRoaXMpO1xuICAgIH0gZWxzZSBpZiAoQXJyYXkuaXNBcnJheShpbml0KSkge1xuICAgICAgaW5pdC5mb3JFYWNoKChbbmFtZSwgdmFsdWVdKSA9PiB7XG4gICAgICAgIHRoaXMuYXBwZW5kKFxuICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgQXJyYXkuaXNBcnJheSh2YWx1ZSkgPyB2YWx1ZS5qb2luKEhFQURFUl9WQUxVRV9ERUxJTUlURVIpIDogdmFsdWVcbiAgICAgICAgKTtcbiAgICAgIH0pO1xuICAgIH0gZWxzZSBpZiAoaW5pdCkge1xuICAgICAgT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXMoaW5pdCkuZm9yRWFjaCgobmFtZSkgPT4ge1xuICAgICAgICBjb25zdCB2YWx1ZSA9IGluaXRbbmFtZV07XG4gICAgICAgIHRoaXMuYXBwZW5kKFxuICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgQXJyYXkuaXNBcnJheSh2YWx1ZSkgPyB2YWx1ZS5qb2luKEhFQURFUl9WQUxVRV9ERUxJTUlURVIpIDogdmFsdWVcbiAgICAgICAgKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuICBbKF9hID0gTk9STUFMSVpFRF9IRUFERVJTLCBfYiA9IFJBV19IRUFERVJfTkFNRVMsIFN5bWJvbC5pdGVyYXRvcildKCkge1xuICAgIHJldHVybiB0aGlzLmVudHJpZXMoKTtcbiAgfVxuICAqa2V5cygpIHtcbiAgICBmb3IgKGNvbnN0IFtuYW1lXSBvZiB0aGlzLmVudHJpZXMoKSkge1xuICAgICAgeWllbGQgbmFtZTtcbiAgICB9XG4gIH1cbiAgKnZhbHVlcygpIHtcbiAgICBmb3IgKGNvbnN0IFssIHZhbHVlXSBvZiB0aGlzLmVudHJpZXMoKSkge1xuICAgICAgeWllbGQgdmFsdWU7XG4gICAgfVxuICB9XG4gICplbnRyaWVzKCkge1xuICAgIGxldCBzb3J0ZWRLZXlzID0gT2JqZWN0LmtleXModGhpc1tOT1JNQUxJWkVEX0hFQURFUlNdKS5zb3J0KFxuICAgICAgKGEsIGIpID0+IGEubG9jYWxlQ29tcGFyZShiKVxuICAgICk7XG4gICAgZm9yIChjb25zdCBuYW1lIG9mIHNvcnRlZEtleXMpIHtcbiAgICAgIGlmIChuYW1lID09PSBcInNldC1jb29raWVcIikge1xuICAgICAgICBmb3IgKGNvbnN0IHZhbHVlIG9mIHRoaXMuZ2V0U2V0Q29va2llKCkpIHtcbiAgICAgICAgICB5aWVsZCBbbmFtZSwgdmFsdWVdO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB5aWVsZCBbbmFtZSwgdGhpcy5nZXQobmFtZSldO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICAvKipcbiAgICogUmV0dXJucyBhIGJvb2xlYW4gc3RhdGluZyB3aGV0aGVyIGEgYEhlYWRlcnNgIG9iamVjdCBjb250YWlucyBhIGNlcnRhaW4gaGVhZGVyLlxuICAgKi9cbiAgaGFzKG5hbWUpIHtcbiAgICBpZiAoIWlzVmFsaWRIZWFkZXJOYW1lKG5hbWUpKSB7XG4gICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKGBJbnZhbGlkIGhlYWRlciBuYW1lIFwiJHtuYW1lfVwiYCk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzW05PUk1BTElaRURfSEVBREVSU10uaGFzT3duUHJvcGVydHkobm9ybWFsaXplSGVhZGVyTmFtZShuYW1lKSk7XG4gIH1cbiAgLyoqXG4gICAqIFJldHVybnMgYSBgQnl0ZVN0cmluZ2Agc2VxdWVuY2Ugb2YgYWxsIHRoZSB2YWx1ZXMgb2YgYSBoZWFkZXIgd2l0aCBhIGdpdmVuIG5hbWUuXG4gICAqL1xuICBnZXQobmFtZSkge1xuICAgIGlmICghaXNWYWxpZEhlYWRlck5hbWUobmFtZSkpIHtcbiAgICAgIHRocm93IFR5cGVFcnJvcihgSW52YWxpZCBoZWFkZXIgbmFtZSBcIiR7bmFtZX1cImApO1xuICAgIH1cbiAgICByZXR1cm4gdGhpc1tOT1JNQUxJWkVEX0hFQURFUlNdW25vcm1hbGl6ZUhlYWRlck5hbWUobmFtZSldID8/IG51bGw7XG4gIH1cbiAgLyoqXG4gICAqIFNldHMgYSBuZXcgdmFsdWUgZm9yIGFuIGV4aXN0aW5nIGhlYWRlciBpbnNpZGUgYSBgSGVhZGVyc2Agb2JqZWN0LCBvciBhZGRzIHRoZSBoZWFkZXIgaWYgaXQgZG9lcyBub3QgYWxyZWFkeSBleGlzdC5cbiAgICovXG4gIHNldChuYW1lLCB2YWx1ZSkge1xuICAgIGlmICghaXNWYWxpZEhlYWRlck5hbWUobmFtZSkgfHwgIWlzVmFsaWRIZWFkZXJWYWx1ZSh2YWx1ZSkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3Qgbm9ybWFsaXplZE5hbWUgPSBub3JtYWxpemVIZWFkZXJOYW1lKG5hbWUpO1xuICAgIGNvbnN0IG5vcm1hbGl6ZWRWYWx1ZSA9IG5vcm1hbGl6ZUhlYWRlclZhbHVlKHZhbHVlKTtcbiAgICB0aGlzW05PUk1BTElaRURfSEVBREVSU11bbm9ybWFsaXplZE5hbWVdID0gbm9ybWFsaXplSGVhZGVyVmFsdWUobm9ybWFsaXplZFZhbHVlKTtcbiAgICB0aGlzW1JBV19IRUFERVJfTkFNRVNdLnNldChub3JtYWxpemVkTmFtZSwgbmFtZSk7XG4gIH1cbiAgLyoqXG4gICAqIEFwcGVuZHMgYSBuZXcgdmFsdWUgb250byBhbiBleGlzdGluZyBoZWFkZXIgaW5zaWRlIGEgYEhlYWRlcnNgIG9iamVjdCwgb3IgYWRkcyB0aGUgaGVhZGVyIGlmIGl0IGRvZXMgbm90IGFscmVhZHkgZXhpc3QuXG4gICAqL1xuICBhcHBlbmQobmFtZSwgdmFsdWUpIHtcbiAgICBpZiAoIWlzVmFsaWRIZWFkZXJOYW1lKG5hbWUpIHx8ICFpc1ZhbGlkSGVhZGVyVmFsdWUodmFsdWUpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IG5vcm1hbGl6ZWROYW1lID0gbm9ybWFsaXplSGVhZGVyTmFtZShuYW1lKTtcbiAgICBjb25zdCBub3JtYWxpemVkVmFsdWUgPSBub3JtYWxpemVIZWFkZXJWYWx1ZSh2YWx1ZSk7XG4gICAgbGV0IHJlc29sdmVkVmFsdWUgPSB0aGlzLmhhcyhub3JtYWxpemVkTmFtZSkgPyBgJHt0aGlzLmdldChub3JtYWxpemVkTmFtZSl9LCAke25vcm1hbGl6ZWRWYWx1ZX1gIDogbm9ybWFsaXplZFZhbHVlO1xuICAgIHRoaXMuc2V0KG5hbWUsIHJlc29sdmVkVmFsdWUpO1xuICB9XG4gIC8qKlxuICAgKiBEZWxldGVzIGEgaGVhZGVyIGZyb20gdGhlIGBIZWFkZXJzYCBvYmplY3QuXG4gICAqL1xuICBkZWxldGUobmFtZSkge1xuICAgIGlmICghaXNWYWxpZEhlYWRlck5hbWUobmFtZSkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKCF0aGlzLmhhcyhuYW1lKSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBub3JtYWxpemVkTmFtZSA9IG5vcm1hbGl6ZUhlYWRlck5hbWUobmFtZSk7XG4gICAgZGVsZXRlIHRoaXNbTk9STUFMSVpFRF9IRUFERVJTXVtub3JtYWxpemVkTmFtZV07XG4gICAgdGhpc1tSQVdfSEVBREVSX05BTUVTXS5kZWxldGUobm9ybWFsaXplZE5hbWUpO1xuICB9XG4gIC8qKlxuICAgKiBUcmF2ZXJzZXMgdGhlIGBIZWFkZXJzYCBvYmplY3QsXG4gICAqIGNhbGxpbmcgdGhlIGdpdmVuIGNhbGxiYWNrIGZvciBlYWNoIGhlYWRlci5cbiAgICovXG4gIGZvckVhY2goY2FsbGJhY2ssIHRoaXNBcmcpIHtcbiAgICBmb3IgKGNvbnN0IFtuYW1lLCB2YWx1ZV0gb2YgdGhpcy5lbnRyaWVzKCkpIHtcbiAgICAgIGNhbGxiYWNrLmNhbGwodGhpc0FyZywgdmFsdWUsIG5hbWUsIHRoaXMpO1xuICAgIH1cbiAgfVxuICAvKipcbiAgICogUmV0dXJucyBhbiBhcnJheSBjb250YWluaW5nIHRoZSB2YWx1ZXNcbiAgICogb2YgYWxsIFNldC1Db29raWUgaGVhZGVycyBhc3NvY2lhdGVkXG4gICAqIHdpdGggYSByZXNwb25zZVxuICAgKi9cbiAgZ2V0U2V0Q29va2llKCkge1xuICAgIGNvbnN0IHNldENvb2tpZUhlYWRlciA9IHRoaXMuZ2V0KFwic2V0LWNvb2tpZVwiKTtcbiAgICBpZiAoc2V0Q29va2llSGVhZGVyID09PSBudWxsKSB7XG4gICAgICByZXR1cm4gW107XG4gICAgfVxuICAgIGlmIChzZXRDb29raWVIZWFkZXIgPT09IFwiXCIpIHtcbiAgICAgIHJldHVybiBbXCJcIl07XG4gICAgfVxuICAgIHJldHVybiAoMCwgaW1wb3J0X3NldF9jb29raWVfcGFyc2VyLnNwbGl0Q29va2llc1N0cmluZykoc2V0Q29va2llSGVhZGVyKTtcbiAgfVxufTtcbmZ1bmN0aW9uIHN0cmluZ1RvSGVhZGVycyhzdHIpIHtcbiAgY29uc3QgbGluZXMgPSBzdHIudHJpbSgpLnNwbGl0KC9bXFxyXFxuXSsvKTtcbiAgcmV0dXJuIGxpbmVzLnJlZHVjZSgoaGVhZGVycywgbGluZSkgPT4ge1xuICAgIGlmIChsaW5lLnRyaW0oKSA9PT0gXCJcIikge1xuICAgICAgcmV0dXJuIGhlYWRlcnM7XG4gICAgfVxuICAgIGNvbnN0IHBhcnRzID0gbGluZS5zcGxpdChcIjogXCIpO1xuICAgIGNvbnN0IG5hbWUgPSBwYXJ0cy5zaGlmdCgpO1xuICAgIGNvbnN0IHZhbHVlID0gcGFydHMuam9pbihcIjogXCIpO1xuICAgIGhlYWRlcnMuYXBwZW5kKG5hbWUsIHZhbHVlKTtcbiAgICByZXR1cm4gaGVhZGVycztcbiAgfSwgbmV3IEhlYWRlcnMyKCkpO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vbXN3QDIuMi4xX3R5cGVzY3JpcHRANS4zLjMvbm9kZV9tb2R1bGVzL21zdy9saWIvY29yZS91dGlscy9pbnRlcm5hbC9wYXJzZU11bHRpcGFydERhdGEubWpzXG5mdW5jdGlvbiBwYXJzZUNvbnRlbnRIZWFkZXJzKGhlYWRlcnNTdHJpbmcpIHtcbiAgdmFyIF9hMiwgX2IyO1xuICBjb25zdCBoZWFkZXJzID0gc3RyaW5nVG9IZWFkZXJzKGhlYWRlcnNTdHJpbmcpO1xuICBjb25zdCBjb250ZW50VHlwZSA9IGhlYWRlcnMuZ2V0KFwiY29udGVudC10eXBlXCIpIHx8IFwidGV4dC9wbGFpblwiO1xuICBjb25zdCBkaXNwb3NpdGlvbiA9IGhlYWRlcnMuZ2V0KFwiY29udGVudC1kaXNwb3NpdGlvblwiKTtcbiAgaWYgKCFkaXNwb3NpdGlvbikge1xuICAgIHRocm93IG5ldyBFcnJvcignXCJDb250ZW50LURpc3Bvc2l0aW9uXCIgaGVhZGVyIGlzIHJlcXVpcmVkLicpO1xuICB9XG4gIGNvbnN0IGRpcmVjdGl2ZXMgPSBkaXNwb3NpdGlvbi5zcGxpdChcIjtcIikucmVkdWNlKChhY2MsIGNodW5rKSA9PiB7XG4gICAgY29uc3QgW25hbWUyLCAuLi5yZXN0XSA9IGNodW5rLnRyaW0oKS5zcGxpdChcIj1cIik7XG4gICAgYWNjW25hbWUyXSA9IHJlc3Quam9pbihcIj1cIik7XG4gICAgcmV0dXJuIGFjYztcbiAgfSwge30pO1xuICBjb25zdCBuYW1lID0gKF9hMiA9IGRpcmVjdGl2ZXMubmFtZSkgPT0gbnVsbCA/IHZvaWQgMCA6IF9hMi5zbGljZSgxLCAtMSk7XG4gIGNvbnN0IGZpbGVuYW1lID0gKF9iMiA9IGRpcmVjdGl2ZXMuZmlsZW5hbWUpID09IG51bGwgPyB2b2lkIDAgOiBfYjIuc2xpY2UoMSwgLTEpO1xuICByZXR1cm4ge1xuICAgIG5hbWUsXG4gICAgZmlsZW5hbWUsXG4gICAgY29udGVudFR5cGVcbiAgfTtcbn1cbmZ1bmN0aW9uIHBhcnNlTXVsdGlwYXJ0RGF0YShkYXRhLCBoZWFkZXJzKSB7XG4gIGNvbnN0IGNvbnRlbnRUeXBlID0gaGVhZGVycyA9PSBudWxsID8gdm9pZCAwIDogaGVhZGVycy5nZXQoXCJjb250ZW50LXR5cGVcIik7XG4gIGlmICghY29udGVudFR5cGUpIHtcbiAgICByZXR1cm4gdm9pZCAwO1xuICB9XG4gIGNvbnN0IFssIC4uLmRpcmVjdGl2ZXNdID0gY29udGVudFR5cGUuc3BsaXQoLzsgKi8pO1xuICBjb25zdCBib3VuZGFyeSA9IGRpcmVjdGl2ZXMuZmlsdGVyKChkKSA9PiBkLnN0YXJ0c1dpdGgoXCJib3VuZGFyeT1cIikpLm1hcCgocykgPT4gcy5yZXBsYWNlKC9eYm91bmRhcnk9LywgXCJcIikpWzBdO1xuICBpZiAoIWJvdW5kYXJ5KSB7XG4gICAgcmV0dXJuIHZvaWQgMDtcbiAgfVxuICBjb25zdCBib3VuZGFyeVJlZ0V4cCA9IG5ldyBSZWdFeHAoYC0tKyR7Ym91bmRhcnl9YCk7XG4gIGNvbnN0IGZpZWxkcyA9IGRhdGEuc3BsaXQoYm91bmRhcnlSZWdFeHApLmZpbHRlcigoY2h1bmspID0+IGNodW5rLnN0YXJ0c1dpdGgoXCJcXHJcXG5cIikgJiYgY2h1bmsuZW5kc1dpdGgoXCJcXHJcXG5cIikpLm1hcCgoY2h1bmspID0+IGNodW5rLnRyaW1TdGFydCgpLnJlcGxhY2UoL1xcclxcbiQvLCBcIlwiKSk7XG4gIGlmICghZmllbGRzLmxlbmd0aCkge1xuICAgIHJldHVybiB2b2lkIDA7XG4gIH1cbiAgY29uc3QgcGFyc2VkQm9keSA9IHt9O1xuICB0cnkge1xuICAgIGZvciAoY29uc3QgZmllbGQgb2YgZmllbGRzKSB7XG4gICAgICBjb25zdCBbY29udGVudEhlYWRlcnMsIC4uLnJlc3RdID0gZmllbGQuc3BsaXQoXCJcXHJcXG5cXHJcXG5cIik7XG4gICAgICBjb25zdCBjb250ZW50Qm9keSA9IHJlc3Quam9pbihcIlxcclxcblxcclxcblwiKTtcbiAgICAgIGNvbnN0IHsgY29udGVudFR5cGU6IGNvbnRlbnRUeXBlMiwgZmlsZW5hbWUsIG5hbWUgfSA9IHBhcnNlQ29udGVudEhlYWRlcnMoY29udGVudEhlYWRlcnMpO1xuICAgICAgY29uc3QgdmFsdWUgPSBmaWxlbmFtZSA9PT0gdm9pZCAwID8gY29udGVudEJvZHkgOiBuZXcgRmlsZShbY29udGVudEJvZHldLCBmaWxlbmFtZSwgeyB0eXBlOiBjb250ZW50VHlwZTIgfSk7XG4gICAgICBjb25zdCBwYXJzZWRWYWx1ZSA9IHBhcnNlZEJvZHlbbmFtZV07XG4gICAgICBpZiAocGFyc2VkVmFsdWUgPT09IHZvaWQgMCkge1xuICAgICAgICBwYXJzZWRCb2R5W25hbWVdID0gdmFsdWU7XG4gICAgICB9IGVsc2UgaWYgKEFycmF5LmlzQXJyYXkocGFyc2VkVmFsdWUpKSB7XG4gICAgICAgIHBhcnNlZEJvZHlbbmFtZV0gPSBbLi4ucGFyc2VkVmFsdWUsIHZhbHVlXTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHBhcnNlZEJvZHlbbmFtZV0gPSBbcGFyc2VkVmFsdWUsIHZhbHVlXTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHBhcnNlZEJvZHk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgcmV0dXJuIHZvaWQgMDtcbiAgfVxufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vbXN3QDIuMi4xX3R5cGVzY3JpcHRANS4zLjMvbm9kZV9tb2R1bGVzL21zdy9saWIvY29yZS91dGlscy9pbnRlcm5hbC9wYXJzZUdyYXBoUUxSZXF1ZXN0Lm1qc1xuZnVuY3Rpb24gcGFyc2VEb2N1bWVudE5vZGUobm9kZSkge1xuICB2YXIgX2EyO1xuICBjb25zdCBvcGVyYXRpb25EZWYgPSBub2RlLmRlZmluaXRpb25zLmZpbmQoKGRlZmluaXRpb24pID0+IHtcbiAgICByZXR1cm4gZGVmaW5pdGlvbi5raW5kID09PSBcIk9wZXJhdGlvbkRlZmluaXRpb25cIjtcbiAgfSk7XG4gIHJldHVybiB7XG4gICAgb3BlcmF0aW9uVHlwZTogb3BlcmF0aW9uRGVmID09IG51bGwgPyB2b2lkIDAgOiBvcGVyYXRpb25EZWYub3BlcmF0aW9uLFxuICAgIG9wZXJhdGlvbk5hbWU6IChfYTIgPSBvcGVyYXRpb25EZWYgPT0gbnVsbCA/IHZvaWQgMCA6IG9wZXJhdGlvbkRlZi5uYW1lKSA9PSBudWxsID8gdm9pZCAwIDogX2EyLnZhbHVlXG4gIH07XG59XG5mdW5jdGlvbiBwYXJzZVF1ZXJ5KHF1ZXJ5KSB7XG4gIHRyeSB7XG4gICAgY29uc3QgYXN0ID0gcGFyc2UyKHF1ZXJ5KTtcbiAgICByZXR1cm4gcGFyc2VEb2N1bWVudE5vZGUoYXN0KTtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICByZXR1cm4gZXJyb3I7XG4gIH1cbn1cbmZ1bmN0aW9uIGV4dHJhY3RNdWx0aXBhcnRWYXJpYWJsZXModmFyaWFibGVzLCBtYXAsIGZpbGVzKSB7XG4gIGNvbnN0IG9wZXJhdGlvbnMgPSB7IHZhcmlhYmxlcyB9O1xuICBmb3IgKGNvbnN0IFtrZXksIHBhdGhBcnJheV0gb2YgT2JqZWN0LmVudHJpZXMobWFwKSkge1xuICAgIGlmICghKGtleSBpbiBmaWxlcykpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihgR2l2ZW4gZmlsZXMgZG8gbm90IGhhdmUgYSBrZXkgJyR7a2V5fScgLmApO1xuICAgIH1cbiAgICBmb3IgKGNvbnN0IGRvdFBhdGggb2YgcGF0aEFycmF5KSB7XG4gICAgICBjb25zdCBbbGFzdFBhdGgsIC4uLnJldmVyc2VkUGF0aHNdID0gZG90UGF0aC5zcGxpdChcIi5cIikucmV2ZXJzZSgpO1xuICAgICAgY29uc3QgcGF0aHMgPSByZXZlcnNlZFBhdGhzLnJldmVyc2UoKTtcbiAgICAgIGxldCB0YXJnZXQgPSBvcGVyYXRpb25zO1xuICAgICAgZm9yIChjb25zdCBwYXRoIG9mIHBhdGhzKSB7XG4gICAgICAgIGlmICghKHBhdGggaW4gdGFyZ2V0KSkge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgUHJvcGVydHkgJyR7cGF0aHN9JyBpcyBub3QgaW4gb3BlcmF0aW9ucy5gKTtcbiAgICAgICAgfVxuICAgICAgICB0YXJnZXQgPSB0YXJnZXRbcGF0aF07XG4gICAgICB9XG4gICAgICB0YXJnZXRbbGFzdFBhdGhdID0gZmlsZXNba2V5XTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG9wZXJhdGlvbnMudmFyaWFibGVzO1xufVxuYXN5bmMgZnVuY3Rpb24gZ2V0R3JhcGhRTElucHV0KHJlcXVlc3QpIHtcbiAgdmFyIF9hMjtcbiAgc3dpdGNoIChyZXF1ZXN0Lm1ldGhvZCkge1xuICAgIGNhc2UgXCJHRVRcIjoge1xuICAgICAgY29uc3QgdXJsID0gbmV3IFVSTChyZXF1ZXN0LnVybCk7XG4gICAgICBjb25zdCBxdWVyeSA9IHVybC5zZWFyY2hQYXJhbXMuZ2V0KFwicXVlcnlcIik7XG4gICAgICBjb25zdCB2YXJpYWJsZXMgPSB1cmwuc2VhcmNoUGFyYW1zLmdldChcInZhcmlhYmxlc1wiKSB8fCBcIlwiO1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgcXVlcnksXG4gICAgICAgIHZhcmlhYmxlczoganNvblBhcnNlKHZhcmlhYmxlcylcbiAgICAgIH07XG4gICAgfVxuICAgIGNhc2UgXCJQT1NUXCI6IHtcbiAgICAgIGNvbnN0IHJlcXVlc3RDbG9uZSA9IHJlcXVlc3QuY2xvbmUoKTtcbiAgICAgIGlmICgoX2EyID0gcmVxdWVzdC5oZWFkZXJzLmdldChcImNvbnRlbnQtdHlwZVwiKSkgPT0gbnVsbCA/IHZvaWQgMCA6IF9hMi5pbmNsdWRlcyhcIm11bHRpcGFydC9mb3JtLWRhdGFcIikpIHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2VKc29uID0gcGFyc2VNdWx0aXBhcnREYXRhKFxuICAgICAgICAgIGF3YWl0IHJlcXVlc3RDbG9uZS50ZXh0KCksXG4gICAgICAgICAgcmVxdWVzdC5oZWFkZXJzXG4gICAgICAgICk7XG4gICAgICAgIGlmICghcmVzcG9uc2VKc29uKSB7XG4gICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgeyBvcGVyYXRpb25zLCBtYXAsIC4uLmZpbGVzIH0gPSByZXNwb25zZUpzb247XG4gICAgICAgIGNvbnN0IHBhcnNlZE9wZXJhdGlvbnMgPSBqc29uUGFyc2UoXG4gICAgICAgICAgb3BlcmF0aW9uc1xuICAgICAgICApIHx8IHt9O1xuICAgICAgICBpZiAoIXBhcnNlZE9wZXJhdGlvbnMucXVlcnkpIHtcbiAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBwYXJzZWRNYXAgPSBqc29uUGFyc2UobWFwIHx8IFwiXCIpIHx8IHt9O1xuICAgICAgICBjb25zdCB2YXJpYWJsZXMgPSBwYXJzZWRPcGVyYXRpb25zLnZhcmlhYmxlcyA/IGV4dHJhY3RNdWx0aXBhcnRWYXJpYWJsZXMoXG4gICAgICAgICAgcGFyc2VkT3BlcmF0aW9ucy52YXJpYWJsZXMsXG4gICAgICAgICAgcGFyc2VkTWFwLFxuICAgICAgICAgIGZpbGVzXG4gICAgICAgICkgOiB7fTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBxdWVyeTogcGFyc2VkT3BlcmF0aW9ucy5xdWVyeSxcbiAgICAgICAgICB2YXJpYWJsZXNcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHJlcXVlc3RKc29uID0gYXdhaXQgcmVxdWVzdENsb25lLmpzb24oKS5jYXRjaCgoKSA9PiBudWxsKTtcbiAgICAgIGlmIChyZXF1ZXN0SnNvbiA9PSBudWxsID8gdm9pZCAwIDogcmVxdWVzdEpzb24ucXVlcnkpIHtcbiAgICAgICAgY29uc3QgeyBxdWVyeSwgdmFyaWFibGVzIH0gPSByZXF1ZXN0SnNvbjtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBxdWVyeSxcbiAgICAgICAgICB2YXJpYWJsZXNcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICB9XG4gICAgZGVmYXVsdDpcbiAgICAgIHJldHVybiBudWxsO1xuICB9XG59XG5hc3luYyBmdW5jdGlvbiBwYXJzZUdyYXBoUUxSZXF1ZXN0KHJlcXVlc3QpIHtcbiAgY29uc3QgaW5wdXQgPSBhd2FpdCBnZXRHcmFwaFFMSW5wdXQocmVxdWVzdCk7XG4gIGlmICghaW5wdXQgfHwgIWlucHV0LnF1ZXJ5KSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IHsgcXVlcnksIHZhcmlhYmxlcyB9ID0gaW5wdXQ7XG4gIGNvbnN0IHBhcnNlZFJlc3VsdCA9IHBhcnNlUXVlcnkocXVlcnkpO1xuICBpZiAocGFyc2VkUmVzdWx0IGluc3RhbmNlb2YgRXJyb3IpIHtcbiAgICBjb25zdCByZXF1ZXN0UHVibGljVXJsID0gdG9QdWJsaWNVcmwocmVxdWVzdC51cmwpO1xuICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgIGRldlV0aWxzLmZvcm1hdE1lc3NhZ2UoXG4gICAgICAgICdGYWlsZWQgdG8gaW50ZXJjZXB0IGEgR3JhcGhRTCByZXF1ZXN0IHRvIFwiJXMgJXNcIjogY2Fubm90IHBhcnNlIHF1ZXJ5LiBTZWUgdGhlIGVycm9yIG1lc3NhZ2UgZnJvbSB0aGUgcGFyc2VyIGJlbG93LlxcblxcbiVzJyxcbiAgICAgICAgcmVxdWVzdC5tZXRob2QsXG4gICAgICAgIHJlcXVlc3RQdWJsaWNVcmwsXG4gICAgICAgIHBhcnNlZFJlc3VsdC5tZXNzYWdlXG4gICAgICApXG4gICAgKTtcbiAgfVxuICByZXR1cm4ge1xuICAgIHF1ZXJ5OiBpbnB1dC5xdWVyeSxcbiAgICBvcGVyYXRpb25UeXBlOiBwYXJzZWRSZXN1bHQub3BlcmF0aW9uVHlwZSxcbiAgICBvcGVyYXRpb25OYW1lOiBwYXJzZWRSZXN1bHQub3BlcmF0aW9uTmFtZSxcbiAgICB2YXJpYWJsZXNcbiAgfTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL21zd0AyLjIuMV90eXBlc2NyaXB0QDUuMy4zL25vZGVfbW9kdWxlcy9tc3cvbGliL2NvcmUvaGFuZGxlcnMvR3JhcGhRTEhhbmRsZXIubWpzXG5mdW5jdGlvbiBpc0RvY3VtZW50Tm9kZSh2YWx1ZSkge1xuICBpZiAodmFsdWUgPT0gbnVsbCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICByZXR1cm4gdHlwZW9mIHZhbHVlID09PSBcIm9iamVjdFwiICYmIFwia2luZFwiIGluIHZhbHVlICYmIFwiZGVmaW5pdGlvbnNcIiBpbiB2YWx1ZTtcbn1cbnZhciBfR3JhcGhRTEhhbmRsZXIgPSBjbGFzcyBfR3JhcGhRTEhhbmRsZXIgZXh0ZW5kcyBSZXF1ZXN0SGFuZGxlciB7XG4gIGNvbnN0cnVjdG9yKG9wZXJhdGlvblR5cGUsIG9wZXJhdGlvbk5hbWUsIGVuZHBvaW50LCByZXNvbHZlciwgb3B0aW9ucykge1xuICAgIGxldCByZXNvbHZlZE9wZXJhdGlvbk5hbWUgPSBvcGVyYXRpb25OYW1lO1xuICAgIGlmIChpc0RvY3VtZW50Tm9kZShvcGVyYXRpb25OYW1lKSkge1xuICAgICAgY29uc3QgcGFyc2VkTm9kZSA9IHBhcnNlRG9jdW1lbnROb2RlKG9wZXJhdGlvbk5hbWUpO1xuICAgICAgaWYgKHBhcnNlZE5vZGUub3BlcmF0aW9uVHlwZSAhPT0gb3BlcmF0aW9uVHlwZSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICAgYEZhaWxlZCB0byBjcmVhdGUgYSBHcmFwaFFMIGhhbmRsZXI6IHByb3ZpZGVkIGEgRG9jdW1lbnROb2RlIHdpdGggYSBtaXNtYXRjaGVkIG9wZXJhdGlvbiB0eXBlIChleHBlY3RlZCBcIiR7b3BlcmF0aW9uVHlwZX1cIiwgYnV0IGdvdCBcIiR7cGFyc2VkTm9kZS5vcGVyYXRpb25UeXBlfVwiKS5gXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBpZiAoIXBhcnNlZE5vZGUub3BlcmF0aW9uTmFtZSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICAgYEZhaWxlZCB0byBjcmVhdGUgYSBHcmFwaFFMIGhhbmRsZXI6IHByb3ZpZGVkIGEgRG9jdW1lbnROb2RlIHdpdGggbm8gb3BlcmF0aW9uIG5hbWUuYFxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgcmVzb2x2ZWRPcGVyYXRpb25OYW1lID0gcGFyc2VkTm9kZS5vcGVyYXRpb25OYW1lO1xuICAgIH1cbiAgICBjb25zdCBoZWFkZXIgPSBvcGVyYXRpb25UeXBlID09PSBcImFsbFwiID8gYCR7b3BlcmF0aW9uVHlwZX0gKG9yaWdpbjogJHtlbmRwb2ludC50b1N0cmluZygpfSlgIDogYCR7b3BlcmF0aW9uVHlwZX0gJHtyZXNvbHZlZE9wZXJhdGlvbk5hbWV9IChvcmlnaW46ICR7ZW5kcG9pbnQudG9TdHJpbmcoKX0pYDtcbiAgICBzdXBlcih7XG4gICAgICBpbmZvOiB7XG4gICAgICAgIGhlYWRlcixcbiAgICAgICAgb3BlcmF0aW9uVHlwZSxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogcmVzb2x2ZWRPcGVyYXRpb25OYW1lXG4gICAgICB9LFxuICAgICAgcmVzb2x2ZXIsXG4gICAgICBvcHRpb25zXG4gICAgfSk7XG4gICAgX19wdWJsaWNGaWVsZCh0aGlzLCBcImVuZHBvaW50XCIpO1xuICAgIHRoaXMuZW5kcG9pbnQgPSBlbmRwb2ludDtcbiAgfVxuICAvKipcbiAgICogUGFyc2VzIHRoZSByZXF1ZXN0IGJvZHksIG9uY2UgcGVyIHJlcXVlc3QsIGNhY2hlZCBhY3Jvc3MgYWxsXG4gICAqIEdyYXBoUUwgaGFuZGxlcnMuIFRoaXMgaXMgZG9uZSB0byBhdm9pZCBtdWx0aXBsZSBwYXJzaW5nIG9mIHRoZVxuICAgKiByZXF1ZXN0IGJvZHksIHdoaWNoIGVhY2ggcmVxdWlyZXMgYSBjbG9uZSBvZiB0aGUgcmVxdWVzdC5cbiAgICovXG4gIGFzeW5jIHBhcnNlR3JhcGhRTFJlcXVlc3RPckdldEZyb21DYWNoZShyZXF1ZXN0KSB7XG4gICAgaWYgKCFfR3JhcGhRTEhhbmRsZXIucGFyc2VkUmVxdWVzdENhY2hlLmhhcyhyZXF1ZXN0KSkge1xuICAgICAgX0dyYXBoUUxIYW5kbGVyLnBhcnNlZFJlcXVlc3RDYWNoZS5zZXQoXG4gICAgICAgIHJlcXVlc3QsXG4gICAgICAgIGF3YWl0IHBhcnNlR3JhcGhRTFJlcXVlc3QocmVxdWVzdCkuY2F0Y2goKGVycm9yKSA9PiB7XG4gICAgICAgICAgY29uc29sZS5lcnJvcihlcnJvcik7XG4gICAgICAgICAgcmV0dXJuIHZvaWQgMDtcbiAgICAgICAgfSlcbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiBfR3JhcGhRTEhhbmRsZXIucGFyc2VkUmVxdWVzdENhY2hlLmdldChyZXF1ZXN0KTtcbiAgfVxuICBhc3luYyBwYXJzZShhcmdzKSB7XG4gICAgY29uc3QgbWF0Y2gyID0gbWF0Y2hSZXF1ZXN0VXJsKG5ldyBVUkwoYXJncy5yZXF1ZXN0LnVybCksIHRoaXMuZW5kcG9pbnQpO1xuICAgIGNvbnN0IGNvb2tpZXMgPSBnZXRBbGxSZXF1ZXN0Q29va2llcyhhcmdzLnJlcXVlc3QpO1xuICAgIGlmICghbWF0Y2gyLm1hdGNoZXMpIHtcbiAgICAgIHJldHVybiB7IG1hdGNoOiBtYXRjaDIsIGNvb2tpZXMgfTtcbiAgICB9XG4gICAgY29uc3QgcGFyc2VkUmVzdWx0ID0gYXdhaXQgdGhpcy5wYXJzZUdyYXBoUUxSZXF1ZXN0T3JHZXRGcm9tQ2FjaGUoXG4gICAgICBhcmdzLnJlcXVlc3RcbiAgICApO1xuICAgIGlmICh0eXBlb2YgcGFyc2VkUmVzdWx0ID09PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICByZXR1cm4geyBtYXRjaDogbWF0Y2gyLCBjb29raWVzIH07XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICBtYXRjaDogbWF0Y2gyLFxuICAgICAgY29va2llcyxcbiAgICAgIHF1ZXJ5OiBwYXJzZWRSZXN1bHQucXVlcnksXG4gICAgICBvcGVyYXRpb25UeXBlOiBwYXJzZWRSZXN1bHQub3BlcmF0aW9uVHlwZSxcbiAgICAgIG9wZXJhdGlvbk5hbWU6IHBhcnNlZFJlc3VsdC5vcGVyYXRpb25OYW1lLFxuICAgICAgdmFyaWFibGVzOiBwYXJzZWRSZXN1bHQudmFyaWFibGVzXG4gICAgfTtcbiAgfVxuICBwcmVkaWNhdGUoYXJncykge1xuICAgIGlmIChhcmdzLnBhcnNlZFJlc3VsdC5vcGVyYXRpb25UeXBlID09PSB2b2lkIDApIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgaWYgKCFhcmdzLnBhcnNlZFJlc3VsdC5vcGVyYXRpb25OYW1lICYmIHRoaXMuaW5mby5vcGVyYXRpb25UeXBlICE9PSBcImFsbFwiKSB7XG4gICAgICBjb25zdCBwdWJsaWNVcmwgPSB0b1B1YmxpY1VybChhcmdzLnJlcXVlc3QudXJsKTtcbiAgICAgIGRldlV0aWxzLndhcm4oYEZhaWxlZCB0byBpbnRlcmNlcHQgYSBHcmFwaFFMIHJlcXVlc3QgYXQgXCIke2FyZ3MucmVxdWVzdC5tZXRob2R9ICR7cHVibGljVXJsfVwiOiBhbm9ueW1vdXMgR3JhcGhRTCBvcGVyYXRpb25zIGFyZSBub3Qgc3VwcG9ydGVkLlxuXG5Db25zaWRlciBuYW1pbmcgdGhpcyBvcGVyYXRpb24gb3IgdXNpbmcgXCJncmFwaHFsLm9wZXJhdGlvbigpXCIgcmVxdWVzdCBoYW5kbGVyIHRvIGludGVyY2VwdCBHcmFwaFFMIHJlcXVlc3RzIHJlZ2FyZGxlc3Mgb2YgdGhlaXIgb3BlcmF0aW9uIG5hbWUvdHlwZS4gUmVhZCBtb3JlOiBodHRwczovL21zd2pzLmlvL2RvY3MvYXBpL2dyYXBocWwvI2dyYXBocWxvcGVyYXRpb25yZXNvbHZlcmApO1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBjb25zdCBoYXNNYXRjaGluZ09wZXJhdGlvblR5cGUgPSB0aGlzLmluZm8ub3BlcmF0aW9uVHlwZSA9PT0gXCJhbGxcIiB8fCBhcmdzLnBhcnNlZFJlc3VsdC5vcGVyYXRpb25UeXBlID09PSB0aGlzLmluZm8ub3BlcmF0aW9uVHlwZTtcbiAgICBjb25zdCBoYXNNYXRjaGluZ09wZXJhdGlvbk5hbWUgPSB0aGlzLmluZm8ub3BlcmF0aW9uTmFtZSBpbnN0YW5jZW9mIFJlZ0V4cCA/IHRoaXMuaW5mby5vcGVyYXRpb25OYW1lLnRlc3QoYXJncy5wYXJzZWRSZXN1bHQub3BlcmF0aW9uTmFtZSB8fCBcIlwiKSA6IGFyZ3MucGFyc2VkUmVzdWx0Lm9wZXJhdGlvbk5hbWUgPT09IHRoaXMuaW5mby5vcGVyYXRpb25OYW1lO1xuICAgIHJldHVybiBhcmdzLnBhcnNlZFJlc3VsdC5tYXRjaC5tYXRjaGVzICYmIGhhc01hdGNoaW5nT3BlcmF0aW9uVHlwZSAmJiBoYXNNYXRjaGluZ09wZXJhdGlvbk5hbWU7XG4gIH1cbiAgZXh0ZW5kUmVzb2x2ZXJBcmdzKGFyZ3MpIHtcbiAgICByZXR1cm4ge1xuICAgICAgcXVlcnk6IGFyZ3MucGFyc2VkUmVzdWx0LnF1ZXJ5IHx8IFwiXCIsXG4gICAgICBvcGVyYXRpb25OYW1lOiBhcmdzLnBhcnNlZFJlc3VsdC5vcGVyYXRpb25OYW1lIHx8IFwiXCIsXG4gICAgICB2YXJpYWJsZXM6IGFyZ3MucGFyc2VkUmVzdWx0LnZhcmlhYmxlcyB8fCB7fSxcbiAgICAgIGNvb2tpZXM6IGFyZ3MucGFyc2VkUmVzdWx0LmNvb2tpZXNcbiAgICB9O1xuICB9XG4gIGFzeW5jIGxvZyhhcmdzKSB7XG4gICAgY29uc3QgbG9nZ2VkUmVxdWVzdCA9IGF3YWl0IHNlcmlhbGl6ZVJlcXVlc3QoYXJncy5yZXF1ZXN0KTtcbiAgICBjb25zdCBsb2dnZWRSZXNwb25zZSA9IGF3YWl0IHNlcmlhbGl6ZVJlc3BvbnNlKGFyZ3MucmVzcG9uc2UpO1xuICAgIGNvbnN0IHN0YXR1c0NvbG9yID0gZ2V0U3RhdHVzQ29kZUNvbG9yKGxvZ2dlZFJlc3BvbnNlLnN0YXR1cyk7XG4gICAgY29uc3QgcmVxdWVzdEluZm8gPSBhcmdzLnBhcnNlZFJlc3VsdC5vcGVyYXRpb25OYW1lID8gYCR7YXJncy5wYXJzZWRSZXN1bHQub3BlcmF0aW9uVHlwZX0gJHthcmdzLnBhcnNlZFJlc3VsdC5vcGVyYXRpb25OYW1lfWAgOiBgYW5vbnltb3VzICR7YXJncy5wYXJzZWRSZXN1bHQub3BlcmF0aW9uVHlwZX1gO1xuICAgIGNvbnNvbGUuZ3JvdXBDb2xsYXBzZWQoXG4gICAgICBkZXZVdGlscy5mb3JtYXRNZXNzYWdlKFxuICAgICAgICBgJHtnZXRUaW1lc3RhbXAoKX0gJHtyZXF1ZXN0SW5mb30gKCVjJHtsb2dnZWRSZXNwb25zZS5zdGF0dXN9ICR7bG9nZ2VkUmVzcG9uc2Uuc3RhdHVzVGV4dH0lYylgXG4gICAgICApLFxuICAgICAgYGNvbG9yOiR7c3RhdHVzQ29sb3J9YCxcbiAgICAgIFwiY29sb3I6aW5oZXJpdFwiXG4gICAgKTtcbiAgICBjb25zb2xlLmxvZyhcIlJlcXVlc3Q6XCIsIGxvZ2dlZFJlcXVlc3QpO1xuICAgIGNvbnNvbGUubG9nKFwiSGFuZGxlcjpcIiwgdGhpcyk7XG4gICAgY29uc29sZS5sb2coXCJSZXNwb25zZTpcIiwgbG9nZ2VkUmVzcG9uc2UpO1xuICAgIGNvbnNvbGUuZ3JvdXBFbmQoKTtcbiAgfVxufTtcbl9fcHVibGljRmllbGQoX0dyYXBoUUxIYW5kbGVyLCBcInBhcnNlZFJlcXVlc3RDYWNoZVwiLCAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKSk7XG52YXIgR3JhcGhRTEhhbmRsZXIgPSBfR3JhcGhRTEhhbmRsZXI7XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9tc3dAMi4yLjFfdHlwZXNjcmlwdEA1LjMuMy9ub2RlX21vZHVsZXMvbXN3L2xpYi9jb3JlL2dyYXBocWwubWpzXG5mdW5jdGlvbiBjcmVhdGVTY29wZWRHcmFwaFFMSGFuZGxlcihvcGVyYXRpb25UeXBlLCB1cmwpIHtcbiAgcmV0dXJuIChvcGVyYXRpb25OYW1lLCByZXNvbHZlciwgb3B0aW9ucyA9IHt9KSA9PiB7XG4gICAgcmV0dXJuIG5ldyBHcmFwaFFMSGFuZGxlcihcbiAgICAgIG9wZXJhdGlvblR5cGUsXG4gICAgICBvcGVyYXRpb25OYW1lLFxuICAgICAgdXJsLFxuICAgICAgcmVzb2x2ZXIsXG4gICAgICBvcHRpb25zXG4gICAgKTtcbiAgfTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUdyYXBoUUxPcGVyYXRpb25IYW5kbGVyKHVybCkge1xuICByZXR1cm4gKHJlc29sdmVyKSA9PiB7XG4gICAgcmV0dXJuIG5ldyBHcmFwaFFMSGFuZGxlcihcImFsbFwiLCBuZXcgUmVnRXhwKFwiLipcIiksIHVybCwgcmVzb2x2ZXIpO1xuICB9O1xufVxudmFyIHN0YW5kYXJkR3JhcGhRTEhhbmRsZXJzID0ge1xuICAvKipcbiAgICogSW50ZXJjZXB0cyBhIEdyYXBoUUwgcXVlcnkgYnkgYSBnaXZlbiBuYW1lLlxuICAgKlxuICAgKiBAZXhhbXBsZVxuICAgKiBncmFwaHFsLnF1ZXJ5KCdHZXRVc2VyJywgKCkgPT4ge1xuICAgKiAgIHJldHVybiBIdHRwUmVzcG9uc2UuanNvbih7IGRhdGE6IHsgdXNlcjogeyBuYW1lOiAnSm9obicgfSB9IH0pXG4gICAqIH0pXG4gICAqXG4gICAqIEBzZWUge0BsaW5rIGh0dHBzOi8vbXN3anMuaW8vZG9jcy9hcGkvZ3JhcGhxbCNncmFwaHFscXVlcnlxdWVyeW5hbWUtcmVzb2x2ZXIgYGdyYXBocWwucXVlcnkoKWAgQVBJIHJlZmVyZW5jZX1cbiAgICovXG4gIHF1ZXJ5OiBjcmVhdGVTY29wZWRHcmFwaFFMSGFuZGxlcihcInF1ZXJ5XCIsIFwiKlwiKSxcbiAgLyoqXG4gICAqIEludGVyY2VwdHMgYSBHcmFwaFFMIG11dGF0aW9uIGJ5IGl0cyBuYW1lLlxuICAgKlxuICAgKiBAZXhhbXBsZVxuICAgKiBncmFwaHFsLm11dGF0aW9uKCdTYXZlUG9zdCcsICgpID0+IHtcbiAgICogICByZXR1cm4gSHR0cFJlc3BvbnNlLmpzb24oeyBkYXRhOiB7IHBvc3Q6IHsgaWQ6ICdhYmMtMTIzIH0gfSB9KVxuICAgKiB9KVxuICAgKlxuICAgKiBAc2VlIHtAbGluayBodHRwczovL21zd2pzLmlvL2RvY3MvYXBpL2dyYXBocWwjZ3JhcGhxbG11dGF0aW9ubXV0YXRpb25uYW1lLXJlc29sdmVyIGBncmFwaHFsLnF1ZXJ5KClgIEFQSSByZWZlcmVuY2V9XG4gICAqXG4gICAqL1xuICBtdXRhdGlvbjogY3JlYXRlU2NvcGVkR3JhcGhRTEhhbmRsZXIoXCJtdXRhdGlvblwiLCBcIipcIiksXG4gIC8qKlxuICAgKiBJbnRlcmNlcHRzIGFueSBHcmFwaFFMIG9wZXJhdGlvbiwgcmVnYXJkbGVzcyBvZiBpdHMgdHlwZSBvciBuYW1lLlxuICAgKlxuICAgKiBAZXhhbXBsZVxuICAgKiBncmFwaHFsLm9wZXJhdGlvbigoKSA9PiB7XG4gICAqICAgcmV0dXJuIEh0dHBSZXNwb25zZS5qc29uKHsgZGF0YTogeyBuYW1lOiAnSm9obicgfSB9KVxuICAgKiB9KVxuICAgKlxuICAgKiBAc2VlIHtAbGluayBodHRwczovL21zd2pzLmlvL2RvY3MvYXBpL2dyYXBocWwjZ3JhcGhsb3BlcmF0aW9ucmVzb2x2ZXIgYGdyYXBocWwub3BlcmF0aW9uKClgIEFQSSByZWZlcmVuY2V9XG4gICAqL1xuICBvcGVyYXRpb246IGNyZWF0ZUdyYXBoUUxPcGVyYXRpb25IYW5kbGVyKFwiKlwiKVxufTtcbmZ1bmN0aW9uIGNyZWF0ZUdyYXBoUUxMaW5rKHVybCkge1xuICByZXR1cm4ge1xuICAgIG9wZXJhdGlvbjogY3JlYXRlR3JhcGhRTE9wZXJhdGlvbkhhbmRsZXIodXJsKSxcbiAgICBxdWVyeTogY3JlYXRlU2NvcGVkR3JhcGhRTEhhbmRsZXIoXCJxdWVyeVwiLCB1cmwpLFxuICAgIG11dGF0aW9uOiBjcmVhdGVTY29wZWRHcmFwaFFMSGFuZGxlcihcIm11dGF0aW9uXCIsIHVybClcbiAgfTtcbn1cbnZhciBncmFwaHFsMiA9IHtcbiAgLi4uc3RhbmRhcmRHcmFwaFFMSGFuZGxlcnMsXG4gIC8qKlxuICAgKiBJbnRlcmNlcHRzIEdyYXBoUUwgb3BlcmF0aW9ucyBzY29wZWQgYnkgdGhlIGdpdmVuIFVSTC5cbiAgICpcbiAgICogQGV4YW1wbGVcbiAgICogY29uc3QgZ2l0aHViID0gZ3JhcGhxbC5saW5rKCdodHRwczovL2FwaS5naXRodWIuY29tL2dyYXBocWwnKVxuICAgKiBnaXRodWIucXVlcnkoJ0dldFJlcG8nLCByZXNvbHZlcilcbiAgICpcbiAgICogQHNlZSB7QGxpbmsgaHR0cHM6Ly9tc3dqcy5pby9kb2NzL2FwaS9ncmFwaHFsI2dyYXBocWxsaW5rdXJsIGBncmFwaHFsLmxpbmsoKWAgQVBJIHJlZmVyZW5jZX1cbiAgICovXG4gIGxpbms6IGNyZWF0ZUdyYXBoUUxMaW5rXG59O1xuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vbXN3QDIuMi4xX3R5cGVzY3JpcHRANS4zLjMvbm9kZV9tb2R1bGVzL21zdy9saWIvY29yZS91dGlscy9pbnRlcm5hbC9yYW5kb21JZC5tanNcbmZ1bmN0aW9uIHJhbmRvbUlkKCkge1xuICByZXR1cm4gTWF0aC5yYW5kb20oKS50b1N0cmluZygxNikuc2xpY2UoMik7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9tc3dAMi4yLjFfdHlwZXNjcmlwdEA1LjMuMy9ub2RlX21vZHVsZXMvbXN3L2xpYi9jb3JlL2dldFJlc3BvbnNlLm1qc1xudmFyIGdldFJlc3BvbnNlID0gYXN5bmMgKGhhbmRsZXJzLCByZXF1ZXN0KSA9PiB7XG4gIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGV4ZWN1dGVIYW5kbGVycyh7XG4gICAgcmVxdWVzdCxcbiAgICByZXF1ZXN0SWQ6IHJhbmRvbUlkKCksXG4gICAgaGFuZGxlcnNcbiAgfSk7XG4gIHJldHVybiByZXN1bHQgPT0gbnVsbCA/IHZvaWQgMCA6IHJlc3VsdC5yZXNwb25zZTtcbn07XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9tc3dAMi4yLjFfdHlwZXNjcmlwdEA1LjMuMy9ub2RlX21vZHVsZXMvbXN3L2xpYi9jb3JlL3V0aWxzL0h0dHBSZXNwb25zZS9kZWNvcmF0b3JzLm1qc1xudmFyIHsgbWVzc2FnZTogbWVzc2FnZTIgfSA9IHNvdXJjZV9kZWZhdWx0O1xuZnVuY3Rpb24gbm9ybWFsaXplUmVzcG9uc2VJbml0KGluaXQgPSB7fSkge1xuICBjb25zdCBzdGF0dXMgPSAoaW5pdCA9PSBudWxsID8gdm9pZCAwIDogaW5pdC5zdGF0dXMpIHx8IDIwMDtcbiAgY29uc3Qgc3RhdHVzVGV4dCA9IChpbml0ID09IG51bGwgPyB2b2lkIDAgOiBpbml0LnN0YXR1c1RleHQpIHx8IG1lc3NhZ2UyW3N0YXR1c10gfHwgXCJcIjtcbiAgY29uc3QgaGVhZGVycyA9IG5ldyBIZWFkZXJzKGluaXQgPT0gbnVsbCA/IHZvaWQgMCA6IGluaXQuaGVhZGVycyk7XG4gIHJldHVybiB7XG4gICAgLi4uaW5pdCxcbiAgICBoZWFkZXJzLFxuICAgIHN0YXR1cyxcbiAgICBzdGF0dXNUZXh0XG4gIH07XG59XG5mdW5jdGlvbiBkZWNvcmF0ZVJlc3BvbnNlKHJlc3BvbnNlLCBpbml0KSB7XG4gIHZhciBfYTI7XG4gIGlmIChpbml0LnR5cGUpIHtcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkocmVzcG9uc2UsIFwidHlwZVwiLCB7XG4gICAgICB2YWx1ZTogaW5pdC50eXBlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIHdyaXRhYmxlOiBmYWxzZVxuICAgIH0pO1xuICB9XG4gIGlmICh0eXBlb2YgZG9jdW1lbnQgIT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICBjb25zdCByZXNwb25zZUNvb2tpZXMgPSAoKF9hMiA9IGluaXQuaGVhZGVycy5nZXQoXCJTZXQtQ29va2llXCIpKSA9PSBudWxsID8gdm9pZCAwIDogX2EyLnNwbGl0KFwiLFwiKSkgfHwgW107XG4gICAgZm9yIChjb25zdCBjb29raWVTdHJpbmcgb2YgcmVzcG9uc2VDb29raWVzKSB7XG4gICAgICBkb2N1bWVudC5jb29raWUgPSBjb29raWVTdHJpbmc7XG4gICAgfVxuICB9XG4gIHJldHVybiByZXNwb25zZTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL21zd0AyLjIuMV90eXBlc2NyaXB0QDUuMy4zL25vZGVfbW9kdWxlcy9tc3cvbGliL2NvcmUvSHR0cFJlc3BvbnNlLm1qc1xudmFyIEh0dHBSZXNwb25zZSA9IGNsYXNzIF9IdHRwUmVzcG9uc2UgZXh0ZW5kcyBSZXNwb25zZSB7XG4gIGNvbnN0cnVjdG9yKGJvZHksIGluaXQpIHtcbiAgICBjb25zdCByZXNwb25zZUluaXQgPSBub3JtYWxpemVSZXNwb25zZUluaXQoaW5pdCk7XG4gICAgc3VwZXIoYm9keSwgcmVzcG9uc2VJbml0KTtcbiAgICBkZWNvcmF0ZVJlc3BvbnNlKHRoaXMsIHJlc3BvbnNlSW5pdCk7XG4gIH1cbiAgLyoqXG4gICAqIENyZWF0ZSBhIGBSZXNwb25zZWAgd2l0aCBhIGBDb250ZW50LVR5cGU6IFwidGV4dC9wbGFpblwiYCBib2R5LlxuICAgKiBAZXhhbXBsZVxuICAgKiBIdHRwUmVzcG9uc2UudGV4dCgnaGVsbG8gd29ybGQnKVxuICAgKiBIdHRwUmVzcG9uc2UudGV4dCgnRXJyb3InLCB7IHN0YXR1czogNTAwIH0pXG4gICAqL1xuICBzdGF0aWMgdGV4dChib2R5LCBpbml0KSB7XG4gICAgY29uc3QgcmVzcG9uc2VJbml0ID0gbm9ybWFsaXplUmVzcG9uc2VJbml0KGluaXQpO1xuICAgIGlmICghcmVzcG9uc2VJbml0LmhlYWRlcnMuaGFzKFwiQ29udGVudC1UeXBlXCIpKSB7XG4gICAgICByZXNwb25zZUluaXQuaGVhZGVycy5zZXQoXCJDb250ZW50LVR5cGVcIiwgXCJ0ZXh0L3BsYWluXCIpO1xuICAgIH1cbiAgICBpZiAoIXJlc3BvbnNlSW5pdC5oZWFkZXJzLmhhcyhcIkNvbnRlbnQtTGVuZ3RoXCIpKSB7XG4gICAgICByZXNwb25zZUluaXQuaGVhZGVycy5zZXQoXG4gICAgICAgIFwiQ29udGVudC1MZW5ndGhcIixcbiAgICAgICAgYm9keSA/IGJvZHkubGVuZ3RoLnRvU3RyaW5nKCkgOiBcIjBcIlxuICAgICAgKTtcbiAgICB9XG4gICAgcmV0dXJuIG5ldyBfSHR0cFJlc3BvbnNlKGJvZHksIHJlc3BvbnNlSW5pdCk7XG4gIH1cbiAgLyoqXG4gICAqIENyZWF0ZSBhIGBSZXNwb25zZWAgd2l0aCBhIGBDb250ZW50LVR5cGU6IFwiYXBwbGljYXRpb24vanNvblwiYCBib2R5LlxuICAgKiBAZXhhbXBsZVxuICAgKiBIdHRwUmVzcG9uc2UuanNvbih7IGZpcnN0TmFtZTogJ0pvaG4nIH0pXG4gICAqIEh0dHBSZXNwb25zZS5qc29uKHsgZXJyb3I6ICdOb3QgQXV0aG9yaXplZCcgfSwgeyBzdGF0dXM6IDQwMSB9KVxuICAgKi9cbiAgc3RhdGljIGpzb24oYm9keSwgaW5pdCkge1xuICAgIGNvbnN0IHJlc3BvbnNlSW5pdCA9IG5vcm1hbGl6ZVJlc3BvbnNlSW5pdChpbml0KTtcbiAgICBpZiAoIXJlc3BvbnNlSW5pdC5oZWFkZXJzLmhhcyhcIkNvbnRlbnQtVHlwZVwiKSkge1xuICAgICAgcmVzcG9uc2VJbml0LmhlYWRlcnMuc2V0KFwiQ29udGVudC1UeXBlXCIsIFwiYXBwbGljYXRpb24vanNvblwiKTtcbiAgICB9XG4gICAgY29uc3QgcmVzcG9uc2VUZXh0ID0gSlNPTi5zdHJpbmdpZnkoYm9keSk7XG4gICAgaWYgKCFyZXNwb25zZUluaXQuaGVhZGVycy5oYXMoXCJDb250ZW50LUxlbmd0aFwiKSkge1xuICAgICAgcmVzcG9uc2VJbml0LmhlYWRlcnMuc2V0KFxuICAgICAgICBcIkNvbnRlbnQtTGVuZ3RoXCIsXG4gICAgICAgIHJlc3BvbnNlVGV4dCA/IHJlc3BvbnNlVGV4dC5sZW5ndGgudG9TdHJpbmcoKSA6IFwiMFwiXG4gICAgICApO1xuICAgIH1cbiAgICByZXR1cm4gbmV3IF9IdHRwUmVzcG9uc2UoXG4gICAgICByZXNwb25zZVRleHQsXG4gICAgICByZXNwb25zZUluaXRcbiAgICApO1xuICB9XG4gIC8qKlxuICAgKiBDcmVhdGUgYSBgUmVzcG9uc2VgIHdpdGggYSBgQ29udGVudC1UeXBlOiBcImFwcGxpY2F0aW9uL3htbFwiYCBib2R5LlxuICAgKiBAZXhhbXBsZVxuICAgKiBIdHRwUmVzcG9uc2UueG1sKGA8dXNlciBuYW1lPVwiSm9oblwiIC8+YClcbiAgICogSHR0cFJlc3BvbnNlLnhtbChgPGFydGljbGUgaWQ9XCJhYmMtMTIzXCIgLz5gLCB7IHN0YXR1czogMjAxIH0pXG4gICAqL1xuICBzdGF0aWMgeG1sKGJvZHksIGluaXQpIHtcbiAgICBjb25zdCByZXNwb25zZUluaXQgPSBub3JtYWxpemVSZXNwb25zZUluaXQoaW5pdCk7XG4gICAgaWYgKCFyZXNwb25zZUluaXQuaGVhZGVycy5oYXMoXCJDb250ZW50LVR5cGVcIikpIHtcbiAgICAgIHJlc3BvbnNlSW5pdC5oZWFkZXJzLnNldChcIkNvbnRlbnQtVHlwZVwiLCBcInRleHQveG1sXCIpO1xuICAgIH1cbiAgICByZXR1cm4gbmV3IF9IdHRwUmVzcG9uc2UoYm9keSwgcmVzcG9uc2VJbml0KTtcbiAgfVxuICAvKipcbiAgICogQ3JlYXRlIGEgYFJlc3BvbnNlYCB3aXRoIGFuIGBBcnJheUJ1ZmZlcmAgYm9keS5cbiAgICogQGV4YW1wbGVcbiAgICogY29uc3QgYnVmZmVyID0gbmV3IEFycmF5QnVmZmVyKDMpXG4gICAqIGNvbnN0IHZpZXcgPSBuZXcgVWludDhBcnJheShidWZmZXIpXG4gICAqIHZpZXcuc2V0KFsxLCAyLCAzXSlcbiAgICpcbiAgICogSHR0cFJlc3BvbnNlLmFycmF5QnVmZmVyKGJ1ZmZlcilcbiAgICovXG4gIHN0YXRpYyBhcnJheUJ1ZmZlcihib2R5LCBpbml0KSB7XG4gICAgY29uc3QgcmVzcG9uc2VJbml0ID0gbm9ybWFsaXplUmVzcG9uc2VJbml0KGluaXQpO1xuICAgIGlmIChib2R5KSB7XG4gICAgICByZXNwb25zZUluaXQuaGVhZGVycy5zZXQoXCJDb250ZW50LUxlbmd0aFwiLCBib2R5LmJ5dGVMZW5ndGgudG9TdHJpbmcoKSk7XG4gICAgfVxuICAgIHJldHVybiBuZXcgX0h0dHBSZXNwb25zZShib2R5LCByZXNwb25zZUluaXQpO1xuICB9XG4gIC8qKlxuICAgKiBDcmVhdGUgYSBgUmVzcG9uc2VgIHdpdGggYSBgRm9ybURhdGFgIGJvZHkuXG4gICAqIEBleGFtcGxlXG4gICAqIGNvbnN0IGRhdGEgPSBuZXcgRm9ybURhdGEoKVxuICAgKiBkYXRhLnNldCgnbmFtZScsICdBbGljZScpXG4gICAqXG4gICAqIEh0dHBSZXNwb25zZS5mb3JtRGF0YShkYXRhKVxuICAgKi9cbiAgc3RhdGljIGZvcm1EYXRhKGJvZHksIGluaXQpIHtcbiAgICByZXR1cm4gbmV3IF9IdHRwUmVzcG9uc2UoYm9keSwgbm9ybWFsaXplUmVzcG9uc2VJbml0KGluaXQpKTtcbiAgfVxufTtcblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL21zd0AyLjIuMV90eXBlc2NyaXB0QDUuMy4zL25vZGVfbW9kdWxlcy9tc3cvbGliL2NvcmUvZGVsYXkubWpzXG52YXIgU0VUX1RJTUVPVVRfTUFYX0FMTE9XRURfSU5UID0gMjE0NzQ4MzY0NztcbnZhciBNSU5fU0VSVkVSX1JFU1BPTlNFX1RJTUUgPSAxMDA7XG52YXIgTUFYX1NFUlZFUl9SRVNQT05TRV9USU1FID0gNDAwO1xudmFyIE5PREVfU0VSVkVSX1JFU1BPTlNFX1RJTUUgPSA1O1xuZnVuY3Rpb24gZ2V0UmVhbGlzdGljUmVzcG9uc2VUaW1lKCkge1xuICBpZiAoaXNOb2RlUHJvY2VzcygpKSB7XG4gICAgcmV0dXJuIE5PREVfU0VSVkVSX1JFU1BPTlNFX1RJTUU7XG4gIH1cbiAgcmV0dXJuIE1hdGguZmxvb3IoXG4gICAgTWF0aC5yYW5kb20oKSAqIChNQVhfU0VSVkVSX1JFU1BPTlNFX1RJTUUgLSBNSU5fU0VSVkVSX1JFU1BPTlNFX1RJTUUpICsgTUlOX1NFUlZFUl9SRVNQT05TRV9USU1FXG4gICk7XG59XG5hc3luYyBmdW5jdGlvbiBkZWxheShkdXJhdGlvbk9yTW9kZSkge1xuICBsZXQgZGVsYXlUaW1lO1xuICBpZiAodHlwZW9mIGR1cmF0aW9uT3JNb2RlID09PSBcInN0cmluZ1wiKSB7XG4gICAgc3dpdGNoIChkdXJhdGlvbk9yTW9kZSkge1xuICAgICAgY2FzZSBcImluZmluaXRlXCI6IHtcbiAgICAgICAgZGVsYXlUaW1lID0gU0VUX1RJTUVPVVRfTUFYX0FMTE9XRURfSU5UO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICAgIGNhc2UgXCJyZWFsXCI6IHtcbiAgICAgICAgZGVsYXlUaW1lID0gZ2V0UmVhbGlzdGljUmVzcG9uc2VUaW1lKCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgZGVmYXVsdDoge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICAgYEZhaWxlZCB0byBkZWxheSBhIHJlc3BvbnNlOiB1bmtub3duIGRlbGF5IG1vZGUgXCIke2R1cmF0aW9uT3JNb2RlfVwiLiBQbGVhc2UgbWFrZSBzdXJlIHlvdSBwcm92aWRlIG9uZSBvZiB0aGUgc3VwcG9ydGVkIG1vZGVzIChcInJlYWxcIiwgXCJpbmZpbml0ZVwiKSBvciBhIG51bWJlci5gXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuICB9IGVsc2UgaWYgKHR5cGVvZiBkdXJhdGlvbk9yTW9kZSA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgIGRlbGF5VGltZSA9IGdldFJlYWxpc3RpY1Jlc3BvbnNlVGltZSgpO1xuICB9IGVsc2Uge1xuICAgIGlmIChkdXJhdGlvbk9yTW9kZSA+IFNFVF9USU1FT1VUX01BWF9BTExPV0VEX0lOVCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICBgRmFpbGVkIHRvIGRlbGF5IGEgcmVzcG9uc2U6IHByb3ZpZGVkIGRlbGF5IGR1cmF0aW9uICgke2R1cmF0aW9uT3JNb2RlfSkgZXhjZWVkcyB0aGUgbWF4aW11bSBhbGxvd2VkIGR1cmF0aW9uIGZvciBcInNldFRpbWVvdXRcIiAoJHtTRVRfVElNRU9VVF9NQVhfQUxMT1dFRF9JTlR9KS4gVGhpcyB3aWxsIGNhdXNlIHRoZSByZXNwb25zZSB0byBiZSByZXR1cm5lZCBpbW1lZGlhdGVseS4gUGxlYXNlIHVzZSBhIG51bWJlciB3aXRoaW4gdGhlIGFsbG93ZWQgcmFuZ2UgdG8gZGVsYXkgdGhlIHJlc3BvbnNlIGJ5IGV4YWN0IGR1cmF0aW9uLCBvciBjb25zaWRlciB0aGUgXCJpbmZpbml0ZVwiIGRlbGF5IG1vZGUgdG8gZGVsYXkgdGhlIHJlc3BvbnNlIGluZGVmaW5pdGVseS5gXG4gICAgICApO1xuICAgIH1cbiAgICBkZWxheVRpbWUgPSBkdXJhdGlvbk9yTW9kZTtcbiAgfVxuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHNldFRpbWVvdXQocmVzb2x2ZSwgZGVsYXlUaW1lKSk7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9tc3dAMi4yLjFfdHlwZXNjcmlwdEA1LjMuMy9ub2RlX21vZHVsZXMvbXN3L2xpYi9jb3JlL2J5cGFzcy5tanNcbmZ1bmN0aW9uIGJ5cGFzcyhpbnB1dCwgaW5pdCkge1xuICBjb25zdCByZXF1ZXN0ID0gaW5wdXQgaW5zdGFuY2VvZiBSZXF1ZXN0ID8gaW5wdXQgOiBuZXcgUmVxdWVzdChpbnB1dCwgaW5pdCk7XG4gIGludmFyaWFudChcbiAgICAhcmVxdWVzdC5ib2R5VXNlZCxcbiAgICAnRmFpbGVkIHRvIGNyZWF0ZSBhIGJ5cGFzc2VkIHJlcXVlc3QgdG8gXCIlcyAlc1wiOiBnaXZlbiByZXF1ZXN0IGluc3RhbmNlIGFscmVhZHkgaGFzIGl0cyBib2R5IHJlYWQuIE1ha2Ugc3VyZSB0byBjbG9uZSB0aGUgaW50ZXJjZXB0ZWQgcmVxdWVzdCBpZiB5b3Ugd2lzaCB0byByZWFkIGl0cyBib2R5IGJlZm9yZSBieXBhc3NpbmcgaXQuJyxcbiAgICByZXF1ZXN0Lm1ldGhvZCxcbiAgICByZXF1ZXN0LnVybFxuICApO1xuICBjb25zdCByZXF1ZXN0Q2xvbmUgPSByZXF1ZXN0LmNsb25lKCk7XG4gIHJlcXVlc3RDbG9uZS5oZWFkZXJzLnNldChcIngtbXN3LWludGVudGlvblwiLCBcImJ5cGFzc1wiKTtcbiAgcmV0dXJuIHJlcXVlc3RDbG9uZTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL21zd0AyLjIuMV90eXBlc2NyaXB0QDUuMy4zL25vZGVfbW9kdWxlcy9tc3cvbGliL2NvcmUvcGFzc3Rocm91Z2gubWpzXG5mdW5jdGlvbiBwYXNzdGhyb3VnaCgpIHtcbiAgcmV0dXJuIG5ldyBSZXNwb25zZShudWxsLCB7XG4gICAgc3RhdHVzOiAzMDIsXG4gICAgc3RhdHVzVGV4dDogXCJQYXNzdGhyb3VnaFwiLFxuICAgIGhlYWRlcnM6IHtcbiAgICAgIFwieC1tc3ctaW50ZW50aW9uXCI6IFwicGFzc3Rocm91Z2hcIlxuICAgIH1cbiAgfSk7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9tc3dAMi4yLjFfdHlwZXNjcmlwdEA1LjMuMy9ub2RlX21vZHVsZXMvbXN3L2xpYi9jb3JlL2luZGV4Lm1qc1xuY2hlY2tHbG9iYWxzKCk7XG5leHBvcnQge1xuICBHcmFwaFFMSGFuZGxlcixcbiAgSHR0cEhhbmRsZXIsXG4gIEh0dHBNZXRob2RzLFxuICBIdHRwUmVzcG9uc2UsXG4gIE1BWF9TRVJWRVJfUkVTUE9OU0VfVElNRSxcbiAgTUlOX1NFUlZFUl9SRVNQT05TRV9USU1FLFxuICBOT0RFX1NFUlZFUl9SRVNQT05TRV9USU1FLFxuICBSZXF1ZXN0SGFuZGxlcixcbiAgU0VUX1RJTUVPVVRfTUFYX0FMTE9XRURfSU5ULFxuICBTZXR1cEFwaSxcbiAgYnlwYXNzLFxuICBjbGVhblVybCxcbiAgZGVsYXksXG4gIGdldFJlc3BvbnNlLFxuICBncmFwaHFsMiBhcyBncmFwaHFsLFxuICBoYW5kbGVSZXF1ZXN0LFxuICBodHRwLFxuICBtYXRjaFJlcXVlc3RVcmwsXG4gIHBhc3N0aHJvdWdoXG59O1xuLyohIEJ1bmRsZWQgbGljZW5zZSBpbmZvcm1hdGlvbjpcblxuQGJ1bmRsZWQtZXMtbW9kdWxlcy9zdGF0dXNlcy9pbmRleC1lc20uanM6XG4gICgqISBCdW5kbGVkIGxpY2Vuc2UgaW5mb3JtYXRpb246XG4gIFxuICBzdGF0dXNlcy9pbmRleC5qczpcbiAgICAoKiFcbiAgICAgKiBzdGF0dXNlc1xuICAgICAqIENvcHlyaWdodChjKSAyMDE0IEpvbmF0aGFuIE9uZ1xuICAgICAqIENvcHlyaWdodChjKSAyMDE2IERvdWdsYXMgQ2hyaXN0b3BoZXIgV2lsc29uXG4gICAgICogTUlUIExpY2Vuc2VkXG4gICAgICopXG4gICopXG5cbkBidW5kbGVkLWVzLW1vZHVsZXMvY29va2llL2luZGV4LWVzbS5qczpcbiAgKCohIEJ1bmRsZWQgbGljZW5zZSBpbmZvcm1hdGlvbjpcbiAgXG4gIGNvb2tpZS9pbmRleC5qczpcbiAgICAoKiFcbiAgICAgKiBjb29raWVcbiAgICAgKiBDb3B5cmlnaHQoYykgMjAxMi0yMDE0IFJvbWFuIFNodHlsbWFuXG4gICAgICogQ29weXJpZ2h0KGMpIDIwMTUgRG91Z2xhcyBDaHJpc3RvcGhlciBXaWxzb25cbiAgICAgKiBNSVQgTGljZW5zZWRcbiAgICAgKilcbiAgKilcbiovXG4vLyMgc291cmNlTWFwcGluZ1VSTD1tc3cuanMubWFwXG4iXSwibWFwcGluZ3MiOiJBQUFBO0FBQUEsRUFDRTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxPQUNLO0FBQ1A7QUFBQSxFQUNFO0FBQUEsT0FDSztBQUdQLFNBQVMsZUFBZTtBQUN0QjtBQUFBLElBQ0UsT0FBTyxRQUFRO0FBQUEsSUFDZixTQUFTO0FBQUEsTUFDUDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0Y7QUFHQSxTQUFTLGNBQWMsUUFBUSxVQUFVO0FBQ3ZDLFNBQU8sT0FBTyxZQUFZLE1BQU0sU0FBUyxZQUFZO0FBQ3ZEO0FBR0EsSUFBSSxtQkFBbUIsQ0FBQyxxQkFBcUI7QUFDM0MsbUJBQWlCLFNBQVMsSUFBSTtBQUM5QixtQkFBaUIsU0FBUyxJQUFJO0FBQzlCLG1CQUFpQixRQUFRLElBQUk7QUFDN0IsU0FBTztBQUNULEdBQUcsbUJBQW1CLENBQUMsQ0FBQztBQUN4QixTQUFTLG1CQUFtQixRQUFRO0FBQ2xDLE1BQUksU0FBUyxLQUFLO0FBQ2hCLFdBQU87QUFBQSxFQUNUO0FBQ0EsTUFBSSxTQUFTLEtBQUs7QUFDaEIsV0FBTztBQUFBLEVBQ1Q7QUFDQSxTQUFPO0FBQ1Q7QUFHQSxTQUFTLGVBQWU7QUFDdEIsUUFBTSxNQUFzQixvQkFBSSxLQUFLO0FBQ3JDLFNBQU8sQ0FBQyxJQUFJLFNBQVMsR0FBRyxJQUFJLFdBQVcsR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFFLElBQUksTUFBTSxFQUFFLElBQUksQ0FBQyxVQUFVLE1BQU0sTUFBTSxHQUFHLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxVQUFVLE1BQU0sU0FBUyxHQUFHLEdBQUcsQ0FBQyxFQUFFLEtBQUssR0FBRztBQUMzSjtBQUdBLGVBQWUsaUJBQWlCLFNBQVM7QUFDdkMsUUFBTSxlQUFlLFFBQVEsTUFBTTtBQUNuQyxRQUFNLGNBQWMsTUFBTSxhQUFhLEtBQUs7QUFDNUMsU0FBTztBQUFBLElBQ0wsS0FBSyxJQUFJLElBQUksUUFBUSxHQUFHO0FBQUEsSUFDeEIsUUFBUSxRQUFRO0FBQUEsSUFDaEIsU0FBUyxPQUFPLFlBQVksUUFBUSxRQUFRLFFBQVEsQ0FBQztBQUFBLElBQ3JELE1BQU07QUFBQSxFQUNSO0FBQ0Y7QUFHQSxJQUFJLFdBQVcsT0FBTztBQUN0QixJQUFJLFlBQVksT0FBTztBQUN2QixJQUFJLG1CQUFtQixPQUFPO0FBQzlCLElBQUksb0JBQW9CLE9BQU87QUFDL0IsSUFBSSxlQUFlLE9BQU87QUFDMUIsSUFBSSxlQUFlLE9BQU8sVUFBVTtBQUNwQyxJQUFJLGFBQWEsQ0FBQyxJQUFJLFFBQVEsU0FBUyxZQUFZO0FBQ2pELFNBQU8sUUFBUSxHQUFHLEdBQUcsa0JBQWtCLEVBQUUsRUFBRSxDQUFDLENBQUMsSUFBSSxNQUFNLEVBQUUsU0FBUyxDQUFDLEVBQUUsR0FBRyxTQUFTLEdBQUcsR0FBRyxJQUFJO0FBQzdGO0FBQ0EsSUFBSSxjQUFjLENBQUMsSUFBSSxNQUFNLFFBQVEsU0FBUztBQUM1QyxNQUFJLFFBQVEsT0FBTyxTQUFTLFlBQVksT0FBTyxTQUFTLFlBQVk7QUFDbEUsYUFBUyxPQUFPLGtCQUFrQixJQUFJO0FBQ3BDLFVBQUksQ0FBQyxhQUFhLEtBQUssSUFBSSxHQUFHLEtBQUssUUFBUTtBQUN6QyxrQkFBVSxJQUFJLEtBQUssRUFBRSxLQUFLLE1BQU0sS0FBSyxHQUFHLEdBQUcsWUFBWSxFQUFFLE9BQU8saUJBQWlCLE1BQU0sR0FBRyxNQUFNLEtBQUssV0FBVyxDQUFDO0FBQUEsRUFDdkg7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxJQUFJLFVBQVUsQ0FBQyxLQUFLLFlBQVksWUFBWSxTQUFTLE9BQU8sT0FBTyxTQUFTLGFBQWEsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUtuRyxjQUFjLENBQUMsT0FBTyxDQUFDLElBQUksYUFBYSxVQUFVLFFBQVEsV0FBVyxFQUFFLE9BQU8sS0FBSyxZQUFZLEtBQUssQ0FBQyxJQUFJO0FBQUEsRUFDekc7QUFDRjtBQUNBLElBQUksZ0JBQWdCLFdBQVc7QUFBQSxFQUM3QixtQ0FBbUMsU0FBUyxRQUFRO0FBQ2xELFdBQU8sVUFBVTtBQUFBLE1BQ2YsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBQ0YsQ0FBQztBQUNELElBQUksbUJBQW1CLFdBQVc7QUFBQSxFQUNoQyxpQ0FBaUMsU0FBUyxRQUFRO0FBQ2hEO0FBQ0EsUUFBSSxRQUFRLGNBQWM7QUFDMUIsV0FBTyxVQUFVO0FBQ2pCLFlBQVEsVUFBVTtBQUNsQixZQUFRLE9BQU8sNkJBQTZCLEtBQUs7QUFDakQsWUFBUSxRQUFRLHFCQUFxQixLQUFLO0FBQzFDLFlBQVEsV0FBVztBQUFBLE1BQ2pCLEtBQUs7QUFBQSxNQUNMLEtBQUs7QUFBQSxNQUNMLEtBQUs7QUFBQSxNQUNMLEtBQUs7QUFBQSxNQUNMLEtBQUs7QUFBQSxNQUNMLEtBQUs7QUFBQSxNQUNMLEtBQUs7QUFBQSxJQUNQO0FBQ0EsWUFBUSxRQUFRO0FBQUEsTUFDZCxLQUFLO0FBQUEsTUFDTCxLQUFLO0FBQUEsTUFDTCxLQUFLO0FBQUEsSUFDUDtBQUNBLFlBQVEsUUFBUTtBQUFBLE1BQ2QsS0FBSztBQUFBLE1BQ0wsS0FBSztBQUFBLE1BQ0wsS0FBSztBQUFBLElBQ1A7QUFDQSxhQUFTLDZCQUE2QixRQUFRO0FBQzVDLFVBQUksTUFBTSxDQUFDO0FBQ1gsYUFBTyxLQUFLLE1BQU0sRUFBRSxRQUFRLFNBQVMsWUFBWSxNQUFNO0FBQ3JELFlBQUksV0FBVyxPQUFPLElBQUk7QUFDMUIsWUFBSSxVQUFVLE9BQU8sSUFBSTtBQUN6QixZQUFJLFNBQVMsWUFBWSxDQUFDLElBQUk7QUFBQSxNQUNoQyxDQUFDO0FBQ0QsYUFBTztBQUFBLElBQ1Q7QUFDQSxhQUFTLHFCQUFxQixRQUFRO0FBQ3BDLGFBQU8sT0FBTyxLQUFLLE1BQU0sRUFBRSxJQUFJLFNBQVMsUUFBUSxNQUFNO0FBQ3BELGVBQU8sT0FBTyxJQUFJO0FBQUEsTUFDcEIsQ0FBQztBQUFBLElBQ0g7QUFDQSxhQUFTLGNBQWMsVUFBVTtBQUMvQixVQUFJLE1BQU0sU0FBUyxZQUFZO0FBQy9CLFVBQUksQ0FBQyxPQUFPLFVBQVUsZUFBZSxLQUFLLFFBQVEsTUFBTSxHQUFHLEdBQUc7QUFDNUQsY0FBTSxJQUFJLE1BQU0sOEJBQThCLFdBQVcsR0FBRztBQUFBLE1BQzlEO0FBQ0EsYUFBTyxRQUFRLEtBQUssR0FBRztBQUFBLElBQ3pCO0FBQ0EsYUFBUyxpQkFBaUIsTUFBTTtBQUM5QixVQUFJLENBQUMsT0FBTyxVQUFVLGVBQWUsS0FBSyxRQUFRLFNBQVMsSUFBSSxHQUFHO0FBQ2hFLGNBQU0sSUFBSSxNQUFNLDBCQUEwQixJQUFJO0FBQUEsTUFDaEQ7QUFDQSxhQUFPLFFBQVEsUUFBUSxJQUFJO0FBQUEsSUFDN0I7QUFDQSxhQUFTLFFBQVEsTUFBTTtBQUNyQixVQUFJLE9BQU8sU0FBUyxVQUFVO0FBQzVCLGVBQU8saUJBQWlCLElBQUk7QUFBQSxNQUM5QjtBQUNBLFVBQUksT0FBTyxTQUFTLFVBQVU7QUFDNUIsY0FBTSxJQUFJLFVBQVUsaUNBQWlDO0FBQUEsTUFDdkQ7QUFDQSxVQUFJLElBQUksU0FBUyxNQUFNLEVBQUU7QUFDekIsVUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHO0FBQ2IsZUFBTyxpQkFBaUIsQ0FBQztBQUFBLE1BQzNCO0FBQ0EsYUFBTyxjQUFjLElBQUk7QUFBQSxJQUMzQjtBQUFBLEVBQ0Y7QUFDRixDQUFDO0FBQ0QsSUFBSSxrQkFBa0IsUUFBUSxpQkFBaUIsR0FBRyxDQUFDO0FBQ25ELElBQUksaUJBQWlCLGdCQUFnQjtBQUdyQyxJQUFJLEVBQUUsUUFBUSxJQUFJO0FBQ2xCLGVBQWUsa0JBQWtCLFVBQVU7QUFDekMsUUFBTSxnQkFBZ0IsU0FBUyxNQUFNO0FBQ3JDLFFBQU0sZUFBZSxNQUFNLGNBQWMsS0FBSztBQUM5QyxRQUFNLGlCQUFpQixjQUFjLFVBQVU7QUFDL0MsUUFBTSxxQkFBcUIsY0FBYyxjQUFjLFFBQVEsY0FBYyxLQUFLO0FBQ2xGLFNBQU87QUFBQSxJQUNMLFFBQVE7QUFBQSxJQUNSLFlBQVk7QUFBQSxJQUNaLFNBQVMsT0FBTyxZQUFZLGNBQWMsUUFBUSxRQUFRLENBQUM7QUFBQSxJQUMzRCxNQUFNO0FBQUEsRUFDUjtBQUNGO0FBR0EsU0FBUyxNQUFNLEtBQUs7QUFDbEIsTUFBSSxTQUFTLENBQUM7QUFDZCxNQUFJLElBQUk7QUFDUixTQUFPLElBQUksSUFBSSxRQUFRO0FBQ3JCLFFBQUksT0FBTyxJQUFJLENBQUM7QUFDaEIsUUFBSSxTQUFTLE9BQU8sU0FBUyxPQUFPLFNBQVMsS0FBSztBQUNoRCxhQUFPLEtBQUssRUFBRSxNQUFNLFlBQVksT0FBTyxHQUFHLE9BQU8sSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUMzRDtBQUFBLElBQ0Y7QUFDQSxRQUFJLFNBQVMsTUFBTTtBQUNqQixhQUFPLEtBQUssRUFBRSxNQUFNLGdCQUFnQixPQUFPLEtBQUssT0FBTyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQ2pFO0FBQUEsSUFDRjtBQUNBLFFBQUksU0FBUyxLQUFLO0FBQ2hCLGFBQU8sS0FBSyxFQUFFLE1BQU0sUUFBUSxPQUFPLEdBQUcsT0FBTyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQ3ZEO0FBQUEsSUFDRjtBQUNBLFFBQUksU0FBUyxLQUFLO0FBQ2hCLGFBQU8sS0FBSyxFQUFFLE1BQU0sU0FBUyxPQUFPLEdBQUcsT0FBTyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQ3hEO0FBQUEsSUFDRjtBQUNBLFFBQUksU0FBUyxLQUFLO0FBQ2hCLFVBQUksT0FBTztBQUNYLFVBQUksSUFBSSxJQUFJO0FBQ1osYUFBTyxJQUFJLElBQUksUUFBUTtBQUNyQixZQUFJLE9BQU8sSUFBSSxXQUFXLENBQUM7QUFDM0I7QUFBQTtBQUFBLFVBRUUsUUFBUSxNQUFNLFFBQVE7QUFBQSxVQUN0QixRQUFRLE1BQU0sUUFBUTtBQUFBLFVBQ3RCLFFBQVEsTUFBTSxRQUFRO0FBQUEsVUFDdEIsU0FBUztBQUFBLFVBQ1Q7QUFDQSxrQkFBUSxJQUFJLEdBQUc7QUFDZjtBQUFBLFFBQ0Y7QUFDQTtBQUFBLE1BQ0Y7QUFDQSxVQUFJLENBQUM7QUFDSCxjQUFNLElBQUksVUFBVSw2QkFBNkIsT0FBTyxDQUFDLENBQUM7QUFDNUQsYUFBTyxLQUFLLEVBQUUsTUFBTSxRQUFRLE9BQU8sR0FBRyxPQUFPLEtBQUssQ0FBQztBQUNuRCxVQUFJO0FBQ0o7QUFBQSxJQUNGO0FBQ0EsUUFBSSxTQUFTLEtBQUs7QUFDaEIsVUFBSSxRQUFRO0FBQ1osVUFBSSxVQUFVO0FBQ2QsVUFBSSxJQUFJLElBQUk7QUFDWixVQUFJLElBQUksQ0FBQyxNQUFNLEtBQUs7QUFDbEIsY0FBTSxJQUFJLFVBQVUsb0NBQW9DLE9BQU8sQ0FBQyxDQUFDO0FBQUEsTUFDbkU7QUFDQSxhQUFPLElBQUksSUFBSSxRQUFRO0FBQ3JCLFlBQUksSUFBSSxDQUFDLE1BQU0sTUFBTTtBQUNuQixxQkFBVyxJQUFJLEdBQUcsSUFBSSxJQUFJLEdBQUc7QUFDN0I7QUFBQSxRQUNGO0FBQ0EsWUFBSSxJQUFJLENBQUMsTUFBTSxLQUFLO0FBQ2xCO0FBQ0EsY0FBSSxVQUFVLEdBQUc7QUFDZjtBQUNBO0FBQUEsVUFDRjtBQUFBLFFBQ0YsV0FBVyxJQUFJLENBQUMsTUFBTSxLQUFLO0FBQ3pCO0FBQ0EsY0FBSSxJQUFJLElBQUksQ0FBQyxNQUFNLEtBQUs7QUFDdEIsa0JBQU0sSUFBSSxVQUFVLHVDQUF1QyxPQUFPLENBQUMsQ0FBQztBQUFBLFVBQ3RFO0FBQUEsUUFDRjtBQUNBLG1CQUFXLElBQUksR0FBRztBQUFBLE1BQ3BCO0FBQ0EsVUFBSTtBQUNGLGNBQU0sSUFBSSxVQUFVLHlCQUF5QixPQUFPLENBQUMsQ0FBQztBQUN4RCxVQUFJLENBQUM7QUFDSCxjQUFNLElBQUksVUFBVSxzQkFBc0IsT0FBTyxDQUFDLENBQUM7QUFDckQsYUFBTyxLQUFLLEVBQUUsTUFBTSxXQUFXLE9BQU8sR0FBRyxPQUFPLFFBQVEsQ0FBQztBQUN6RCxVQUFJO0FBQ0o7QUFBQSxJQUNGO0FBQ0EsV0FBTyxLQUFLLEVBQUUsTUFBTSxRQUFRLE9BQU8sR0FBRyxPQUFPLElBQUksR0FBRyxFQUFFLENBQUM7QUFBQSxFQUN6RDtBQUNBLFNBQU8sS0FBSyxFQUFFLE1BQU0sT0FBTyxPQUFPLEdBQUcsT0FBTyxHQUFHLENBQUM7QUFDaEQsU0FBTztBQUNUO0FBQ0EsU0FBUyxNQUFNLEtBQUssU0FBUztBQUMzQixNQUFJLFlBQVksUUFBUTtBQUN0QixjQUFVLENBQUM7QUFBQSxFQUNiO0FBQ0EsTUFBSSxTQUFTLE1BQU0sR0FBRztBQUN0QixNQUFJLE1BQU0sUUFBUSxVQUFVLFdBQVcsUUFBUSxTQUFTLE9BQU87QUFDL0QsTUFBSSxpQkFBaUIsS0FBSyxPQUFPLGFBQWEsUUFBUSxhQUFhLEtBQUssR0FBRyxLQUFLO0FBQ2hGLE1BQUksU0FBUyxDQUFDO0FBQ2QsTUFBSSxNQUFNO0FBQ1YsTUFBSSxJQUFJO0FBQ1IsTUFBSSxPQUFPO0FBQ1gsTUFBSSxhQUFhLFNBQVMsTUFBTTtBQUM5QixRQUFJLElBQUksT0FBTyxVQUFVLE9BQU8sQ0FBQyxFQUFFLFNBQVM7QUFDMUMsYUFBTyxPQUFPLEdBQUcsRUFBRTtBQUFBLEVBQ3ZCO0FBQ0EsTUFBSSxjQUFjLFNBQVMsTUFBTTtBQUMvQixRQUFJLFNBQVMsV0FBVyxJQUFJO0FBQzVCLFFBQUksV0FBVztBQUNiLGFBQU87QUFDVCxRQUFJLE1BQU0sT0FBTyxDQUFDLEdBQUcsV0FBVyxJQUFJLE1BQU0sUUFBUSxJQUFJO0FBQ3RELFVBQU0sSUFBSSxVQUFVLGNBQWMsT0FBTyxVQUFVLE1BQU0sRUFBRSxPQUFPLE9BQU8sYUFBYSxFQUFFLE9BQU8sSUFBSSxDQUFDO0FBQUEsRUFDdEc7QUFDQSxNQUFJLGNBQWMsV0FBVztBQUMzQixRQUFJLFVBQVU7QUFDZCxRQUFJO0FBQ0osV0FBTyxTQUFTLFdBQVcsTUFBTSxLQUFLLFdBQVcsY0FBYyxHQUFHO0FBQ2hFLGlCQUFXO0FBQUEsSUFDYjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQ0EsU0FBTyxJQUFJLE9BQU8sUUFBUTtBQUN4QixRQUFJLE9BQU8sV0FBVyxNQUFNO0FBQzVCLFFBQUksT0FBTyxXQUFXLE1BQU07QUFDNUIsUUFBSSxVQUFVLFdBQVcsU0FBUztBQUNsQyxRQUFJLFFBQVEsU0FBUztBQUNuQixVQUFJLFNBQVMsUUFBUTtBQUNyQixVQUFJLFNBQVMsUUFBUSxNQUFNLE1BQU0sSUFBSTtBQUNuQyxnQkFBUTtBQUNSLGlCQUFTO0FBQUEsTUFDWDtBQUNBLFVBQUksTUFBTTtBQUNSLGVBQU8sS0FBSyxJQUFJO0FBQ2hCLGVBQU87QUFBQSxNQUNUO0FBQ0EsYUFBTyxLQUFLO0FBQUEsUUFDVixNQUFNLFFBQVE7QUFBQSxRQUNkO0FBQUEsUUFDQSxRQUFRO0FBQUEsUUFDUixTQUFTLFdBQVc7QUFBQSxRQUNwQixVQUFVLFdBQVcsVUFBVSxLQUFLO0FBQUEsTUFDdEMsQ0FBQztBQUNEO0FBQUEsSUFDRjtBQUNBLFFBQUksUUFBUSxRQUFRLFdBQVcsY0FBYztBQUM3QyxRQUFJLE9BQU87QUFDVCxjQUFRO0FBQ1I7QUFBQSxJQUNGO0FBQ0EsUUFBSSxNQUFNO0FBQ1IsYUFBTyxLQUFLLElBQUk7QUFDaEIsYUFBTztBQUFBLElBQ1Q7QUFDQSxRQUFJLE9BQU8sV0FBVyxNQUFNO0FBQzVCLFFBQUksTUFBTTtBQUNSLFVBQUksU0FBUyxZQUFZO0FBQ3pCLFVBQUksU0FBUyxXQUFXLE1BQU0sS0FBSztBQUNuQyxVQUFJLFlBQVksV0FBVyxTQUFTLEtBQUs7QUFDekMsVUFBSSxTQUFTLFlBQVk7QUFDekIsa0JBQVksT0FBTztBQUNuQixhQUFPLEtBQUs7QUFBQSxRQUNWLE1BQU0sV0FBVyxZQUFZLFFBQVE7QUFBQSxRQUNyQyxTQUFTLFVBQVUsQ0FBQyxZQUFZLGlCQUFpQjtBQUFBLFFBQ2pEO0FBQUEsUUFDQTtBQUFBLFFBQ0EsVUFBVSxXQUFXLFVBQVUsS0FBSztBQUFBLE1BQ3RDLENBQUM7QUFDRDtBQUFBLElBQ0Y7QUFDQSxnQkFBWSxLQUFLO0FBQUEsRUFDbkI7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLE1BQU0sS0FBSyxTQUFTO0FBQzNCLE1BQUksT0FBTyxDQUFDO0FBQ1osTUFBSSxLQUFLLGFBQWEsS0FBSyxNQUFNLE9BQU87QUFDeEMsU0FBTyxpQkFBaUIsSUFBSSxNQUFNLE9BQU87QUFDM0M7QUFDQSxTQUFTLGlCQUFpQixJQUFJLE1BQU0sU0FBUztBQUMzQyxNQUFJLFlBQVksUUFBUTtBQUN0QixjQUFVLENBQUM7QUFBQSxFQUNiO0FBQ0EsTUFBSSxNQUFNLFFBQVEsUUFBUSxTQUFTLFFBQVEsU0FBUyxTQUFTLEdBQUc7QUFDOUQsV0FBTztBQUFBLEVBQ1QsSUFBSTtBQUNKLFNBQU8sU0FBUyxVQUFVO0FBQ3hCLFFBQUksSUFBSSxHQUFHLEtBQUssUUFBUTtBQUN4QixRQUFJLENBQUM7QUFDSCxhQUFPO0FBQ1QsUUFBSSxPQUFPLEVBQUUsQ0FBQyxHQUFHLFFBQVEsRUFBRTtBQUMzQixRQUFJLFNBQXlCLHVCQUFPLE9BQU8sSUFBSTtBQUMvQyxRQUFJLFVBQVUsU0FBUyxJQUFJO0FBQ3pCLFVBQUksRUFBRSxFQUFFLE1BQU07QUFDWixlQUFPO0FBQ1QsVUFBSSxNQUFNLEtBQUssS0FBSyxDQUFDO0FBQ3JCLFVBQUksSUFBSSxhQUFhLE9BQU8sSUFBSSxhQUFhLEtBQUs7QUFDaEQsZUFBTyxJQUFJLElBQUksSUFBSSxFQUFFLEVBQUUsRUFBRSxNQUFNLElBQUksU0FBUyxJQUFJLE1BQU0sRUFBRSxJQUFJLFNBQVMsT0FBTztBQUMxRSxpQkFBTyxPQUFPLE9BQU8sR0FBRztBQUFBLFFBQzFCLENBQUM7QUFBQSxNQUNILE9BQU87QUFDTCxlQUFPLElBQUksSUFBSSxJQUFJLE9BQU8sRUFBRSxFQUFFLEdBQUcsR0FBRztBQUFBLE1BQ3RDO0FBQUEsSUFDRjtBQUNBLGFBQVMsSUFBSSxHQUFHLElBQUksRUFBRSxRQUFRLEtBQUs7QUFDakMsY0FBUSxDQUFDO0FBQUEsSUFDWDtBQUNBLFdBQU8sRUFBRSxNQUFNLE9BQU8sT0FBTztBQUFBLEVBQy9CO0FBQ0Y7QUFDQSxTQUFTLGFBQWEsS0FBSztBQUN6QixTQUFPLElBQUksUUFBUSw2QkFBNkIsTUFBTTtBQUN4RDtBQUNBLFNBQVMsTUFBTSxTQUFTO0FBQ3RCLFNBQU8sV0FBVyxRQUFRLFlBQVksS0FBSztBQUM3QztBQUNBLFNBQVMsZUFBZSxNQUFNLE1BQU07QUFDbEMsTUFBSSxDQUFDO0FBQ0gsV0FBTztBQUNULE1BQUksY0FBYztBQUNsQixNQUFJLFFBQVE7QUFDWixNQUFJLGFBQWEsWUFBWSxLQUFLLEtBQUssTUFBTTtBQUM3QyxTQUFPLFlBQVk7QUFDakIsU0FBSyxLQUFLO0FBQUE7QUFBQSxNQUVSLE1BQU0sV0FBVyxDQUFDLEtBQUs7QUFBQSxNQUN2QixRQUFRO0FBQUEsTUFDUixRQUFRO0FBQUEsTUFDUixVQUFVO0FBQUEsTUFDVixTQUFTO0FBQUEsSUFDWCxDQUFDO0FBQ0QsaUJBQWEsWUFBWSxLQUFLLEtBQUssTUFBTTtBQUFBLEVBQzNDO0FBQ0EsU0FBTztBQUNUO0FBQ0EsU0FBUyxjQUFjLE9BQU8sTUFBTSxTQUFTO0FBQzNDLE1BQUksUUFBUSxNQUFNLElBQUksU0FBUyxNQUFNO0FBQ25DLFdBQU8sYUFBYSxNQUFNLE1BQU0sT0FBTyxFQUFFO0FBQUEsRUFDM0MsQ0FBQztBQUNELFNBQU8sSUFBSSxPQUFPLE1BQU0sT0FBTyxNQUFNLEtBQUssR0FBRyxHQUFHLEdBQUcsR0FBRyxNQUFNLE9BQU8sQ0FBQztBQUN0RTtBQUNBLFNBQVMsZUFBZSxNQUFNLE1BQU0sU0FBUztBQUMzQyxTQUFPLGVBQWUsTUFBTSxNQUFNLE9BQU8sR0FBRyxNQUFNLE9BQU87QUFDM0Q7QUFDQSxTQUFTLGVBQWUsUUFBUSxNQUFNLFNBQVM7QUFDN0MsTUFBSSxZQUFZLFFBQVE7QUFDdEIsY0FBVSxDQUFDO0FBQUEsRUFDYjtBQUNBLE1BQUksTUFBTSxRQUFRLFFBQVEsU0FBUyxRQUFRLFNBQVMsUUFBUSxLQUFLLE1BQU0sUUFBUSxPQUFPLFFBQVEsUUFBUSxTQUFTLE9BQU8sS0FBSyxLQUFLLFFBQVEsS0FBSyxNQUFNLE9BQU8sU0FBUyxPQUFPLElBQUksS0FBSyxRQUFRLFFBQVEsU0FBUyxPQUFPLFNBQVMsU0FBUyxHQUFHO0FBQ3RPLFdBQU87QUFBQSxFQUNULElBQUksSUFBSSxLQUFLLFFBQVEsV0FBVyxZQUFZLE9BQU8sU0FBUyxRQUFRLElBQUksS0FBSyxRQUFRLFVBQVUsV0FBVyxPQUFPLFNBQVMsS0FBSztBQUMvSCxNQUFJLGFBQWEsSUFBSSxPQUFPLGFBQWEsUUFBUSxHQUFHLEtBQUs7QUFDekQsTUFBSSxjQUFjLElBQUksT0FBTyxhQUFhLFNBQVMsR0FBRyxHQUFHO0FBQ3pELE1BQUksUUFBUSxRQUFRLE1BQU07QUFDMUIsV0FBUyxLQUFLLEdBQUcsV0FBVyxRQUFRLEtBQUssU0FBUyxRQUFRLE1BQU07QUFDOUQsUUFBSSxRQUFRLFNBQVMsRUFBRTtBQUN2QixRQUFJLE9BQU8sVUFBVSxVQUFVO0FBQzdCLGVBQVMsYUFBYSxPQUFPLEtBQUssQ0FBQztBQUFBLElBQ3JDLE9BQU87QUFDTCxVQUFJLFNBQVMsYUFBYSxPQUFPLE1BQU0sTUFBTSxDQUFDO0FBQzlDLFVBQUksU0FBUyxhQUFhLE9BQU8sTUFBTSxNQUFNLENBQUM7QUFDOUMsVUFBSSxNQUFNLFNBQVM7QUFDakIsWUFBSTtBQUNGLGVBQUssS0FBSyxLQUFLO0FBQ2pCLFlBQUksVUFBVSxRQUFRO0FBQ3BCLGNBQUksTUFBTSxhQUFhLE9BQU8sTUFBTSxhQUFhLEtBQUs7QUFDcEQsZ0JBQUksTUFBTSxNQUFNLGFBQWEsTUFBTSxNQUFNO0FBQ3pDLHFCQUFTLE1BQU0sT0FBTyxRQUFRLE1BQU0sRUFBRSxPQUFPLE1BQU0sU0FBUyxNQUFNLEVBQUUsT0FBTyxNQUFNLEVBQUUsT0FBTyxRQUFRLEtBQUssRUFBRSxPQUFPLE1BQU0sU0FBUyxNQUFNLEVBQUUsT0FBTyxRQUFRLEdBQUcsRUFBRSxPQUFPLEdBQUc7QUFBQSxVQUN2SyxPQUFPO0FBQ0wscUJBQVMsTUFBTSxPQUFPLFFBQVEsR0FBRyxFQUFFLE9BQU8sTUFBTSxTQUFTLEdBQUcsRUFBRSxPQUFPLFFBQVEsR0FBRyxFQUFFLE9BQU8sTUFBTSxRQUFRO0FBQUEsVUFDekc7QUFBQSxRQUNGLE9BQU87QUFDTCxjQUFJLE1BQU0sYUFBYSxPQUFPLE1BQU0sYUFBYSxLQUFLO0FBQ3BELHFCQUFTLE9BQU8sT0FBTyxNQUFNLFNBQVMsR0FBRyxFQUFFLE9BQU8sTUFBTSxVQUFVLEdBQUc7QUFBQSxVQUN2RSxPQUFPO0FBQ0wscUJBQVMsSUFBSSxPQUFPLE1BQU0sU0FBUyxHQUFHLEVBQUUsT0FBTyxNQUFNLFFBQVE7QUFBQSxVQUMvRDtBQUFBLFFBQ0Y7QUFBQSxNQUNGLE9BQU87QUFDTCxpQkFBUyxNQUFNLE9BQU8sTUFBTSxFQUFFLE9BQU8sUUFBUSxHQUFHLEVBQUUsT0FBTyxNQUFNLFFBQVE7QUFBQSxNQUN6RTtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsTUFBSSxLQUFLO0FBQ1AsUUFBSSxDQUFDO0FBQ0gsZUFBUyxHQUFHLE9BQU8sYUFBYSxHQUFHO0FBQ3JDLGFBQVMsQ0FBQyxRQUFRLFdBQVcsTUFBTSxNQUFNLE9BQU8sWUFBWSxHQUFHO0FBQUEsRUFDakUsT0FBTztBQUNMLFFBQUksV0FBVyxPQUFPLE9BQU8sU0FBUyxDQUFDO0FBQ3ZDLFFBQUksaUJBQWlCLE9BQU8sYUFBYSxXQUFXLFlBQVksUUFBUSxTQUFTLFNBQVMsU0FBUyxDQUFDLENBQUMsSUFBSSxLQUFLLGFBQWE7QUFDM0gsUUFBSSxDQUFDLFFBQVE7QUFDWCxlQUFTLE1BQU0sT0FBTyxhQUFhLEtBQUssRUFBRSxPQUFPLFlBQVksS0FBSztBQUFBLElBQ3BFO0FBQ0EsUUFBSSxDQUFDLGdCQUFnQjtBQUNuQixlQUFTLE1BQU0sT0FBTyxhQUFhLEdBQUcsRUFBRSxPQUFPLFlBQVksR0FBRztBQUFBLElBQ2hFO0FBQUEsRUFDRjtBQUNBLFNBQU8sSUFBSSxPQUFPLE9BQU8sTUFBTSxPQUFPLENBQUM7QUFDekM7QUFDQSxTQUFTLGFBQWEsTUFBTSxNQUFNLFNBQVM7QUFDekMsTUFBSSxnQkFBZ0I7QUFDbEIsV0FBTyxlQUFlLE1BQU0sSUFBSTtBQUNsQyxNQUFJLE1BQU0sUUFBUSxJQUFJO0FBQ3BCLFdBQU8sY0FBYyxNQUFNLE1BQU0sT0FBTztBQUMxQyxTQUFPLGVBQWUsTUFBTSxNQUFNLE9BQU87QUFDM0M7QUFHQSxJQUFJLFVBQVUsSUFBSSxZQUFZO0FBRzlCLFNBQVMsZ0JBQWdCO0FBQ3ZCLE1BQUksT0FBTyxjQUFjLGVBQWUsVUFBVSxZQUFZLGVBQWU7QUFDM0UsV0FBTztBQUFBLEVBQ1Q7QUFDQSxNQUFJLE9BQU8sWUFBWSxhQUFhO0FBQ2xDLFVBQU0sT0FBTyxRQUFRO0FBQ3JCLFFBQUksU0FBUyxjQUFjLFNBQVMsVUFBVTtBQUM1QyxhQUFPO0FBQUEsSUFDVDtBQUNBLFdBQU8sQ0FBQyxFQUFFLFFBQVEsWUFBWSxRQUFRLFNBQVM7QUFBQSxFQUNqRDtBQUNBLFNBQU87QUFDVDtBQUdBLElBQUksYUFBYSxPQUFPO0FBQ3hCLElBQUksV0FBVyxDQUFDLFFBQVEsUUFBUTtBQUM5QixXQUFTLFFBQVE7QUFDZixlQUFXLFFBQVEsTUFBTSxFQUFFLEtBQUssSUFBSSxJQUFJLEdBQUcsWUFBWSxLQUFLLENBQUM7QUFDakU7QUFDQSxJQUFJLGlCQUFpQixDQUFDO0FBQ3RCLFNBQVMsZ0JBQWdCO0FBQUEsRUFDdkIsTUFBTSxNQUFNO0FBQUEsRUFDWixNQUFNLE1BQU07QUFBQSxFQUNaLE9BQU8sTUFBTTtBQUFBLEVBQ2IsS0FBSyxNQUFNO0FBQUEsRUFDWCxRQUFRLE1BQU07QUFDaEIsQ0FBQztBQUNELFNBQVMsT0FBTyxNQUFNO0FBQ3BCLFNBQU8sV0FBVyxJQUFJO0FBQ3hCO0FBQ0EsU0FBUyxLQUFLLE1BQU07QUFDbEIsU0FBTyxXQUFXLElBQUk7QUFDeEI7QUFDQSxTQUFTLEtBQUssTUFBTTtBQUNsQixTQUFPLFdBQVcsSUFBSTtBQUN4QjtBQUNBLFNBQVMsSUFBSSxNQUFNO0FBQ2pCLFNBQU8sV0FBVyxJQUFJO0FBQ3hCO0FBQ0EsU0FBUyxNQUFNLE1BQU07QUFDbkIsU0FBTyxXQUFXLElBQUk7QUFDeEI7QUFDQSxJQUFJLFVBQVUsY0FBYztBQUc1QixJQUFJLG9CQUFvQixPQUFPLGlCQUFpQjtBQUNoRCxJQUFJLHlCQUF5QixDQUFDLDJCQUEyQjtBQUN2RCx5QkFBdUIsVUFBVSxJQUFJO0FBQ3JDLHlCQUF1QixVQUFVLElBQUk7QUFDckMseUJBQXVCLFNBQVMsSUFBSTtBQUNwQyx5QkFBdUIsV0FBVyxJQUFJO0FBQ3RDLHlCQUF1QixVQUFVLElBQUk7QUFDckMsU0FBTztBQUNULEdBQUcseUJBQXlCLENBQUMsQ0FBQztBQUc5QixTQUFTLFlBQVksS0FBSyxhQUFhLE1BQU07QUFDM0MsU0FBTyxDQUFDLGNBQWMsSUFBSSxRQUFRLElBQUksUUFBUSxFQUFFLE9BQU8sT0FBTyxFQUFFLEtBQUssRUFBRTtBQUN6RTtBQUdBLElBQUksMkJBQTJCO0FBQy9CLFNBQVMsZ0JBQWdCLE1BQU07QUFDN0IsU0FBTyxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksa0JBQWtCLEVBQUU7QUFDakQ7QUFDQSxTQUFTLFNBQVMsTUFBTTtBQUN0QixTQUFPLEtBQUssUUFBUSwwQkFBMEIsRUFBRTtBQUNsRDtBQUdBLFNBQVMsY0FBYyxLQUFLO0FBQzFCLFNBQU8sZ0NBQWdDLEtBQUssR0FBRztBQUNqRDtBQUdBLFNBQVMsZUFBZSxNQUFNLFNBQVM7QUFDckMsTUFBSSxjQUFjLElBQUksR0FBRztBQUN2QixXQUFPO0FBQUEsRUFDVDtBQUNBLE1BQUksS0FBSyxXQUFXLEdBQUcsR0FBRztBQUN4QixXQUFPO0FBQUEsRUFDVDtBQUNBLFFBQU0sU0FBUyxXQUFXLE9BQU8sYUFBYSxlQUFlLFNBQVM7QUFDdEUsU0FBTztBQUFBO0FBQUEsSUFFTCxVQUFVLElBQUksSUFBSSxVQUFVLElBQUksR0FBRyxNQUFNLEVBQUUsSUFBSTtBQUFBLE1BQzdDO0FBQ047QUFHQSxTQUFTLGNBQWMsTUFBTSxTQUFTO0FBQ3BDLE1BQUksZ0JBQWdCLFFBQVE7QUFDMUIsV0FBTztBQUFBLEVBQ1Q7QUFDQSxRQUFNLG1CQUFtQixlQUFlLE1BQU0sT0FBTztBQUNyRCxTQUFPLFNBQVMsZ0JBQWdCO0FBQ2xDO0FBR0EsU0FBUyxXQUFXLE1BQU07QUFDeEIsU0FBTyxLQUFLO0FBQUEsSUFDVjtBQUFBLElBQ0EsQ0FBQyxHQUFHLGVBQWUsYUFBYTtBQUM5QixZQUFNLGFBQWE7QUFDbkIsVUFBSSxDQUFDLGVBQWU7QUFDbEIsZUFBTztBQUFBLE1BQ1Q7QUFDQSxhQUFPLGNBQWMsV0FBVyxHQUFHLElBQUksR0FBRyxhQUFhLEdBQUcsUUFBUSxLQUFLLEdBQUcsYUFBYSxHQUFHLFVBQVU7QUFBQSxJQUN0RztBQUFBLEVBQ0YsRUFBRSxRQUFRLHFCQUFxQixRQUFRLEVBQUUsUUFBUSx3QkFBd0IsUUFBUTtBQUNuRjtBQUNBLFNBQVMsZ0JBQWdCLEtBQUssTUFBTSxTQUFTO0FBQzNDLFFBQU0saUJBQWlCLGNBQWMsTUFBTSxPQUFPO0FBQ2xELFFBQU0sWUFBWSxPQUFPLG1CQUFtQixXQUFXLFdBQVcsY0FBYyxJQUFJO0FBQ3BGLFFBQU0sWUFBWSxZQUFZLEdBQUc7QUFDakMsUUFBTSxTQUFTLE1BQU0sV0FBVyxFQUFFLFFBQVEsbUJBQW1CLENBQUMsRUFBRSxTQUFTO0FBQ3pFLFFBQU0sU0FBUyxVQUFVLE9BQU8sVUFBVSxDQUFDO0FBQzNDLFNBQU87QUFBQSxJQUNMLFNBQVMsV0FBVztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUNGO0FBR0EsSUFBSSxZQUFZLE9BQU87QUFDdkIsSUFBSSxhQUFhLE9BQU87QUFDeEIsSUFBSSxvQkFBb0IsT0FBTztBQUMvQixJQUFJLHFCQUFxQixPQUFPO0FBQ2hDLElBQUksZ0JBQWdCLE9BQU87QUFDM0IsSUFBSSxnQkFBZ0IsT0FBTyxVQUFVO0FBQ3JDLElBQUksY0FBYyxDQUFDLElBQUksUUFBUSxTQUFTLFlBQVk7QUFDbEQsU0FBTyxRQUFRLEdBQUcsR0FBRyxtQkFBbUIsRUFBRSxFQUFFLENBQUMsQ0FBQyxJQUFJLE1BQU0sRUFBRSxTQUFTLENBQUMsRUFBRSxHQUFHLFNBQVMsR0FBRyxHQUFHLElBQUk7QUFDOUY7QUFDQSxJQUFJLGVBQWUsQ0FBQyxJQUFJLE1BQU0sUUFBUSxTQUFTO0FBQzdDLE1BQUksUUFBUSxPQUFPLFNBQVMsWUFBWSxPQUFPLFNBQVMsWUFBWTtBQUNsRSxhQUFTLE9BQU8sbUJBQW1CLElBQUk7QUFDckMsVUFBSSxDQUFDLGNBQWMsS0FBSyxJQUFJLEdBQUcsS0FBSyxRQUFRO0FBQzFDLG1CQUFXLElBQUksS0FBSyxFQUFFLEtBQUssTUFBTSxLQUFLLEdBQUcsR0FBRyxZQUFZLEVBQUUsT0FBTyxrQkFBa0IsTUFBTSxHQUFHLE1BQU0sS0FBSyxXQUFXLENBQUM7QUFBQSxFQUN6SDtBQUNBLFNBQU87QUFDVDtBQUNBLElBQUksV0FBVyxDQUFDLEtBQUssWUFBWSxZQUFZLFNBQVMsT0FBTyxPQUFPLFVBQVUsY0FBYyxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS3RHLGNBQWMsQ0FBQyxPQUFPLENBQUMsSUFBSSxhQUFhLFdBQVcsUUFBUSxXQUFXLEVBQUUsT0FBTyxLQUFLLFlBQVksS0FBSyxDQUFDLElBQUk7QUFBQSxFQUMxRztBQUNGO0FBQ0EsSUFBSSxpQkFBaUIsWUFBWTtBQUFBLEVBQy9CLCtCQUErQixTQUFTO0FBQ3RDO0FBQ0EsWUFBUSxRQUFRO0FBQ2hCLFlBQVEsWUFBWTtBQUNwQixRQUFJLGFBQWEsT0FBTyxVQUFVO0FBQ2xDLFFBQUkscUJBQXFCO0FBQ3pCLGFBQVMsT0FBTyxLQUFLLFNBQVM7QUFDNUIsVUFBSSxPQUFPLFFBQVEsVUFBVTtBQUMzQixjQUFNLElBQUksVUFBVSwrQkFBK0I7QUFBQSxNQUNyRDtBQUNBLFVBQUksTUFBTSxDQUFDO0FBQ1gsVUFBSSxNQUFNLFdBQVcsQ0FBQztBQUN0QixVQUFJLE1BQU0sSUFBSSxVQUFVO0FBQ3hCLFVBQUksUUFBUTtBQUNaLGFBQU8sUUFBUSxJQUFJLFFBQVE7QUFDekIsWUFBSSxRQUFRLElBQUksUUFBUSxLQUFLLEtBQUs7QUFDbEMsWUFBSSxVQUFVLElBQUk7QUFDaEI7QUFBQSxRQUNGO0FBQ0EsWUFBSSxTQUFTLElBQUksUUFBUSxLQUFLLEtBQUs7QUFDbkMsWUFBSSxXQUFXLElBQUk7QUFDakIsbUJBQVMsSUFBSTtBQUFBLFFBQ2YsV0FBVyxTQUFTLE9BQU87QUFDekIsa0JBQVEsSUFBSSxZQUFZLEtBQUssUUFBUSxDQUFDLElBQUk7QUFDMUM7QUFBQSxRQUNGO0FBQ0EsWUFBSSxNQUFNLElBQUksTUFBTSxPQUFPLEtBQUssRUFBRSxLQUFLO0FBQ3ZDLFlBQUksV0FBVyxJQUFJLEdBQUcsR0FBRztBQUN2QixjQUFJLE1BQU0sSUFBSSxNQUFNLFFBQVEsR0FBRyxNQUFNLEVBQUUsS0FBSztBQUM1QyxjQUFJLElBQUksV0FBVyxDQUFDLE1BQU0sSUFBSTtBQUM1QixrQkFBTSxJQUFJLE1BQU0sR0FBRyxFQUFFO0FBQUEsVUFDdkI7QUFDQSxjQUFJLEdBQUcsSUFBSSxVQUFVLEtBQUssR0FBRztBQUFBLFFBQy9CO0FBQ0EsZ0JBQVEsU0FBUztBQUFBLE1BQ25CO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFDQSxhQUFTLFVBQVUsTUFBTSxLQUFLLFNBQVM7QUFDckMsVUFBSSxNQUFNLFdBQVcsQ0FBQztBQUN0QixVQUFJLE1BQU0sSUFBSSxVQUFVO0FBQ3hCLFVBQUksT0FBTyxRQUFRLFlBQVk7QUFDN0IsY0FBTSxJQUFJLFVBQVUsMEJBQTBCO0FBQUEsTUFDaEQ7QUFDQSxVQUFJLENBQUMsbUJBQW1CLEtBQUssSUFBSSxHQUFHO0FBQ2xDLGNBQU0sSUFBSSxVQUFVLDBCQUEwQjtBQUFBLE1BQ2hEO0FBQ0EsVUFBSSxRQUFRLElBQUksR0FBRztBQUNuQixVQUFJLFNBQVMsQ0FBQyxtQkFBbUIsS0FBSyxLQUFLLEdBQUc7QUFDNUMsY0FBTSxJQUFJLFVBQVUseUJBQXlCO0FBQUEsTUFDL0M7QUFDQSxVQUFJLE1BQU0sT0FBTyxNQUFNO0FBQ3ZCLFVBQUksUUFBUSxJQUFJLFFBQVE7QUFDdEIsWUFBSSxTQUFTLElBQUksU0FBUztBQUMxQixZQUFJLE1BQU0sTUFBTSxLQUFLLENBQUMsU0FBUyxNQUFNLEdBQUc7QUFDdEMsZ0JBQU0sSUFBSSxVQUFVLDBCQUEwQjtBQUFBLFFBQ2hEO0FBQ0EsZUFBTyxlQUFlLEtBQUssTUFBTSxNQUFNO0FBQUEsTUFDekM7QUFDQSxVQUFJLElBQUksUUFBUTtBQUNkLFlBQUksQ0FBQyxtQkFBbUIsS0FBSyxJQUFJLE1BQU0sR0FBRztBQUN4QyxnQkFBTSxJQUFJLFVBQVUsMEJBQTBCO0FBQUEsUUFDaEQ7QUFDQSxlQUFPLGNBQWMsSUFBSTtBQUFBLE1BQzNCO0FBQ0EsVUFBSSxJQUFJLE1BQU07QUFDWixZQUFJLENBQUMsbUJBQW1CLEtBQUssSUFBSSxJQUFJLEdBQUc7QUFDdEMsZ0JBQU0sSUFBSSxVQUFVLHdCQUF3QjtBQUFBLFFBQzlDO0FBQ0EsZUFBTyxZQUFZLElBQUk7QUFBQSxNQUN6QjtBQUNBLFVBQUksSUFBSSxTQUFTO0FBQ2YsWUFBSSxVQUFVLElBQUk7QUFDbEIsWUFBSSxDQUFDLE9BQU8sT0FBTyxLQUFLLE1BQU0sUUFBUSxRQUFRLENBQUMsR0FBRztBQUNoRCxnQkFBTSxJQUFJLFVBQVUsMkJBQTJCO0FBQUEsUUFDakQ7QUFDQSxlQUFPLGVBQWUsUUFBUSxZQUFZO0FBQUEsTUFDNUM7QUFDQSxVQUFJLElBQUksVUFBVTtBQUNoQixlQUFPO0FBQUEsTUFDVDtBQUNBLFVBQUksSUFBSSxRQUFRO0FBQ2QsZUFBTztBQUFBLE1BQ1Q7QUFDQSxVQUFJLElBQUksVUFBVTtBQUNoQixZQUFJLFdBQVcsT0FBTyxJQUFJLGFBQWEsV0FBVyxJQUFJLFNBQVMsWUFBWSxJQUFJLElBQUk7QUFDbkYsZ0JBQVEsVUFBVTtBQUFBLFVBQ2hCLEtBQUs7QUFDSCxtQkFBTztBQUNQO0FBQUEsVUFDRixLQUFLO0FBQ0gsbUJBQU87QUFDUDtBQUFBLFVBQ0YsS0FBSztBQUNILG1CQUFPO0FBQ1A7QUFBQSxVQUNGO0FBQ0Usa0JBQU0sSUFBSSxVQUFVLDRCQUE0QjtBQUFBLFFBQ3BEO0FBQUEsTUFDRjtBQUNBLFVBQUksSUFBSSxVQUFVO0FBQ2hCLFlBQUksV0FBVyxPQUFPLElBQUksYUFBYSxXQUFXLElBQUksU0FBUyxZQUFZLElBQUksSUFBSTtBQUNuRixnQkFBUSxVQUFVO0FBQUEsVUFDaEIsS0FBSztBQUNILG1CQUFPO0FBQ1A7QUFBQSxVQUNGLEtBQUs7QUFDSCxtQkFBTztBQUNQO0FBQUEsVUFDRixLQUFLO0FBQ0gsbUJBQU87QUFDUDtBQUFBLFVBQ0YsS0FBSztBQUNILG1CQUFPO0FBQ1A7QUFBQSxVQUNGO0FBQ0Usa0JBQU0sSUFBSSxVQUFVLDRCQUE0QjtBQUFBLFFBQ3BEO0FBQUEsTUFDRjtBQUNBLGFBQU87QUFBQSxJQUNUO0FBQ0EsYUFBUyxPQUFPLEtBQUs7QUFDbkIsYUFBTyxJQUFJLFFBQVEsR0FBRyxNQUFNLEtBQUssbUJBQW1CLEdBQUcsSUFBSTtBQUFBLElBQzdEO0FBQ0EsYUFBUyxPQUFPLEtBQUs7QUFDbkIsYUFBTyxtQkFBbUIsR0FBRztBQUFBLElBQy9CO0FBQ0EsYUFBUyxPQUFPLEtBQUs7QUFDbkIsYUFBTyxXQUFXLEtBQUssR0FBRyxNQUFNLG1CQUFtQixlQUFlO0FBQUEsSUFDcEU7QUFDQSxhQUFTLFVBQVUsS0FBSyxTQUFTO0FBQy9CLFVBQUk7QUFDRixlQUFPLFFBQVEsR0FBRztBQUFBLE1BQ3BCLFNBQVMsR0FBRztBQUNWLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRixDQUFDO0FBQ0QsSUFBSSxnQkFBZ0IsU0FBUyxlQUFlLEdBQUcsQ0FBQztBQUNoRCxJQUFJLGtCQUFrQixjQUFjO0FBR3BDLFNBQVMsd0JBQXdCO0FBQy9CLFNBQU8sZ0JBQWdCLE1BQU0sU0FBUyxNQUFNO0FBQzlDO0FBQ0EsU0FBUyxrQkFBa0IsU0FBUztBQUNsQyxNQUFJLE9BQU8sYUFBYSxlQUFlLE9BQU8sYUFBYSxhQUFhO0FBQ3RFLFdBQU8sQ0FBQztBQUFBLEVBQ1Y7QUFDQSxVQUFRLFFBQVEsYUFBYTtBQUFBLElBQzNCLEtBQUssZUFBZTtBQUNsQixZQUFNLE1BQU0sSUFBSSxJQUFJLFFBQVEsR0FBRztBQUMvQixhQUFPLFNBQVMsV0FBVyxJQUFJLFNBQVMsc0JBQXNCLElBQUksQ0FBQztBQUFBLElBQ3JFO0FBQUEsSUFDQSxLQUFLLFdBQVc7QUFDZCxhQUFPLHNCQUFzQjtBQUFBLElBQy9CO0FBQUEsSUFDQSxTQUFTO0FBQ1AsYUFBTyxDQUFDO0FBQUEsSUFDVjtBQUFBLEVBQ0Y7QUFDRjtBQUNBLFNBQVMscUJBQXFCLFNBQVM7QUFDckMsTUFBSTtBQUNKLFFBQU0sdUJBQXVCLFFBQVEsUUFBUSxJQUFJLFFBQVE7QUFDekQsUUFBTSxxQkFBcUIsdUJBQXVCLGdCQUFnQixNQUFNLG9CQUFvQixJQUFJLENBQUM7QUFDakcsUUFBTSxRQUFRO0FBQ2QsUUFBTSxtQkFBbUIsTUFBTSxNQUFNLE1BQU0sTUFBTSxJQUFJLE9BQU8sTUFBTSxPQUFPLFNBQVMsSUFBSSxRQUFRLENBQUMsRUFBRSxPQUFPLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtBQUN0SSxXQUFPLE9BQU8sT0FBTyxTQUFTLEVBQUUsQ0FBQyxLQUFLLEtBQUssQ0FBQyxHQUFHLE1BQU0sQ0FBQztBQUFBLEVBQ3hELEdBQUcsQ0FBQyxDQUFDO0FBQ0wsUUFBTSxzQkFBc0Isa0JBQWtCLE9BQU87QUFDckQsUUFBTSxtQkFBbUI7QUFBQSxJQUN2QixHQUFHO0FBQUEsSUFDSCxHQUFHO0FBQUEsRUFDTDtBQUNBLGFBQVcsQ0FBQyxNQUFNLEtBQUssS0FBSyxPQUFPLFFBQVEsZ0JBQWdCLEdBQUc7QUFDNUQsWUFBUSxRQUFRLE9BQU8sVUFBVSxnQkFBZ0IsVUFBVSxNQUFNLEtBQUssQ0FBQztBQUFBLEVBQ3pFO0FBQ0EsU0FBTztBQUFBLElBQ0wsR0FBRztBQUFBLElBQ0gsR0FBRztBQUFBLEVBQ0w7QUFDRjtBQUdBLElBQUksZUFBZSxDQUFDLGlCQUFpQjtBQUNuQyxlQUFhLE1BQU0sSUFBSTtBQUN2QixlQUFhLEtBQUssSUFBSTtBQUN0QixlQUFhLE1BQU0sSUFBSTtBQUN2QixlQUFhLEtBQUssSUFBSTtBQUN0QixlQUFhLE9BQU8sSUFBSTtBQUN4QixlQUFhLFNBQVMsSUFBSTtBQUMxQixlQUFhLFFBQVEsSUFBSTtBQUN6QixTQUFPO0FBQ1QsR0FBRyxlQUFlLENBQUMsQ0FBQztBQUNwQixJQUFJLGNBQWMsY0FBYyxlQUFlO0FBQUEsRUFDN0MsWUFBWSxRQUFRLE1BQU0sVUFBVSxTQUFTO0FBQzNDLFVBQU07QUFBQSxNQUNKLE1BQU07QUFBQSxRQUNKLFFBQVEsR0FBRyxNQUFNLElBQUksSUFBSTtBQUFBLFFBQ3pCO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0YsQ0FBQztBQUNELFNBQUssOEJBQThCO0FBQUEsRUFDckM7QUFBQSxFQUNBLGdDQUFnQztBQUM5QixVQUFNLEVBQUUsUUFBUSxLQUFLLElBQUksS0FBSztBQUM5QixRQUFJLGdCQUFnQixRQUFRO0FBQzFCO0FBQUEsSUFDRjtBQUNBLFVBQU0sTUFBTSxTQUFTLElBQUk7QUFDekIsUUFBSSxRQUFRLE1BQU07QUFDaEI7QUFBQSxJQUNGO0FBQ0EsVUFBTSxlQUFlLGdCQUFnQixJQUFJO0FBQ3pDLFVBQU0sY0FBYyxDQUFDO0FBQ3JCLGlCQUFhLFFBQVEsQ0FBQyxHQUFHLGNBQWM7QUFDckMsa0JBQVksS0FBSyxTQUFTO0FBQUEsSUFDNUIsQ0FBQztBQUNELGFBQVM7QUFBQSxNQUNQLCtFQUErRSxNQUFNLElBQUksSUFBSTtBQUFBLElBQy9GO0FBQUEsRUFDRjtBQUFBLEVBQ0EsTUFBTSxNQUFNLE1BQU07QUFDaEIsUUFBSTtBQUNKLFVBQU0sTUFBTSxJQUFJLElBQUksS0FBSyxRQUFRLEdBQUc7QUFDcEMsVUFBTSxTQUFTO0FBQUEsTUFDYjtBQUFBLE1BQ0EsS0FBSyxLQUFLO0FBQUEsT0FDVCxNQUFNLEtBQUssc0JBQXNCLE9BQU8sU0FBUyxJQUFJO0FBQUEsSUFDeEQ7QUFDQSxVQUFNLFVBQVUscUJBQXFCLEtBQUssT0FBTztBQUNqRCxXQUFPO0FBQUEsTUFDTCxPQUFPO0FBQUEsTUFDUDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUEsRUFDQSxVQUFVLE1BQU07QUFDZCxVQUFNLG9CQUFvQixLQUFLLFlBQVksS0FBSyxRQUFRLE1BQU07QUFDOUQsVUFBTSxpQkFBaUIsS0FBSyxhQUFhLE1BQU07QUFDL0MsV0FBTyxxQkFBcUI7QUFBQSxFQUM5QjtBQUFBLEVBQ0EsWUFBWSxjQUFjO0FBQ3hCLFdBQU8sS0FBSyxLQUFLLGtCQUFrQixTQUFTLEtBQUssS0FBSyxPQUFPLEtBQUssWUFBWSxJQUFJLGNBQWMsS0FBSyxLQUFLLFFBQVEsWUFBWTtBQUFBLEVBQ2hJO0FBQUEsRUFDQSxtQkFBbUIsTUFBTTtBQUN2QixRQUFJO0FBQ0osV0FBTztBQUFBLE1BQ0wsVUFBVSxNQUFNLEtBQUssYUFBYSxVQUFVLE9BQU8sU0FBUyxJQUFJLFdBQVcsQ0FBQztBQUFBLE1BQzVFLFNBQVMsS0FBSyxhQUFhO0FBQUEsSUFDN0I7QUFBQSxFQUNGO0FBQUEsRUFDQSxNQUFNLElBQUksTUFBTTtBQUNkLFVBQU0sWUFBWSxZQUFZLEtBQUssUUFBUSxHQUFHO0FBQzlDLFVBQU0sZ0JBQWdCLE1BQU0saUJBQWlCLEtBQUssT0FBTztBQUN6RCxVQUFNLGlCQUFpQixNQUFNLGtCQUFrQixLQUFLLFFBQVE7QUFDNUQsVUFBTSxjQUFjLG1CQUFtQixlQUFlLE1BQU07QUFDNUQsWUFBUTtBQUFBLE1BQ04sU0FBUztBQUFBLFFBQ1AsR0FBRyxhQUFhLENBQUMsSUFBSSxLQUFLLFFBQVEsTUFBTSxJQUFJLFNBQVMsT0FBTyxlQUFlLE1BQU0sSUFBSSxlQUFlLFVBQVU7QUFBQSxNQUNoSDtBQUFBLE1BQ0EsU0FBUyxXQUFXO0FBQUEsTUFDcEI7QUFBQSxJQUNGO0FBQ0EsWUFBUSxJQUFJLFdBQVcsYUFBYTtBQUNwQyxZQUFRLElBQUksWUFBWSxJQUFJO0FBQzVCLFlBQVEsSUFBSSxZQUFZLGNBQWM7QUFDdEMsWUFBUSxTQUFTO0FBQUEsRUFDbkI7QUFDRjtBQUdBLFNBQVMsa0JBQWtCLFFBQVE7QUFDakMsU0FBTyxDQUFDLE1BQU0sVUFBVSxVQUFVLENBQUMsTUFBTTtBQUN2QyxXQUFPLElBQUksWUFBWSxRQUFRLE1BQU0sVUFBVSxPQUFPO0FBQUEsRUFDeEQ7QUFDRjtBQUNBLElBQUksT0FBTztBQUFBLEVBQ1QsS0FBSyxrQkFBa0IsSUFBSTtBQUFBLEVBQzNCLE1BQU0sa0JBQWtCLFlBQVksSUFBSTtBQUFBLEVBQ3hDLEtBQUssa0JBQWtCLFlBQVksR0FBRztBQUFBLEVBQ3RDLE1BQU0sa0JBQWtCLFlBQVksSUFBSTtBQUFBLEVBQ3hDLEtBQUssa0JBQWtCLFlBQVksR0FBRztBQUFBLEVBQ3RDLFFBQVEsa0JBQWtCLFlBQVksTUFBTTtBQUFBLEVBQzVDLE9BQU8sa0JBQWtCLFlBQVksS0FBSztBQUFBLEVBQzFDLFNBQVMsa0JBQWtCLFlBQVksT0FBTztBQUNoRDtBQUdBLElBQUksY0FBYyxPQUFPLE9BQU87QUFBQSxFQUM5QixPQUFPO0FBQUEsRUFDUCxPQUFPO0FBQUEsRUFDUCxPQUFPO0FBQUEsRUFDUCxlQUFlO0FBQ2pCLENBQUM7QUFHRCxTQUFTLFVBQVUsV0FBVyxVQUFVO0FBQ3RDLFFBQU0sbUJBQW1CLFFBQVEsU0FBUztBQUMxQyxNQUFJLENBQUMsa0JBQWtCO0FBQ3JCLFVBQU0sSUFBSSxNQUFNLFFBQVE7QUFBQSxFQUMxQjtBQUNGO0FBR0EsU0FBUyxhQUFhLE9BQU87QUFDM0IsU0FBTyxPQUFPLFNBQVMsWUFBWSxVQUFVO0FBQy9DO0FBR0EsU0FBUyxXQUFXLFdBQVcsVUFBVTtBQUN2QyxRQUFNLG1CQUFtQixRQUFRLFNBQVM7QUFDMUMsTUFBSSxDQUFDLGtCQUFrQjtBQUNyQixVQUFNLElBQUk7QUFBQSxNQUNSLFlBQVksT0FBTyxXQUFXO0FBQUEsSUFDaEM7QUFBQSxFQUNGO0FBQ0Y7QUFHQSxJQUFJLGFBQWE7QUFDakIsU0FBUyxZQUFZLFFBQVEsVUFBVTtBQUNyQyxNQUFJLGdCQUFnQjtBQUNwQixNQUFJLE9BQU87QUFDWCxhQUFXLFVBQVUsT0FBTyxLQUFLLFNBQVMsVUFBVSxHQUFHO0FBQ3JELFdBQU8sT0FBTyxVQUFVLFlBQVksV0FBVyxLQUFLO0FBQ3BELFFBQUksT0FBTyxTQUFTLFVBQVU7QUFDNUI7QUFBQSxJQUNGO0FBQ0Esb0JBQWdCLE9BQU8sUUFBUSxPQUFPLENBQUMsRUFBRTtBQUN6QyxZQUFRO0FBQUEsRUFDVjtBQUNBLFNBQU87QUFBQSxJQUNMO0FBQUEsSUFDQSxRQUFRLFdBQVcsSUFBSTtBQUFBLEVBQ3pCO0FBQ0Y7QUFHQSxTQUFTLGNBQWMsV0FBVztBQUNoQyxTQUFPO0FBQUEsSUFDTCxVQUFVO0FBQUEsSUFDVixZQUFZLFVBQVUsUUFBUSxVQUFVLEtBQUs7QUFBQSxFQUMvQztBQUNGO0FBQ0EsU0FBUyxvQkFBb0IsUUFBUSxnQkFBZ0I7QUFDbkQsUUFBTSx3QkFBd0IsT0FBTyxlQUFlLFNBQVM7QUFDN0QsUUFBTSxPQUFPLEdBQUcsU0FBUyxxQkFBcUIsSUFBSSxPQUFPO0FBQ3pELFFBQU0sWUFBWSxlQUFlLE9BQU87QUFDeEMsUUFBTSxhQUFhLE9BQU8sZUFBZSxPQUFPO0FBQ2hELFFBQU0sVUFBVSxlQUFlLE9BQU87QUFDdEMsUUFBTSxlQUFlLGVBQWUsU0FBUyxJQUFJLHdCQUF3QjtBQUN6RSxRQUFNLFlBQVksZUFBZSxTQUFTO0FBQzFDLFFBQU0sY0FBYyxHQUFHLE9BQU8sSUFBSSxJQUFJLE9BQU8sSUFBSSxTQUFTO0FBQUE7QUFFMUQsUUFBTSxRQUFRLEtBQUssTUFBTSxjQUFjO0FBQ3ZDLFFBQU0sZUFBZSxNQUFNLFNBQVM7QUFDcEMsTUFBSSxhQUFhLFNBQVMsS0FBSztBQUM3QixVQUFNLGVBQWUsS0FBSyxNQUFNLFlBQVksRUFBRTtBQUM5QyxVQUFNLG1CQUFtQixZQUFZO0FBQ3JDLFVBQU0sV0FBVyxDQUFDO0FBQ2xCLGFBQVMsSUFBSSxHQUFHLElBQUksYUFBYSxRQUFRLEtBQUssSUFBSTtBQUNoRCxlQUFTLEtBQUssYUFBYSxNQUFNLEdBQUcsSUFBSSxFQUFFLENBQUM7QUFBQSxJQUM3QztBQUNBLFdBQU8sY0FBYyxtQkFBbUI7QUFBQSxNQUN0QyxDQUFDLEdBQUcsT0FBTyxNQUFNLFNBQVMsQ0FBQyxDQUFDO0FBQUEsTUFDNUIsR0FBRyxTQUFTLE1BQU0sR0FBRyxlQUFlLENBQUMsRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssT0FBTyxDQUFDO0FBQUEsTUFDdEUsQ0FBQyxLQUFLLElBQUksU0FBUyxnQkFBZ0IsQ0FBQztBQUFBLE1BQ3BDLENBQUMsS0FBSyxTQUFTLGVBQWUsQ0FBQyxDQUFDO0FBQUEsSUFDbEMsQ0FBQztBQUFBLEVBQ0g7QUFDQSxTQUFPLGNBQWMsbUJBQW1CO0FBQUE7QUFBQSxJQUV0QyxDQUFDLEdBQUcsVUFBVSxDQUFDLE1BQU0sTUFBTSxZQUFZLENBQUMsQ0FBQztBQUFBLElBQ3pDLENBQUMsR0FBRyxPQUFPLE1BQU0sWUFBWTtBQUFBLElBQzdCLENBQUMsS0FBSyxJQUFJLFNBQVMsU0FBUyxDQUFDO0FBQUEsSUFDN0IsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxNQUFNLE1BQU0sWUFBWSxDQUFDLENBQUM7QUFBQSxFQUMzQyxDQUFDO0FBQ0g7QUFDQSxTQUFTLG1CQUFtQixPQUFPO0FBQ2pDLFFBQU0sZ0JBQWdCLE1BQU0sT0FBTyxDQUFDLENBQUMsR0FBRyxJQUFJLE1BQU0sU0FBUyxNQUFNO0FBQ2pFLFFBQU0sU0FBUyxLQUFLLElBQUksR0FBRyxjQUFjLElBQUksQ0FBQyxDQUFDLE1BQU0sTUFBTSxPQUFPLE1BQU0sQ0FBQztBQUN6RSxTQUFPLGNBQWMsSUFBSSxDQUFDLENBQUMsUUFBUSxJQUFJLE1BQU0sT0FBTyxTQUFTLE1BQU0sS0FBSyxPQUFPLE1BQU0sT0FBTyxHQUFHLEVBQUUsS0FBSyxJQUFJO0FBQzVHO0FBR0EsU0FBUyxvQkFBb0IsTUFBTTtBQUNqQyxRQUFNLFdBQVcsS0FBSyxDQUFDO0FBQ3ZCLE1BQUksWUFBWSxRQUFRLFVBQVUsWUFBWSxZQUFZLFVBQVU7QUFDbEUsV0FBTztBQUFBLE1BQ0wsT0FBTztBQUFBLE1BQ1AsUUFBUSxLQUFLLENBQUM7QUFBQSxNQUNkLFdBQVcsS0FBSyxDQUFDO0FBQUEsTUFDakIsTUFBTSxLQUFLLENBQUM7QUFBQSxNQUNaLGVBQWUsS0FBSyxDQUFDO0FBQUEsTUFDckIsWUFBWSxLQUFLLENBQUM7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxJQUFJLGVBQWUsTUFBTSxzQkFBc0IsTUFBTTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQXVDbkQsWUFBWSxhQUFhLFNBQVM7QUFDaEMsUUFBSSxhQUFhLGlCQUFpQjtBQUNsQyxVQUFNLEVBQUUsT0FBTyxRQUFRLFdBQVcsTUFBTSxlQUFlLFdBQVcsSUFBSSxvQkFBb0IsT0FBTztBQUNqRyxVQUFNLFFBQVE7QUFDZCxTQUFLLE9BQU87QUFDWixTQUFLLE9BQU8sU0FBUyxRQUFRLFNBQVMsU0FBUyxPQUFPO0FBQ3RELFNBQUssZ0JBQWdCLGtCQUFrQixRQUFRLGtCQUFrQixTQUFTLGdCQUFnQjtBQUMxRixTQUFLLFFBQVE7QUFBQSxNQUNYLE1BQU0sUUFBUSxLQUFLLElBQUksUUFBUSxRQUFRLENBQUMsS0FBSyxJQUFJO0FBQUEsSUFDbkQ7QUFDQSxVQUFNLGdCQUFnQjtBQUFBLE9BQ25CLGNBQWMsS0FBSyxXQUFXLFFBQVEsZ0JBQWdCLFNBQVMsU0FBUyxZQUFZLElBQUksQ0FBQyxTQUFTLEtBQUssR0FBRyxFQUFFLE9BQU8sQ0FBQyxRQUFRLE9BQU8sSUFBSTtBQUFBLElBQzFJO0FBQ0EsU0FBSyxTQUFTLFdBQVcsUUFBUSxXQUFXLFNBQVMsU0FBUyxrQkFBa0IsUUFBUSxrQkFBa0IsU0FBUyxVQUFVLGtCQUFrQixjQUFjLENBQUMsT0FBTyxRQUFRLG9CQUFvQixTQUFTLFNBQVMsZ0JBQWdCO0FBQ25PLFNBQUssWUFBWSxjQUFjLFFBQVEsY0FBYyxTQUFTLFlBQVksa0JBQWtCLFFBQVEsa0JBQWtCLFNBQVMsU0FBUyxjQUFjLElBQUksQ0FBQyxRQUFRLElBQUksS0FBSztBQUM1SyxTQUFLLFlBQVksYUFBYSxTQUFTLFVBQVUsSUFBSSxDQUFDLFFBQVEsWUFBWSxRQUFRLEdBQUcsQ0FBQyxJQUFJLGtCQUFrQixRQUFRLGtCQUFrQixTQUFTLFNBQVMsY0FBYyxJQUFJLENBQUMsUUFBUSxZQUFZLElBQUksUUFBUSxJQUFJLEtBQUssQ0FBQztBQUNyTixVQUFNLHFCQUFxQjtBQUFBLE1BQ3pCLGtCQUFrQixRQUFRLGtCQUFrQixTQUFTLFNBQVMsY0FBYztBQUFBLElBQzlFLElBQUksa0JBQWtCLFFBQVEsa0JBQWtCLFNBQVMsU0FBUyxjQUFjLGFBQWE7QUFDN0YsU0FBSyxjQUFjLE9BQU8sZUFBZSxRQUFRLGVBQWUsU0FBUyxhQUFhLHdCQUF3QixRQUFRLFNBQVMsU0FBUyxPQUF1Qix1QkFBTyxPQUFPLElBQUk7QUFDakwsV0FBTyxpQkFBaUIsTUFBTTtBQUFBLE1BQzVCLFNBQVM7QUFBQSxRQUNQLFVBQVU7QUFBQSxRQUNWLFlBQVk7QUFBQSxNQUNkO0FBQUEsTUFDQSxNQUFNO0FBQUEsUUFDSixZQUFZO0FBQUEsTUFDZDtBQUFBLE1BQ0EsT0FBTztBQUFBLFFBQ0wsWUFBWTtBQUFBLE1BQ2Q7QUFBQSxNQUNBLFFBQVE7QUFBQSxRQUNOLFlBQVk7QUFBQSxNQUNkO0FBQUEsTUFDQSxXQUFXO0FBQUEsUUFDVCxZQUFZO0FBQUEsTUFDZDtBQUFBLE1BQ0EsZUFBZTtBQUFBLFFBQ2IsWUFBWTtBQUFBLE1BQ2Q7QUFBQSxJQUNGLENBQUM7QUFDRCxRQUFJLGtCQUFrQixRQUFRLGtCQUFrQixVQUFVLGNBQWMsT0FBTztBQUM3RSxhQUFPLGVBQWUsTUFBTSxTQUFTO0FBQUEsUUFDbkMsT0FBTyxjQUFjO0FBQUEsUUFDckIsVUFBVTtBQUFBLFFBQ1YsY0FBYztBQUFBLE1BQ2hCLENBQUM7QUFBQSxJQUNILFdBQVcsTUFBTSxtQkFBbUI7QUFDbEMsWUFBTSxrQkFBa0IsTUFBTSxhQUFhO0FBQUEsSUFDN0MsT0FBTztBQUNMLGFBQU8sZUFBZSxNQUFNLFNBQVM7QUFBQSxRQUNuQyxPQUFPLE1BQU0sRUFBRTtBQUFBLFFBQ2YsVUFBVTtBQUFBLFFBQ1YsY0FBYztBQUFBLE1BQ2hCLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUFBLEVBQ0EsS0FBSyxPQUFPLFdBQVcsSUFBSTtBQUN6QixXQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0EsV0FBVztBQUNULFFBQUksU0FBUyxLQUFLO0FBQ2xCLFFBQUksS0FBSyxPQUFPO0FBQ2QsaUJBQVcsUUFBUSxLQUFLLE9BQU87QUFDN0IsWUFBSSxLQUFLLEtBQUs7QUFDWixvQkFBVSxTQUFTLGNBQWMsS0FBSyxHQUFHO0FBQUEsUUFDM0M7QUFBQSxNQUNGO0FBQUEsSUFDRixXQUFXLEtBQUssVUFBVSxLQUFLLFdBQVc7QUFDeEMsaUJBQVcsYUFBYSxLQUFLLFdBQVc7QUFDdEMsa0JBQVUsU0FBUyxvQkFBb0IsS0FBSyxRQUFRLFNBQVM7QUFBQSxNQUMvRDtBQUFBLElBQ0Y7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0EsU0FBUztBQUNQLFVBQU0saUJBQWlCO0FBQUEsTUFDckIsU0FBUyxLQUFLO0FBQUEsSUFDaEI7QUFDQSxRQUFJLEtBQUssYUFBYSxNQUFNO0FBQzFCLHFCQUFlLFlBQVksS0FBSztBQUFBLElBQ2xDO0FBQ0EsUUFBSSxLQUFLLFFBQVEsTUFBTTtBQUNyQixxQkFBZSxPQUFPLEtBQUs7QUFBQSxJQUM3QjtBQUNBLFFBQUksS0FBSyxjQUFjLFFBQVEsT0FBTyxLQUFLLEtBQUssVUFBVSxFQUFFLFNBQVMsR0FBRztBQUN0RSxxQkFBZSxhQUFhLEtBQUs7QUFBQSxJQUNuQztBQUNBLFdBQU87QUFBQSxFQUNUO0FBQ0Y7QUFDQSxTQUFTLGlCQUFpQixPQUFPO0FBQy9CLFNBQU8sVUFBVSxVQUFVLE1BQU0sV0FBVyxJQUFJLFNBQVM7QUFDM0Q7QUFHQSxTQUFTLFlBQVksUUFBUSxVQUFVLGFBQWE7QUFDbEQsU0FBTyxJQUFJLGFBQWEsaUJBQWlCLFdBQVcsSUFBSTtBQUFBLElBQ3REO0FBQUEsSUFDQSxXQUFXLENBQUMsUUFBUTtBQUFBLEVBQ3RCLENBQUM7QUFDSDtBQUdBLElBQUksV0FBVyxNQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFnQm5CLFlBQVksWUFBWSxVQUFVLFFBQVE7QUFDeEMsU0FBSyxRQUFRLFdBQVc7QUFDeEIsU0FBSyxNQUFNLFNBQVM7QUFDcEIsU0FBSyxhQUFhO0FBQ2xCLFNBQUssV0FBVztBQUNoQixTQUFLLFNBQVM7QUFBQSxFQUNoQjtBQUFBLEVBQ0EsS0FBSyxPQUFPLFdBQVcsSUFBSTtBQUN6QixXQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0EsU0FBUztBQUNQLFdBQU87QUFBQSxNQUNMLE9BQU8sS0FBSztBQUFBLE1BQ1osS0FBSyxLQUFLO0FBQUEsSUFDWjtBQUFBLEVBQ0Y7QUFDRjtBQUNBLElBQUksUUFBUSxNQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBMkJoQixZQUFZLE1BQU0sT0FBTyxLQUFLLE1BQU0sUUFBUSxPQUFPO0FBQ2pELFNBQUssT0FBTztBQUNaLFNBQUssUUFBUTtBQUNiLFNBQUssTUFBTTtBQUNYLFNBQUssT0FBTztBQUNaLFNBQUssU0FBUztBQUNkLFNBQUssUUFBUTtBQUNiLFNBQUssT0FBTztBQUNaLFNBQUssT0FBTztBQUFBLEVBQ2Q7QUFBQSxFQUNBLEtBQUssT0FBTyxXQUFXLElBQUk7QUFDekIsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBLFNBQVM7QUFDUCxXQUFPO0FBQUEsTUFDTCxNQUFNLEtBQUs7QUFBQSxNQUNYLE9BQU8sS0FBSztBQUFBLE1BQ1osTUFBTSxLQUFLO0FBQUEsTUFDWCxRQUFRLEtBQUs7QUFBQSxJQUNmO0FBQUEsRUFDRjtBQUNGO0FBQ0EsSUFBSSxvQkFBb0I7QUFBQSxFQUN0QixNQUFNLENBQUM7QUFBQSxFQUNQLFVBQVUsQ0FBQyxhQUFhO0FBQUEsRUFDeEIscUJBQXFCO0FBQUEsSUFDbkI7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQUEsRUFDQSxvQkFBb0IsQ0FBQyxZQUFZLFFBQVEsZ0JBQWdCLFlBQVk7QUFBQSxFQUNyRSxVQUFVLENBQUMsTUFBTTtBQUFBLEVBQ2pCLGNBQWMsQ0FBQyxZQUFZO0FBQUEsRUFDM0IsT0FBTyxDQUFDLFNBQVMsUUFBUSxhQUFhLGNBQWMsY0FBYztBQUFBLEVBQ2xFLFVBQVUsQ0FBQyxRQUFRLE9BQU87QUFBQSxFQUMxQixnQkFBZ0IsQ0FBQyxRQUFRLFlBQVk7QUFBQSxFQUNyQyxnQkFBZ0IsQ0FBQyxpQkFBaUIsY0FBYyxjQUFjO0FBQUEsRUFDOUQsb0JBQW9CO0FBQUEsSUFDbEI7QUFBQTtBQUFBLElBRUE7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQUEsRUFDQSxVQUFVLENBQUM7QUFBQSxFQUNYLFlBQVksQ0FBQztBQUFBLEVBQ2IsYUFBYSxDQUFDO0FBQUEsRUFDZCxjQUFjLENBQUM7QUFBQSxFQUNmLFdBQVcsQ0FBQztBQUFBLEVBQ1osV0FBVyxDQUFDO0FBQUEsRUFDWixXQUFXLENBQUMsUUFBUTtBQUFBLEVBQ3BCLGFBQWEsQ0FBQyxRQUFRO0FBQUEsRUFDdEIsYUFBYSxDQUFDLFFBQVEsT0FBTztBQUFBLEVBQzdCLFdBQVcsQ0FBQyxRQUFRLFdBQVc7QUFBQSxFQUMvQixXQUFXLENBQUMsTUFBTTtBQUFBLEVBQ2xCLFVBQVUsQ0FBQyxNQUFNO0FBQUEsRUFDakIsYUFBYSxDQUFDLE1BQU07QUFBQSxFQUNwQixrQkFBa0IsQ0FBQyxlQUFlLGNBQWMsZ0JBQWdCO0FBQUEsRUFDaEUseUJBQXlCLENBQUMsTUFBTTtBQUFBLEVBQ2hDLHNCQUFzQixDQUFDLGVBQWUsUUFBUSxZQUFZO0FBQUEsRUFDMUQsc0JBQXNCO0FBQUEsSUFDcEI7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUFBLEVBQ0EsaUJBQWlCLENBQUMsZUFBZSxRQUFRLGFBQWEsUUFBUSxZQUFZO0FBQUEsRUFDMUUsc0JBQXNCO0FBQUEsSUFDcEI7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUFBLEVBQ0EseUJBQXlCO0FBQUEsSUFDdkI7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUFBLEVBQ0EscUJBQXFCLENBQUMsZUFBZSxRQUFRLGNBQWMsT0FBTztBQUFBLEVBQ2xFLG9CQUFvQixDQUFDLGVBQWUsUUFBUSxjQUFjLFFBQVE7QUFBQSxFQUNsRSxxQkFBcUIsQ0FBQyxlQUFlLFFBQVEsWUFBWTtBQUFBLEVBQ3pELDJCQUEyQixDQUFDLGVBQWUsUUFBUSxjQUFjLFFBQVE7QUFBQSxFQUN6RSxxQkFBcUIsQ0FBQyxlQUFlLFFBQVEsYUFBYSxXQUFXO0FBQUEsRUFDckUsaUJBQWlCLENBQUMsY0FBYyxnQkFBZ0I7QUFBQSxFQUNoRCxxQkFBcUIsQ0FBQyxRQUFRLFlBQVk7QUFBQSxFQUMxQyxxQkFBcUIsQ0FBQyxRQUFRLGNBQWMsY0FBYyxRQUFRO0FBQUEsRUFDbEUsd0JBQXdCLENBQUMsUUFBUSxjQUFjLGNBQWMsUUFBUTtBQUFBLEVBQ3JFLG9CQUFvQixDQUFDLFFBQVEsY0FBYyxPQUFPO0FBQUEsRUFDbEQsbUJBQW1CLENBQUMsUUFBUSxjQUFjLFFBQVE7QUFBQSxFQUNsRCwwQkFBMEIsQ0FBQyxRQUFRLGNBQWMsUUFBUTtBQUMzRDtBQUNBLElBQUksYUFBYSxJQUFJLElBQUksT0FBTyxLQUFLLGlCQUFpQixDQUFDO0FBQ3ZELFNBQVMsT0FBTyxXQUFXO0FBQ3pCLFFBQU0sWUFBWSxjQUFjLFFBQVEsY0FBYyxTQUFTLFNBQVMsVUFBVTtBQUNsRixTQUFPLE9BQU8sY0FBYyxZQUFZLFdBQVcsSUFBSSxTQUFTO0FBQ2xFO0FBQ0EsSUFBSTtBQUFBLENBQ0gsU0FBUyxvQkFBb0I7QUFDNUIscUJBQW1CLE9BQU8sSUFBSTtBQUM5QixxQkFBbUIsVUFBVSxJQUFJO0FBQ2pDLHFCQUFtQixjQUFjLElBQUk7QUFDdkMsR0FBRyxzQkFBc0Isb0JBQW9CLENBQUMsRUFBRTtBQUdoRCxJQUFJO0FBQUEsQ0FDSCxTQUFTLG9CQUFvQjtBQUM1QixxQkFBbUIsT0FBTyxJQUFJO0FBQzlCLHFCQUFtQixVQUFVLElBQUk7QUFDakMscUJBQW1CLGNBQWMsSUFBSTtBQUNyQyxxQkFBbUIsT0FBTyxJQUFJO0FBQzlCLHFCQUFtQixxQkFBcUIsSUFBSTtBQUM1QyxxQkFBbUIsaUJBQWlCLElBQUk7QUFDeEMscUJBQW1CLGlCQUFpQixJQUFJO0FBQ3hDLHFCQUFtQixxQkFBcUIsSUFBSTtBQUM1QyxxQkFBbUIsUUFBUSxJQUFJO0FBQy9CLHFCQUFtQixRQUFRLElBQUk7QUFDL0IscUJBQW1CLFFBQVEsSUFBSTtBQUMvQixxQkFBbUIsa0JBQWtCLElBQUk7QUFDekMscUJBQW1CLHFCQUFxQixJQUFJO0FBQzVDLHFCQUFtQixXQUFXLElBQUk7QUFDbEMscUJBQW1CLE9BQU8sSUFBSTtBQUM5QixxQkFBbUIsTUFBTSxJQUFJO0FBQzdCLHFCQUFtQixZQUFZLElBQUk7QUFDbkMscUJBQW1CLGNBQWMsSUFBSTtBQUNyQyxxQkFBbUIsd0JBQXdCLElBQUk7QUFDakQsR0FBRyxzQkFBc0Isb0JBQW9CLENBQUMsRUFBRTtBQUdoRCxJQUFJO0FBQUEsQ0FDSCxTQUFTLE9BQU87QUFDZixRQUFNLE1BQU0sSUFBSTtBQUNoQixRQUFNLFVBQVUsSUFBSTtBQUNwQixRQUFNLHNCQUFzQixJQUFJO0FBQ2hDLFFBQU0scUJBQXFCLElBQUk7QUFDL0IsUUFBTSxlQUFlLElBQUk7QUFDekIsUUFBTSxPQUFPLElBQUk7QUFDakIsUUFBTSxVQUFVLElBQUk7QUFDcEIsUUFBTSxpQkFBaUIsSUFBSTtBQUMzQixRQUFNLGlCQUFpQixJQUFJO0FBQzNCLFFBQU0scUJBQXFCLElBQUk7QUFDL0IsUUFBTSxVQUFVLElBQUk7QUFDcEIsUUFBTSxLQUFLLElBQUk7QUFDZixRQUFNLE9BQU8sSUFBSTtBQUNqQixRQUFNLFFBQVEsSUFBSTtBQUNsQixRQUFNLFNBQVMsSUFBSTtBQUNuQixRQUFNLE1BQU0sSUFBSTtBQUNoQixRQUFNLE1BQU0sSUFBSTtBQUNoQixRQUFNLE1BQU0sSUFBSTtBQUNoQixRQUFNLFFBQVEsSUFBSTtBQUNsQixRQUFNLGNBQWMsSUFBSTtBQUN4QixRQUFNLFdBQVcsSUFBSTtBQUNyQixRQUFNLFlBQVksSUFBSTtBQUN0QixRQUFNLFdBQVcsSUFBSTtBQUNyQixRQUFNLGVBQWUsSUFBSTtBQUN6QixRQUFNLG1CQUFtQixJQUFJO0FBQzdCLFFBQU0sMkJBQTJCLElBQUk7QUFDckMsUUFBTSx3QkFBd0IsSUFBSTtBQUNsQyxRQUFNLHdCQUF3QixJQUFJO0FBQ2xDLFFBQU0sa0JBQWtCLElBQUk7QUFDNUIsUUFBTSx3QkFBd0IsSUFBSTtBQUNsQyxRQUFNLDJCQUEyQixJQUFJO0FBQ3JDLFFBQU0sdUJBQXVCLElBQUk7QUFDakMsUUFBTSxzQkFBc0IsSUFBSTtBQUNoQyxRQUFNLHVCQUF1QixJQUFJO0FBQ2pDLFFBQU0sOEJBQThCLElBQUk7QUFDeEMsUUFBTSxzQkFBc0IsSUFBSTtBQUNoQyxRQUFNLGtCQUFrQixJQUFJO0FBQzVCLFFBQU0sdUJBQXVCLElBQUk7QUFDakMsUUFBTSx1QkFBdUIsSUFBSTtBQUNqQyxRQUFNLDBCQUEwQixJQUFJO0FBQ3BDLFFBQU0sc0JBQXNCLElBQUk7QUFDaEMsUUFBTSxxQkFBcUIsSUFBSTtBQUMvQixRQUFNLDZCQUE2QixJQUFJO0FBQ3pDLEdBQUcsU0FBUyxPQUFPLENBQUMsRUFBRTtBQUd0QixTQUFTLGFBQWEsTUFBTTtBQUMxQixTQUFPLFNBQVMsS0FBSyxTQUFTO0FBQ2hDO0FBQ0EsU0FBUyxRQUFRLE1BQU07QUFDckIsU0FBTyxRQUFRLE1BQU0sUUFBUTtBQUMvQjtBQUNBLFNBQVMsU0FBUyxNQUFNO0FBQ3RCLFNBQU8sUUFBUSxNQUFNLFFBQVE7QUFBQSxFQUM3QixRQUFRLE1BQU0sUUFBUTtBQUN4QjtBQUNBLFNBQVMsWUFBWSxNQUFNO0FBQ3pCLFNBQU8sU0FBUyxJQUFJLEtBQUssU0FBUztBQUNwQztBQUNBLFNBQVMsZUFBZSxNQUFNO0FBQzVCLFNBQU8sU0FBUyxJQUFJLEtBQUssUUFBUSxJQUFJLEtBQUssU0FBUztBQUNyRDtBQUdBLFNBQVMsdUJBQXVCLE9BQU87QUFDckMsTUFBSTtBQUNKLE1BQUksZUFBZSxPQUFPO0FBQzFCLE1BQUksb0JBQW9CO0FBQ3hCLE1BQUksbUJBQW1CO0FBQ3ZCLFdBQVMsSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEVBQUUsR0FBRztBQUNyQyxRQUFJO0FBQ0osVUFBTSxPQUFPLE1BQU0sQ0FBQztBQUNwQixVQUFNLFVBQVUsa0JBQWtCLElBQUk7QUFDdEMsUUFBSSxZQUFZLEtBQUssUUFBUTtBQUMzQjtBQUFBLElBQ0Y7QUFDQSx5QkFBcUIscUJBQXFCLHVCQUF1QixRQUFRLHVCQUF1QixTQUFTLHFCQUFxQjtBQUM5SCx1QkFBbUI7QUFDbkIsUUFBSSxNQUFNLEtBQUssVUFBVSxjQUFjO0FBQ3JDLHFCQUFlO0FBQUEsSUFDakI7QUFBQSxFQUNGO0FBQ0EsU0FBTyxNQUFNLElBQUksQ0FBQyxNQUFNLE1BQU0sTUFBTSxJQUFJLE9BQU8sS0FBSyxNQUFNLFlBQVksQ0FBQyxFQUFFO0FBQUEsS0FDdEUsc0JBQXNCLHVCQUF1QixRQUFRLHdCQUF3QixTQUFTLHNCQUFzQjtBQUFBLElBQzdHLG1CQUFtQjtBQUFBLEVBQ3JCO0FBQ0Y7QUFDQSxTQUFTLGtCQUFrQixLQUFLO0FBQzlCLE1BQUksSUFBSTtBQUNSLFNBQU8sSUFBSSxJQUFJLFVBQVUsYUFBYSxJQUFJLFdBQVcsQ0FBQyxDQUFDLEdBQUc7QUFDeEQsTUFBRTtBQUFBLEVBQ0o7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLGlCQUFpQixPQUFPLFNBQVM7QUFDeEMsUUFBTSxlQUFlLE1BQU0sUUFBUSxRQUFRLE9BQU87QUFDbEQsUUFBTSxRQUFRLGFBQWEsTUFBTSxjQUFjO0FBQy9DLFFBQU0sZUFBZSxNQUFNLFdBQVc7QUFDdEMsUUFBTSxzQkFBc0IsTUFBTSxTQUFTLEtBQUssTUFBTSxNQUFNLENBQUMsRUFBRSxNQUFNLENBQUMsU0FBUyxLQUFLLFdBQVcsS0FBSyxhQUFhLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQztBQUNwSSxRQUFNLDBCQUEwQixhQUFhLFNBQVMsT0FBTztBQUM3RCxRQUFNLG1CQUFtQixNQUFNLFNBQVMsR0FBRyxLQUFLLENBQUM7QUFDakQsUUFBTSxtQkFBbUIsTUFBTSxTQUFTLElBQUk7QUFDNUMsUUFBTSx1QkFBdUIsb0JBQW9CO0FBQ2pELFFBQU0sdUJBQXVCLEVBQUUsWUFBWSxRQUFRLFlBQVksVUFBVSxRQUFRO0FBQUEsR0FDaEYsQ0FBQyxnQkFBZ0IsTUFBTSxTQUFTLE1BQU0sd0JBQXdCLHVCQUF1QjtBQUN0RixNQUFJLFNBQVM7QUFDYixRQUFNLHFCQUFxQixnQkFBZ0IsYUFBYSxNQUFNLFdBQVcsQ0FBQyxDQUFDO0FBQzNFLE1BQUksd0JBQXdCLENBQUMsc0JBQXNCLHFCQUFxQjtBQUN0RSxjQUFVO0FBQUEsRUFDWjtBQUNBLFlBQVU7QUFDVixNQUFJLHdCQUF3QixzQkFBc0I7QUFDaEQsY0FBVTtBQUFBLEVBQ1o7QUFDQSxTQUFPLFFBQVEsU0FBUztBQUMxQjtBQUdBLElBQUk7QUFBQSxDQUNILFNBQVMsWUFBWTtBQUNwQixhQUFXLEtBQUssSUFBSTtBQUNwQixhQUFXLEtBQUssSUFBSTtBQUNwQixhQUFXLE1BQU0sSUFBSTtBQUNyQixhQUFXLFFBQVEsSUFBSTtBQUN2QixhQUFXLEtBQUssSUFBSTtBQUNwQixhQUFXLFNBQVMsSUFBSTtBQUN4QixhQUFXLFNBQVMsSUFBSTtBQUN4QixhQUFXLFFBQVEsSUFBSTtBQUN2QixhQUFXLE9BQU8sSUFBSTtBQUN0QixhQUFXLFFBQVEsSUFBSTtBQUN2QixhQUFXLElBQUksSUFBSTtBQUNuQixhQUFXLFdBQVcsSUFBSTtBQUMxQixhQUFXLFdBQVcsSUFBSTtBQUMxQixhQUFXLFNBQVMsSUFBSTtBQUN4QixhQUFXLE1BQU0sSUFBSTtBQUNyQixhQUFXLFNBQVMsSUFBSTtBQUN4QixhQUFXLE1BQU0sSUFBSTtBQUNyQixhQUFXLEtBQUssSUFBSTtBQUNwQixhQUFXLE9BQU8sSUFBSTtBQUN0QixhQUFXLFFBQVEsSUFBSTtBQUN2QixhQUFXLGNBQWMsSUFBSTtBQUM3QixhQUFXLFNBQVMsSUFBSTtBQUMxQixHQUFHLGNBQWMsWUFBWSxDQUFDLEVBQUU7QUFHaEMsSUFBSSxRQUFRLE1BQU07QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWFoQixZQUFZLFFBQVE7QUFDbEIsVUFBTSxtQkFBbUIsSUFBSSxNQUFNLFVBQVUsS0FBSyxHQUFHLEdBQUcsR0FBRyxDQUFDO0FBQzVELFNBQUssU0FBUztBQUNkLFNBQUssWUFBWTtBQUNqQixTQUFLLFFBQVE7QUFDYixTQUFLLE9BQU87QUFDWixTQUFLLFlBQVk7QUFBQSxFQUNuQjtBQUFBLEVBQ0EsS0FBSyxPQUFPLFdBQVcsSUFBSTtBQUN6QixXQUFPO0FBQUEsRUFDVDtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSUEsVUFBVTtBQUNSLFNBQUssWUFBWSxLQUFLO0FBQ3RCLFVBQU0sUUFBUSxLQUFLLFFBQVEsS0FBSyxVQUFVO0FBQzFDLFdBQU87QUFBQSxFQUNUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUtBLFlBQVk7QUFDVixRQUFJLFFBQVEsS0FBSztBQUNqQixRQUFJLE1BQU0sU0FBUyxVQUFVLEtBQUs7QUFDaEMsU0FBRztBQUNELFlBQUksTUFBTSxNQUFNO0FBQ2Qsa0JBQVEsTUFBTTtBQUFBLFFBQ2hCLE9BQU87QUFDTCxnQkFBTSxZQUFZLGNBQWMsTUFBTSxNQUFNLEdBQUc7QUFDL0MsZ0JBQU0sT0FBTztBQUNiLG9CQUFVLE9BQU87QUFDakIsa0JBQVE7QUFBQSxRQUNWO0FBQUEsTUFDRixTQUFTLE1BQU0sU0FBUyxVQUFVO0FBQUEsSUFDcEM7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUNGO0FBQ0EsU0FBUyxzQkFBc0IsTUFBTTtBQUNuQyxTQUFPLFNBQVMsVUFBVSxRQUFRLFNBQVMsVUFBVSxVQUFVLFNBQVMsVUFBVSxPQUFPLFNBQVMsVUFBVSxXQUFXLFNBQVMsVUFBVSxXQUFXLFNBQVMsVUFBVSxVQUFVLFNBQVMsVUFBVSxTQUFTLFNBQVMsVUFBVSxVQUFVLFNBQVMsVUFBVSxNQUFNLFNBQVMsVUFBVSxhQUFhLFNBQVMsVUFBVSxhQUFhLFNBQVMsVUFBVSxXQUFXLFNBQVMsVUFBVSxRQUFRLFNBQVMsVUFBVTtBQUNsWjtBQUNBLFNBQVMscUJBQXFCLE1BQU07QUFDbEMsU0FBTyxRQUFRLEtBQUssUUFBUSxTQUFTLFFBQVEsU0FBUyxRQUFRO0FBQ2hFO0FBQ0EsU0FBUyx5QkFBeUIsTUFBTSxXQUFXO0FBQ2pELFNBQU8sbUJBQW1CLEtBQUssV0FBVyxTQUFTLENBQUMsS0FBSyxvQkFBb0IsS0FBSyxXQUFXLFlBQVksQ0FBQyxDQUFDO0FBQzdHO0FBQ0EsU0FBUyxtQkFBbUIsTUFBTTtBQUNoQyxTQUFPLFFBQVEsU0FBUyxRQUFRO0FBQ2xDO0FBQ0EsU0FBUyxvQkFBb0IsTUFBTTtBQUNqQyxTQUFPLFFBQVEsU0FBUyxRQUFRO0FBQ2xDO0FBQ0EsU0FBUyxpQkFBaUIsUUFBUSxXQUFXO0FBQzNDLFFBQU0sT0FBTyxPQUFPLE9BQU8sS0FBSyxZQUFZLFNBQVM7QUFDckQsTUFBSSxTQUFTLFFBQVE7QUFDbkIsV0FBTyxVQUFVO0FBQUEsRUFDbkIsV0FBVyxRQUFRLE1BQU0sUUFBUSxLQUFLO0FBQ3BDLFVBQU0sT0FBTyxPQUFPLGNBQWMsSUFBSTtBQUN0QyxXQUFPLFNBQVMsTUFBTSxRQUFRLElBQUksSUFBSTtBQUFBLEVBQ3hDO0FBQ0EsU0FBTyxPQUFPLEtBQUssU0FBUyxFQUFFLEVBQUUsWUFBWSxFQUFFLFNBQVMsR0FBRyxHQUFHO0FBQy9EO0FBQ0EsU0FBUyxZQUFZLFFBQVEsTUFBTSxPQUFPLEtBQUssT0FBTztBQUNwRCxRQUFNLE9BQU8sT0FBTztBQUNwQixRQUFNLE1BQU0sSUFBSSxRQUFRLE9BQU87QUFDL0IsU0FBTyxJQUFJLE1BQU0sTUFBTSxPQUFPLEtBQUssTUFBTSxLQUFLLEtBQUs7QUFDckQ7QUFDQSxTQUFTLGNBQWMsUUFBUSxPQUFPO0FBQ3BDLFFBQU0sT0FBTyxPQUFPLE9BQU87QUFDM0IsUUFBTSxhQUFhLEtBQUs7QUFDeEIsTUFBSSxXQUFXO0FBQ2YsU0FBTyxXQUFXLFlBQVk7QUFDNUIsVUFBTSxPQUFPLEtBQUssV0FBVyxRQUFRO0FBQ3JDLFlBQVEsTUFBTTtBQUFBLE1BQ1osS0FBSztBQUFBLE1BQ0wsS0FBSztBQUFBLE1BQ0wsS0FBSztBQUFBLE1BQ0wsS0FBSztBQUNILFVBQUU7QUFDRjtBQUFBLE1BQ0YsS0FBSztBQUNILFVBQUU7QUFDRixVQUFFLE9BQU87QUFDVCxlQUFPLFlBQVk7QUFDbkI7QUFBQSxNQUNGLEtBQUs7QUFDSCxZQUFJLEtBQUssV0FBVyxXQUFXLENBQUMsTUFBTSxJQUFJO0FBQ3hDLHNCQUFZO0FBQUEsUUFDZCxPQUFPO0FBQ0wsWUFBRTtBQUFBLFFBQ0o7QUFDQSxVQUFFLE9BQU87QUFDVCxlQUFPLFlBQVk7QUFDbkI7QUFBQSxNQUNGLEtBQUs7QUFDSCxlQUFPLFlBQVksUUFBUSxRQUFRO0FBQUEsTUFDckMsS0FBSztBQUNILGVBQU8sWUFBWSxRQUFRLFVBQVUsTUFBTSxVQUFVLFdBQVcsQ0FBQztBQUFBLE1BQ25FLEtBQUs7QUFDSCxlQUFPLFlBQVksUUFBUSxVQUFVLFFBQVEsVUFBVSxXQUFXLENBQUM7QUFBQSxNQUNyRSxLQUFLO0FBQ0gsZUFBTyxZQUFZLFFBQVEsVUFBVSxLQUFLLFVBQVUsV0FBVyxDQUFDO0FBQUEsTUFDbEUsS0FBSztBQUNILGVBQU8sWUFBWSxRQUFRLFVBQVUsU0FBUyxVQUFVLFdBQVcsQ0FBQztBQUFBLE1BQ3RFLEtBQUs7QUFDSCxlQUFPLFlBQVksUUFBUSxVQUFVLFNBQVMsVUFBVSxXQUFXLENBQUM7QUFBQSxNQUN0RSxLQUFLO0FBQ0gsWUFBSSxLQUFLLFdBQVcsV0FBVyxDQUFDLE1BQU0sTUFBTSxLQUFLLFdBQVcsV0FBVyxDQUFDLE1BQU0sSUFBSTtBQUNoRixpQkFBTyxZQUFZLFFBQVEsVUFBVSxRQUFRLFVBQVUsV0FBVyxDQUFDO0FBQUEsUUFDckU7QUFDQTtBQUFBLE1BQ0YsS0FBSztBQUNILGVBQU8sWUFBWSxRQUFRLFVBQVUsT0FBTyxVQUFVLFdBQVcsQ0FBQztBQUFBLE1BQ3BFLEtBQUs7QUFDSCxlQUFPLFlBQVksUUFBUSxVQUFVLFFBQVEsVUFBVSxXQUFXLENBQUM7QUFBQSxNQUNyRSxLQUFLO0FBQ0gsZUFBTyxZQUFZLFFBQVEsVUFBVSxJQUFJLFVBQVUsV0FBVyxDQUFDO0FBQUEsTUFDakUsS0FBSztBQUNILGVBQU8sWUFBWSxRQUFRLFVBQVUsV0FBVyxVQUFVLFdBQVcsQ0FBQztBQUFBLE1BQ3hFLEtBQUs7QUFDSCxlQUFPLFlBQVksUUFBUSxVQUFVLFdBQVcsVUFBVSxXQUFXLENBQUM7QUFBQSxNQUN4RSxLQUFLO0FBQ0gsZUFBTyxZQUFZLFFBQVEsVUFBVSxTQUFTLFVBQVUsV0FBVyxDQUFDO0FBQUEsTUFDdEUsS0FBSztBQUNILGVBQU8sWUFBWSxRQUFRLFVBQVUsTUFBTSxVQUFVLFdBQVcsQ0FBQztBQUFBLE1BQ25FLEtBQUs7QUFDSCxlQUFPLFlBQVksUUFBUSxVQUFVLFNBQVMsVUFBVSxXQUFXLENBQUM7QUFBQSxNQUN0RSxLQUFLO0FBQ0gsWUFBSSxLQUFLLFdBQVcsV0FBVyxDQUFDLE1BQU0sTUFBTSxLQUFLLFdBQVcsV0FBVyxDQUFDLE1BQU0sSUFBSTtBQUNoRixpQkFBTyxnQkFBZ0IsUUFBUSxRQUFRO0FBQUEsUUFDekM7QUFDQSxlQUFPLFdBQVcsUUFBUSxRQUFRO0FBQUEsSUFDdEM7QUFDQSxRQUFJLFFBQVEsSUFBSSxLQUFLLFNBQVMsSUFBSTtBQUNoQyxhQUFPLFdBQVcsUUFBUSxVQUFVLElBQUk7QUFBQSxJQUMxQztBQUNBLFFBQUksWUFBWSxJQUFJLEdBQUc7QUFDckIsYUFBTyxTQUFTLFFBQVEsUUFBUTtBQUFBLElBQ2xDO0FBQ0EsVUFBTTtBQUFBLE1BQ0osT0FBTztBQUFBLE1BQ1A7QUFBQSxNQUNBLFNBQVMsS0FBSyxtRkFBbUYscUJBQXFCLElBQUksS0FBSyx5QkFBeUIsTUFBTSxRQUFRLElBQUkseUJBQXlCLGlCQUFpQixRQUFRLFFBQVEsQ0FBQyxNQUFNLHNCQUFzQixpQkFBaUIsUUFBUSxRQUFRLENBQUM7QUFBQSxJQUNyUztBQUFBLEVBQ0Y7QUFDQSxTQUFPLFlBQVksUUFBUSxVQUFVLEtBQUssWUFBWSxVQUFVO0FBQ2xFO0FBQ0EsU0FBUyxZQUFZLFFBQVEsT0FBTztBQUNsQyxRQUFNLE9BQU8sT0FBTyxPQUFPO0FBQzNCLFFBQU0sYUFBYSxLQUFLO0FBQ3hCLE1BQUksV0FBVyxRQUFRO0FBQ3ZCLFNBQU8sV0FBVyxZQUFZO0FBQzVCLFVBQU0sT0FBTyxLQUFLLFdBQVcsUUFBUTtBQUNyQyxRQUFJLFNBQVMsTUFBTSxTQUFTLElBQUk7QUFDOUI7QUFBQSxJQUNGO0FBQ0EsUUFBSSxxQkFBcUIsSUFBSSxHQUFHO0FBQzlCLFFBQUU7QUFBQSxJQUNKLFdBQVcseUJBQXlCLE1BQU0sUUFBUSxHQUFHO0FBQ25ELGtCQUFZO0FBQUEsSUFDZCxPQUFPO0FBQ0w7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFBQSxJQUNMO0FBQUEsSUFDQSxVQUFVO0FBQUEsSUFDVjtBQUFBLElBQ0E7QUFBQSxJQUNBLEtBQUssTUFBTSxRQUFRLEdBQUcsUUFBUTtBQUFBLEVBQ2hDO0FBQ0Y7QUFDQSxTQUFTLFdBQVcsUUFBUSxPQUFPLFdBQVc7QUFDNUMsUUFBTSxPQUFPLE9BQU8sT0FBTztBQUMzQixNQUFJLFdBQVc7QUFDZixNQUFJLE9BQU87QUFDWCxNQUFJLFVBQVU7QUFDZCxNQUFJLFNBQVMsSUFBSTtBQUNmLFdBQU8sS0FBSyxXQUFXLEVBQUUsUUFBUTtBQUFBLEVBQ25DO0FBQ0EsTUFBSSxTQUFTLElBQUk7QUFDZixXQUFPLEtBQUssV0FBVyxFQUFFLFFBQVE7QUFDakMsUUFBSSxRQUFRLElBQUksR0FBRztBQUNqQixZQUFNO0FBQUEsUUFDSixPQUFPO0FBQUEsUUFDUDtBQUFBLFFBQ0EsNkNBQTZDO0FBQUEsVUFDM0M7QUFBQSxVQUNBO0FBQUEsUUFDRixDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0Y7QUFBQSxFQUNGLE9BQU87QUFDTCxlQUFXLFdBQVcsUUFBUSxVQUFVLElBQUk7QUFDNUMsV0FBTyxLQUFLLFdBQVcsUUFBUTtBQUFBLEVBQ2pDO0FBQ0EsTUFBSSxTQUFTLElBQUk7QUFDZixjQUFVO0FBQ1YsV0FBTyxLQUFLLFdBQVcsRUFBRSxRQUFRO0FBQ2pDLGVBQVcsV0FBVyxRQUFRLFVBQVUsSUFBSTtBQUM1QyxXQUFPLEtBQUssV0FBVyxRQUFRO0FBQUEsRUFDakM7QUFDQSxNQUFJLFNBQVMsTUFBTSxTQUFTLEtBQUs7QUFDL0IsY0FBVTtBQUNWLFdBQU8sS0FBSyxXQUFXLEVBQUUsUUFBUTtBQUNqQyxRQUFJLFNBQVMsTUFBTSxTQUFTLElBQUk7QUFDOUIsYUFBTyxLQUFLLFdBQVcsRUFBRSxRQUFRO0FBQUEsSUFDbkM7QUFDQSxlQUFXLFdBQVcsUUFBUSxVQUFVLElBQUk7QUFDNUMsV0FBTyxLQUFLLFdBQVcsUUFBUTtBQUFBLEVBQ2pDO0FBQ0EsTUFBSSxTQUFTLE1BQU0sWUFBWSxJQUFJLEdBQUc7QUFDcEMsVUFBTTtBQUFBLE1BQ0osT0FBTztBQUFBLE1BQ1A7QUFBQSxNQUNBLDJDQUEyQztBQUFBLFFBQ3pDO0FBQUEsUUFDQTtBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUFBLElBQ0w7QUFBQSxJQUNBLFVBQVUsVUFBVSxRQUFRLFVBQVU7QUFBQSxJQUN0QztBQUFBLElBQ0E7QUFBQSxJQUNBLEtBQUssTUFBTSxPQUFPLFFBQVE7QUFBQSxFQUM1QjtBQUNGO0FBQ0EsU0FBUyxXQUFXLFFBQVEsT0FBTyxXQUFXO0FBQzVDLE1BQUksQ0FBQyxRQUFRLFNBQVMsR0FBRztBQUN2QixVQUFNO0FBQUEsTUFDSixPQUFPO0FBQUEsTUFDUDtBQUFBLE1BQ0EsMkNBQTJDO0FBQUEsUUFDekM7QUFBQSxRQUNBO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFDQSxRQUFNLE9BQU8sT0FBTyxPQUFPO0FBQzNCLE1BQUksV0FBVyxRQUFRO0FBQ3ZCLFNBQU8sUUFBUSxLQUFLLFdBQVcsUUFBUSxDQUFDLEdBQUc7QUFDekMsTUFBRTtBQUFBLEVBQ0o7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLFdBQVcsUUFBUSxPQUFPO0FBQ2pDLFFBQU0sT0FBTyxPQUFPLE9BQU87QUFDM0IsUUFBTSxhQUFhLEtBQUs7QUFDeEIsTUFBSSxXQUFXLFFBQVE7QUFDdkIsTUFBSSxhQUFhO0FBQ2pCLE1BQUksUUFBUTtBQUNaLFNBQU8sV0FBVyxZQUFZO0FBQzVCLFVBQU0sT0FBTyxLQUFLLFdBQVcsUUFBUTtBQUNyQyxRQUFJLFNBQVMsSUFBSTtBQUNmLGVBQVMsS0FBSyxNQUFNLFlBQVksUUFBUTtBQUN4QyxhQUFPLFlBQVksUUFBUSxVQUFVLFFBQVEsT0FBTyxXQUFXLEdBQUcsS0FBSztBQUFBLElBQ3pFO0FBQ0EsUUFBSSxTQUFTLElBQUk7QUFDZixlQUFTLEtBQUssTUFBTSxZQUFZLFFBQVE7QUFDeEMsWUFBTSxTQUFTLEtBQUssV0FBVyxXQUFXLENBQUMsTUFBTSxNQUFNLEtBQUssV0FBVyxXQUFXLENBQUMsTUFBTSxNQUFNLGdDQUFnQyxRQUFRLFFBQVEsSUFBSSw2QkFBNkIsUUFBUSxRQUFRLElBQUkscUJBQXFCLFFBQVEsUUFBUTtBQUN6TyxlQUFTLE9BQU87QUFDaEIsa0JBQVksT0FBTztBQUNuQixtQkFBYTtBQUNiO0FBQUEsSUFDRjtBQUNBLFFBQUksU0FBUyxNQUFNLFNBQVMsSUFBSTtBQUM5QjtBQUFBLElBQ0Y7QUFDQSxRQUFJLHFCQUFxQixJQUFJLEdBQUc7QUFDOUIsUUFBRTtBQUFBLElBQ0osV0FBVyx5QkFBeUIsTUFBTSxRQUFRLEdBQUc7QUFDbkQsa0JBQVk7QUFBQSxJQUNkLE9BQU87QUFDTCxZQUFNO0FBQUEsUUFDSixPQUFPO0FBQUEsUUFDUDtBQUFBLFFBQ0Esb0NBQW9DO0FBQUEsVUFDbEM7QUFBQSxVQUNBO0FBQUEsUUFDRixDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsUUFBTSxZQUFZLE9BQU8sUUFBUSxVQUFVLHNCQUFzQjtBQUNuRTtBQUNBLFNBQVMsZ0NBQWdDLFFBQVEsVUFBVTtBQUN6RCxRQUFNLE9BQU8sT0FBTyxPQUFPO0FBQzNCLE1BQUksUUFBUTtBQUNaLE1BQUksT0FBTztBQUNYLFNBQU8sT0FBTyxJQUFJO0FBQ2hCLFVBQU0sT0FBTyxLQUFLLFdBQVcsV0FBVyxNQUFNO0FBQzlDLFFBQUksU0FBUyxLQUFLO0FBQ2hCLFVBQUksT0FBTyxLQUFLLENBQUMscUJBQXFCLEtBQUssR0FBRztBQUM1QztBQUFBLE1BQ0Y7QUFDQSxhQUFPO0FBQUEsUUFDTCxPQUFPLE9BQU8sY0FBYyxLQUFLO0FBQUEsUUFDakM7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFlBQVEsU0FBUyxJQUFJLGFBQWEsSUFBSTtBQUN0QyxRQUFJLFFBQVEsR0FBRztBQUNiO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxRQUFNO0FBQUEsSUFDSixPQUFPO0FBQUEsSUFDUDtBQUFBLElBQ0EscUNBQXFDLEtBQUs7QUFBQSxNQUN4QztBQUFBLE1BQ0EsV0FBVztBQUFBLElBQ2IsQ0FBQztBQUFBLEVBQ0g7QUFDRjtBQUNBLFNBQVMsNkJBQTZCLFFBQVEsVUFBVTtBQUN0RCxRQUFNLE9BQU8sT0FBTyxPQUFPO0FBQzNCLFFBQU0sT0FBTyxpQkFBaUIsTUFBTSxXQUFXLENBQUM7QUFDaEQsTUFBSSxxQkFBcUIsSUFBSSxHQUFHO0FBQzlCLFdBQU87QUFBQSxNQUNMLE9BQU8sT0FBTyxjQUFjLElBQUk7QUFBQSxNQUNoQyxNQUFNO0FBQUEsSUFDUjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLG1CQUFtQixJQUFJLEdBQUc7QUFDNUIsUUFBSSxLQUFLLFdBQVcsV0FBVyxDQUFDLE1BQU0sTUFBTSxLQUFLLFdBQVcsV0FBVyxDQUFDLE1BQU0sS0FBSztBQUNqRixZQUFNLGVBQWUsaUJBQWlCLE1BQU0sV0FBVyxDQUFDO0FBQ3hELFVBQUksb0JBQW9CLFlBQVksR0FBRztBQUNyQyxlQUFPO0FBQUEsVUFDTCxPQUFPLE9BQU8sY0FBYyxNQUFNLFlBQVk7QUFBQSxVQUM5QyxNQUFNO0FBQUEsUUFDUjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFFBQU07QUFBQSxJQUNKLE9BQU87QUFBQSxJQUNQO0FBQUEsSUFDQSxxQ0FBcUMsS0FBSyxNQUFNLFVBQVUsV0FBVyxDQUFDLENBQUM7QUFBQSxFQUN6RTtBQUNGO0FBQ0EsU0FBUyxpQkFBaUIsTUFBTSxVQUFVO0FBQ3hDLFNBQU8sYUFBYSxLQUFLLFdBQVcsUUFBUSxDQUFDLEtBQUssS0FBSyxhQUFhLEtBQUssV0FBVyxXQUFXLENBQUMsQ0FBQyxLQUFLLElBQUksYUFBYSxLQUFLLFdBQVcsV0FBVyxDQUFDLENBQUMsS0FBSyxJQUFJLGFBQWEsS0FBSyxXQUFXLFdBQVcsQ0FBQyxDQUFDO0FBQ3pNO0FBQ0EsU0FBUyxhQUFhLE1BQU07QUFDMUIsU0FBTyxRQUFRLE1BQU0sUUFBUSxLQUFLLE9BQU8sS0FBSyxRQUFRLE1BQU0sUUFBUSxLQUFLLE9BQU8sS0FBSyxRQUFRLE1BQU0sUUFBUSxNQUFNLE9BQU8sS0FBSztBQUMvSDtBQUNBLFNBQVMscUJBQXFCLFFBQVEsVUFBVTtBQUM5QyxRQUFNLE9BQU8sT0FBTyxPQUFPO0FBQzNCLFFBQU0sT0FBTyxLQUFLLFdBQVcsV0FBVyxDQUFDO0FBQ3pDLFVBQVEsTUFBTTtBQUFBLElBQ1osS0FBSztBQUNILGFBQU87QUFBQSxRQUNMLE9BQU87QUFBQSxRQUNQLE1BQU07QUFBQSxNQUNSO0FBQUEsSUFDRixLQUFLO0FBQ0gsYUFBTztBQUFBLFFBQ0wsT0FBTztBQUFBLFFBQ1AsTUFBTTtBQUFBLE1BQ1I7QUFBQSxJQUNGLEtBQUs7QUFDSCxhQUFPO0FBQUEsUUFDTCxPQUFPO0FBQUEsUUFDUCxNQUFNO0FBQUEsTUFDUjtBQUFBLElBQ0YsS0FBSztBQUNILGFBQU87QUFBQSxRQUNMLE9BQU87QUFBQSxRQUNQLE1BQU07QUFBQSxNQUNSO0FBQUEsSUFDRixLQUFLO0FBQ0gsYUFBTztBQUFBLFFBQ0wsT0FBTztBQUFBLFFBQ1AsTUFBTTtBQUFBLE1BQ1I7QUFBQSxJQUNGLEtBQUs7QUFDSCxhQUFPO0FBQUEsUUFDTCxPQUFPO0FBQUEsUUFDUCxNQUFNO0FBQUEsTUFDUjtBQUFBLElBQ0YsS0FBSztBQUNILGFBQU87QUFBQSxRQUNMLE9BQU87QUFBQSxRQUNQLE1BQU07QUFBQSxNQUNSO0FBQUEsSUFDRixLQUFLO0FBQ0gsYUFBTztBQUFBLFFBQ0wsT0FBTztBQUFBLFFBQ1AsTUFBTTtBQUFBLE1BQ1I7QUFBQSxFQUNKO0FBQ0EsUUFBTTtBQUFBLElBQ0osT0FBTztBQUFBLElBQ1A7QUFBQSxJQUNBLHVDQUF1QyxLQUFLO0FBQUEsTUFDMUM7QUFBQSxNQUNBLFdBQVc7QUFBQSxJQUNiLENBQUM7QUFBQSxFQUNIO0FBQ0Y7QUFDQSxTQUFTLGdCQUFnQixRQUFRLE9BQU87QUFDdEMsUUFBTSxPQUFPLE9BQU8sT0FBTztBQUMzQixRQUFNLGFBQWEsS0FBSztBQUN4QixNQUFJLFlBQVksT0FBTztBQUN2QixNQUFJLFdBQVcsUUFBUTtBQUN2QixNQUFJLGFBQWE7QUFDakIsTUFBSSxjQUFjO0FBQ2xCLFFBQU0sYUFBYSxDQUFDO0FBQ3BCLFNBQU8sV0FBVyxZQUFZO0FBQzVCLFVBQU0sT0FBTyxLQUFLLFdBQVcsUUFBUTtBQUNyQyxRQUFJLFNBQVMsTUFBTSxLQUFLLFdBQVcsV0FBVyxDQUFDLE1BQU0sTUFBTSxLQUFLLFdBQVcsV0FBVyxDQUFDLE1BQU0sSUFBSTtBQUMvRixxQkFBZSxLQUFLLE1BQU0sWUFBWSxRQUFRO0FBQzlDLGlCQUFXLEtBQUssV0FBVztBQUMzQixZQUFNLFFBQVE7QUFBQSxRQUNaO0FBQUEsUUFDQSxVQUFVO0FBQUEsUUFDVjtBQUFBLFFBQ0EsV0FBVztBQUFBO0FBQUEsUUFFWCx1QkFBdUIsVUFBVSxFQUFFLEtBQUssSUFBSTtBQUFBLE1BQzlDO0FBQ0EsYUFBTyxRQUFRLFdBQVcsU0FBUztBQUNuQyxhQUFPLFlBQVk7QUFDbkIsYUFBTztBQUFBLElBQ1Q7QUFDQSxRQUFJLFNBQVMsTUFBTSxLQUFLLFdBQVcsV0FBVyxDQUFDLE1BQU0sTUFBTSxLQUFLLFdBQVcsV0FBVyxDQUFDLE1BQU0sTUFBTSxLQUFLLFdBQVcsV0FBVyxDQUFDLE1BQU0sSUFBSTtBQUN2SSxxQkFBZSxLQUFLLE1BQU0sWUFBWSxRQUFRO0FBQzlDLG1CQUFhLFdBQVc7QUFDeEIsa0JBQVk7QUFDWjtBQUFBLElBQ0Y7QUFDQSxRQUFJLFNBQVMsTUFBTSxTQUFTLElBQUk7QUFDOUIscUJBQWUsS0FBSyxNQUFNLFlBQVksUUFBUTtBQUM5QyxpQkFBVyxLQUFLLFdBQVc7QUFDM0IsVUFBSSxTQUFTLE1BQU0sS0FBSyxXQUFXLFdBQVcsQ0FBQyxNQUFNLElBQUk7QUFDdkQsb0JBQVk7QUFBQSxNQUNkLE9BQU87QUFDTCxVQUFFO0FBQUEsTUFDSjtBQUNBLG9CQUFjO0FBQ2QsbUJBQWE7QUFDYixrQkFBWTtBQUNaO0FBQUEsSUFDRjtBQUNBLFFBQUkscUJBQXFCLElBQUksR0FBRztBQUM5QixRQUFFO0FBQUEsSUFDSixXQUFXLHlCQUF5QixNQUFNLFFBQVEsR0FBRztBQUNuRCxrQkFBWTtBQUFBLElBQ2QsT0FBTztBQUNMLFlBQU07QUFBQSxRQUNKLE9BQU87QUFBQSxRQUNQO0FBQUEsUUFDQSxvQ0FBb0M7QUFBQSxVQUNsQztBQUFBLFVBQ0E7QUFBQSxRQUNGLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLFlBQVksT0FBTyxRQUFRLFVBQVUsc0JBQXNCO0FBQ25FO0FBQ0EsU0FBUyxTQUFTLFFBQVEsT0FBTztBQUMvQixRQUFNLE9BQU8sT0FBTyxPQUFPO0FBQzNCLFFBQU0sYUFBYSxLQUFLO0FBQ3hCLE1BQUksV0FBVyxRQUFRO0FBQ3ZCLFNBQU8sV0FBVyxZQUFZO0FBQzVCLFVBQU0sT0FBTyxLQUFLLFdBQVcsUUFBUTtBQUNyQyxRQUFJLGVBQWUsSUFBSSxHQUFHO0FBQ3hCLFFBQUU7QUFBQSxJQUNKLE9BQU87QUFDTDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUFBLElBQ0w7QUFBQSxJQUNBLFVBQVU7QUFBQSxJQUNWO0FBQUEsSUFDQTtBQUFBLElBQ0EsS0FBSyxNQUFNLE9BQU8sUUFBUTtBQUFBLEVBQzVCO0FBQ0Y7QUFHQSxJQUFJLG1CQUFtQjtBQUN2QixJQUFJLHNCQUFzQjtBQUMxQixTQUFTLFFBQVEsT0FBTztBQUN0QixTQUFPLFlBQVksT0FBTyxDQUFDLENBQUM7QUFDOUI7QUFDQSxTQUFTLFlBQVksT0FBTyxZQUFZO0FBQ3RDLFVBQVEsT0FBTyxPQUFPO0FBQUEsSUFDcEIsS0FBSztBQUNILGFBQU8sS0FBSyxVQUFVLEtBQUs7QUFBQSxJQUM3QixLQUFLO0FBQ0gsYUFBTyxNQUFNLE9BQU8sYUFBYSxNQUFNLElBQUksTUFBTTtBQUFBLElBQ25ELEtBQUs7QUFDSCxhQUFPLGtCQUFrQixPQUFPLFVBQVU7QUFBQSxJQUM1QztBQUNFLGFBQU8sT0FBTyxLQUFLO0FBQUEsRUFDdkI7QUFDRjtBQUNBLFNBQVMsa0JBQWtCLE9BQU8sc0JBQXNCO0FBQ3RELE1BQUksVUFBVSxNQUFNO0FBQ2xCLFdBQU87QUFBQSxFQUNUO0FBQ0EsTUFBSSxxQkFBcUIsU0FBUyxLQUFLLEdBQUc7QUFDeEMsV0FBTztBQUFBLEVBQ1Q7QUFDQSxRQUFNLGFBQWEsQ0FBQyxHQUFHLHNCQUFzQixLQUFLO0FBQ2xELE1BQUksV0FBVyxLQUFLLEdBQUc7QUFDckIsVUFBTSxZQUFZLE1BQU0sT0FBTztBQUMvQixRQUFJLGNBQWMsT0FBTztBQUN2QixhQUFPLE9BQU8sY0FBYyxXQUFXLFlBQVksWUFBWSxXQUFXLFVBQVU7QUFBQSxJQUN0RjtBQUFBLEVBQ0YsV0FBVyxNQUFNLFFBQVEsS0FBSyxHQUFHO0FBQy9CLFdBQU8sWUFBWSxPQUFPLFVBQVU7QUFBQSxFQUN0QztBQUNBLFNBQU8sYUFBYSxPQUFPLFVBQVU7QUFDdkM7QUFDQSxTQUFTLFdBQVcsT0FBTztBQUN6QixTQUFPLE9BQU8sTUFBTSxXQUFXO0FBQ2pDO0FBQ0EsU0FBUyxhQUFhLFFBQVEsWUFBWTtBQUN4QyxRQUFNLFVBQVUsT0FBTyxRQUFRLE1BQU07QUFDckMsTUFBSSxRQUFRLFdBQVcsR0FBRztBQUN4QixXQUFPO0FBQUEsRUFDVDtBQUNBLE1BQUksV0FBVyxTQUFTLHFCQUFxQjtBQUMzQyxXQUFPLE1BQU0sYUFBYSxNQUFNLElBQUk7QUFBQSxFQUN0QztBQUNBLFFBQU0sYUFBYSxRQUFRO0FBQUEsSUFDekIsQ0FBQyxDQUFDLEtBQUssS0FBSyxNQUFNLE1BQU0sT0FBTyxZQUFZLE9BQU8sVUFBVTtBQUFBLEVBQzlEO0FBQ0EsU0FBTyxPQUFPLFdBQVcsS0FBSyxJQUFJLElBQUk7QUFDeEM7QUFDQSxTQUFTLFlBQVksT0FBTyxZQUFZO0FBQ3RDLE1BQUksTUFBTSxXQUFXLEdBQUc7QUFDdEIsV0FBTztBQUFBLEVBQ1Q7QUFDQSxNQUFJLFdBQVcsU0FBUyxxQkFBcUI7QUFDM0MsV0FBTztBQUFBLEVBQ1Q7QUFDQSxRQUFNLE1BQU0sS0FBSyxJQUFJLGtCQUFrQixNQUFNLE1BQU07QUFDbkQsUUFBTSxZQUFZLE1BQU0sU0FBUztBQUNqQyxRQUFNLFFBQVEsQ0FBQztBQUNmLFdBQVMsSUFBSSxHQUFHLElBQUksS0FBSyxFQUFFLEdBQUc7QUFDNUIsVUFBTSxLQUFLLFlBQVksTUFBTSxDQUFDLEdBQUcsVUFBVSxDQUFDO0FBQUEsRUFDOUM7QUFDQSxNQUFJLGNBQWMsR0FBRztBQUNuQixVQUFNLEtBQUssaUJBQWlCO0FBQUEsRUFDOUIsV0FBVyxZQUFZLEdBQUc7QUFDeEIsVUFBTSxLQUFLLE9BQU8sU0FBUyxhQUFhO0FBQUEsRUFDMUM7QUFDQSxTQUFPLE1BQU0sTUFBTSxLQUFLLElBQUksSUFBSTtBQUNsQztBQUNBLFNBQVMsYUFBYSxRQUFRO0FBQzVCLFFBQU0sTUFBTSxPQUFPLFVBQVUsU0FBUyxLQUFLLE1BQU0sRUFBRSxRQUFRLGNBQWMsRUFBRSxFQUFFLFFBQVEsTUFBTSxFQUFFO0FBQzdGLE1BQUksUUFBUSxZQUFZLE9BQU8sT0FBTyxnQkFBZ0IsWUFBWTtBQUNoRSxVQUFNLE9BQU8sT0FBTyxZQUFZO0FBQ2hDLFFBQUksT0FBTyxTQUFTLFlBQVksU0FBUyxJQUFJO0FBQzNDLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUdBLElBQUk7QUFBQTtBQUFBO0FBQUEsRUFHRixXQUFXLFdBQVcsUUFBbUQsU0FBUyxZQUFZLE9BQU8sYUFBYTtBQUNoSCxXQUFPLGlCQUFpQjtBQUFBLEVBQzFCLElBQUksU0FBUyxZQUFZLE9BQU8sYUFBYTtBQUMzQyxRQUFJLGlCQUFpQixhQUFhO0FBQ2hDLGFBQU87QUFBQSxJQUNUO0FBQ0EsUUFBSSxPQUFPLFVBQVUsWUFBWSxVQUFVLE1BQU07QUFDL0MsVUFBSTtBQUNKLFlBQU0sWUFBWSxZQUFZLFVBQVUsT0FBTyxXQUFXO0FBQzFELFlBQU07QUFBQTtBQUFBLFFBRUosT0FBTyxlQUFlLFFBQVEsTUFBTSxPQUFPLFdBQVcsS0FBSyxxQkFBcUIsTUFBTSxpQkFBaUIsUUFBUSx1QkFBdUIsU0FBUyxTQUFTLG1CQUFtQjtBQUFBO0FBRTdLLFVBQUksY0FBYyxnQkFBZ0I7QUFDaEMsY0FBTSxtQkFBbUIsUUFBUSxLQUFLO0FBQ3RDLGNBQU0sSUFBSSxNQUFNLGNBQWMsU0FBUyxLQUFLLGdCQUFnQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBV2xEO0FBQUEsTUFDWjtBQUFBLElBQ0Y7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUFBO0FBSUYsSUFBSSxTQUFTLE1BQU07QUFBQSxFQUNqQixZQUFZLE1BQU0sT0FBTyxtQkFBbUIsaUJBQWlCO0FBQUEsSUFDM0QsTUFBTTtBQUFBLElBQ04sUUFBUTtBQUFBLEVBQ1YsR0FBRztBQUNELFdBQU8sU0FBUyxZQUFZLFVBQVUsT0FBTyxvQ0FBb0MsUUFBUSxJQUFJLENBQUMsR0FBRztBQUNqRyxTQUFLLE9BQU87QUFDWixTQUFLLE9BQU87QUFDWixTQUFLLGlCQUFpQjtBQUN0QixTQUFLLGVBQWUsT0FBTyxLQUFLO0FBQUEsTUFDOUI7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBLFNBQUssZUFBZSxTQUFTLEtBQUs7QUFBQSxNQUNoQztBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBLEVBQ0EsS0FBSyxPQUFPLFdBQVcsSUFBSTtBQUN6QixXQUFPO0FBQUEsRUFDVDtBQUNGO0FBQ0EsU0FBUyxTQUFTLFFBQVE7QUFDeEIsU0FBTyxXQUFXLFFBQVEsTUFBTTtBQUNsQztBQUdBLFNBQVMsT0FBTyxRQUFRLFNBQVM7QUFDL0IsUUFBTSxTQUFTLElBQUksT0FBTyxRQUFRLE9BQU87QUFDekMsU0FBTyxPQUFPLGNBQWM7QUFDOUI7QUFDQSxJQUFJLFNBQVMsTUFBTTtBQUFBLEVBQ2pCLFlBQVksUUFBUSxVQUFVLENBQUMsR0FBRztBQUNoQyxVQUFNLFlBQVksU0FBUyxNQUFNLElBQUksU0FBUyxJQUFJLE9BQU8sTUFBTTtBQUMvRCxTQUFLLFNBQVMsSUFBSSxNQUFNLFNBQVM7QUFDakMsU0FBSyxXQUFXO0FBQ2hCLFNBQUssZ0JBQWdCO0FBQUEsRUFDdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLFlBQVk7QUFDVixVQUFNLFFBQVEsS0FBSyxZQUFZLFVBQVUsSUFBSTtBQUM3QyxXQUFPLEtBQUssS0FBSyxPQUFPO0FBQUEsTUFDdEIsTUFBTSxLQUFLO0FBQUEsTUFDWCxPQUFPLE1BQU07QUFBQSxJQUNmLENBQUM7QUFBQSxFQUNIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUtBLGdCQUFnQjtBQUNkLFdBQU8sS0FBSyxLQUFLLEtBQUssT0FBTyxPQUFPO0FBQUEsTUFDbEMsTUFBTSxLQUFLO0FBQUEsTUFDWCxhQUFhLEtBQUs7QUFBQSxRQUNoQixVQUFVO0FBQUEsUUFDVixLQUFLO0FBQUEsUUFDTCxVQUFVO0FBQUEsTUFDWjtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUF3QkEsa0JBQWtCO0FBQ2hCLFFBQUksS0FBSyxLQUFLLFVBQVUsT0FBTyxHQUFHO0FBQ2hDLGFBQU8sS0FBSyx5QkFBeUI7QUFBQSxJQUN2QztBQUNBLFVBQU0saUJBQWlCLEtBQUssZ0JBQWdCO0FBQzVDLFVBQU0sZUFBZSxpQkFBaUIsS0FBSyxPQUFPLFVBQVUsSUFBSSxLQUFLLE9BQU87QUFDNUUsUUFBSSxhQUFhLFNBQVMsVUFBVSxNQUFNO0FBQ3hDLGNBQVEsYUFBYSxPQUFPO0FBQUEsUUFDMUIsS0FBSztBQUNILGlCQUFPLEtBQUssc0JBQXNCO0FBQUEsUUFDcEMsS0FBSztBQUNILGlCQUFPLEtBQUssMEJBQTBCO0FBQUEsUUFDeEMsS0FBSztBQUNILGlCQUFPLEtBQUssMEJBQTBCO0FBQUEsUUFDeEMsS0FBSztBQUNILGlCQUFPLEtBQUssNkJBQTZCO0FBQUEsUUFDM0MsS0FBSztBQUNILGlCQUFPLEtBQUsseUJBQXlCO0FBQUEsUUFDdkMsS0FBSztBQUNILGlCQUFPLEtBQUssd0JBQXdCO0FBQUEsUUFDdEMsS0FBSztBQUNILGlCQUFPLEtBQUssK0JBQStCO0FBQUEsUUFDN0MsS0FBSztBQUNILGlCQUFPLEtBQUsseUJBQXlCO0FBQUEsTUFDekM7QUFDQSxVQUFJLGdCQUFnQjtBQUNsQixjQUFNO0FBQUEsVUFDSixLQUFLLE9BQU87QUFBQSxVQUNaLEtBQUssT0FBTyxNQUFNO0FBQUEsVUFDbEI7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBLGNBQVEsYUFBYSxPQUFPO0FBQUEsUUFDMUIsS0FBSztBQUFBLFFBQ0wsS0FBSztBQUFBLFFBQ0wsS0FBSztBQUNILGlCQUFPLEtBQUsseUJBQXlCO0FBQUEsUUFDdkMsS0FBSztBQUNILGlCQUFPLEtBQUssd0JBQXdCO0FBQUEsUUFDdEMsS0FBSztBQUNILGlCQUFPLEtBQUsseUJBQXlCO0FBQUEsTUFDekM7QUFBQSxJQUNGO0FBQ0EsVUFBTSxLQUFLLFdBQVcsWUFBWTtBQUFBLEVBQ3BDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFPQSwyQkFBMkI7QUFDekIsVUFBTSxRQUFRLEtBQUssT0FBTztBQUMxQixRQUFJLEtBQUssS0FBSyxVQUFVLE9BQU8sR0FBRztBQUNoQyxhQUFPLEtBQUssS0FBSyxPQUFPO0FBQUEsUUFDdEIsTUFBTSxLQUFLO0FBQUEsUUFDWCxXQUFXLGtCQUFrQjtBQUFBLFFBQzdCLE1BQU07QUFBQSxRQUNOLHFCQUFxQixDQUFDO0FBQUEsUUFDdEIsWUFBWSxDQUFDO0FBQUEsUUFDYixjQUFjLEtBQUssa0JBQWtCO0FBQUEsTUFDdkMsQ0FBQztBQUFBLElBQ0g7QUFDQSxVQUFNLFlBQVksS0FBSyxtQkFBbUI7QUFDMUMsUUFBSTtBQUNKLFFBQUksS0FBSyxLQUFLLFVBQVUsSUFBSSxHQUFHO0FBQzdCLGFBQU8sS0FBSyxVQUFVO0FBQUEsSUFDeEI7QUFDQSxXQUFPLEtBQUssS0FBSyxPQUFPO0FBQUEsTUFDdEIsTUFBTSxLQUFLO0FBQUEsTUFDWDtBQUFBLE1BQ0E7QUFBQSxNQUNBLHFCQUFxQixLQUFLLHlCQUF5QjtBQUFBLE1BQ25ELFlBQVksS0FBSyxnQkFBZ0IsS0FBSztBQUFBLE1BQ3RDLGNBQWMsS0FBSyxrQkFBa0I7QUFBQSxJQUN2QyxDQUFDO0FBQUEsRUFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSUEscUJBQXFCO0FBQ25CLFVBQU0saUJBQWlCLEtBQUssWUFBWSxVQUFVLElBQUk7QUFDdEQsWUFBUSxlQUFlLE9BQU87QUFBQSxNQUM1QixLQUFLO0FBQ0gsZUFBTyxrQkFBa0I7QUFBQSxNQUMzQixLQUFLO0FBQ0gsZUFBTyxrQkFBa0I7QUFBQSxNQUMzQixLQUFLO0FBQ0gsZUFBTyxrQkFBa0I7QUFBQSxJQUM3QjtBQUNBLFVBQU0sS0FBSyxXQUFXLGNBQWM7QUFBQSxFQUN0QztBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSUEsMkJBQTJCO0FBQ3pCLFdBQU8sS0FBSztBQUFBLE1BQ1YsVUFBVTtBQUFBLE1BQ1YsS0FBSztBQUFBLE1BQ0wsVUFBVTtBQUFBLElBQ1o7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSwwQkFBMEI7QUFDeEIsV0FBTyxLQUFLLEtBQUssS0FBSyxPQUFPLE9BQU87QUFBQSxNQUNsQyxNQUFNLEtBQUs7QUFBQSxNQUNYLFVBQVUsS0FBSyxjQUFjO0FBQUEsTUFDN0IsT0FBTyxLQUFLLFlBQVksVUFBVSxLQUFLLEdBQUcsS0FBSyxtQkFBbUI7QUFBQSxNQUNsRSxjQUFjLEtBQUssb0JBQW9CLFVBQVUsTUFBTSxJQUFJLEtBQUssdUJBQXVCLElBQUk7QUFBQSxNQUMzRixZQUFZLEtBQUsscUJBQXFCO0FBQUEsSUFDeEMsQ0FBQztBQUFBLEVBQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLGdCQUFnQjtBQUNkLFVBQU0sUUFBUSxLQUFLLE9BQU87QUFDMUIsU0FBSyxZQUFZLFVBQVUsTUFBTTtBQUNqQyxXQUFPLEtBQUssS0FBSyxPQUFPO0FBQUEsTUFDdEIsTUFBTSxLQUFLO0FBQUEsTUFDWCxNQUFNLEtBQUssVUFBVTtBQUFBLElBQ3ZCLENBQUM7QUFBQSxFQUNIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsb0JBQW9CO0FBQ2xCLFdBQU8sS0FBSyxLQUFLLEtBQUssT0FBTyxPQUFPO0FBQUEsTUFDbEMsTUFBTSxLQUFLO0FBQUEsTUFDWCxZQUFZLEtBQUs7QUFBQSxRQUNmLFVBQVU7QUFBQSxRQUNWLEtBQUs7QUFBQSxRQUNMLFVBQVU7QUFBQSxNQUNaO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT0EsaUJBQWlCO0FBQ2YsV0FBTyxLQUFLLEtBQUssVUFBVSxNQUFNLElBQUksS0FBSyxjQUFjLElBQUksS0FBSyxXQUFXO0FBQUEsRUFDOUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSxhQUFhO0FBQ1gsVUFBTSxRQUFRLEtBQUssT0FBTztBQUMxQixVQUFNLGNBQWMsS0FBSyxVQUFVO0FBQ25DLFFBQUk7QUFDSixRQUFJO0FBQ0osUUFBSSxLQUFLLG9CQUFvQixVQUFVLEtBQUssR0FBRztBQUM3QyxjQUFRO0FBQ1IsYUFBTyxLQUFLLFVBQVU7QUFBQSxJQUN4QixPQUFPO0FBQ0wsYUFBTztBQUFBLElBQ1Q7QUFDQSxXQUFPLEtBQUssS0FBSyxPQUFPO0FBQUEsTUFDdEIsTUFBTSxLQUFLO0FBQUEsTUFDWDtBQUFBLE1BQ0E7QUFBQSxNQUNBLFdBQVcsS0FBSyxlQUFlLEtBQUs7QUFBQSxNQUNwQyxZQUFZLEtBQUssZ0JBQWdCLEtBQUs7QUFBQSxNQUN0QyxjQUFjLEtBQUssS0FBSyxVQUFVLE9BQU8sSUFBSSxLQUFLLGtCQUFrQixJQUFJO0FBQUEsSUFDMUUsQ0FBQztBQUFBLEVBQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLGVBQWUsU0FBUztBQUN0QixVQUFNLE9BQU8sVUFBVSxLQUFLLHFCQUFxQixLQUFLO0FBQ3RELFdBQU8sS0FBSyxhQUFhLFVBQVUsU0FBUyxNQUFNLFVBQVUsT0FBTztBQUFBLEVBQ3JFO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSxjQUFjLFVBQVUsT0FBTztBQUM3QixVQUFNLFFBQVEsS0FBSyxPQUFPO0FBQzFCLFVBQU0sT0FBTyxLQUFLLFVBQVU7QUFDNUIsU0FBSyxZQUFZLFVBQVUsS0FBSztBQUNoQyxXQUFPLEtBQUssS0FBSyxPQUFPO0FBQUEsTUFDdEIsTUFBTSxLQUFLO0FBQUEsTUFDWDtBQUFBLE1BQ0EsT0FBTyxLQUFLLGtCQUFrQixPQUFPO0FBQUEsSUFDdkMsQ0FBQztBQUFBLEVBQ0g7QUFBQSxFQUNBLHFCQUFxQjtBQUNuQixXQUFPLEtBQUssY0FBYyxJQUFJO0FBQUEsRUFDaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFTQSxnQkFBZ0I7QUFDZCxVQUFNLFFBQVEsS0FBSyxPQUFPO0FBQzFCLFNBQUssWUFBWSxVQUFVLE1BQU07QUFDakMsVUFBTSxtQkFBbUIsS0FBSyxzQkFBc0IsSUFBSTtBQUN4RCxRQUFJLENBQUMsb0JBQW9CLEtBQUssS0FBSyxVQUFVLElBQUksR0FBRztBQUNsRCxhQUFPLEtBQUssS0FBSyxPQUFPO0FBQUEsUUFDdEIsTUFBTSxLQUFLO0FBQUEsUUFDWCxNQUFNLEtBQUssa0JBQWtCO0FBQUEsUUFDN0IsWUFBWSxLQUFLLGdCQUFnQixLQUFLO0FBQUEsTUFDeEMsQ0FBQztBQUFBLElBQ0g7QUFDQSxXQUFPLEtBQUssS0FBSyxPQUFPO0FBQUEsTUFDdEIsTUFBTSxLQUFLO0FBQUEsTUFDWCxlQUFlLG1CQUFtQixLQUFLLGVBQWUsSUFBSTtBQUFBLE1BQzFELFlBQVksS0FBSyxnQkFBZ0IsS0FBSztBQUFBLE1BQ3RDLGNBQWMsS0FBSyxrQkFBa0I7QUFBQSxJQUN2QyxDQUFDO0FBQUEsRUFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT0EsMEJBQTBCO0FBQ3hCLFVBQU0sUUFBUSxLQUFLLE9BQU87QUFDMUIsU0FBSyxjQUFjLFVBQVU7QUFDN0IsUUFBSSxLQUFLLFNBQVMsaUNBQWlDLE1BQU07QUFDdkQsYUFBTyxLQUFLLEtBQUssT0FBTztBQUFBLFFBQ3RCLE1BQU0sS0FBSztBQUFBLFFBQ1gsTUFBTSxLQUFLLGtCQUFrQjtBQUFBLFFBQzdCLHFCQUFxQixLQUFLLHlCQUF5QjtBQUFBLFFBQ25ELGdCQUFnQixLQUFLLGNBQWMsSUFBSSxHQUFHLEtBQUssZUFBZTtBQUFBLFFBQzlELFlBQVksS0FBSyxnQkFBZ0IsS0FBSztBQUFBLFFBQ3RDLGNBQWMsS0FBSyxrQkFBa0I7QUFBQSxNQUN2QyxDQUFDO0FBQUEsSUFDSDtBQUNBLFdBQU8sS0FBSyxLQUFLLE9BQU87QUFBQSxNQUN0QixNQUFNLEtBQUs7QUFBQSxNQUNYLE1BQU0sS0FBSyxrQkFBa0I7QUFBQSxNQUM3QixnQkFBZ0IsS0FBSyxjQUFjLElBQUksR0FBRyxLQUFLLGVBQWU7QUFBQSxNQUM5RCxZQUFZLEtBQUssZ0JBQWdCLEtBQUs7QUFBQSxNQUN0QyxjQUFjLEtBQUssa0JBQWtCO0FBQUEsSUFDdkMsQ0FBQztBQUFBLEVBQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLG9CQUFvQjtBQUNsQixRQUFJLEtBQUssT0FBTyxNQUFNLFVBQVUsTUFBTTtBQUNwQyxZQUFNLEtBQUssV0FBVztBQUFBLElBQ3hCO0FBQ0EsV0FBTyxLQUFLLFVBQVU7QUFBQSxFQUN4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFvQkEsa0JBQWtCLFNBQVM7QUFDekIsVUFBTSxRQUFRLEtBQUssT0FBTztBQUMxQixZQUFRLE1BQU0sTUFBTTtBQUFBLE1BQ2xCLEtBQUssVUFBVTtBQUNiLGVBQU8sS0FBSyxVQUFVLE9BQU87QUFBQSxNQUMvQixLQUFLLFVBQVU7QUFDYixlQUFPLEtBQUssWUFBWSxPQUFPO0FBQUEsTUFDakMsS0FBSyxVQUFVO0FBQ2IsYUFBSyxhQUFhO0FBQ2xCLGVBQU8sS0FBSyxLQUFLLE9BQU87QUFBQSxVQUN0QixNQUFNLEtBQUs7QUFBQSxVQUNYLE9BQU8sTUFBTTtBQUFBLFFBQ2YsQ0FBQztBQUFBLE1BQ0gsS0FBSyxVQUFVO0FBQ2IsYUFBSyxhQUFhO0FBQ2xCLGVBQU8sS0FBSyxLQUFLLE9BQU87QUFBQSxVQUN0QixNQUFNLEtBQUs7QUFBQSxVQUNYLE9BQU8sTUFBTTtBQUFBLFFBQ2YsQ0FBQztBQUFBLE1BQ0gsS0FBSyxVQUFVO0FBQUEsTUFDZixLQUFLLFVBQVU7QUFDYixlQUFPLEtBQUssbUJBQW1CO0FBQUEsTUFDakMsS0FBSyxVQUFVO0FBQ2IsYUFBSyxhQUFhO0FBQ2xCLGdCQUFRLE1BQU0sT0FBTztBQUFBLFVBQ25CLEtBQUs7QUFDSCxtQkFBTyxLQUFLLEtBQUssT0FBTztBQUFBLGNBQ3RCLE1BQU0sS0FBSztBQUFBLGNBQ1gsT0FBTztBQUFBLFlBQ1QsQ0FBQztBQUFBLFVBQ0gsS0FBSztBQUNILG1CQUFPLEtBQUssS0FBSyxPQUFPO0FBQUEsY0FDdEIsTUFBTSxLQUFLO0FBQUEsY0FDWCxPQUFPO0FBQUEsWUFDVCxDQUFDO0FBQUEsVUFDSCxLQUFLO0FBQ0gsbUJBQU8sS0FBSyxLQUFLLE9BQU87QUFBQSxjQUN0QixNQUFNLEtBQUs7QUFBQSxZQUNiLENBQUM7QUFBQSxVQUNIO0FBQ0UsbUJBQU8sS0FBSyxLQUFLLE9BQU87QUFBQSxjQUN0QixNQUFNLEtBQUs7QUFBQSxjQUNYLE9BQU8sTUFBTTtBQUFBLFlBQ2YsQ0FBQztBQUFBLFFBQ0w7QUFBQSxNQUNGLEtBQUssVUFBVTtBQUNiLFlBQUksU0FBUztBQUNYLGVBQUssWUFBWSxVQUFVLE1BQU07QUFDakMsY0FBSSxLQUFLLE9BQU8sTUFBTSxTQUFTLFVBQVUsTUFBTTtBQUM3QyxrQkFBTSxVQUFVLEtBQUssT0FBTyxNQUFNO0FBQ2xDLGtCQUFNO0FBQUEsY0FDSixLQUFLLE9BQU87QUFBQSxjQUNaLE1BQU07QUFBQSxjQUNOLHlCQUF5QixPQUFPO0FBQUEsWUFDbEM7QUFBQSxVQUNGLE9BQU87QUFDTCxrQkFBTSxLQUFLLFdBQVcsS0FBSztBQUFBLFVBQzdCO0FBQUEsUUFDRjtBQUNBLGVBQU8sS0FBSyxjQUFjO0FBQUEsTUFDNUI7QUFDRSxjQUFNLEtBQUssV0FBVztBQUFBLElBQzFCO0FBQUEsRUFDRjtBQUFBLEVBQ0EseUJBQXlCO0FBQ3ZCLFdBQU8sS0FBSyxrQkFBa0IsSUFBSTtBQUFBLEVBQ3BDO0FBQUEsRUFDQSxxQkFBcUI7QUFDbkIsVUFBTSxRQUFRLEtBQUssT0FBTztBQUMxQixTQUFLLGFBQWE7QUFDbEIsV0FBTyxLQUFLLEtBQUssT0FBTztBQUFBLE1BQ3RCLE1BQU0sS0FBSztBQUFBLE1BQ1gsT0FBTyxNQUFNO0FBQUEsTUFDYixPQUFPLE1BQU0sU0FBUyxVQUFVO0FBQUEsSUFDbEMsQ0FBQztBQUFBLEVBQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSxVQUFVLFNBQVM7QUFDakIsVUFBTSxPQUFPLE1BQU0sS0FBSyxrQkFBa0IsT0FBTztBQUNqRCxXQUFPLEtBQUssS0FBSyxLQUFLLE9BQU8sT0FBTztBQUFBLE1BQ2xDLE1BQU0sS0FBSztBQUFBLE1BQ1gsUUFBUSxLQUFLLElBQUksVUFBVSxXQUFXLE1BQU0sVUFBVSxTQUFTO0FBQUEsSUFDakUsQ0FBQztBQUFBLEVBQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBUUEsWUFBWSxTQUFTO0FBQ25CLFVBQU0sT0FBTyxNQUFNLEtBQUssaUJBQWlCLE9BQU87QUFDaEQsV0FBTyxLQUFLLEtBQUssS0FBSyxPQUFPLE9BQU87QUFBQSxNQUNsQyxNQUFNLEtBQUs7QUFBQSxNQUNYLFFBQVEsS0FBSyxJQUFJLFVBQVUsU0FBUyxNQUFNLFVBQVUsT0FBTztBQUFBLElBQzdELENBQUM7QUFBQSxFQUNIO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSxpQkFBaUIsU0FBUztBQUN4QixVQUFNLFFBQVEsS0FBSyxPQUFPO0FBQzFCLFVBQU0sT0FBTyxLQUFLLFVBQVU7QUFDNUIsU0FBSyxZQUFZLFVBQVUsS0FBSztBQUNoQyxXQUFPLEtBQUssS0FBSyxPQUFPO0FBQUEsTUFDdEIsTUFBTSxLQUFLO0FBQUEsTUFDWDtBQUFBLE1BQ0EsT0FBTyxLQUFLLGtCQUFrQixPQUFPO0FBQUEsSUFDdkMsQ0FBQztBQUFBLEVBQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS0EsZ0JBQWdCLFNBQVM7QUFDdkIsVUFBTSxhQUFhLENBQUM7QUFDcEIsV0FBTyxLQUFLLEtBQUssVUFBVSxFQUFFLEdBQUc7QUFDOUIsaUJBQVcsS0FBSyxLQUFLLGVBQWUsT0FBTyxDQUFDO0FBQUEsSUFDOUM7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0EsdUJBQXVCO0FBQ3JCLFdBQU8sS0FBSyxnQkFBZ0IsSUFBSTtBQUFBLEVBQ2xDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsZUFBZSxTQUFTO0FBQ3RCLFVBQU0sUUFBUSxLQUFLLE9BQU87QUFDMUIsU0FBSyxZQUFZLFVBQVUsRUFBRTtBQUM3QixXQUFPLEtBQUssS0FBSyxPQUFPO0FBQUEsTUFDdEIsTUFBTSxLQUFLO0FBQUEsTUFDWCxNQUFNLEtBQUssVUFBVTtBQUFBLE1BQ3JCLFdBQVcsS0FBSyxlQUFlLE9BQU87QUFBQSxJQUN4QyxDQUFDO0FBQUEsRUFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFRQSxxQkFBcUI7QUFDbkIsVUFBTSxRQUFRLEtBQUssT0FBTztBQUMxQixRQUFJO0FBQ0osUUFBSSxLQUFLLG9CQUFvQixVQUFVLFNBQVMsR0FBRztBQUNqRCxZQUFNLFlBQVksS0FBSyxtQkFBbUI7QUFDMUMsV0FBSyxZQUFZLFVBQVUsU0FBUztBQUNwQyxhQUFPLEtBQUssS0FBSyxPQUFPO0FBQUEsUUFDdEIsTUFBTSxLQUFLO0FBQUEsUUFDWCxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQUEsSUFDSCxPQUFPO0FBQ0wsYUFBTyxLQUFLLGVBQWU7QUFBQSxJQUM3QjtBQUNBLFFBQUksS0FBSyxvQkFBb0IsVUFBVSxJQUFJLEdBQUc7QUFDNUMsYUFBTyxLQUFLLEtBQUssT0FBTztBQUFBLFFBQ3RCLE1BQU0sS0FBSztBQUFBLFFBQ1g7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNIO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLGlCQUFpQjtBQUNmLFdBQU8sS0FBSyxLQUFLLEtBQUssT0FBTyxPQUFPO0FBQUEsTUFDbEMsTUFBTSxLQUFLO0FBQUEsTUFDWCxNQUFNLEtBQUssVUFBVTtBQUFBLElBQ3ZCLENBQUM7QUFBQSxFQUNIO0FBQUE7QUFBQSxFQUVBLGtCQUFrQjtBQUNoQixXQUFPLEtBQUssS0FBSyxVQUFVLE1BQU0sS0FBSyxLQUFLLEtBQUssVUFBVSxZQUFZO0FBQUEsRUFDeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLG1CQUFtQjtBQUNqQixRQUFJLEtBQUssZ0JBQWdCLEdBQUc7QUFDMUIsYUFBTyxLQUFLLG1CQUFtQjtBQUFBLElBQ2pDO0FBQUEsRUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLHdCQUF3QjtBQUN0QixVQUFNLFFBQVEsS0FBSyxPQUFPO0FBQzFCLFVBQU0sY0FBYyxLQUFLLGlCQUFpQjtBQUMxQyxTQUFLLGNBQWMsUUFBUTtBQUMzQixVQUFNLGFBQWEsS0FBSyxxQkFBcUI7QUFDN0MsVUFBTSxpQkFBaUIsS0FBSztBQUFBLE1BQzFCLFVBQVU7QUFBQSxNQUNWLEtBQUs7QUFBQSxNQUNMLFVBQVU7QUFBQSxJQUNaO0FBQ0EsV0FBTyxLQUFLLEtBQUssT0FBTztBQUFBLE1BQ3RCLE1BQU0sS0FBSztBQUFBLE1BQ1g7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLCtCQUErQjtBQUM3QixVQUFNLFFBQVEsS0FBSyxPQUFPO0FBQzFCLFVBQU0sWUFBWSxLQUFLLG1CQUFtQjtBQUMxQyxTQUFLLFlBQVksVUFBVSxLQUFLO0FBQ2hDLFVBQU0sT0FBTyxLQUFLLGVBQWU7QUFDakMsV0FBTyxLQUFLLEtBQUssT0FBTztBQUFBLE1BQ3RCLE1BQU0sS0FBSztBQUFBLE1BQ1g7QUFBQSxNQUNBO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSUEsNEJBQTRCO0FBQzFCLFVBQU0sUUFBUSxLQUFLLE9BQU87QUFDMUIsVUFBTSxjQUFjLEtBQUssaUJBQWlCO0FBQzFDLFNBQUssY0FBYyxRQUFRO0FBQzNCLFVBQU0sT0FBTyxLQUFLLFVBQVU7QUFDNUIsVUFBTSxhQUFhLEtBQUsscUJBQXFCO0FBQzdDLFdBQU8sS0FBSyxLQUFLLE9BQU87QUFBQSxNQUN0QixNQUFNLEtBQUs7QUFBQSxNQUNYO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsNEJBQTRCO0FBQzFCLFVBQU0sUUFBUSxLQUFLLE9BQU87QUFDMUIsVUFBTSxjQUFjLEtBQUssaUJBQWlCO0FBQzFDLFNBQUssY0FBYyxNQUFNO0FBQ3pCLFVBQU0sT0FBTyxLQUFLLFVBQVU7QUFDNUIsVUFBTSxhQUFhLEtBQUssMEJBQTBCO0FBQ2xELFVBQU0sYUFBYSxLQUFLLHFCQUFxQjtBQUM3QyxVQUFNLFNBQVMsS0FBSyxzQkFBc0I7QUFDMUMsV0FBTyxLQUFLLEtBQUssT0FBTztBQUFBLE1BQ3RCLE1BQU0sS0FBSztBQUFBLE1BQ1g7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLDRCQUE0QjtBQUMxQixXQUFPLEtBQUssc0JBQXNCLFlBQVksSUFBSSxLQUFLLGNBQWMsVUFBVSxLQUFLLEtBQUssY0FBYyxJQUFJLENBQUM7QUFBQSxFQUM5RztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLHdCQUF3QjtBQUN0QixXQUFPLEtBQUs7QUFBQSxNQUNWLFVBQVU7QUFBQSxNQUNWLEtBQUs7QUFBQSxNQUNMLFVBQVU7QUFBQSxJQUNaO0FBQUEsRUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLQSx1QkFBdUI7QUFDckIsVUFBTSxRQUFRLEtBQUssT0FBTztBQUMxQixVQUFNLGNBQWMsS0FBSyxpQkFBaUI7QUFDMUMsVUFBTSxPQUFPLEtBQUssVUFBVTtBQUM1QixVQUFNLE9BQU8sS0FBSyxrQkFBa0I7QUFDcEMsU0FBSyxZQUFZLFVBQVUsS0FBSztBQUNoQyxVQUFNLE9BQU8sS0FBSyxtQkFBbUI7QUFDckMsVUFBTSxhQUFhLEtBQUsscUJBQXFCO0FBQzdDLFdBQU8sS0FBSyxLQUFLLE9BQU87QUFBQSxNQUN0QixNQUFNLEtBQUs7QUFBQSxNQUNYO0FBQUEsTUFDQTtBQUFBLE1BQ0EsV0FBVztBQUFBLE1BQ1g7QUFBQSxNQUNBO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSUEsb0JBQW9CO0FBQ2xCLFdBQU8sS0FBSztBQUFBLE1BQ1YsVUFBVTtBQUFBLE1BQ1YsS0FBSztBQUFBLE1BQ0wsVUFBVTtBQUFBLElBQ1o7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUtBLHFCQUFxQjtBQUNuQixVQUFNLFFBQVEsS0FBSyxPQUFPO0FBQzFCLFVBQU0sY0FBYyxLQUFLLGlCQUFpQjtBQUMxQyxVQUFNLE9BQU8sS0FBSyxVQUFVO0FBQzVCLFNBQUssWUFBWSxVQUFVLEtBQUs7QUFDaEMsVUFBTSxPQUFPLEtBQUssbUJBQW1CO0FBQ3JDLFFBQUk7QUFDSixRQUFJLEtBQUssb0JBQW9CLFVBQVUsTUFBTSxHQUFHO0FBQzlDLHFCQUFlLEtBQUssdUJBQXVCO0FBQUEsSUFDN0M7QUFDQSxVQUFNLGFBQWEsS0FBSyxxQkFBcUI7QUFDN0MsV0FBTyxLQUFLLEtBQUssT0FBTztBQUFBLE1BQ3RCLE1BQU0sS0FBSztBQUFBLE1BQ1g7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLQSwrQkFBK0I7QUFDN0IsVUFBTSxRQUFRLEtBQUssT0FBTztBQUMxQixVQUFNLGNBQWMsS0FBSyxpQkFBaUI7QUFDMUMsU0FBSyxjQUFjLFdBQVc7QUFDOUIsVUFBTSxPQUFPLEtBQUssVUFBVTtBQUM1QixVQUFNLGFBQWEsS0FBSywwQkFBMEI7QUFDbEQsVUFBTSxhQUFhLEtBQUsscUJBQXFCO0FBQzdDLFVBQU0sU0FBUyxLQUFLLHNCQUFzQjtBQUMxQyxXQUFPLEtBQUssS0FBSyxPQUFPO0FBQUEsTUFDdEIsTUFBTSxLQUFLO0FBQUEsTUFDWDtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUtBLDJCQUEyQjtBQUN6QixVQUFNLFFBQVEsS0FBSyxPQUFPO0FBQzFCLFVBQU0sY0FBYyxLQUFLLGlCQUFpQjtBQUMxQyxTQUFLLGNBQWMsT0FBTztBQUMxQixVQUFNLE9BQU8sS0FBSyxVQUFVO0FBQzVCLFVBQU0sYUFBYSxLQUFLLHFCQUFxQjtBQUM3QyxVQUFNLFFBQVEsS0FBSyxzQkFBc0I7QUFDekMsV0FBTyxLQUFLLEtBQUssT0FBTztBQUFBLE1BQ3RCLE1BQU0sS0FBSztBQUFBLE1BQ1g7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsd0JBQXdCO0FBQ3RCLFdBQU8sS0FBSyxvQkFBb0IsVUFBVSxNQUFNLElBQUksS0FBSyxjQUFjLFVBQVUsTUFBTSxLQUFLLGNBQWMsSUFBSSxDQUFDO0FBQUEsRUFDakg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS0EsMEJBQTBCO0FBQ3hCLFVBQU0sUUFBUSxLQUFLLE9BQU87QUFDMUIsVUFBTSxjQUFjLEtBQUssaUJBQWlCO0FBQzFDLFNBQUssY0FBYyxNQUFNO0FBQ3pCLFVBQU0sT0FBTyxLQUFLLFVBQVU7QUFDNUIsVUFBTSxhQUFhLEtBQUsscUJBQXFCO0FBQzdDLFVBQU0sU0FBUyxLQUFLLDBCQUEwQjtBQUM5QyxXQUFPLEtBQUssS0FBSyxPQUFPO0FBQUEsTUFDdEIsTUFBTSxLQUFLO0FBQUEsTUFDWDtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSw0QkFBNEI7QUFDMUIsV0FBTyxLQUFLO0FBQUEsTUFDVixVQUFVO0FBQUEsTUFDVixLQUFLO0FBQUEsTUFDTCxVQUFVO0FBQUEsSUFDWjtBQUFBLEVBQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLDJCQUEyQjtBQUN6QixVQUFNLFFBQVEsS0FBSyxPQUFPO0FBQzFCLFVBQU0sY0FBYyxLQUFLLGlCQUFpQjtBQUMxQyxVQUFNLE9BQU8sS0FBSyxtQkFBbUI7QUFDckMsVUFBTSxhQUFhLEtBQUsscUJBQXFCO0FBQzdDLFdBQU8sS0FBSyxLQUFLLE9BQU87QUFBQSxNQUN0QixNQUFNLEtBQUs7QUFBQSxNQUNYO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSxxQkFBcUI7QUFDbkIsUUFBSSxLQUFLLE9BQU8sTUFBTSxVQUFVLFVBQVUsS0FBSyxPQUFPLE1BQU0sVUFBVSxXQUFXLEtBQUssT0FBTyxNQUFNLFVBQVUsUUFBUTtBQUNuSCxZQUFNO0FBQUEsUUFDSixLQUFLLE9BQU87QUFBQSxRQUNaLEtBQUssT0FBTyxNQUFNO0FBQUEsUUFDbEIsR0FBRztBQUFBLFVBQ0QsS0FBSyxPQUFPO0FBQUEsUUFDZCxDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0Y7QUFDQSxXQUFPLEtBQUssVUFBVTtBQUFBLEVBQ3hCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUtBLGlDQUFpQztBQUMvQixVQUFNLFFBQVEsS0FBSyxPQUFPO0FBQzFCLFVBQU0sY0FBYyxLQUFLLGlCQUFpQjtBQUMxQyxTQUFLLGNBQWMsT0FBTztBQUMxQixVQUFNLE9BQU8sS0FBSyxVQUFVO0FBQzVCLFVBQU0sYUFBYSxLQUFLLHFCQUFxQjtBQUM3QyxVQUFNLFNBQVMsS0FBSywyQkFBMkI7QUFDL0MsV0FBTyxLQUFLLEtBQUssT0FBTztBQUFBLE1BQ3RCLE1BQU0sS0FBSztBQUFBLE1BQ1g7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsNkJBQTZCO0FBQzNCLFdBQU8sS0FBSztBQUFBLE1BQ1YsVUFBVTtBQUFBLE1BQ1YsS0FBSztBQUFBLE1BQ0wsVUFBVTtBQUFBLElBQ1o7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWNBLDJCQUEyQjtBQUN6QixVQUFNLGVBQWUsS0FBSyxPQUFPLFVBQVU7QUFDM0MsUUFBSSxhQUFhLFNBQVMsVUFBVSxNQUFNO0FBQ3hDLGNBQVEsYUFBYSxPQUFPO0FBQUEsUUFDMUIsS0FBSztBQUNILGlCQUFPLEtBQUsscUJBQXFCO0FBQUEsUUFDbkMsS0FBSztBQUNILGlCQUFPLEtBQUsseUJBQXlCO0FBQUEsUUFDdkMsS0FBSztBQUNILGlCQUFPLEtBQUsseUJBQXlCO0FBQUEsUUFDdkMsS0FBSztBQUNILGlCQUFPLEtBQUssNEJBQTRCO0FBQUEsUUFDMUMsS0FBSztBQUNILGlCQUFPLEtBQUssd0JBQXdCO0FBQUEsUUFDdEMsS0FBSztBQUNILGlCQUFPLEtBQUssdUJBQXVCO0FBQUEsUUFDckMsS0FBSztBQUNILGlCQUFPLEtBQUssOEJBQThCO0FBQUEsTUFDOUM7QUFBQSxJQUNGO0FBQ0EsVUFBTSxLQUFLLFdBQVcsWUFBWTtBQUFBLEVBQ3BDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVFBLHVCQUF1QjtBQUNyQixVQUFNLFFBQVEsS0FBSyxPQUFPO0FBQzFCLFNBQUssY0FBYyxRQUFRO0FBQzNCLFNBQUssY0FBYyxRQUFRO0FBQzNCLFVBQU0sYUFBYSxLQUFLLHFCQUFxQjtBQUM3QyxVQUFNLGlCQUFpQixLQUFLO0FBQUEsTUFDMUIsVUFBVTtBQUFBLE1BQ1YsS0FBSztBQUFBLE1BQ0wsVUFBVTtBQUFBLElBQ1o7QUFDQSxRQUFJLFdBQVcsV0FBVyxLQUFLLGVBQWUsV0FBVyxHQUFHO0FBQzFELFlBQU0sS0FBSyxXQUFXO0FBQUEsSUFDeEI7QUFDQSxXQUFPLEtBQUssS0FBSyxPQUFPO0FBQUEsTUFDdEIsTUFBTSxLQUFLO0FBQUEsTUFDWDtBQUFBLE1BQ0E7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUtBLDJCQUEyQjtBQUN6QixVQUFNLFFBQVEsS0FBSyxPQUFPO0FBQzFCLFNBQUssY0FBYyxRQUFRO0FBQzNCLFNBQUssY0FBYyxRQUFRO0FBQzNCLFVBQU0sT0FBTyxLQUFLLFVBQVU7QUFDNUIsVUFBTSxhQUFhLEtBQUsscUJBQXFCO0FBQzdDLFFBQUksV0FBVyxXQUFXLEdBQUc7QUFDM0IsWUFBTSxLQUFLLFdBQVc7QUFBQSxJQUN4QjtBQUNBLFdBQU8sS0FBSyxLQUFLLE9BQU87QUFBQSxNQUN0QixNQUFNLEtBQUs7QUFBQSxNQUNYO0FBQUEsTUFDQTtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU9BLDJCQUEyQjtBQUN6QixVQUFNLFFBQVEsS0FBSyxPQUFPO0FBQzFCLFNBQUssY0FBYyxRQUFRO0FBQzNCLFNBQUssY0FBYyxNQUFNO0FBQ3pCLFVBQU0sT0FBTyxLQUFLLFVBQVU7QUFDNUIsVUFBTSxhQUFhLEtBQUssMEJBQTBCO0FBQ2xELFVBQU0sYUFBYSxLQUFLLHFCQUFxQjtBQUM3QyxVQUFNLFNBQVMsS0FBSyxzQkFBc0I7QUFDMUMsUUFBSSxXQUFXLFdBQVcsS0FBSyxXQUFXLFdBQVcsS0FBSyxPQUFPLFdBQVcsR0FBRztBQUM3RSxZQUFNLEtBQUssV0FBVztBQUFBLElBQ3hCO0FBQ0EsV0FBTyxLQUFLLEtBQUssT0FBTztBQUFBLE1BQ3RCLE1BQU0sS0FBSztBQUFBLE1BQ1g7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFPQSw4QkFBOEI7QUFDNUIsVUFBTSxRQUFRLEtBQUssT0FBTztBQUMxQixTQUFLLGNBQWMsUUFBUTtBQUMzQixTQUFLLGNBQWMsV0FBVztBQUM5QixVQUFNLE9BQU8sS0FBSyxVQUFVO0FBQzVCLFVBQU0sYUFBYSxLQUFLLDBCQUEwQjtBQUNsRCxVQUFNLGFBQWEsS0FBSyxxQkFBcUI7QUFDN0MsVUFBTSxTQUFTLEtBQUssc0JBQXNCO0FBQzFDLFFBQUksV0FBVyxXQUFXLEtBQUssV0FBVyxXQUFXLEtBQUssT0FBTyxXQUFXLEdBQUc7QUFDN0UsWUFBTSxLQUFLLFdBQVc7QUFBQSxJQUN4QjtBQUNBLFdBQU8sS0FBSyxLQUFLLE9BQU87QUFBQSxNQUN0QixNQUFNLEtBQUs7QUFBQSxNQUNYO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLDBCQUEwQjtBQUN4QixVQUFNLFFBQVEsS0FBSyxPQUFPO0FBQzFCLFNBQUssY0FBYyxRQUFRO0FBQzNCLFNBQUssY0FBYyxPQUFPO0FBQzFCLFVBQU0sT0FBTyxLQUFLLFVBQVU7QUFDNUIsVUFBTSxhQUFhLEtBQUsscUJBQXFCO0FBQzdDLFVBQU0sUUFBUSxLQUFLLHNCQUFzQjtBQUN6QyxRQUFJLFdBQVcsV0FBVyxLQUFLLE1BQU0sV0FBVyxHQUFHO0FBQ2pELFlBQU0sS0FBSyxXQUFXO0FBQUEsSUFDeEI7QUFDQSxXQUFPLEtBQUssS0FBSyxPQUFPO0FBQUEsTUFDdEIsTUFBTSxLQUFLO0FBQUEsTUFDWDtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLHlCQUF5QjtBQUN2QixVQUFNLFFBQVEsS0FBSyxPQUFPO0FBQzFCLFNBQUssY0FBYyxRQUFRO0FBQzNCLFNBQUssY0FBYyxNQUFNO0FBQ3pCLFVBQU0sT0FBTyxLQUFLLFVBQVU7QUFDNUIsVUFBTSxhQUFhLEtBQUsscUJBQXFCO0FBQzdDLFVBQU0sU0FBUyxLQUFLLDBCQUEwQjtBQUM5QyxRQUFJLFdBQVcsV0FBVyxLQUFLLE9BQU8sV0FBVyxHQUFHO0FBQ2xELFlBQU0sS0FBSyxXQUFXO0FBQUEsSUFDeEI7QUFDQSxXQUFPLEtBQUssS0FBSyxPQUFPO0FBQUEsTUFDdEIsTUFBTSxLQUFLO0FBQUEsTUFDWDtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLGdDQUFnQztBQUM5QixVQUFNLFFBQVEsS0FBSyxPQUFPO0FBQzFCLFNBQUssY0FBYyxRQUFRO0FBQzNCLFNBQUssY0FBYyxPQUFPO0FBQzFCLFVBQU0sT0FBTyxLQUFLLFVBQVU7QUFDNUIsVUFBTSxhQUFhLEtBQUsscUJBQXFCO0FBQzdDLFVBQU0sU0FBUyxLQUFLLDJCQUEyQjtBQUMvQyxRQUFJLFdBQVcsV0FBVyxLQUFLLE9BQU8sV0FBVyxHQUFHO0FBQ2xELFlBQU0sS0FBSyxXQUFXO0FBQUEsSUFDeEI7QUFDQSxXQUFPLEtBQUssS0FBSyxPQUFPO0FBQUEsTUFDdEIsTUFBTSxLQUFLO0FBQUEsTUFDWDtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT0EsMkJBQTJCO0FBQ3pCLFVBQU0sUUFBUSxLQUFLLE9BQU87QUFDMUIsVUFBTSxjQUFjLEtBQUssaUJBQWlCO0FBQzFDLFNBQUssY0FBYyxXQUFXO0FBQzlCLFNBQUssWUFBWSxVQUFVLEVBQUU7QUFDN0IsVUFBTSxPQUFPLEtBQUssVUFBVTtBQUM1QixVQUFNLE9BQU8sS0FBSyxrQkFBa0I7QUFDcEMsVUFBTSxhQUFhLEtBQUssc0JBQXNCLFlBQVk7QUFDMUQsU0FBSyxjQUFjLElBQUk7QUFDdkIsVUFBTSxZQUFZLEtBQUssd0JBQXdCO0FBQy9DLFdBQU8sS0FBSyxLQUFLLE9BQU87QUFBQSxNQUN0QixNQUFNLEtBQUs7QUFBQSxNQUNYO0FBQUEsTUFDQTtBQUFBLE1BQ0EsV0FBVztBQUFBLE1BQ1g7QUFBQSxNQUNBO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLDBCQUEwQjtBQUN4QixXQUFPLEtBQUssY0FBYyxVQUFVLE1BQU0sS0FBSyxzQkFBc0I7QUFBQSxFQUN2RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBNEJBLHlCQUF5QjtBQUN2QixVQUFNLFFBQVEsS0FBSyxPQUFPO0FBQzFCLFVBQU0sT0FBTyxLQUFLLFVBQVU7QUFDNUIsUUFBSSxPQUFPLFVBQVUsZUFBZSxLQUFLLG1CQUFtQixLQUFLLEtBQUssR0FBRztBQUN2RSxhQUFPO0FBQUEsSUFDVDtBQUNBLFVBQU0sS0FBSyxXQUFXLEtBQUs7QUFBQSxFQUM3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT0EsS0FBSyxZQUFZLE1BQU07QUFDckIsUUFBSSxLQUFLLFNBQVMsZUFBZSxNQUFNO0FBQ3JDLFdBQUssTUFBTSxJQUFJO0FBQUEsUUFDYjtBQUFBLFFBQ0EsS0FBSyxPQUFPO0FBQUEsUUFDWixLQUFLLE9BQU87QUFBQSxNQUNkO0FBQUEsSUFDRjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSxLQUFLLE1BQU07QUFDVCxXQUFPLEtBQUssT0FBTyxNQUFNLFNBQVM7QUFBQSxFQUNwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLQSxZQUFZLE1BQU07QUFDaEIsVUFBTSxRQUFRLEtBQUssT0FBTztBQUMxQixRQUFJLE1BQU0sU0FBUyxNQUFNO0FBQ3ZCLFdBQUssYUFBYTtBQUNsQixhQUFPO0FBQUEsSUFDVDtBQUNBLFVBQU07QUFBQSxNQUNKLEtBQUssT0FBTztBQUFBLE1BQ1osTUFBTTtBQUFBLE1BQ04sWUFBWSxpQkFBaUIsSUFBSSxDQUFDLFdBQVcsYUFBYSxLQUFLLENBQUM7QUFBQSxJQUNsRTtBQUFBLEVBQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS0Esb0JBQW9CLE1BQU07QUFDeEIsVUFBTSxRQUFRLEtBQUssT0FBTztBQUMxQixRQUFJLE1BQU0sU0FBUyxNQUFNO0FBQ3ZCLFdBQUssYUFBYTtBQUNsQixhQUFPO0FBQUEsSUFDVDtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUtBLGNBQWMsT0FBTztBQUNuQixVQUFNLFFBQVEsS0FBSyxPQUFPO0FBQzFCLFFBQUksTUFBTSxTQUFTLFVBQVUsUUFBUSxNQUFNLFVBQVUsT0FBTztBQUMxRCxXQUFLLGFBQWE7QUFBQSxJQUNwQixPQUFPO0FBQ0wsWUFBTTtBQUFBLFFBQ0osS0FBSyxPQUFPO0FBQUEsUUFDWixNQUFNO0FBQUEsUUFDTixhQUFhLEtBQUssWUFBWSxhQUFhLEtBQUssQ0FBQztBQUFBLE1BQ25EO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS0Esc0JBQXNCLE9BQU87QUFDM0IsVUFBTSxRQUFRLEtBQUssT0FBTztBQUMxQixRQUFJLE1BQU0sU0FBUyxVQUFVLFFBQVEsTUFBTSxVQUFVLE9BQU87QUFDMUQsV0FBSyxhQUFhO0FBQ2xCLGFBQU87QUFBQSxJQUNUO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLFdBQVcsU0FBUztBQUNsQixVQUFNLFFBQVEsWUFBWSxRQUFRLFlBQVksU0FBUyxVQUFVLEtBQUssT0FBTztBQUM3RSxXQUFPO0FBQUEsTUFDTCxLQUFLLE9BQU87QUFBQSxNQUNaLE1BQU07QUFBQSxNQUNOLGNBQWMsYUFBYSxLQUFLLENBQUM7QUFBQSxJQUNuQztBQUFBLEVBQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSxJQUFJLFVBQVUsU0FBUyxXQUFXO0FBQ2hDLFNBQUssWUFBWSxRQUFRO0FBQ3pCLFVBQU0sUUFBUSxDQUFDO0FBQ2YsV0FBTyxDQUFDLEtBQUssb0JBQW9CLFNBQVMsR0FBRztBQUMzQyxZQUFNLEtBQUssUUFBUSxLQUFLLElBQUksQ0FBQztBQUFBLElBQy9CO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU9BLGFBQWEsVUFBVSxTQUFTLFdBQVc7QUFDekMsUUFBSSxLQUFLLG9CQUFvQixRQUFRLEdBQUc7QUFDdEMsWUFBTSxRQUFRLENBQUM7QUFDZixTQUFHO0FBQ0QsY0FBTSxLQUFLLFFBQVEsS0FBSyxJQUFJLENBQUM7QUFBQSxNQUMvQixTQUFTLENBQUMsS0FBSyxvQkFBb0IsU0FBUztBQUM1QyxhQUFPO0FBQUEsSUFDVDtBQUNBLFdBQU8sQ0FBQztBQUFBLEVBQ1Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSxLQUFLLFVBQVUsU0FBUyxXQUFXO0FBQ2pDLFNBQUssWUFBWSxRQUFRO0FBQ3pCLFVBQU0sUUFBUSxDQUFDO0FBQ2YsT0FBRztBQUNELFlBQU0sS0FBSyxRQUFRLEtBQUssSUFBSSxDQUFDO0FBQUEsSUFDL0IsU0FBUyxDQUFDLEtBQUssb0JBQW9CLFNBQVM7QUFDNUMsV0FBTztBQUFBLEVBQ1Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSxjQUFjLGVBQWUsU0FBUztBQUNwQyxTQUFLLG9CQUFvQixhQUFhO0FBQ3RDLFVBQU0sUUFBUSxDQUFDO0FBQ2YsT0FBRztBQUNELFlBQU0sS0FBSyxRQUFRLEtBQUssSUFBSSxDQUFDO0FBQUEsSUFDL0IsU0FBUyxLQUFLLG9CQUFvQixhQUFhO0FBQy9DLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFDQSxlQUFlO0FBQ2IsVUFBTSxFQUFFLFVBQVUsSUFBSSxLQUFLO0FBQzNCLFVBQU0sUUFBUSxLQUFLLE9BQU8sUUFBUTtBQUNsQyxRQUFJLGNBQWMsVUFBVSxNQUFNLFNBQVMsVUFBVSxLQUFLO0FBQ3hELFFBQUUsS0FBSztBQUNQLFVBQUksS0FBSyxnQkFBZ0IsV0FBVztBQUNsQyxjQUFNO0FBQUEsVUFDSixLQUFLLE9BQU87QUFBQSxVQUNaLE1BQU07QUFBQSxVQUNOLCtCQUErQixTQUFTO0FBQUEsUUFDMUM7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUNBLFNBQVMsYUFBYSxPQUFPO0FBQzNCLFFBQU0sUUFBUSxNQUFNO0FBQ3BCLFNBQU8saUJBQWlCLE1BQU0sSUFBSSxLQUFLLFNBQVMsT0FBTyxLQUFLLEtBQUssTUFBTTtBQUN6RTtBQUNBLFNBQVMsaUJBQWlCLE1BQU07QUFDOUIsU0FBTyxzQkFBc0IsSUFBSSxJQUFJLElBQUksSUFBSSxNQUFNO0FBQ3JEO0FBR0EsSUFBSSxrQkFBa0I7QUFDdEIsU0FBUyxXQUFXLFVBQVUsV0FBVztBQUN2QyxRQUFNLENBQUMsWUFBWSxjQUFjLElBQUksWUFBWSxDQUFDLFVBQVUsU0FBUyxJQUFJLENBQUMsUUFBUSxRQUFRO0FBQzFGLE1BQUksV0FBVztBQUNmLE1BQUksWUFBWTtBQUNkLGdCQUFZLGFBQWE7QUFBQSxFQUMzQjtBQUNBLFFBQU0sY0FBYyxlQUFlLElBQUksQ0FBQyxNQUFNLElBQUksQ0FBQyxHQUFHO0FBQ3RELFVBQVEsWUFBWSxRQUFRO0FBQUEsSUFDMUIsS0FBSztBQUNILGFBQU87QUFBQSxJQUNULEtBQUs7QUFDSCxhQUFPLFdBQVcsWUFBWSxDQUFDLElBQUk7QUFBQSxJQUNyQyxLQUFLO0FBQ0gsYUFBTyxXQUFXLFlBQVksQ0FBQyxJQUFJLFNBQVMsWUFBWSxDQUFDLElBQUk7QUFBQSxFQUNqRTtBQUNBLFFBQU0sV0FBVyxZQUFZLE1BQU0sR0FBRyxlQUFlO0FBQ3JELFFBQU0sV0FBVyxTQUFTLElBQUk7QUFDOUIsU0FBTyxXQUFXLFNBQVMsS0FBSyxJQUFJLElBQUksVUFBVSxXQUFXO0FBQy9EO0FBR0EsU0FBUyxhQUFhLEdBQUc7QUFDdkIsU0FBTztBQUNUO0FBR0EsU0FBUyxPQUFPLE1BQU0sT0FBTztBQUMzQixRQUFNLFNBQXlCLHVCQUFPLE9BQU8sSUFBSTtBQUNqRCxhQUFXLFFBQVEsTUFBTTtBQUN2QixXQUFPLE1BQU0sSUFBSSxDQUFDLElBQUk7QUFBQSxFQUN4QjtBQUNBLFNBQU87QUFDVDtBQUdBLFNBQVMsVUFBVSxNQUFNLE9BQU8sT0FBTztBQUNyQyxRQUFNLFNBQXlCLHVCQUFPLE9BQU8sSUFBSTtBQUNqRCxhQUFXLFFBQVEsTUFBTTtBQUN2QixXQUFPLE1BQU0sSUFBSSxDQUFDLElBQUksTUFBTSxJQUFJO0FBQUEsRUFDbEM7QUFDQSxTQUFPO0FBQ1Q7QUFHQSxTQUFTLFNBQVMsS0FBSyxJQUFJO0FBQ3pCLFFBQU0sU0FBeUIsdUJBQU8sT0FBTyxJQUFJO0FBQ2pELGFBQVcsT0FBTyxPQUFPLEtBQUssR0FBRyxHQUFHO0FBQ2xDLFdBQU8sR0FBRyxJQUFJLEdBQUcsSUFBSSxHQUFHLEdBQUcsR0FBRztBQUFBLEVBQ2hDO0FBQ0EsU0FBTztBQUNUO0FBR0EsU0FBUyxlQUFlLE1BQU0sTUFBTTtBQUNsQyxNQUFJLFNBQVM7QUFDYixNQUFJLFNBQVM7QUFDYixTQUFPLFNBQVMsS0FBSyxVQUFVLFNBQVMsS0FBSyxRQUFRO0FBQ25ELFFBQUksUUFBUSxLQUFLLFdBQVcsTUFBTTtBQUNsQyxRQUFJLFFBQVEsS0FBSyxXQUFXLE1BQU07QUFDbEMsUUFBSSxTQUFTLEtBQUssS0FBSyxTQUFTLEtBQUssR0FBRztBQUN0QyxVQUFJLE9BQU87QUFDWCxTQUFHO0FBQ0QsVUFBRTtBQUNGLGVBQU8sT0FBTyxLQUFLLFFBQVE7QUFDM0IsZ0JBQVEsS0FBSyxXQUFXLE1BQU07QUFBQSxNQUNoQyxTQUFTLFNBQVMsS0FBSyxLQUFLLE9BQU87QUFDbkMsVUFBSSxPQUFPO0FBQ1gsU0FBRztBQUNELFVBQUU7QUFDRixlQUFPLE9BQU8sS0FBSyxRQUFRO0FBQzNCLGdCQUFRLEtBQUssV0FBVyxNQUFNO0FBQUEsTUFDaEMsU0FBUyxTQUFTLEtBQUssS0FBSyxPQUFPO0FBQ25DLFVBQUksT0FBTyxNQUFNO0FBQ2YsZUFBTztBQUFBLE1BQ1Q7QUFDQSxVQUFJLE9BQU8sTUFBTTtBQUNmLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRixPQUFPO0FBQ0wsVUFBSSxRQUFRLE9BQU87QUFDakIsZUFBTztBQUFBLE1BQ1Q7QUFDQSxVQUFJLFFBQVEsT0FBTztBQUNqQixlQUFPO0FBQUEsTUFDVDtBQUNBLFFBQUU7QUFDRixRQUFFO0FBQUEsSUFDSjtBQUFBLEVBQ0Y7QUFDQSxTQUFPLEtBQUssU0FBUyxLQUFLO0FBQzVCO0FBQ0EsSUFBSSxVQUFVO0FBQ2QsSUFBSSxVQUFVO0FBQ2QsU0FBUyxTQUFTLE1BQU07QUFDdEIsU0FBTyxDQUFDLE1BQU0sSUFBSSxLQUFLLFdBQVcsUUFBUSxRQUFRO0FBQ3BEO0FBR0EsU0FBUyxlQUFlLE9BQU8sU0FBUztBQUN0QyxRQUFNLG9CQUFvQyx1QkFBTyxPQUFPLElBQUk7QUFDNUQsUUFBTSxrQkFBa0IsSUFBSSxnQkFBZ0IsS0FBSztBQUNqRCxRQUFNLFlBQVksS0FBSyxNQUFNLE1BQU0sU0FBUyxHQUFHLElBQUk7QUFDbkQsYUFBVyxVQUFVLFNBQVM7QUFDNUIsVUFBTSxXQUFXLGdCQUFnQixRQUFRLFFBQVEsU0FBUztBQUMxRCxRQUFJLGFBQWEsUUFBUTtBQUN2Qix3QkFBa0IsTUFBTSxJQUFJO0FBQUEsSUFDOUI7QUFBQSxFQUNGO0FBQ0EsU0FBTyxPQUFPLEtBQUssaUJBQWlCLEVBQUUsS0FBSyxDQUFDLEdBQUcsTUFBTTtBQUNuRCxVQUFNLGVBQWUsa0JBQWtCLENBQUMsSUFBSSxrQkFBa0IsQ0FBQztBQUMvRCxXQUFPLGlCQUFpQixJQUFJLGVBQWUsZUFBZSxHQUFHLENBQUM7QUFBQSxFQUNoRSxDQUFDO0FBQ0g7QUFDQSxJQUFJLGtCQUFrQixNQUFNO0FBQUEsRUFDMUIsWUFBWSxPQUFPO0FBQ2pCLFNBQUssU0FBUztBQUNkLFNBQUssa0JBQWtCLE1BQU0sWUFBWTtBQUN6QyxTQUFLLGNBQWMsY0FBYyxLQUFLLGVBQWU7QUFDckQsU0FBSyxRQUFRO0FBQUEsTUFDWCxJQUFJLE1BQU0sTUFBTSxTQUFTLENBQUMsRUFBRSxLQUFLLENBQUM7QUFBQSxNQUNsQyxJQUFJLE1BQU0sTUFBTSxTQUFTLENBQUMsRUFBRSxLQUFLLENBQUM7QUFBQSxNQUNsQyxJQUFJLE1BQU0sTUFBTSxTQUFTLENBQUMsRUFBRSxLQUFLLENBQUM7QUFBQSxJQUNwQztBQUFBLEVBQ0Y7QUFBQSxFQUNBLFFBQVEsUUFBUSxXQUFXO0FBQ3pCLFFBQUksS0FBSyxXQUFXLFFBQVE7QUFDMUIsYUFBTztBQUFBLElBQ1Q7QUFDQSxVQUFNLGtCQUFrQixPQUFPLFlBQVk7QUFDM0MsUUFBSSxLQUFLLG9CQUFvQixpQkFBaUI7QUFDNUMsYUFBTztBQUFBLElBQ1Q7QUFDQSxRQUFJLElBQUksY0FBYyxlQUFlO0FBQ3JDLFFBQUksSUFBSSxLQUFLO0FBQ2IsUUFBSSxFQUFFLFNBQVMsRUFBRSxRQUFRO0FBQ3ZCLFlBQU0sTUFBTTtBQUNaLFVBQUk7QUFDSixVQUFJO0FBQUEsSUFDTjtBQUNBLFVBQU0sVUFBVSxFQUFFO0FBQ2xCLFVBQU0sVUFBVSxFQUFFO0FBQ2xCLFFBQUksVUFBVSxVQUFVLFdBQVc7QUFDakMsYUFBTztBQUFBLElBQ1Q7QUFDQSxVQUFNLE9BQU8sS0FBSztBQUNsQixhQUFTLElBQUksR0FBRyxLQUFLLFNBQVMsS0FBSztBQUNqQyxXQUFLLENBQUMsRUFBRSxDQUFDLElBQUk7QUFBQSxJQUNmO0FBQ0EsYUFBUyxJQUFJLEdBQUcsS0FBSyxTQUFTLEtBQUs7QUFDakMsWUFBTSxRQUFRLE1BQU0sSUFBSSxLQUFLLENBQUM7QUFDOUIsWUFBTSxhQUFhLEtBQUssSUFBSSxDQUFDO0FBQzdCLFVBQUksZUFBZSxXQUFXLENBQUMsSUFBSTtBQUNuQyxlQUFTLElBQUksR0FBRyxLQUFLLFNBQVMsS0FBSztBQUNqQyxjQUFNLE9BQU8sRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxJQUFJLElBQUk7QUFDekMsWUFBSSxjQUFjLEtBQUs7QUFBQSxVQUNyQixNQUFNLENBQUMsSUFBSTtBQUFBO0FBQUEsVUFFWCxXQUFXLElBQUksQ0FBQyxJQUFJO0FBQUE7QUFBQSxVQUVwQixNQUFNLElBQUksQ0FBQyxJQUFJO0FBQUE7QUFBQSxRQUVqQjtBQUNBLFlBQUksSUFBSSxLQUFLLElBQUksS0FBSyxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxHQUFHO0FBQ3BFLGdCQUFNLHFCQUFxQixNQUFNLElBQUksS0FBSyxDQUFDLEVBQUUsSUFBSSxDQUFDO0FBQ2xELHdCQUFjLEtBQUssSUFBSSxhQUFhLHFCQUFxQixDQUFDO0FBQUEsUUFDNUQ7QUFDQSxZQUFJLGNBQWMsY0FBYztBQUM5Qix5QkFBZTtBQUFBLFFBQ2pCO0FBQ0EsbUJBQVcsQ0FBQyxJQUFJO0FBQUEsTUFDbEI7QUFDQSxVQUFJLGVBQWUsV0FBVztBQUM1QixlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFDQSxVQUFNLFdBQVcsS0FBSyxVQUFVLENBQUMsRUFBRSxPQUFPO0FBQzFDLFdBQU8sWUFBWSxZQUFZLFdBQVc7QUFBQSxFQUM1QztBQUNGO0FBQ0EsU0FBUyxjQUFjLEtBQUs7QUFDMUIsUUFBTSxZQUFZLElBQUk7QUFDdEIsUUFBTSxRQUFRLElBQUksTUFBTSxTQUFTO0FBQ2pDLFdBQVMsSUFBSSxHQUFHLElBQUksV0FBVyxFQUFFLEdBQUc7QUFDbEMsVUFBTSxDQUFDLElBQUksSUFBSSxXQUFXLENBQUM7QUFBQSxFQUM3QjtBQUNBLFNBQU87QUFDVDtBQUdBLFNBQVMsU0FBUyxLQUFLO0FBQ3JCLE1BQUksT0FBTyxNQUFNO0FBQ2YsV0FBdUIsdUJBQU8sT0FBTyxJQUFJO0FBQUEsRUFDM0M7QUFDQSxNQUFJLE9BQU8sZUFBZSxHQUFHLE1BQU0sTUFBTTtBQUN2QyxXQUFPO0FBQUEsRUFDVDtBQUNBLFFBQU0sTUFBc0IsdUJBQU8sT0FBTyxJQUFJO0FBQzlDLGFBQVcsQ0FBQyxLQUFLLEtBQUssS0FBSyxPQUFPLFFBQVEsR0FBRyxHQUFHO0FBQzlDLFFBQUksR0FBRyxJQUFJO0FBQUEsRUFDYjtBQUNBLFNBQU87QUFDVDtBQUdBLFNBQVMsWUFBWSxLQUFLO0FBQ3hCLFNBQU8sSUFBSSxJQUFJLFFBQVEsZUFBZSxlQUFlLENBQUM7QUFDeEQ7QUFDQSxJQUFJLGdCQUFnQjtBQUNwQixTQUFTLGdCQUFnQixLQUFLO0FBQzVCLFNBQU8sZ0JBQWdCLElBQUksV0FBVyxDQUFDLENBQUM7QUFDMUM7QUFDQSxJQUFJLGtCQUFrQjtBQUFBLEVBQ3BCO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQTtBQUFBLEVBRUE7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQTtBQUFBLEVBRUE7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQTtBQUFBLEVBRUE7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQTtBQUFBLEVBRUE7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQTtBQUFBLEVBRUE7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUNGO0FBR0EsSUFBSSxRQUFRLE9BQU8sT0FBTyxDQUFDLENBQUM7QUFDNUIsU0FBUyxNQUFNLE1BQU0sU0FBUyxjQUFjLG1CQUFtQjtBQUM3RCxRQUFNLGdCQUFnQyxvQkFBSSxJQUFJO0FBQzlDLGFBQVcsUUFBUSxPQUFPLE9BQU8sSUFBSSxHQUFHO0FBQ3RDLGtCQUFjLElBQUksTUFBTSxxQkFBcUIsU0FBUyxJQUFJLENBQUM7QUFBQSxFQUM3RDtBQUNBLE1BQUksUUFBUTtBQUNaLE1BQUksVUFBVSxNQUFNLFFBQVEsSUFBSTtBQUNoQyxNQUFJLE9BQU8sQ0FBQyxJQUFJO0FBQ2hCLE1BQUksUUFBUTtBQUNaLE1BQUksUUFBUSxDQUFDO0FBQ2IsTUFBSSxPQUFPO0FBQ1gsTUFBSSxNQUFNO0FBQ1YsTUFBSSxTQUFTO0FBQ2IsUUFBTSxPQUFPLENBQUM7QUFDZCxRQUFNLFlBQVksQ0FBQztBQUNuQixLQUFHO0FBQ0Q7QUFDQSxVQUFNLFlBQVksVUFBVSxLQUFLO0FBQ2pDLFVBQU0sV0FBVyxhQUFhLE1BQU0sV0FBVztBQUMvQyxRQUFJLFdBQVc7QUFDYixZQUFNLFVBQVUsV0FBVyxJQUFJLFNBQVMsS0FBSyxLQUFLLFNBQVMsQ0FBQztBQUM1RCxhQUFPO0FBQ1AsZUFBUyxVQUFVLElBQUk7QUFDdkIsVUFBSSxVQUFVO0FBQ1osWUFBSSxTQUFTO0FBQ1gsaUJBQU8sS0FBSyxNQUFNO0FBQ2xCLGNBQUksYUFBYTtBQUNqQixxQkFBVyxDQUFDLFNBQVMsU0FBUyxLQUFLLE9BQU87QUFDeEMsa0JBQU0sV0FBVyxVQUFVO0FBQzNCLGdCQUFJLGNBQWMsTUFBTTtBQUN0QixtQkFBSyxPQUFPLFVBQVUsQ0FBQztBQUN2QjtBQUFBLFlBQ0YsT0FBTztBQUNMLG1CQUFLLFFBQVEsSUFBSTtBQUFBLFlBQ25CO0FBQUEsVUFDRjtBQUFBLFFBQ0YsT0FBTztBQUNMLGlCQUFPLE9BQU87QUFBQSxZQUNaLENBQUM7QUFBQSxZQUNELE9BQU8sMEJBQTBCLElBQUk7QUFBQSxVQUN2QztBQUNBLHFCQUFXLENBQUMsU0FBUyxTQUFTLEtBQUssT0FBTztBQUN4QyxpQkFBSyxPQUFPLElBQUk7QUFBQSxVQUNsQjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQ0EsY0FBUSxNQUFNO0FBQ2QsYUFBTyxNQUFNO0FBQ2IsY0FBUSxNQUFNO0FBQ2QsZ0JBQVUsTUFBTTtBQUNoQixjQUFRLE1BQU07QUFBQSxJQUNoQixXQUFXLFFBQVE7QUFDakIsWUFBTSxVQUFVLFFBQVEsS0FBSyxLQUFLO0FBQ2xDLGFBQU8sT0FBTyxHQUFHO0FBQ2pCLFVBQUksU0FBUyxRQUFRLFNBQVMsUUFBUTtBQUNwQztBQUFBLE1BQ0Y7QUFDQSxXQUFLLEtBQUssR0FBRztBQUFBLElBQ2Y7QUFDQSxRQUFJO0FBQ0osUUFBSSxDQUFDLE1BQU0sUUFBUSxJQUFJLEdBQUc7QUFDeEIsVUFBSSxvQkFBb0I7QUFDeEIsYUFBTyxJQUFJLEtBQUssVUFBVSxPQUFPLHFCQUFxQixRQUFRLElBQUksQ0FBQyxHQUFHO0FBQ3RFLFlBQU0sVUFBVSxhQUFhLHFCQUFxQixjQUFjLElBQUksS0FBSyxJQUFJLE9BQU8sUUFBUSx1QkFBdUIsU0FBUyxTQUFTLG1CQUFtQixTQUFTLHNCQUFzQixjQUFjLElBQUksS0FBSyxJQUFJLE9BQU8sUUFBUSx3QkFBd0IsU0FBUyxTQUFTLG9CQUFvQjtBQUMvUixlQUFTLFlBQVksUUFBUSxZQUFZLFNBQVMsU0FBUyxRQUFRLEtBQUssU0FBUyxNQUFNLEtBQUssUUFBUSxNQUFNLFNBQVM7QUFDbkgsVUFBSSxXQUFXLE9BQU87QUFDcEI7QUFBQSxNQUNGO0FBQ0EsVUFBSSxXQUFXLE9BQU87QUFDcEIsWUFBSSxDQUFDLFdBQVc7QUFDZCxlQUFLLElBQUk7QUFDVDtBQUFBLFFBQ0Y7QUFBQSxNQUNGLFdBQVcsV0FBVyxRQUFRO0FBQzVCLGNBQU0sS0FBSyxDQUFDLEtBQUssTUFBTSxDQUFDO0FBQ3hCLFlBQUksQ0FBQyxXQUFXO0FBQ2QsY0FBSSxPQUFPLE1BQU0sR0FBRztBQUNsQixtQkFBTztBQUFBLFVBQ1QsT0FBTztBQUNMLGlCQUFLLElBQUk7QUFDVDtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSxRQUFJLFdBQVcsVUFBVSxVQUFVO0FBQ2pDLFlBQU0sS0FBSyxDQUFDLEtBQUssSUFBSSxDQUFDO0FBQUEsSUFDeEI7QUFDQSxRQUFJLFdBQVc7QUFDYixXQUFLLElBQUk7QUFBQSxJQUNYLE9BQU87QUFDTCxVQUFJO0FBQ0osY0FBUTtBQUFBLFFBQ047QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBLE1BQU07QUFBQSxNQUNSO0FBQ0EsZ0JBQVUsTUFBTSxRQUFRLElBQUk7QUFDNUIsYUFBTyxVQUFVLFFBQVEsYUFBYSxZQUFZLEtBQUssSUFBSSxPQUFPLFFBQVEsZUFBZSxTQUFTLGFBQWEsQ0FBQztBQUNoSCxjQUFRO0FBQ1IsY0FBUSxDQUFDO0FBQ1QsVUFBSSxRQUFRO0FBQ1Ysa0JBQVUsS0FBSyxNQUFNO0FBQUEsTUFDdkI7QUFDQSxlQUFTO0FBQUEsSUFDWDtBQUFBLEVBQ0YsU0FBUyxVQUFVO0FBQ25CLE1BQUksTUFBTSxXQUFXLEdBQUc7QUFDdEIsV0FBTyxNQUFNLE1BQU0sU0FBUyxDQUFDLEVBQUUsQ0FBQztBQUFBLEVBQ2xDO0FBQ0EsU0FBTztBQUNUO0FBQ0EsU0FBUyxxQkFBcUIsU0FBUyxNQUFNO0FBQzNDLFFBQU0sY0FBYyxRQUFRLElBQUk7QUFDaEMsTUFBSSxPQUFPLGdCQUFnQixVQUFVO0FBQ25DLFdBQU87QUFBQSxFQUNULFdBQVcsT0FBTyxnQkFBZ0IsWUFBWTtBQUM1QyxXQUFPO0FBQUEsTUFDTCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQUEsSUFDTCxPQUFPLFFBQVE7QUFBQSxJQUNmLE9BQU8sUUFBUTtBQUFBLEVBQ2pCO0FBQ0Y7QUFHQSxTQUFTLE1BQU0sS0FBSztBQUNsQixTQUFPLE1BQU0sS0FBSyxrQkFBa0I7QUFDdEM7QUFDQSxJQUFJLGtCQUFrQjtBQUN0QixJQUFJLHFCQUFxQjtBQUFBLEVBQ3ZCLE1BQU07QUFBQSxJQUNKLE9BQU8sQ0FBQyxTQUFTLEtBQUs7QUFBQSxFQUN4QjtBQUFBLEVBQ0EsVUFBVTtBQUFBLElBQ1IsT0FBTyxDQUFDLFNBQVMsTUFBTSxLQUFLO0FBQUEsRUFDOUI7QUFBQTtBQUFBLEVBRUEsVUFBVTtBQUFBLElBQ1IsT0FBTyxDQUFDLFNBQVMsS0FBSyxLQUFLLGFBQWEsTUFBTTtBQUFBLEVBQ2hEO0FBQUEsRUFDQSxxQkFBcUI7QUFBQSxJQUNuQixNQUFNLE1BQU07QUFDVixZQUFNLFVBQVUsS0FBSyxLQUFLLEtBQUssS0FBSyxxQkFBcUIsSUFBSSxHQUFHLEdBQUc7QUFDbkUsWUFBTSxTQUFTO0FBQUEsUUFDYjtBQUFBLFVBQ0UsS0FBSztBQUFBLFVBQ0wsS0FBSyxDQUFDLEtBQUssTUFBTSxPQUFPLENBQUM7QUFBQSxVQUN6QixLQUFLLEtBQUssWUFBWSxHQUFHO0FBQUEsUUFDM0I7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUNBLGNBQVEsV0FBVyxVQUFVLEtBQUssU0FBUyxPQUFPLEtBQUs7QUFBQSxJQUN6RDtBQUFBLEVBQ0Y7QUFBQSxFQUNBLG9CQUFvQjtBQUFBLElBQ2xCLE9BQU8sQ0FBQyxFQUFFLFVBQVUsTUFBTSxjQUFjLFdBQVcsTUFBTSxXQUFXLE9BQU8sT0FBTyxLQUFLLE9BQU8sWUFBWSxJQUFJLEtBQUssS0FBSyxLQUFLLFlBQVksR0FBRyxDQUFDO0FBQUEsRUFDL0k7QUFBQSxFQUNBLGNBQWM7QUFBQSxJQUNaLE9BQU8sQ0FBQyxFQUFFLFdBQVcsTUFBTSxNQUFNLFVBQVU7QUFBQSxFQUM3QztBQUFBLEVBQ0EsT0FBTztBQUFBLElBQ0wsTUFBTSxFQUFFLE9BQU8sTUFBTSxXQUFXLE1BQU0sWUFBWSxhQUFhLEdBQUc7QUFDaEUsWUFBTSxTQUFTLEtBQUssSUFBSSxPQUFPLElBQUksSUFBSTtBQUN2QyxVQUFJLFdBQVcsU0FBUyxLQUFLLEtBQUssS0FBSyxNQUFNLElBQUksR0FBRyxHQUFHO0FBQ3ZELFVBQUksU0FBUyxTQUFTLGlCQUFpQjtBQUNyQyxtQkFBVyxTQUFTLEtBQUssT0FBTyxPQUFPLEtBQUssTUFBTSxJQUFJLENBQUMsR0FBRyxLQUFLO0FBQUEsTUFDakU7QUFDQSxhQUFPLEtBQUssQ0FBQyxVQUFVLEtBQUssWUFBWSxHQUFHLEdBQUcsWUFBWSxHQUFHLEdBQUc7QUFBQSxJQUNsRTtBQUFBLEVBQ0Y7QUFBQSxFQUNBLFVBQVU7QUFBQSxJQUNSLE9BQU8sQ0FBQyxFQUFFLE1BQU0sTUFBTSxNQUFNLE9BQU8sT0FBTztBQUFBLEVBQzVDO0FBQUE7QUFBQSxFQUVBLGdCQUFnQjtBQUFBLElBQ2QsT0FBTyxDQUFDLEVBQUUsTUFBTSxXQUFXLE1BQU0sUUFBUSxPQUFPLEtBQUssS0FBSyxLQUFLLFlBQVksR0FBRyxDQUFDO0FBQUEsRUFDakY7QUFBQSxFQUNBLGdCQUFnQjtBQUFBLElBQ2QsT0FBTyxDQUFDLEVBQUUsZUFBZSxZQUFZLGFBQWEsTUFBTTtBQUFBLE1BQ3REO0FBQUEsUUFDRTtBQUFBLFFBQ0EsS0FBSyxPQUFPLGFBQWE7QUFBQSxRQUN6QixLQUFLLFlBQVksR0FBRztBQUFBLFFBQ3BCO0FBQUEsTUFDRjtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBLEVBQ0Esb0JBQW9CO0FBQUEsSUFDbEIsT0FBTyxDQUFDLEVBQUUsTUFBTSxlQUFlLHFCQUFxQixZQUFZLGFBQWE7QUFBQTtBQUFBLE1BRTNFLFlBQVksSUFBSSxHQUFHLEtBQUssS0FBSyxLQUFLLHFCQUFxQixJQUFJLEdBQUcsR0FBRyxDQUFDLE9BQU8sYUFBYSxJQUFJLEtBQUssSUFBSSxLQUFLLFlBQVksR0FBRyxHQUFHLEdBQUcsQ0FBQyxLQUFLO0FBQUE7QUFBQSxFQUV2STtBQUFBO0FBQUEsRUFFQSxVQUFVO0FBQUEsSUFDUixPQUFPLENBQUMsRUFBRSxNQUFNLE1BQU07QUFBQSxFQUN4QjtBQUFBLEVBQ0EsWUFBWTtBQUFBLElBQ1YsT0FBTyxDQUFDLEVBQUUsTUFBTSxNQUFNO0FBQUEsRUFDeEI7QUFBQSxFQUNBLGFBQWE7QUFBQSxJQUNYLE9BQU8sQ0FBQyxFQUFFLE9BQU8sT0FBTyxjQUFjLE1BQU0sZ0JBQWdCLGlCQUFpQixLQUFLLElBQUksWUFBWSxLQUFLO0FBQUEsRUFDekc7QUFBQSxFQUNBLGNBQWM7QUFBQSxJQUNaLE9BQU8sQ0FBQyxFQUFFLE1BQU0sTUFBTSxRQUFRLFNBQVM7QUFBQSxFQUN6QztBQUFBLEVBQ0EsV0FBVztBQUFBLElBQ1QsT0FBTyxNQUFNO0FBQUEsRUFDZjtBQUFBLEVBQ0EsV0FBVztBQUFBLElBQ1QsT0FBTyxDQUFDLEVBQUUsTUFBTSxNQUFNO0FBQUEsRUFDeEI7QUFBQSxFQUNBLFdBQVc7QUFBQSxJQUNULE9BQU8sQ0FBQyxFQUFFLE9BQU8sTUFBTSxNQUFNLEtBQUssUUFBUSxJQUFJLElBQUk7QUFBQSxFQUNwRDtBQUFBLEVBQ0EsYUFBYTtBQUFBLElBQ1gsT0FBTyxDQUFDLEVBQUUsT0FBTyxNQUFNLE1BQU0sS0FBSyxRQUFRLElBQUksSUFBSTtBQUFBLEVBQ3BEO0FBQUEsRUFDQSxhQUFhO0FBQUEsSUFDWCxPQUFPLENBQUMsRUFBRSxNQUFNLE1BQU0sTUFBTSxPQUFPLE9BQU87QUFBQSxFQUM1QztBQUFBO0FBQUEsRUFFQSxXQUFXO0FBQUEsSUFDVCxPQUFPLENBQUMsRUFBRSxNQUFNLFdBQVcsS0FBSyxNQUFNLE1BQU0sT0FBTyxLQUFLLEtBQUssS0FBSyxNQUFNLElBQUksR0FBRyxHQUFHO0FBQUEsRUFDcEY7QUFBQTtBQUFBLEVBRUEsV0FBVztBQUFBLElBQ1QsT0FBTyxDQUFDLEVBQUUsS0FBSyxNQUFNO0FBQUEsRUFDdkI7QUFBQSxFQUNBLFVBQVU7QUFBQSxJQUNSLE9BQU8sQ0FBQyxFQUFFLEtBQUssTUFBTSxNQUFNLE9BQU87QUFBQSxFQUNwQztBQUFBLEVBQ0EsYUFBYTtBQUFBLElBQ1gsT0FBTyxDQUFDLEVBQUUsS0FBSyxNQUFNLE9BQU87QUFBQSxFQUM5QjtBQUFBO0FBQUEsRUFFQSxrQkFBa0I7QUFBQSxJQUNoQixPQUFPLENBQUMsRUFBRSxhQUFhLFlBQVksZUFBZSxNQUFNLEtBQUssSUFBSSxhQUFhLElBQUksSUFBSSxLQUFLLENBQUMsVUFBVSxLQUFLLFlBQVksR0FBRyxHQUFHLE1BQU0sY0FBYyxDQUFDLEdBQUcsR0FBRztBQUFBLEVBQzFKO0FBQUEsRUFDQSx5QkFBeUI7QUFBQSxJQUN2QixPQUFPLENBQUMsRUFBRSxXQUFXLEtBQUssTUFBTSxZQUFZLE9BQU87QUFBQSxFQUNyRDtBQUFBLEVBQ0Esc0JBQXNCO0FBQUEsSUFDcEIsT0FBTyxDQUFDLEVBQUUsYUFBYSxNQUFNLFdBQVcsTUFBTSxLQUFLLElBQUksYUFBYSxJQUFJLElBQUksS0FBSyxDQUFDLFVBQVUsTUFBTSxLQUFLLFlBQVksR0FBRyxDQUFDLEdBQUcsR0FBRztBQUFBLEVBQy9IO0FBQUEsRUFDQSxzQkFBc0I7QUFBQSxJQUNwQixPQUFPLENBQUMsRUFBRSxhQUFhLE1BQU0sWUFBWSxZQUFZLE9BQU8sTUFBTSxLQUFLLElBQUksYUFBYSxJQUFJLElBQUk7QUFBQSxNQUM5RjtBQUFBLFFBQ0U7QUFBQSxRQUNBO0FBQUEsUUFDQSxLQUFLLGVBQWUsS0FBSyxZQUFZLEtBQUssQ0FBQztBQUFBLFFBQzNDLEtBQUssWUFBWSxHQUFHO0FBQUEsUUFDcEIsTUFBTSxNQUFNO0FBQUEsTUFDZDtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBLEVBQ0EsaUJBQWlCO0FBQUEsSUFDZixPQUFPLENBQUMsRUFBRSxhQUFhLE1BQU0sV0FBVyxNQUFNLE1BQU0sV0FBVyxNQUFNLEtBQUssSUFBSSxhQUFhLElBQUksSUFBSSxRQUFRLGtCQUFrQixJQUFJLElBQUksS0FBSyxPQUFPLE9BQU8sS0FBSyxNQUFNLElBQUksQ0FBQyxHQUFHLEtBQUssSUFBSSxLQUFLLEtBQUssS0FBSyxNQUFNLElBQUksR0FBRyxHQUFHLEtBQUssT0FBTyxPQUFPLEtBQUssS0FBSyxLQUFLLFlBQVksR0FBRyxDQUFDO0FBQUEsRUFDdlE7QUFBQSxFQUNBLHNCQUFzQjtBQUFBLElBQ3BCLE9BQU8sQ0FBQyxFQUFFLGFBQWEsTUFBTSxNQUFNLGNBQWMsV0FBVyxNQUFNLEtBQUssSUFBSSxhQUFhLElBQUksSUFBSTtBQUFBLE1BQzlGLENBQUMsT0FBTyxPQUFPLE1BQU0sS0FBSyxNQUFNLFlBQVksR0FBRyxLQUFLLFlBQVksR0FBRyxDQUFDO0FBQUEsTUFDcEU7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBLEVBQ0EseUJBQXlCO0FBQUEsSUFDdkIsT0FBTyxDQUFDLEVBQUUsYUFBYSxNQUFNLFlBQVksWUFBWSxPQUFPLE1BQU0sS0FBSyxJQUFJLGFBQWEsSUFBSSxJQUFJO0FBQUEsTUFDOUY7QUFBQSxRQUNFO0FBQUEsUUFDQTtBQUFBLFFBQ0EsS0FBSyxlQUFlLEtBQUssWUFBWSxLQUFLLENBQUM7QUFBQSxRQUMzQyxLQUFLLFlBQVksR0FBRztBQUFBLFFBQ3BCLE1BQU0sTUFBTTtBQUFBLE1BQ2Q7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLHFCQUFxQjtBQUFBLElBQ25CLE9BQU8sQ0FBQyxFQUFFLGFBQWEsTUFBTSxZQUFZLE1BQU0sTUFBTSxLQUFLLElBQUksYUFBYSxJQUFJLElBQUk7QUFBQSxNQUNqRixDQUFDLFNBQVMsTUFBTSxLQUFLLFlBQVksR0FBRyxHQUFHLEtBQUssTUFBTSxLQUFLLE9BQU8sS0FBSyxDQUFDLENBQUM7QUFBQSxNQUNyRTtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUEsRUFDQSxvQkFBb0I7QUFBQSxJQUNsQixPQUFPLENBQUMsRUFBRSxhQUFhLE1BQU0sWUFBWSxPQUFPLE1BQU0sS0FBSyxJQUFJLGFBQWEsSUFBSSxJQUFJLEtBQUssQ0FBQyxRQUFRLE1BQU0sS0FBSyxZQUFZLEdBQUcsR0FBRyxNQUFNLE1BQU0sQ0FBQyxHQUFHLEdBQUc7QUFBQSxFQUNwSjtBQUFBLEVBQ0EscUJBQXFCO0FBQUEsSUFDbkIsT0FBTyxDQUFDLEVBQUUsYUFBYSxNQUFNLFdBQVcsTUFBTSxLQUFLLElBQUksYUFBYSxJQUFJLElBQUksS0FBSyxDQUFDLE1BQU0sS0FBSyxZQUFZLEdBQUcsQ0FBQyxHQUFHLEdBQUc7QUFBQSxFQUNySDtBQUFBLEVBQ0EsMkJBQTJCO0FBQUEsSUFDekIsT0FBTyxDQUFDLEVBQUUsYUFBYSxNQUFNLFlBQVksT0FBTyxNQUFNLEtBQUssSUFBSSxhQUFhLElBQUksSUFBSSxLQUFLLENBQUMsU0FBUyxNQUFNLEtBQUssWUFBWSxHQUFHLEdBQUcsTUFBTSxNQUFNLENBQUMsR0FBRyxHQUFHO0FBQUEsRUFDcko7QUFBQSxFQUNBLHFCQUFxQjtBQUFBLElBQ25CLE9BQU8sQ0FBQyxFQUFFLGFBQWEsTUFBTSxXQUFXLE1BQU0sWUFBWSxVQUFVLE1BQU0sS0FBSyxJQUFJLGFBQWEsSUFBSSxJQUFJLGdCQUFnQixRQUFRLGtCQUFrQixJQUFJLElBQUksS0FBSyxPQUFPLE9BQU8sS0FBSyxNQUFNLElBQUksQ0FBQyxHQUFHLEtBQUssSUFBSSxLQUFLLEtBQUssS0FBSyxNQUFNLElBQUksR0FBRyxHQUFHLE1BQU0sYUFBYSxnQkFBZ0IsTUFBTSxTQUFTLEtBQUssV0FBVyxLQUFLO0FBQUEsRUFDalQ7QUFBQSxFQUNBLGlCQUFpQjtBQUFBLElBQ2YsT0FBTyxDQUFDLEVBQUUsWUFBWSxlQUFlLE1BQU07QUFBQSxNQUN6QyxDQUFDLGlCQUFpQixLQUFLLFlBQVksR0FBRyxHQUFHLE1BQU0sY0FBYyxDQUFDO0FBQUEsTUFDOUQ7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBLEVBQ0EscUJBQXFCO0FBQUEsSUFDbkIsT0FBTyxDQUFDLEVBQUUsTUFBTSxXQUFXLE1BQU0sS0FBSyxDQUFDLGlCQUFpQixNQUFNLEtBQUssWUFBWSxHQUFHLENBQUMsR0FBRyxHQUFHO0FBQUEsRUFDM0Y7QUFBQSxFQUNBLHFCQUFxQjtBQUFBLElBQ25CLE9BQU8sQ0FBQyxFQUFFLE1BQU0sWUFBWSxZQUFZLE9BQU8sTUFBTTtBQUFBLE1BQ25EO0FBQUEsUUFDRTtBQUFBLFFBQ0E7QUFBQSxRQUNBLEtBQUssZUFBZSxLQUFLLFlBQVksS0FBSyxDQUFDO0FBQUEsUUFDM0MsS0FBSyxZQUFZLEdBQUc7QUFBQSxRQUNwQixNQUFNLE1BQU07QUFBQSxNQUNkO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUEsRUFDQSx3QkFBd0I7QUFBQSxJQUN0QixPQUFPLENBQUMsRUFBRSxNQUFNLFlBQVksWUFBWSxPQUFPLE1BQU07QUFBQSxNQUNuRDtBQUFBLFFBQ0U7QUFBQSxRQUNBO0FBQUEsUUFDQSxLQUFLLGVBQWUsS0FBSyxZQUFZLEtBQUssQ0FBQztBQUFBLFFBQzNDLEtBQUssWUFBWSxHQUFHO0FBQUEsUUFDcEIsTUFBTSxNQUFNO0FBQUEsTUFDZDtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBLEVBQ0Esb0JBQW9CO0FBQUEsSUFDbEIsT0FBTyxDQUFDLEVBQUUsTUFBTSxZQUFZLE1BQU0sTUFBTTtBQUFBLE1BQ3RDO0FBQUEsUUFDRTtBQUFBLFFBQ0E7QUFBQSxRQUNBLEtBQUssWUFBWSxHQUFHO0FBQUEsUUFDcEIsS0FBSyxNQUFNLEtBQUssT0FBTyxLQUFLLENBQUM7QUFBQSxNQUMvQjtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBLEVBQ0EsbUJBQW1CO0FBQUEsSUFDakIsT0FBTyxDQUFDLEVBQUUsTUFBTSxZQUFZLE9BQU8sTUFBTSxLQUFLLENBQUMsZUFBZSxNQUFNLEtBQUssWUFBWSxHQUFHLEdBQUcsTUFBTSxNQUFNLENBQUMsR0FBRyxHQUFHO0FBQUEsRUFDaEg7QUFBQSxFQUNBLDBCQUEwQjtBQUFBLElBQ3hCLE9BQU8sQ0FBQyxFQUFFLE1BQU0sWUFBWSxPQUFPLE1BQU0sS0FBSyxDQUFDLGdCQUFnQixNQUFNLEtBQUssWUFBWSxHQUFHLEdBQUcsTUFBTSxNQUFNLENBQUMsR0FBRyxHQUFHO0FBQUEsRUFDakg7QUFDRjtBQUNBLFNBQVMsS0FBSyxZQUFZLFlBQVksSUFBSTtBQUN4QyxNQUFJO0FBQ0osVUFBUSx3QkFBd0IsZUFBZSxRQUFRLGVBQWUsU0FBUyxTQUFTLFdBQVcsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFLEtBQUssU0FBUyxPQUFPLFFBQVEsMEJBQTBCLFNBQVMsd0JBQXdCO0FBQzlNO0FBQ0EsU0FBUyxNQUFNLE9BQU87QUFDcEIsU0FBTyxLQUFLLE9BQU8sT0FBTyxLQUFLLE9BQU8sSUFBSSxDQUFDLEdBQUcsS0FBSztBQUNyRDtBQUNBLFNBQVMsS0FBSyxPQUFPLGFBQWEsTUFBTSxJQUFJO0FBQzFDLFNBQU8sZUFBZSxRQUFRLGdCQUFnQixLQUFLLFFBQVEsY0FBYyxNQUFNO0FBQ2pGO0FBQ0EsU0FBUyxPQUFPLEtBQUs7QUFDbkIsU0FBTyxLQUFLLE1BQU0sSUFBSSxRQUFRLE9BQU8sTUFBTSxDQUFDO0FBQzlDO0FBQ0EsU0FBUyxrQkFBa0IsWUFBWTtBQUNyQyxNQUFJO0FBQ0osVUFBUSxtQkFBbUIsZUFBZSxRQUFRLGVBQWUsU0FBUyxTQUFTLFdBQVcsS0FBSyxDQUFDLFFBQVEsSUFBSSxTQUFTLElBQUksQ0FBQyxPQUFPLFFBQVEscUJBQXFCLFNBQVMsbUJBQW1CO0FBQ2hNO0FBR0EsU0FBUyxvQkFBb0IsV0FBVyxXQUFXO0FBQ2pELFVBQVEsVUFBVSxNQUFNO0FBQUEsSUFDdEIsS0FBSyxLQUFLO0FBQ1IsYUFBTztBQUFBLElBQ1QsS0FBSyxLQUFLO0FBQ1IsYUFBTyxTQUFTLFVBQVUsT0FBTyxFQUFFO0FBQUEsSUFDckMsS0FBSyxLQUFLO0FBQ1IsYUFBTyxXQUFXLFVBQVUsS0FBSztBQUFBLElBQ25DLEtBQUssS0FBSztBQUFBLElBQ1YsS0FBSyxLQUFLO0FBQUEsSUFDVixLQUFLLEtBQUs7QUFDUixhQUFPLFVBQVU7QUFBQSxJQUNuQixLQUFLLEtBQUs7QUFDUixhQUFPLFVBQVUsT0FBTztBQUFBLFFBQ3RCLENBQUMsU0FBUyxvQkFBb0IsTUFBTSxTQUFTO0FBQUEsTUFDL0M7QUFBQSxJQUNGLEtBQUssS0FBSztBQUNSLGFBQU87QUFBQSxRQUNMLFVBQVU7QUFBQSxRQUNWLENBQUMsVUFBVSxNQUFNLEtBQUs7QUFBQSxRQUN0QixDQUFDLFVBQVUsb0JBQW9CLE1BQU0sT0FBTyxTQUFTO0FBQUEsTUFDdkQ7QUFBQSxJQUNGLEtBQUssS0FBSztBQUNSLGFBQU8sY0FBYyxRQUFRLGNBQWMsU0FBUyxTQUFTLFVBQVUsVUFBVSxLQUFLLEtBQUs7QUFBQSxFQUMvRjtBQUNGO0FBR0EsU0FBUyxXQUFXLE1BQU07QUFDeEIsVUFBUSxRQUFRLFVBQVUsT0FBTyxvQkFBb0I7QUFDckQsU0FBTyxTQUFTLFlBQVksVUFBVSxPQUFPLCtCQUErQjtBQUM1RSxNQUFJLEtBQUssV0FBVyxHQUFHO0FBQ3JCLFVBQU0sSUFBSSxhQUFhLHlDQUF5QztBQUFBLEVBQ2xFO0FBQ0EsV0FBUyxJQUFJLEdBQUcsSUFBSSxLQUFLLFFBQVEsRUFBRSxHQUFHO0FBQ3BDLFFBQUksQ0FBQyxlQUFlLEtBQUssV0FBVyxDQUFDLENBQUMsR0FBRztBQUN2QyxZQUFNLElBQUk7QUFBQSxRQUNSLDZDQUE2QyxJQUFJO0FBQUEsTUFDbkQ7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLE1BQUksQ0FBQyxZQUFZLEtBQUssV0FBVyxDQUFDLENBQUMsR0FBRztBQUNwQyxVQUFNLElBQUk7QUFBQSxNQUNSLHdDQUF3QyxJQUFJO0FBQUEsSUFDOUM7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBQ0EsU0FBUyxvQkFBb0IsTUFBTTtBQUNqQyxNQUFJLFNBQVMsVUFBVSxTQUFTLFdBQVcsU0FBUyxRQUFRO0FBQzFELFVBQU0sSUFBSSxhQUFhLGdDQUFnQyxJQUFJLEVBQUU7QUFBQSxFQUMvRDtBQUNBLFNBQU8sV0FBVyxJQUFJO0FBQ3hCO0FBR0EsU0FBUyxPQUFPLE1BQU07QUFDcEIsU0FBTyxhQUFhLElBQUksS0FBSyxhQUFhLElBQUksS0FBSyxnQkFBZ0IsSUFBSSxLQUFLLFlBQVksSUFBSSxLQUFLLFdBQVcsSUFBSSxLQUFLLGtCQUFrQixJQUFJLEtBQUssV0FBVyxJQUFJLEtBQUssY0FBYyxJQUFJO0FBQ3hMO0FBQ0EsU0FBUyxhQUFhLE1BQU07QUFDMUIsU0FBTyxXQUFXLE1BQU0saUJBQWlCO0FBQzNDO0FBQ0EsU0FBUyxhQUFhLE1BQU07QUFDMUIsU0FBTyxXQUFXLE1BQU0saUJBQWlCO0FBQzNDO0FBQ0EsU0FBUyxnQkFBZ0IsTUFBTTtBQUM3QixTQUFPLFdBQVcsTUFBTSxvQkFBb0I7QUFDOUM7QUFDQSxTQUFTLFlBQVksTUFBTTtBQUN6QixTQUFPLFdBQVcsTUFBTSxnQkFBZ0I7QUFDMUM7QUFDQSxTQUFTLFdBQVcsTUFBTTtBQUN4QixTQUFPLFdBQVcsTUFBTSxlQUFlO0FBQ3pDO0FBQ0EsU0FBUyxrQkFBa0IsTUFBTTtBQUMvQixTQUFPLFdBQVcsTUFBTSxzQkFBc0I7QUFDaEQ7QUFDQSxTQUFTLFdBQVcsTUFBTTtBQUN4QixTQUFPLFdBQVcsTUFBTSxXQUFXO0FBQ3JDO0FBQ0EsU0FBUyxjQUFjLE1BQU07QUFDM0IsU0FBTyxXQUFXLE1BQU0sY0FBYztBQUN4QztBQUNBLFNBQVMsWUFBWSxNQUFNO0FBQ3pCLFNBQU8sYUFBYSxJQUFJLEtBQUssV0FBVyxJQUFJLEtBQUssa0JBQWtCLElBQUksS0FBSyxlQUFlLElBQUksS0FBSyxZQUFZLEtBQUssTUFBTTtBQUM3SDtBQUNBLFNBQVMsV0FBVyxNQUFNO0FBQ3hCLFNBQU8sYUFBYSxJQUFJLEtBQUssV0FBVyxJQUFJO0FBQzlDO0FBQ0EsU0FBUyxnQkFBZ0IsTUFBTTtBQUM3QixTQUFPLGFBQWEsSUFBSSxLQUFLLGdCQUFnQixJQUFJLEtBQUssWUFBWSxJQUFJO0FBQ3hFO0FBQ0EsU0FBUyxlQUFlLE1BQU07QUFDNUIsU0FBTyxnQkFBZ0IsSUFBSSxLQUFLLFlBQVksSUFBSTtBQUNsRDtBQUNBLElBQUksY0FBYyxNQUFNO0FBQUEsRUFDdEIsWUFBWSxRQUFRO0FBQ2xCLFdBQU8sTUFBTSxLQUFLLFVBQVUsT0FBTyxZQUFZLFFBQVEsTUFBTSxDQUFDLHdCQUF3QjtBQUN0RixTQUFLLFNBQVM7QUFBQSxFQUNoQjtBQUFBLEVBQ0EsS0FBSyxPQUFPLFdBQVcsSUFBSTtBQUN6QixXQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0EsV0FBVztBQUNULFdBQU8sTUFBTSxPQUFPLEtBQUssTUFBTSxJQUFJO0FBQUEsRUFDckM7QUFBQSxFQUNBLFNBQVM7QUFDUCxXQUFPLEtBQUssU0FBUztBQUFBLEVBQ3ZCO0FBQ0Y7QUFDQSxJQUFJLGlCQUFpQixNQUFNO0FBQUEsRUFDekIsWUFBWSxRQUFRO0FBQ2xCLG1CQUFlLE1BQU0sS0FBSztBQUFBLE1BQ3hCO0FBQUEsTUFDQSxZQUFZLFFBQVEsTUFBTSxDQUFDO0FBQUEsSUFDN0I7QUFDQSxTQUFLLFNBQVM7QUFBQSxFQUNoQjtBQUFBLEVBQ0EsS0FBSyxPQUFPLFdBQVcsSUFBSTtBQUN6QixXQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0EsV0FBVztBQUNULFdBQU8sT0FBTyxLQUFLLE1BQU0sSUFBSTtBQUFBLEVBQy9CO0FBQUEsRUFDQSxTQUFTO0FBQ1AsV0FBTyxLQUFLLFNBQVM7QUFBQSxFQUN2QjtBQUNGO0FBQ0EsU0FBUyxlQUFlLE1BQU07QUFDNUIsU0FBTyxXQUFXLElBQUksS0FBSyxjQUFjLElBQUk7QUFDL0M7QUFDQSxTQUFTLGVBQWUsTUFBTTtBQUM1QixTQUFPLE9BQU8sSUFBSSxLQUFLLENBQUMsY0FBYyxJQUFJO0FBQzVDO0FBQ0EsU0FBUyxnQkFBZ0IsTUFBTTtBQUM3QixNQUFJLE1BQU07QUFDUixXQUFPLGNBQWMsSUFBSSxJQUFJLEtBQUssU0FBUztBQUFBLEVBQzdDO0FBQ0Y7QUFDQSxTQUFTLGFBQWEsTUFBTTtBQUMxQixNQUFJLE1BQU07QUFDUixRQUFJLGdCQUFnQjtBQUNwQixXQUFPLGVBQWUsYUFBYSxHQUFHO0FBQ3BDLHNCQUFnQixjQUFjO0FBQUEsSUFDaEM7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUNGO0FBQ0EsU0FBUywwQkFBMEIsT0FBTztBQUN4QyxTQUFPLE9BQU8sVUFBVSxhQUFhLE1BQU0sSUFBSTtBQUNqRDtBQUNBLFNBQVMsbUJBQW1CLE9BQU87QUFDakMsU0FBTyxPQUFPLFVBQVUsYUFBYSxNQUFNLElBQUk7QUFDakQ7QUFDQSxJQUFJLG9CQUFvQixNQUFNO0FBQUEsRUFDNUIsWUFBWSxRQUFRO0FBQ2xCLFFBQUksb0JBQW9CLG1CQUFtQixzQkFBc0I7QUFDakUsVUFBTSxlQUFlLHFCQUFxQixPQUFPLGdCQUFnQixRQUFRLHVCQUF1QixTQUFTLHFCQUFxQjtBQUM5SCxTQUFLLE9BQU8sV0FBVyxPQUFPLElBQUk7QUFDbEMsU0FBSyxjQUFjLE9BQU87QUFDMUIsU0FBSyxpQkFBaUIsT0FBTztBQUM3QixTQUFLLGFBQWEsb0JBQW9CLE9BQU8sZUFBZSxRQUFRLHNCQUFzQixTQUFTLG9CQUFvQjtBQUN2SCxTQUFLLGFBQWE7QUFDbEIsU0FBSyxnQkFBZ0IsdUJBQXVCLE9BQU8sa0JBQWtCLFFBQVEseUJBQXlCLFNBQVMsdUJBQXVCLENBQUMsTUFBTSxjQUFjLFlBQVksb0JBQW9CLE1BQU0sU0FBUyxDQUFDO0FBQzNNLFNBQUssYUFBYSxTQUFTLE9BQU8sVUFBVTtBQUM1QyxTQUFLLFVBQVUsT0FBTztBQUN0QixTQUFLLHFCQUFxQix3QkFBd0IsT0FBTyx1QkFBdUIsUUFBUSwwQkFBMEIsU0FBUyx3QkFBd0IsQ0FBQztBQUNwSixXQUFPLGtCQUFrQixRQUFRLE9BQU8sT0FBTyxtQkFBbUIsWUFBWTtBQUFBLE1BQzVFO0FBQUEsTUFDQSxHQUFHLEtBQUssSUFBSSx3REFBd0QsUUFBUSxPQUFPLGNBQWMsQ0FBQztBQUFBLElBQ3BHO0FBQ0EsV0FBTyxhQUFhLFFBQVEsT0FBTyxPQUFPLGNBQWMsY0FBYztBQUFBLE1BQ3BFO0FBQUEsTUFDQSxHQUFHLEtBQUssSUFBSTtBQUFBLElBQ2Q7QUFDQSxRQUFJLE9BQU8sY0FBYztBQUN2QixhQUFPLE9BQU8sZUFBZSxjQUFjLE9BQU8sT0FBTyxpQkFBaUIsY0FBYztBQUFBLFFBQ3RGO0FBQUEsUUFDQSxHQUFHLEtBQUssSUFBSTtBQUFBLE1BQ2Q7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBLEVBQ0EsS0FBSyxPQUFPLFdBQVcsSUFBSTtBQUN6QixXQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0EsV0FBVztBQUNULFdBQU87QUFBQSxNQUNMLE1BQU0sS0FBSztBQUFBLE1BQ1gsYUFBYSxLQUFLO0FBQUEsTUFDbEIsZ0JBQWdCLEtBQUs7QUFBQSxNQUNyQixXQUFXLEtBQUs7QUFBQSxNQUNoQixZQUFZLEtBQUs7QUFBQSxNQUNqQixjQUFjLEtBQUs7QUFBQSxNQUNuQixZQUFZLEtBQUs7QUFBQSxNQUNqQixTQUFTLEtBQUs7QUFBQSxNQUNkLG1CQUFtQixLQUFLO0FBQUEsSUFDMUI7QUFBQSxFQUNGO0FBQUEsRUFDQSxXQUFXO0FBQ1QsV0FBTyxLQUFLO0FBQUEsRUFDZDtBQUFBLEVBQ0EsU0FBUztBQUNQLFdBQU8sS0FBSyxTQUFTO0FBQUEsRUFDdkI7QUFDRjtBQUNBLElBQUksb0JBQW9CLE1BQU07QUFBQSxFQUM1QixZQUFZLFFBQVE7QUFDbEIsUUFBSTtBQUNKLFNBQUssT0FBTyxXQUFXLE9BQU8sSUFBSTtBQUNsQyxTQUFLLGNBQWMsT0FBTztBQUMxQixTQUFLLFdBQVcsT0FBTztBQUN2QixTQUFLLGFBQWEsU0FBUyxPQUFPLFVBQVU7QUFDNUMsU0FBSyxVQUFVLE9BQU87QUFDdEIsU0FBSyxxQkFBcUIseUJBQXlCLE9BQU8sdUJBQXVCLFFBQVEsMkJBQTJCLFNBQVMseUJBQXlCLENBQUM7QUFDdkosU0FBSyxVQUFVLE1BQU0sZUFBZSxNQUFNO0FBQzFDLFNBQUssY0FBYyxNQUFNLGlCQUFpQixNQUFNO0FBQ2hELFdBQU8sWUFBWSxRQUFRLE9BQU8sT0FBTyxhQUFhLGNBQWM7QUFBQSxNQUNsRTtBQUFBLE1BQ0EsR0FBRyxLQUFLLElBQUksb0RBQW9ELFFBQVEsT0FBTyxRQUFRLENBQUM7QUFBQSxJQUMxRjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLEtBQUssT0FBTyxXQUFXLElBQUk7QUFDekIsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBLFlBQVk7QUFDVixRQUFJLE9BQU8sS0FBSyxZQUFZLFlBQVk7QUFDdEMsV0FBSyxVQUFVLEtBQUssUUFBUTtBQUFBLElBQzlCO0FBQ0EsV0FBTyxLQUFLO0FBQUEsRUFDZDtBQUFBLEVBQ0EsZ0JBQWdCO0FBQ2QsUUFBSSxPQUFPLEtBQUssZ0JBQWdCLFlBQVk7QUFDMUMsV0FBSyxjQUFjLEtBQUssWUFBWTtBQUFBLElBQ3RDO0FBQ0EsV0FBTyxLQUFLO0FBQUEsRUFDZDtBQUFBLEVBQ0EsV0FBVztBQUNULFdBQU87QUFBQSxNQUNMLE1BQU0sS0FBSztBQUFBLE1BQ1gsYUFBYSxLQUFLO0FBQUEsTUFDbEIsWUFBWSxLQUFLLGNBQWM7QUFBQSxNQUMvQixRQUFRLHFCQUFxQixLQUFLLFVBQVUsQ0FBQztBQUFBLE1BQzdDLFVBQVUsS0FBSztBQUFBLE1BQ2YsWUFBWSxLQUFLO0FBQUEsTUFDakIsU0FBUyxLQUFLO0FBQUEsTUFDZCxtQkFBbUIsS0FBSztBQUFBLElBQzFCO0FBQUEsRUFDRjtBQUFBLEVBQ0EsV0FBVztBQUNULFdBQU8sS0FBSztBQUFBLEVBQ2Q7QUFBQSxFQUNBLFNBQVM7QUFDUCxXQUFPLEtBQUssU0FBUztBQUFBLEVBQ3ZCO0FBQ0Y7QUFDQSxTQUFTLGlCQUFpQixRQUFRO0FBQ2hDLE1BQUk7QUFDSixRQUFNLGFBQWE7QUFBQSxLQUNoQixxQkFBcUIsT0FBTyxnQkFBZ0IsUUFBUSx1QkFBdUIsU0FBUyxxQkFBcUIsQ0FBQztBQUFBLEVBQzdHO0FBQ0EsUUFBTSxRQUFRLFVBQVUsS0FBSztBQUFBLElBQzNCO0FBQUEsSUFDQSxHQUFHLE9BQU8sSUFBSTtBQUFBLEVBQ2hCO0FBQ0EsU0FBTztBQUNUO0FBQ0EsU0FBUyxlQUFlLFFBQVE7QUFDOUIsUUFBTSxXQUFXLG1CQUFtQixPQUFPLE1BQU07QUFDakQsYUFBVyxRQUFRLEtBQUs7QUFBQSxJQUN0QjtBQUFBLElBQ0EsR0FBRyxPQUFPLElBQUk7QUFBQSxFQUNoQjtBQUNBLFNBQU8sU0FBUyxVQUFVLENBQUMsYUFBYSxjQUFjO0FBQ3BELFFBQUk7QUFDSixlQUFXLFdBQVcsS0FBSztBQUFBLE1BQ3pCO0FBQUEsTUFDQSxHQUFHLE9BQU8sSUFBSSxJQUFJLFNBQVM7QUFBQSxJQUM3QjtBQUNBLGdCQUFZLFdBQVcsUUFBUSxPQUFPLFlBQVksWUFBWSxjQUFjO0FBQUEsTUFDMUU7QUFBQSxNQUNBLEdBQUcsT0FBTyxJQUFJLElBQUksU0FBUyw0REFBNEQsUUFBUSxZQUFZLE9BQU8sQ0FBQztBQUFBLElBQ3JIO0FBQ0EsVUFBTSxjQUFjLG9CQUFvQixZQUFZLFVBQVUsUUFBUSxzQkFBc0IsU0FBUyxvQkFBb0IsQ0FBQztBQUMxSCxlQUFXLFVBQVUsS0FBSztBQUFBLE1BQ3hCO0FBQUEsTUFDQSxHQUFHLE9BQU8sSUFBSSxJQUFJLFNBQVM7QUFBQSxJQUM3QjtBQUNBLFdBQU87QUFBQSxNQUNMLE1BQU0sV0FBVyxTQUFTO0FBQUEsTUFDMUIsYUFBYSxZQUFZO0FBQUEsTUFDekIsTUFBTSxZQUFZO0FBQUEsTUFDbEIsTUFBTSxnQkFBZ0IsVUFBVTtBQUFBLE1BQ2hDLFNBQVMsWUFBWTtBQUFBLE1BQ3JCLFdBQVcsWUFBWTtBQUFBLE1BQ3ZCLG1CQUFtQixZQUFZO0FBQUEsTUFDL0IsWUFBWSxTQUFTLFlBQVksVUFBVTtBQUFBLE1BQzNDLFNBQVMsWUFBWTtBQUFBLElBQ3ZCO0FBQUEsRUFDRixDQUFDO0FBQ0g7QUFDQSxTQUFTLGdCQUFnQixRQUFRO0FBQy9CLFNBQU8sT0FBTyxRQUFRLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQyxTQUFTLFNBQVMsT0FBTztBQUFBLElBQzNELE1BQU0sV0FBVyxPQUFPO0FBQUEsSUFDeEIsYUFBYSxVQUFVO0FBQUEsSUFDdkIsTUFBTSxVQUFVO0FBQUEsSUFDaEIsY0FBYyxVQUFVO0FBQUEsSUFDeEIsbUJBQW1CLFVBQVU7QUFBQSxJQUM3QixZQUFZLFNBQVMsVUFBVSxVQUFVO0FBQUEsSUFDekMsU0FBUyxVQUFVO0FBQUEsRUFDckIsRUFBRTtBQUNKO0FBQ0EsU0FBUyxXQUFXLEtBQUs7QUFDdkIsU0FBTyxhQUFhLEdBQUcsS0FBSyxDQUFDLE1BQU0sUUFBUSxHQUFHO0FBQ2hEO0FBQ0EsU0FBUyxxQkFBcUIsUUFBUTtBQUNwQyxTQUFPLFNBQVMsUUFBUSxDQUFDLFdBQVc7QUFBQSxJQUNsQyxhQUFhLE1BQU07QUFBQSxJQUNuQixNQUFNLE1BQU07QUFBQSxJQUNaLE1BQU0saUJBQWlCLE1BQU0sSUFBSTtBQUFBLElBQ2pDLFNBQVMsTUFBTTtBQUFBLElBQ2YsV0FBVyxNQUFNO0FBQUEsSUFDakIsbUJBQW1CLE1BQU07QUFBQSxJQUN6QixZQUFZLE1BQU07QUFBQSxJQUNsQixTQUFTLE1BQU07QUFBQSxFQUNqQixFQUFFO0FBQ0o7QUFDQSxTQUFTLGlCQUFpQixNQUFNO0FBQzlCLFNBQU87QUFBQSxJQUNMO0FBQUEsSUFDQSxDQUFDLFFBQVEsSUFBSTtBQUFBLElBQ2IsQ0FBQyxTQUFTO0FBQUEsTUFDUixhQUFhLElBQUk7QUFBQSxNQUNqQixNQUFNLElBQUk7QUFBQSxNQUNWLGNBQWMsSUFBSTtBQUFBLE1BQ2xCLG1CQUFtQixJQUFJO0FBQUEsTUFDdkIsWUFBWSxJQUFJO0FBQUEsTUFDaEIsU0FBUyxJQUFJO0FBQUEsSUFDZjtBQUFBLEVBQ0Y7QUFDRjtBQUNBLFNBQVMsbUJBQW1CLEtBQUs7QUFDL0IsU0FBTyxjQUFjLElBQUksSUFBSSxLQUFLLElBQUksaUJBQWlCO0FBQ3pEO0FBQ0EsSUFBSSx1QkFBdUIsTUFBTTtBQUFBLEVBQy9CLFlBQVksUUFBUTtBQUNsQixRQUFJO0FBQ0osU0FBSyxPQUFPLFdBQVcsT0FBTyxJQUFJO0FBQ2xDLFNBQUssY0FBYyxPQUFPO0FBQzFCLFNBQUssY0FBYyxPQUFPO0FBQzFCLFNBQUssYUFBYSxTQUFTLE9BQU8sVUFBVTtBQUM1QyxTQUFLLFVBQVUsT0FBTztBQUN0QixTQUFLLHFCQUFxQix5QkFBeUIsT0FBTyx1QkFBdUIsUUFBUSwyQkFBMkIsU0FBUyx5QkFBeUIsQ0FBQztBQUN2SixTQUFLLFVBQVUsZUFBZSxLQUFLLFFBQVEsTUFBTTtBQUNqRCxTQUFLLGNBQWMsaUJBQWlCLEtBQUssUUFBUSxNQUFNO0FBQ3ZELFdBQU8sZUFBZSxRQUFRLE9BQU8sT0FBTyxnQkFBZ0IsY0FBYztBQUFBLE1BQ3hFO0FBQUEsTUFDQSxHQUFHLEtBQUssSUFBSSx1REFBdUQsUUFBUSxPQUFPLFdBQVcsQ0FBQztBQUFBLElBQ2hHO0FBQUEsRUFDRjtBQUFBLEVBQ0EsS0FBSyxPQUFPLFdBQVcsSUFBSTtBQUN6QixXQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0EsWUFBWTtBQUNWLFFBQUksT0FBTyxLQUFLLFlBQVksWUFBWTtBQUN0QyxXQUFLLFVBQVUsS0FBSyxRQUFRO0FBQUEsSUFDOUI7QUFDQSxXQUFPLEtBQUs7QUFBQSxFQUNkO0FBQUEsRUFDQSxnQkFBZ0I7QUFDZCxRQUFJLE9BQU8sS0FBSyxnQkFBZ0IsWUFBWTtBQUMxQyxXQUFLLGNBQWMsS0FBSyxZQUFZO0FBQUEsSUFDdEM7QUFDQSxXQUFPLEtBQUs7QUFBQSxFQUNkO0FBQUEsRUFDQSxXQUFXO0FBQ1QsV0FBTztBQUFBLE1BQ0wsTUFBTSxLQUFLO0FBQUEsTUFDWCxhQUFhLEtBQUs7QUFBQSxNQUNsQixZQUFZLEtBQUssY0FBYztBQUFBLE1BQy9CLFFBQVEscUJBQXFCLEtBQUssVUFBVSxDQUFDO0FBQUEsTUFDN0MsYUFBYSxLQUFLO0FBQUEsTUFDbEIsWUFBWSxLQUFLO0FBQUEsTUFDakIsU0FBUyxLQUFLO0FBQUEsTUFDZCxtQkFBbUIsS0FBSztBQUFBLElBQzFCO0FBQUEsRUFDRjtBQUFBLEVBQ0EsV0FBVztBQUNULFdBQU8sS0FBSztBQUFBLEVBQ2Q7QUFBQSxFQUNBLFNBQVM7QUFDUCxXQUFPLEtBQUssU0FBUztBQUFBLEVBQ3ZCO0FBQ0Y7QUFDQSxJQUFJLG1CQUFtQixNQUFNO0FBQUEsRUFDM0IsWUFBWSxRQUFRO0FBQ2xCLFFBQUk7QUFDSixTQUFLLE9BQU8sV0FBVyxPQUFPLElBQUk7QUFDbEMsU0FBSyxjQUFjLE9BQU87QUFDMUIsU0FBSyxjQUFjLE9BQU87QUFDMUIsU0FBSyxhQUFhLFNBQVMsT0FBTyxVQUFVO0FBQzVDLFNBQUssVUFBVSxPQUFPO0FBQ3RCLFNBQUsscUJBQXFCLHlCQUF5QixPQUFPLHVCQUF1QixRQUFRLDJCQUEyQixTQUFTLHlCQUF5QixDQUFDO0FBQ3ZKLFNBQUssU0FBUyxZQUFZLEtBQUssUUFBUSxNQUFNO0FBQzdDLFdBQU8sZUFBZSxRQUFRLE9BQU8sT0FBTyxnQkFBZ0IsY0FBYztBQUFBLE1BQ3hFO0FBQUEsTUFDQSxHQUFHLEtBQUssSUFBSSx1REFBdUQsUUFBUSxPQUFPLFdBQVcsQ0FBQztBQUFBLElBQ2hHO0FBQUEsRUFDRjtBQUFBLEVBQ0EsS0FBSyxPQUFPLFdBQVcsSUFBSTtBQUN6QixXQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0EsV0FBVztBQUNULFFBQUksT0FBTyxLQUFLLFdBQVcsWUFBWTtBQUNyQyxXQUFLLFNBQVMsS0FBSyxPQUFPO0FBQUEsSUFDNUI7QUFDQSxXQUFPLEtBQUs7QUFBQSxFQUNkO0FBQUEsRUFDQSxXQUFXO0FBQ1QsV0FBTztBQUFBLE1BQ0wsTUFBTSxLQUFLO0FBQUEsTUFDWCxhQUFhLEtBQUs7QUFBQSxNQUNsQixPQUFPLEtBQUssU0FBUztBQUFBLE1BQ3JCLGFBQWEsS0FBSztBQUFBLE1BQ2xCLFlBQVksS0FBSztBQUFBLE1BQ2pCLFNBQVMsS0FBSztBQUFBLE1BQ2QsbUJBQW1CLEtBQUs7QUFBQSxJQUMxQjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLFdBQVc7QUFDVCxXQUFPLEtBQUs7QUFBQSxFQUNkO0FBQUEsRUFDQSxTQUFTO0FBQ1AsV0FBTyxLQUFLLFNBQVM7QUFBQSxFQUN2QjtBQUNGO0FBQ0EsU0FBUyxZQUFZLFFBQVE7QUFDM0IsUUFBTSxRQUFRLDBCQUEwQixPQUFPLEtBQUs7QUFDcEQsUUFBTSxRQUFRLEtBQUssS0FBSztBQUFBLElBQ3RCO0FBQUEsSUFDQSxtRkFBbUYsT0FBTyxJQUFJO0FBQUEsRUFDaEc7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxJQUFJLGtCQUFrQixNQUFNO0FBQUE7QUFBQSxFQUUxQixZQUFZLFFBQVE7QUFDbEIsUUFBSTtBQUNKLFNBQUssT0FBTyxXQUFXLE9BQU8sSUFBSTtBQUNsQyxTQUFLLGNBQWMsT0FBTztBQUMxQixTQUFLLGFBQWEsU0FBUyxPQUFPLFVBQVU7QUFDNUMsU0FBSyxVQUFVLE9BQU87QUFDdEIsU0FBSyxxQkFBcUIseUJBQXlCLE9BQU8sdUJBQXVCLFFBQVEsMkJBQTJCLFNBQVMseUJBQXlCLENBQUM7QUFDdkosU0FBSyxVQUFVLGlCQUFpQixLQUFLLE1BQU0sT0FBTyxNQUFNO0FBQ3hELFNBQUssZUFBZSxJQUFJO0FBQUEsTUFDdEIsS0FBSyxRQUFRLElBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxPQUFPLFNBQVMsQ0FBQztBQUFBLElBQzlEO0FBQ0EsU0FBSyxjQUFjLE9BQU8sS0FBSyxTQUFTLENBQUMsVUFBVSxNQUFNLElBQUk7QUFBQSxFQUMvRDtBQUFBLEVBQ0EsS0FBSyxPQUFPLFdBQVcsSUFBSTtBQUN6QixXQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0EsWUFBWTtBQUNWLFdBQU8sS0FBSztBQUFBLEVBQ2Q7QUFBQSxFQUNBLFNBQVMsTUFBTTtBQUNiLFdBQU8sS0FBSyxZQUFZLElBQUk7QUFBQSxFQUM5QjtBQUFBLEVBQ0EsVUFBVSxhQUFhO0FBQ3JCLFVBQU0sWUFBWSxLQUFLLGFBQWEsSUFBSSxXQUFXO0FBQ25ELFFBQUksY0FBYyxRQUFRO0FBQ3hCLFlBQU0sSUFBSTtBQUFBLFFBQ1IsU0FBUyxLQUFLLElBQUksNkJBQTZCLFFBQVEsV0FBVyxDQUFDO0FBQUEsTUFDckU7QUFBQSxJQUNGO0FBQ0EsV0FBTyxVQUFVO0FBQUEsRUFDbkI7QUFBQSxFQUNBLFdBQVcsWUFBWTtBQUNyQixRQUFJLE9BQU8sZUFBZSxVQUFVO0FBQ2xDLFlBQU0sV0FBVyxRQUFRLFVBQVU7QUFDbkMsWUFBTSxJQUFJO0FBQUEsUUFDUixTQUFTLEtBQUssSUFBSSx3Q0FBd0MsUUFBUSxNQUFNLG9CQUFvQixNQUFNLFFBQVE7QUFBQSxNQUM1RztBQUFBLElBQ0Y7QUFDQSxVQUFNLFlBQVksS0FBSyxTQUFTLFVBQVU7QUFDMUMsUUFBSSxhQUFhLE1BQU07QUFDckIsWUFBTSxJQUFJO0FBQUEsUUFDUixVQUFVLFVBQVUsd0JBQXdCLEtBQUssSUFBSSxZQUFZLG9CQUFvQixNQUFNLFVBQVU7QUFBQSxNQUN2RztBQUFBLElBQ0Y7QUFDQSxXQUFPLFVBQVU7QUFBQSxFQUNuQjtBQUFBLEVBQ0EsYUFBYSxXQUFXLFlBQVk7QUFDbEMsUUFBSSxVQUFVLFNBQVMsS0FBSyxNQUFNO0FBQ2hDLFlBQU0sV0FBVyxNQUFNLFNBQVM7QUFDaEMsWUFBTSxJQUFJO0FBQUEsUUFDUixTQUFTLEtBQUssSUFBSSxzQ0FBc0MsUUFBUSxNQUFNLG9CQUFvQixNQUFNLFFBQVE7QUFBQSxRQUN4RztBQUFBLFVBQ0UsT0FBTztBQUFBLFFBQ1Q7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFVBQU0sWUFBWSxLQUFLLFNBQVMsVUFBVSxLQUFLO0FBQy9DLFFBQUksYUFBYSxNQUFNO0FBQ3JCLFlBQU0sV0FBVyxNQUFNLFNBQVM7QUFDaEMsWUFBTSxJQUFJO0FBQUEsUUFDUixVQUFVLFFBQVEsd0JBQXdCLEtBQUssSUFBSSxZQUFZLG9CQUFvQixNQUFNLFFBQVE7QUFBQSxRQUNqRztBQUFBLFVBQ0UsT0FBTztBQUFBLFFBQ1Q7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFdBQU8sVUFBVTtBQUFBLEVBQ25CO0FBQUEsRUFDQSxXQUFXO0FBQ1QsVUFBTSxTQUFTO0FBQUEsTUFDYixLQUFLLFVBQVU7QUFBQSxNQUNmLENBQUMsVUFBVSxNQUFNO0FBQUEsTUFDakIsQ0FBQyxXQUFXO0FBQUEsUUFDVixhQUFhLE1BQU07QUFBQSxRQUNuQixPQUFPLE1BQU07QUFBQSxRQUNiLG1CQUFtQixNQUFNO0FBQUEsUUFDekIsWUFBWSxNQUFNO0FBQUEsUUFDbEIsU0FBUyxNQUFNO0FBQUEsTUFDakI7QUFBQSxJQUNGO0FBQ0EsV0FBTztBQUFBLE1BQ0wsTUFBTSxLQUFLO0FBQUEsTUFDWCxhQUFhLEtBQUs7QUFBQSxNQUNsQjtBQUFBLE1BQ0EsWUFBWSxLQUFLO0FBQUEsTUFDakIsU0FBUyxLQUFLO0FBQUEsTUFDZCxtQkFBbUIsS0FBSztBQUFBLElBQzFCO0FBQUEsRUFDRjtBQUFBLEVBQ0EsV0FBVztBQUNULFdBQU8sS0FBSztBQUFBLEVBQ2Q7QUFBQSxFQUNBLFNBQVM7QUFDUCxXQUFPLEtBQUssU0FBUztBQUFBLEVBQ3ZCO0FBQ0Y7QUFDQSxTQUFTLG9CQUFvQixVQUFVLGlCQUFpQjtBQUN0RCxRQUFNLFdBQVcsU0FBUyxVQUFVLEVBQUUsSUFBSSxDQUFDLFVBQVUsTUFBTSxJQUFJO0FBQy9ELFFBQU0sa0JBQWtCLGVBQWUsaUJBQWlCLFFBQVE7QUFDaEUsU0FBTyxXQUFXLGtCQUFrQixlQUFlO0FBQ3JEO0FBQ0EsU0FBUyxpQkFBaUIsVUFBVSxVQUFVO0FBQzVDLGFBQVcsUUFBUSxLQUFLO0FBQUEsSUFDdEI7QUFBQSxJQUNBLEdBQUcsUUFBUTtBQUFBLEVBQ2I7QUFDQSxTQUFPLE9BQU8sUUFBUSxRQUFRLEVBQUUsSUFBSSxDQUFDLENBQUMsV0FBVyxXQUFXLE1BQU07QUFDaEUsZUFBVyxXQUFXLEtBQUs7QUFBQSxNQUN6QjtBQUFBLE1BQ0EsR0FBRyxRQUFRLElBQUksU0FBUyx1RkFBdUYsUUFBUSxXQUFXLENBQUM7QUFBQSxJQUNySTtBQUNBLFdBQU87QUFBQSxNQUNMLE1BQU0sb0JBQW9CLFNBQVM7QUFBQSxNQUNuQyxhQUFhLFlBQVk7QUFBQSxNQUN6QixPQUFPLFlBQVksVUFBVSxTQUFTLFlBQVksUUFBUTtBQUFBLE1BQzFELG1CQUFtQixZQUFZO0FBQUEsTUFDL0IsWUFBWSxTQUFTLFlBQVksVUFBVTtBQUFBLE1BQzNDLFNBQVMsWUFBWTtBQUFBLElBQ3ZCO0FBQUEsRUFDRixDQUFDO0FBQ0g7QUFDQSxJQUFJLHlCQUF5QixNQUFNO0FBQUEsRUFDakMsWUFBWSxRQUFRO0FBQ2xCLFFBQUk7QUFDSixTQUFLLE9BQU8sV0FBVyxPQUFPLElBQUk7QUFDbEMsU0FBSyxjQUFjLE9BQU87QUFDMUIsU0FBSyxhQUFhLFNBQVMsT0FBTyxVQUFVO0FBQzVDLFNBQUssVUFBVSxPQUFPO0FBQ3RCLFNBQUsscUJBQXFCLHlCQUF5QixPQUFPLHVCQUF1QixRQUFRLDJCQUEyQixTQUFTLHlCQUF5QixDQUFDO0FBQ3ZKLFNBQUssVUFBVSxvQkFBb0IsS0FBSyxRQUFRLE1BQU07QUFBQSxFQUN4RDtBQUFBLEVBQ0EsS0FBSyxPQUFPLFdBQVcsSUFBSTtBQUN6QixXQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0EsWUFBWTtBQUNWLFFBQUksT0FBTyxLQUFLLFlBQVksWUFBWTtBQUN0QyxXQUFLLFVBQVUsS0FBSyxRQUFRO0FBQUEsSUFDOUI7QUFDQSxXQUFPLEtBQUs7QUFBQSxFQUNkO0FBQUEsRUFDQSxXQUFXO0FBQ1QsVUFBTSxTQUFTLFNBQVMsS0FBSyxVQUFVLEdBQUcsQ0FBQyxXQUFXO0FBQUEsTUFDcEQsYUFBYSxNQUFNO0FBQUEsTUFDbkIsTUFBTSxNQUFNO0FBQUEsTUFDWixjQUFjLE1BQU07QUFBQSxNQUNwQixtQkFBbUIsTUFBTTtBQUFBLE1BQ3pCLFlBQVksTUFBTTtBQUFBLE1BQ2xCLFNBQVMsTUFBTTtBQUFBLElBQ2pCLEVBQUU7QUFDRixXQUFPO0FBQUEsTUFDTCxNQUFNLEtBQUs7QUFBQSxNQUNYLGFBQWEsS0FBSztBQUFBLE1BQ2xCO0FBQUEsTUFDQSxZQUFZLEtBQUs7QUFBQSxNQUNqQixTQUFTLEtBQUs7QUFBQSxNQUNkLG1CQUFtQixLQUFLO0FBQUEsSUFDMUI7QUFBQSxFQUNGO0FBQUEsRUFDQSxXQUFXO0FBQ1QsV0FBTyxLQUFLO0FBQUEsRUFDZDtBQUFBLEVBQ0EsU0FBUztBQUNQLFdBQU8sS0FBSyxTQUFTO0FBQUEsRUFDdkI7QUFDRjtBQUNBLFNBQVMsb0JBQW9CLFFBQVE7QUFDbkMsUUFBTSxXQUFXLG1CQUFtQixPQUFPLE1BQU07QUFDakQsYUFBVyxRQUFRLEtBQUs7QUFBQSxJQUN0QjtBQUFBLElBQ0EsR0FBRyxPQUFPLElBQUk7QUFBQSxFQUNoQjtBQUNBLFNBQU8sU0FBUyxVQUFVLENBQUMsYUFBYSxjQUFjO0FBQ3BELE1BQUUsYUFBYSxnQkFBZ0I7QUFBQSxNQUM3QjtBQUFBLE1BQ0EsR0FBRyxPQUFPLElBQUksSUFBSSxTQUFTO0FBQUEsSUFDN0I7QUFDQSxXQUFPO0FBQUEsTUFDTCxNQUFNLFdBQVcsU0FBUztBQUFBLE1BQzFCLGFBQWEsWUFBWTtBQUFBLE1BQ3pCLE1BQU0sWUFBWTtBQUFBLE1BQ2xCLGNBQWMsWUFBWTtBQUFBLE1BQzFCLG1CQUFtQixZQUFZO0FBQUEsTUFDL0IsWUFBWSxTQUFTLFlBQVksVUFBVTtBQUFBLE1BQzNDLFNBQVMsWUFBWTtBQUFBLElBQ3ZCO0FBQUEsRUFDRixDQUFDO0FBQ0g7QUFDQSxTQUFTLHFCQUFxQixPQUFPO0FBQ25DLFNBQU8sY0FBYyxNQUFNLElBQUksS0FBSyxNQUFNLGlCQUFpQjtBQUM3RDtBQUdBLFNBQVMsZ0JBQWdCLFFBQVEsY0FBYyxXQUFXO0FBQ3hELE1BQUksaUJBQWlCLFdBQVc7QUFDOUIsV0FBTztBQUFBLEVBQ1Q7QUFDQSxNQUFJLGNBQWMsU0FBUyxHQUFHO0FBQzVCLFFBQUksY0FBYyxZQUFZLEdBQUc7QUFDL0IsYUFBTyxnQkFBZ0IsUUFBUSxhQUFhLFFBQVEsVUFBVSxNQUFNO0FBQUEsSUFDdEU7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUNBLE1BQUksY0FBYyxZQUFZLEdBQUc7QUFDL0IsV0FBTyxnQkFBZ0IsUUFBUSxhQUFhLFFBQVEsU0FBUztBQUFBLEVBQy9EO0FBQ0EsTUFBSSxXQUFXLFNBQVMsR0FBRztBQUN6QixRQUFJLFdBQVcsWUFBWSxHQUFHO0FBQzVCLGFBQU8sZ0JBQWdCLFFBQVEsYUFBYSxRQUFRLFVBQVUsTUFBTTtBQUFBLElBQ3RFO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDQSxNQUFJLFdBQVcsWUFBWSxHQUFHO0FBQzVCLFdBQU87QUFBQSxFQUNUO0FBQ0EsU0FBTyxlQUFlLFNBQVMsTUFBTSxnQkFBZ0IsWUFBWSxLQUFLLGFBQWEsWUFBWSxNQUFNLE9BQU8sVUFBVSxXQUFXLFlBQVk7QUFDL0k7QUFDQSxTQUFTLGVBQWUsUUFBUSxPQUFPLE9BQU87QUFDNUMsTUFBSSxVQUFVLE9BQU87QUFDbkIsV0FBTztBQUFBLEVBQ1Q7QUFDQSxNQUFJLGVBQWUsS0FBSyxHQUFHO0FBQ3pCLFFBQUksZUFBZSxLQUFLLEdBQUc7QUFDekIsYUFBTyxPQUFPLGlCQUFpQixLQUFLLEVBQUUsS0FBSyxDQUFDLFNBQVMsT0FBTyxVQUFVLE9BQU8sSUFBSSxDQUFDO0FBQUEsSUFDcEY7QUFDQSxXQUFPLE9BQU8sVUFBVSxPQUFPLEtBQUs7QUFBQSxFQUN0QztBQUNBLE1BQUksZUFBZSxLQUFLLEdBQUc7QUFDekIsV0FBTyxPQUFPLFVBQVUsT0FBTyxLQUFLO0FBQUEsRUFDdEM7QUFDQSxTQUFPO0FBQ1Q7QUFHQSxJQUFJLGtCQUFrQjtBQUN0QixJQUFJLGtCQUFrQjtBQUN0QixJQUFJLGFBQWEsSUFBSSxrQkFBa0I7QUFBQSxFQUNyQyxNQUFNO0FBQUEsRUFDTixhQUFhO0FBQUEsRUFDYixVQUFVLGFBQWE7QUFDckIsVUFBTSxlQUFlLGdCQUFnQixXQUFXO0FBQ2hELFFBQUksT0FBTyxpQkFBaUIsV0FBVztBQUNyQyxhQUFPLGVBQWUsSUFBSTtBQUFBLElBQzVCO0FBQ0EsUUFBSSxNQUFNO0FBQ1YsUUFBSSxPQUFPLGlCQUFpQixZQUFZLGlCQUFpQixJQUFJO0FBQzNELFlBQU0sT0FBTyxZQUFZO0FBQUEsSUFDM0I7QUFDQSxRQUFJLE9BQU8sUUFBUSxZQUFZLENBQUMsT0FBTyxVQUFVLEdBQUcsR0FBRztBQUNyRCxZQUFNLElBQUk7QUFBQSxRQUNSLDJDQUEyQyxRQUFRLFlBQVksQ0FBQztBQUFBLE1BQ2xFO0FBQUEsSUFDRjtBQUNBLFFBQUksTUFBTSxtQkFBbUIsTUFBTSxpQkFBaUI7QUFDbEQsWUFBTSxJQUFJO0FBQUEsUUFDUiwyREFBMkQsUUFBUSxZQUFZO0FBQUEsTUFDakY7QUFBQSxJQUNGO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBLFdBQVcsWUFBWTtBQUNyQixRQUFJLE9BQU8sZUFBZSxZQUFZLENBQUMsT0FBTyxVQUFVLFVBQVUsR0FBRztBQUNuRSxZQUFNLElBQUk7QUFBQSxRQUNSLDJDQUEyQyxRQUFRLFVBQVUsQ0FBQztBQUFBLE1BQ2hFO0FBQUEsSUFDRjtBQUNBLFFBQUksYUFBYSxtQkFBbUIsYUFBYSxpQkFBaUI7QUFDaEUsWUFBTSxJQUFJO0FBQUEsUUFDUix5REFBeUQsVUFBVTtBQUFBLE1BQ3JFO0FBQUEsSUFDRjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFDQSxhQUFhLFdBQVc7QUFDdEIsUUFBSSxVQUFVLFNBQVMsS0FBSyxLQUFLO0FBQy9CLFlBQU0sSUFBSTtBQUFBLFFBQ1IsMkNBQTJDLE1BQU0sU0FBUyxDQUFDO0FBQUEsUUFDM0Q7QUFBQSxVQUNFLE9BQU87QUFBQSxRQUNUO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSxVQUFNLE1BQU0sU0FBUyxVQUFVLE9BQU8sRUFBRTtBQUN4QyxRQUFJLE1BQU0sbUJBQW1CLE1BQU0saUJBQWlCO0FBQ2xELFlBQU0sSUFBSTtBQUFBLFFBQ1IseURBQXlELFVBQVUsS0FBSztBQUFBLFFBQ3hFO0FBQUEsVUFDRSxPQUFPO0FBQUEsUUFDVDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDRixDQUFDO0FBQ0QsSUFBSSxlQUFlLElBQUksa0JBQWtCO0FBQUEsRUFDdkMsTUFBTTtBQUFBLEVBQ04sYUFBYTtBQUFBLEVBQ2IsVUFBVSxhQUFhO0FBQ3JCLFVBQU0sZUFBZSxnQkFBZ0IsV0FBVztBQUNoRCxRQUFJLE9BQU8saUJBQWlCLFdBQVc7QUFDckMsYUFBTyxlQUFlLElBQUk7QUFBQSxJQUM1QjtBQUNBLFFBQUksTUFBTTtBQUNWLFFBQUksT0FBTyxpQkFBaUIsWUFBWSxpQkFBaUIsSUFBSTtBQUMzRCxZQUFNLE9BQU8sWUFBWTtBQUFBLElBQzNCO0FBQ0EsUUFBSSxPQUFPLFFBQVEsWUFBWSxDQUFDLE9BQU8sU0FBUyxHQUFHLEdBQUc7QUFDcEQsWUFBTSxJQUFJO0FBQUEsUUFDUiw2Q0FBNkMsUUFBUSxZQUFZLENBQUM7QUFBQSxNQUNwRTtBQUFBLElBQ0Y7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0EsV0FBVyxZQUFZO0FBQ3JCLFFBQUksT0FBTyxlQUFlLFlBQVksQ0FBQyxPQUFPLFNBQVMsVUFBVSxHQUFHO0FBQ2xFLFlBQU0sSUFBSTtBQUFBLFFBQ1IsNkNBQTZDLFFBQVEsVUFBVSxDQUFDO0FBQUEsTUFDbEU7QUFBQSxJQUNGO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBLGFBQWEsV0FBVztBQUN0QixRQUFJLFVBQVUsU0FBUyxLQUFLLFNBQVMsVUFBVSxTQUFTLEtBQUssS0FBSztBQUNoRSxZQUFNLElBQUk7QUFBQSxRQUNSLDZDQUE2QyxNQUFNLFNBQVMsQ0FBQztBQUFBLFFBQzdEO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSxXQUFPLFdBQVcsVUFBVSxLQUFLO0FBQUEsRUFDbkM7QUFDRixDQUFDO0FBQ0QsSUFBSSxnQkFBZ0IsSUFBSSxrQkFBa0I7QUFBQSxFQUN4QyxNQUFNO0FBQUEsRUFDTixhQUFhO0FBQUEsRUFDYixVQUFVLGFBQWE7QUFDckIsVUFBTSxlQUFlLGdCQUFnQixXQUFXO0FBQ2hELFFBQUksT0FBTyxpQkFBaUIsVUFBVTtBQUNwQyxhQUFPO0FBQUEsSUFDVDtBQUNBLFFBQUksT0FBTyxpQkFBaUIsV0FBVztBQUNyQyxhQUFPLGVBQWUsU0FBUztBQUFBLElBQ2pDO0FBQ0EsUUFBSSxPQUFPLGlCQUFpQixZQUFZLE9BQU8sU0FBUyxZQUFZLEdBQUc7QUFDckUsYUFBTyxhQUFhLFNBQVM7QUFBQSxJQUMvQjtBQUNBLFVBQU0sSUFBSTtBQUFBLE1BQ1Isa0NBQWtDLFFBQVEsV0FBVyxDQUFDO0FBQUEsSUFDeEQ7QUFBQSxFQUNGO0FBQUEsRUFDQSxXQUFXLFlBQVk7QUFDckIsUUFBSSxPQUFPLGVBQWUsVUFBVTtBQUNsQyxZQUFNLElBQUk7QUFBQSxRQUNSLCtDQUErQyxRQUFRLFVBQVUsQ0FBQztBQUFBLE1BQ3BFO0FBQUEsSUFDRjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFDQSxhQUFhLFdBQVc7QUFDdEIsUUFBSSxVQUFVLFNBQVMsS0FBSyxRQUFRO0FBQ2xDLFlBQU0sSUFBSTtBQUFBLFFBQ1IsK0NBQStDLE1BQU0sU0FBUyxDQUFDO0FBQUEsUUFDL0Q7QUFBQSxVQUNFLE9BQU87QUFBQSxRQUNUO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSxXQUFPLFVBQVU7QUFBQSxFQUNuQjtBQUNGLENBQUM7QUFDRCxJQUFJLGlCQUFpQixJQUFJLGtCQUFrQjtBQUFBLEVBQ3pDLE1BQU07QUFBQSxFQUNOLGFBQWE7QUFBQSxFQUNiLFVBQVUsYUFBYTtBQUNyQixVQUFNLGVBQWUsZ0JBQWdCLFdBQVc7QUFDaEQsUUFBSSxPQUFPLGlCQUFpQixXQUFXO0FBQ3JDLGFBQU87QUFBQSxJQUNUO0FBQ0EsUUFBSSxPQUFPLFNBQVMsWUFBWSxHQUFHO0FBQ2pDLGFBQU8saUJBQWlCO0FBQUEsSUFDMUI7QUFDQSxVQUFNLElBQUk7QUFBQSxNQUNSLGlEQUFpRCxRQUFRLFlBQVksQ0FBQztBQUFBLElBQ3hFO0FBQUEsRUFDRjtBQUFBLEVBQ0EsV0FBVyxZQUFZO0FBQ3JCLFFBQUksT0FBTyxlQUFlLFdBQVc7QUFDbkMsWUFBTSxJQUFJO0FBQUEsUUFDUixpREFBaUQsUUFBUSxVQUFVLENBQUM7QUFBQSxNQUN0RTtBQUFBLElBQ0Y7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0EsYUFBYSxXQUFXO0FBQ3RCLFFBQUksVUFBVSxTQUFTLEtBQUssU0FBUztBQUNuQyxZQUFNLElBQUk7QUFBQSxRQUNSLGlEQUFpRCxNQUFNLFNBQVMsQ0FBQztBQUFBLFFBQ2pFO0FBQUEsVUFDRSxPQUFPO0FBQUEsUUFDVDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsV0FBTyxVQUFVO0FBQUEsRUFDbkI7QUFDRixDQUFDO0FBQ0QsSUFBSSxZQUFZLElBQUksa0JBQWtCO0FBQUEsRUFDcEMsTUFBTTtBQUFBLEVBQ04sYUFBYTtBQUFBLEVBQ2IsVUFBVSxhQUFhO0FBQ3JCLFVBQU0sZUFBZSxnQkFBZ0IsV0FBVztBQUNoRCxRQUFJLE9BQU8saUJBQWlCLFVBQVU7QUFDcEMsYUFBTztBQUFBLElBQ1Q7QUFDQSxRQUFJLE9BQU8sVUFBVSxZQUFZLEdBQUc7QUFDbEMsYUFBTyxPQUFPLFlBQVk7QUFBQSxJQUM1QjtBQUNBLFVBQU0sSUFBSTtBQUFBLE1BQ1IsOEJBQThCLFFBQVEsV0FBVyxDQUFDO0FBQUEsSUFDcEQ7QUFBQSxFQUNGO0FBQUEsRUFDQSxXQUFXLFlBQVk7QUFDckIsUUFBSSxPQUFPLGVBQWUsVUFBVTtBQUNsQyxhQUFPO0FBQUEsSUFDVDtBQUNBLFFBQUksT0FBTyxlQUFlLFlBQVksT0FBTyxVQUFVLFVBQVUsR0FBRztBQUNsRSxhQUFPLFdBQVcsU0FBUztBQUFBLElBQzdCO0FBQ0EsVUFBTSxJQUFJLGFBQWEsOEJBQThCLFFBQVEsVUFBVSxDQUFDLEVBQUU7QUFBQSxFQUM1RTtBQUFBLEVBQ0EsYUFBYSxXQUFXO0FBQ3RCLFFBQUksVUFBVSxTQUFTLEtBQUssVUFBVSxVQUFVLFNBQVMsS0FBSyxLQUFLO0FBQ2pFLFlBQU0sSUFBSTtBQUFBLFFBQ1IsNkRBQTZELE1BQU0sU0FBUztBQUFBLFFBQzVFO0FBQUEsVUFDRSxPQUFPO0FBQUEsUUFDVDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsV0FBTyxVQUFVO0FBQUEsRUFDbkI7QUFDRixDQUFDO0FBQ0QsSUFBSSx1QkFBdUIsT0FBTyxPQUFPO0FBQUEsRUFDdkM7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQ0YsQ0FBQztBQUNELFNBQVMsZ0JBQWdCLGFBQWE7QUFDcEMsTUFBSSxhQUFhLFdBQVcsR0FBRztBQUM3QixRQUFJLE9BQU8sWUFBWSxZQUFZLFlBQVk7QUFDN0MsWUFBTSxnQkFBZ0IsWUFBWSxRQUFRO0FBQzFDLFVBQUksQ0FBQyxhQUFhLGFBQWEsR0FBRztBQUNoQyxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFDQSxRQUFJLE9BQU8sWUFBWSxXQUFXLFlBQVk7QUFDNUMsYUFBTyxZQUFZLE9BQU87QUFBQSxJQUM1QjtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFHQSxJQUFJLG1CQUFtQixNQUFNO0FBQUEsRUFDM0IsWUFBWSxRQUFRO0FBQ2xCLFFBQUksc0JBQXNCO0FBQzFCLFNBQUssT0FBTyxXQUFXLE9BQU8sSUFBSTtBQUNsQyxTQUFLLGNBQWMsT0FBTztBQUMxQixTQUFLLFlBQVksT0FBTztBQUN4QixTQUFLLGdCQUFnQix1QkFBdUIsT0FBTyxrQkFBa0IsUUFBUSx5QkFBeUIsU0FBUyx1QkFBdUI7QUFDdEksU0FBSyxhQUFhLFNBQVMsT0FBTyxVQUFVO0FBQzVDLFNBQUssVUFBVSxPQUFPO0FBQ3RCLFVBQU0sUUFBUSxPQUFPLFNBQVMsS0FBSyxVQUFVLE9BQU8sSUFBSSxPQUFPLElBQUksOEJBQThCO0FBQ2pHLFVBQU0sUUFBUSxlQUFlLE9BQU8sVUFBVSxRQUFRLGlCQUFpQixTQUFTLGVBQWUsQ0FBQztBQUNoRyxpQkFBYSxJQUFJLEtBQUssQ0FBQyxNQUFNLFFBQVEsSUFBSSxLQUFLO0FBQUEsTUFDNUM7QUFBQSxNQUNBLElBQUksT0FBTyxJQUFJO0FBQUEsSUFDakI7QUFDQSxTQUFLLE9BQU8sZ0JBQWdCLElBQUk7QUFBQSxFQUNsQztBQUFBLEVBQ0EsS0FBSyxPQUFPLFdBQVcsSUFBSTtBQUN6QixXQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0EsV0FBVztBQUNULFdBQU87QUFBQSxNQUNMLE1BQU0sS0FBSztBQUFBLE1BQ1gsYUFBYSxLQUFLO0FBQUEsTUFDbEIsV0FBVyxLQUFLO0FBQUEsTUFDaEIsTUFBTSxpQkFBaUIsS0FBSyxJQUFJO0FBQUEsTUFDaEMsY0FBYyxLQUFLO0FBQUEsTUFDbkIsWUFBWSxLQUFLO0FBQUEsTUFDakIsU0FBUyxLQUFLO0FBQUEsSUFDaEI7QUFBQSxFQUNGO0FBQUEsRUFDQSxXQUFXO0FBQ1QsV0FBTyxNQUFNLEtBQUs7QUFBQSxFQUNwQjtBQUFBLEVBQ0EsU0FBUztBQUNQLFdBQU8sS0FBSyxTQUFTO0FBQUEsRUFDdkI7QUFDRjtBQUNBLElBQUksMEJBQTBCLElBQUksaUJBQWlCO0FBQUEsRUFDakQsTUFBTTtBQUFBLEVBQ04sYUFBYTtBQUFBLEVBQ2IsV0FBVztBQUFBLElBQ1Qsa0JBQWtCO0FBQUEsSUFDbEIsa0JBQWtCO0FBQUEsSUFDbEIsa0JBQWtCO0FBQUEsRUFDcEI7QUFBQSxFQUNBLE1BQU07QUFBQSxJQUNKLElBQUk7QUFBQSxNQUNGLE1BQU0sSUFBSSxlQUFlLGNBQWM7QUFBQSxNQUN2QyxhQUFhO0FBQUEsSUFDZjtBQUFBLEVBQ0Y7QUFDRixDQUFDO0FBQ0QsSUFBSSx1QkFBdUIsSUFBSSxpQkFBaUI7QUFBQSxFQUM5QyxNQUFNO0FBQUEsRUFDTixhQUFhO0FBQUEsRUFDYixXQUFXO0FBQUEsSUFDVCxrQkFBa0I7QUFBQSxJQUNsQixrQkFBa0I7QUFBQSxJQUNsQixrQkFBa0I7QUFBQSxFQUNwQjtBQUFBLEVBQ0EsTUFBTTtBQUFBLElBQ0osSUFBSTtBQUFBLE1BQ0YsTUFBTSxJQUFJLGVBQWUsY0FBYztBQUFBLE1BQ3ZDLGFBQWE7QUFBQSxJQUNmO0FBQUEsRUFDRjtBQUNGLENBQUM7QUFDRCxJQUFJLDZCQUE2QjtBQUNqQyxJQUFJLDZCQUE2QixJQUFJLGlCQUFpQjtBQUFBLEVBQ3BELE1BQU07QUFBQSxFQUNOLGFBQWE7QUFBQSxFQUNiLFdBQVc7QUFBQSxJQUNULGtCQUFrQjtBQUFBLElBQ2xCLGtCQUFrQjtBQUFBLElBQ2xCLGtCQUFrQjtBQUFBLElBQ2xCLGtCQUFrQjtBQUFBLEVBQ3BCO0FBQUEsRUFDQSxNQUFNO0FBQUEsSUFDSixRQUFRO0FBQUEsTUFDTixNQUFNO0FBQUEsTUFDTixhQUFhO0FBQUEsTUFDYixjQUFjO0FBQUEsSUFDaEI7QUFBQSxFQUNGO0FBQ0YsQ0FBQztBQUNELElBQUksOEJBQThCLElBQUksaUJBQWlCO0FBQUEsRUFDckQsTUFBTTtBQUFBLEVBQ04sYUFBYTtBQUFBLEVBQ2IsV0FBVyxDQUFDLGtCQUFrQixNQUFNO0FBQUEsRUFDcEMsTUFBTTtBQUFBLElBQ0osS0FBSztBQUFBLE1BQ0gsTUFBTSxJQUFJLGVBQWUsYUFBYTtBQUFBLE1BQ3RDLGFBQWE7QUFBQSxJQUNmO0FBQUEsRUFDRjtBQUNGLENBQUM7QUFDRCxJQUFJLHNCQUFzQixPQUFPLE9BQU87QUFBQSxFQUN0QztBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUNGLENBQUM7QUFHRCxTQUFTLGlCQUFpQixlQUFlO0FBQ3ZDLFNBQU8sT0FBTyxrQkFBa0IsWUFBWSxRQUFRLGtCQUFrQixRQUFRLGtCQUFrQixTQUFTLFNBQVMsY0FBYyxPQUFPLFFBQVEsT0FBTztBQUN4SjtBQUdBLFNBQVMsYUFBYSxPQUFPLE1BQU07QUFDakMsTUFBSSxjQUFjLElBQUksR0FBRztBQUN2QixVQUFNLFdBQVcsYUFBYSxPQUFPLEtBQUssTUFBTTtBQUNoRCxTQUFLLGFBQWEsUUFBUSxhQUFhLFNBQVMsU0FBUyxTQUFTLFVBQVUsS0FBSyxNQUFNO0FBQ3JGLGFBQU87QUFBQSxJQUNUO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDQSxNQUFJLFVBQVUsTUFBTTtBQUNsQixXQUFPO0FBQUEsTUFDTCxNQUFNLEtBQUs7QUFBQSxJQUNiO0FBQUEsRUFDRjtBQUNBLE1BQUksVUFBVSxRQUFRO0FBQ3BCLFdBQU87QUFBQSxFQUNUO0FBQ0EsTUFBSSxXQUFXLElBQUksR0FBRztBQUNwQixVQUFNLFdBQVcsS0FBSztBQUN0QixRQUFJLGlCQUFpQixLQUFLLEdBQUc7QUFDM0IsWUFBTSxjQUFjLENBQUM7QUFDckIsaUJBQVcsUUFBUSxPQUFPO0FBQ3hCLGNBQU0sV0FBVyxhQUFhLE1BQU0sUUFBUTtBQUM1QyxZQUFJLFlBQVksTUFBTTtBQUNwQixzQkFBWSxLQUFLLFFBQVE7QUFBQSxRQUMzQjtBQUFBLE1BQ0Y7QUFDQSxhQUFPO0FBQUEsUUFDTCxNQUFNLEtBQUs7QUFBQSxRQUNYLFFBQVE7QUFBQSxNQUNWO0FBQUEsSUFDRjtBQUNBLFdBQU8sYUFBYSxPQUFPLFFBQVE7QUFBQSxFQUNyQztBQUNBLE1BQUksa0JBQWtCLElBQUksR0FBRztBQUMzQixRQUFJLENBQUMsYUFBYSxLQUFLLEdBQUc7QUFDeEIsYUFBTztBQUFBLElBQ1Q7QUFDQSxVQUFNLGFBQWEsQ0FBQztBQUNwQixlQUFXLFNBQVMsT0FBTyxPQUFPLEtBQUssVUFBVSxDQUFDLEdBQUc7QUFDbkQsWUFBTSxhQUFhLGFBQWEsTUFBTSxNQUFNLElBQUksR0FBRyxNQUFNLElBQUk7QUFDN0QsVUFBSSxZQUFZO0FBQ2QsbUJBQVcsS0FBSztBQUFBLFVBQ2QsTUFBTSxLQUFLO0FBQUEsVUFDWCxNQUFNO0FBQUEsWUFDSixNQUFNLEtBQUs7QUFBQSxZQUNYLE9BQU8sTUFBTTtBQUFBLFVBQ2Y7QUFBQSxVQUNBLE9BQU87QUFBQSxRQUNULENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRjtBQUNBLFdBQU87QUFBQSxNQUNMLE1BQU0sS0FBSztBQUFBLE1BQ1gsUUFBUTtBQUFBLElBQ1Y7QUFBQSxFQUNGO0FBQ0EsTUFBSSxXQUFXLElBQUksR0FBRztBQUNwQixVQUFNLGFBQWEsS0FBSyxVQUFVLEtBQUs7QUFDdkMsUUFBSSxjQUFjLE1BQU07QUFDdEIsYUFBTztBQUFBLElBQ1Q7QUFDQSxRQUFJLE9BQU8sZUFBZSxXQUFXO0FBQ25DLGFBQU87QUFBQSxRQUNMLE1BQU0sS0FBSztBQUFBLFFBQ1gsT0FBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQ0EsUUFBSSxPQUFPLGVBQWUsWUFBWSxPQUFPLFNBQVMsVUFBVSxHQUFHO0FBQ2pFLFlBQU0sWUFBWSxPQUFPLFVBQVU7QUFDbkMsYUFBTyxvQkFBb0IsS0FBSyxTQUFTLElBQUk7QUFBQSxRQUMzQyxNQUFNLEtBQUs7QUFBQSxRQUNYLE9BQU87QUFBQSxNQUNULElBQUk7QUFBQSxRQUNGLE1BQU0sS0FBSztBQUFBLFFBQ1gsT0FBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQ0EsUUFBSSxPQUFPLGVBQWUsVUFBVTtBQUNsQyxVQUFJLFdBQVcsSUFBSSxHQUFHO0FBQ3BCLGVBQU87QUFBQSxVQUNMLE1BQU0sS0FBSztBQUFBLFVBQ1gsT0FBTztBQUFBLFFBQ1Q7QUFBQSxNQUNGO0FBQ0EsVUFBSSxTQUFTLGFBQWEsb0JBQW9CLEtBQUssVUFBVSxHQUFHO0FBQzlELGVBQU87QUFBQSxVQUNMLE1BQU0sS0FBSztBQUFBLFVBQ1gsT0FBTztBQUFBLFFBQ1Q7QUFBQSxNQUNGO0FBQ0EsYUFBTztBQUFBLFFBQ0wsTUFBTSxLQUFLO0FBQUEsUUFDWCxPQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFDQSxVQUFNLElBQUksVUFBVSxnQ0FBZ0MsUUFBUSxVQUFVLENBQUMsR0FBRztBQUFBLEVBQzVFO0FBQ0EsYUFBVyxPQUFPLDRCQUE0QixRQUFRLElBQUksQ0FBQztBQUM3RDtBQUNBLElBQUksc0JBQXNCO0FBRzFCLElBQUksV0FBVyxJQUFJLGtCQUFrQjtBQUFBLEVBQ25DLE1BQU07QUFBQSxFQUNOLGFBQWE7QUFBQSxFQUNiLFFBQVEsT0FBTztBQUFBLElBQ2IsYUFBYTtBQUFBLE1BQ1gsTUFBTTtBQUFBLE1BQ04sU0FBUyxDQUFDLFdBQVcsT0FBTztBQUFBLElBQzlCO0FBQUEsSUFDQSxPQUFPO0FBQUEsTUFDTCxhQUFhO0FBQUEsTUFDYixNQUFNLElBQUksZUFBZSxJQUFJLFlBQVksSUFBSSxlQUFlLE1BQU0sQ0FBQyxDQUFDO0FBQUEsTUFDcEUsUUFBUSxRQUFRO0FBQ2QsZUFBTyxPQUFPLE9BQU8sT0FBTyxXQUFXLENBQUM7QUFBQSxNQUMxQztBQUFBLElBQ0Y7QUFBQSxJQUNBLFdBQVc7QUFBQSxNQUNULGFBQWE7QUFBQSxNQUNiLE1BQU0sSUFBSSxlQUFlLE1BQU07QUFBQSxNQUMvQixTQUFTLENBQUMsV0FBVyxPQUFPLGFBQWE7QUFBQSxJQUMzQztBQUFBLElBQ0EsY0FBYztBQUFBLE1BQ1osYUFBYTtBQUFBLE1BQ2IsTUFBTTtBQUFBLE1BQ04sU0FBUyxDQUFDLFdBQVcsT0FBTyxnQkFBZ0I7QUFBQSxJQUM5QztBQUFBLElBQ0Esa0JBQWtCO0FBQUEsTUFDaEIsYUFBYTtBQUFBLE1BQ2IsTUFBTTtBQUFBLE1BQ04sU0FBUyxDQUFDLFdBQVcsT0FBTyxvQkFBb0I7QUFBQSxJQUNsRDtBQUFBLElBQ0EsWUFBWTtBQUFBLE1BQ1YsYUFBYTtBQUFBLE1BQ2IsTUFBTSxJQUFJO0FBQUEsUUFDUixJQUFJLFlBQVksSUFBSSxlQUFlLFdBQVcsQ0FBQztBQUFBLE1BQ2pEO0FBQUEsTUFDQSxTQUFTLENBQUMsV0FBVyxPQUFPLGNBQWM7QUFBQSxJQUM1QztBQUFBLEVBQ0Y7QUFDRixDQUFDO0FBQ0QsSUFBSSxjQUFjLElBQUksa0JBQWtCO0FBQUEsRUFDdEMsTUFBTTtBQUFBLEVBQ04sYUFBYTtBQUFBLEVBQ2IsUUFBUSxPQUFPO0FBQUEsSUFDYixNQUFNO0FBQUEsTUFDSixNQUFNLElBQUksZUFBZSxhQUFhO0FBQUEsTUFDdEMsU0FBUyxDQUFDLGNBQWMsVUFBVTtBQUFBLElBQ3BDO0FBQUEsSUFDQSxhQUFhO0FBQUEsTUFDWCxNQUFNO0FBQUEsTUFDTixTQUFTLENBQUMsY0FBYyxVQUFVO0FBQUEsSUFDcEM7QUFBQSxJQUNBLGNBQWM7QUFBQSxNQUNaLE1BQU0sSUFBSSxlQUFlLGNBQWM7QUFBQSxNQUN2QyxTQUFTLENBQUMsY0FBYyxVQUFVO0FBQUEsSUFDcEM7QUFBQSxJQUNBLFdBQVc7QUFBQSxNQUNULE1BQU0sSUFBSTtBQUFBLFFBQ1IsSUFBSSxZQUFZLElBQUksZUFBZSxtQkFBbUIsQ0FBQztBQUFBLE1BQ3pEO0FBQUEsTUFDQSxTQUFTLENBQUMsY0FBYyxVQUFVO0FBQUEsSUFDcEM7QUFBQSxJQUNBLE1BQU07QUFBQSxNQUNKLE1BQU0sSUFBSTtBQUFBLFFBQ1IsSUFBSSxZQUFZLElBQUksZUFBZSxZQUFZLENBQUM7QUFBQSxNQUNsRDtBQUFBLE1BQ0EsTUFBTTtBQUFBLFFBQ0osbUJBQW1CO0FBQUEsVUFDakIsTUFBTTtBQUFBLFVBQ04sY0FBYztBQUFBLFFBQ2hCO0FBQUEsTUFDRjtBQUFBLE1BQ0EsUUFBUSxPQUFPLEVBQUUsa0JBQWtCLEdBQUc7QUFDcEMsZUFBTyxvQkFBb0IsTUFBTSxPQUFPLE1BQU0sS0FBSyxPQUFPLENBQUMsUUFBUSxJQUFJLHFCQUFxQixJQUFJO0FBQUEsTUFDbEc7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGLENBQUM7QUFDRCxJQUFJLHNCQUFzQixJQUFJLGdCQUFnQjtBQUFBLEVBQzVDLE1BQU07QUFBQSxFQUNOLGFBQWE7QUFBQSxFQUNiLFFBQVE7QUFBQSxJQUNOLE9BQU87QUFBQSxNQUNMLE9BQU8sa0JBQWtCO0FBQUEsTUFDekIsYUFBYTtBQUFBLElBQ2Y7QUFBQSxJQUNBLFVBQVU7QUFBQSxNQUNSLE9BQU8sa0JBQWtCO0FBQUEsTUFDekIsYUFBYTtBQUFBLElBQ2Y7QUFBQSxJQUNBLGNBQWM7QUFBQSxNQUNaLE9BQU8sa0JBQWtCO0FBQUEsTUFDekIsYUFBYTtBQUFBLElBQ2Y7QUFBQSxJQUNBLE9BQU87QUFBQSxNQUNMLE9BQU8sa0JBQWtCO0FBQUEsTUFDekIsYUFBYTtBQUFBLElBQ2Y7QUFBQSxJQUNBLHFCQUFxQjtBQUFBLE1BQ25CLE9BQU8sa0JBQWtCO0FBQUEsTUFDekIsYUFBYTtBQUFBLElBQ2Y7QUFBQSxJQUNBLGlCQUFpQjtBQUFBLE1BQ2YsT0FBTyxrQkFBa0I7QUFBQSxNQUN6QixhQUFhO0FBQUEsSUFDZjtBQUFBLElBQ0EsaUJBQWlCO0FBQUEsTUFDZixPQUFPLGtCQUFrQjtBQUFBLE1BQ3pCLGFBQWE7QUFBQSxJQUNmO0FBQUEsSUFDQSxxQkFBcUI7QUFBQSxNQUNuQixPQUFPLGtCQUFrQjtBQUFBLE1BQ3pCLGFBQWE7QUFBQSxJQUNmO0FBQUEsSUFDQSxRQUFRO0FBQUEsTUFDTixPQUFPLGtCQUFrQjtBQUFBLE1BQ3pCLGFBQWE7QUFBQSxJQUNmO0FBQUEsSUFDQSxRQUFRO0FBQUEsTUFDTixPQUFPLGtCQUFrQjtBQUFBLE1BQ3pCLGFBQWE7QUFBQSxJQUNmO0FBQUEsSUFDQSxRQUFRO0FBQUEsTUFDTixPQUFPLGtCQUFrQjtBQUFBLE1BQ3pCLGFBQWE7QUFBQSxJQUNmO0FBQUEsSUFDQSxrQkFBa0I7QUFBQSxNQUNoQixPQUFPLGtCQUFrQjtBQUFBLE1BQ3pCLGFBQWE7QUFBQSxJQUNmO0FBQUEsSUFDQSxxQkFBcUI7QUFBQSxNQUNuQixPQUFPLGtCQUFrQjtBQUFBLE1BQ3pCLGFBQWE7QUFBQSxJQUNmO0FBQUEsSUFDQSxXQUFXO0FBQUEsTUFDVCxPQUFPLGtCQUFrQjtBQUFBLE1BQ3pCLGFBQWE7QUFBQSxJQUNmO0FBQUEsSUFDQSxPQUFPO0FBQUEsTUFDTCxPQUFPLGtCQUFrQjtBQUFBLE1BQ3pCLGFBQWE7QUFBQSxJQUNmO0FBQUEsSUFDQSxNQUFNO0FBQUEsTUFDSixPQUFPLGtCQUFrQjtBQUFBLE1BQ3pCLGFBQWE7QUFBQSxJQUNmO0FBQUEsSUFDQSxZQUFZO0FBQUEsTUFDVixPQUFPLGtCQUFrQjtBQUFBLE1BQ3pCLGFBQWE7QUFBQSxJQUNmO0FBQUEsSUFDQSxjQUFjO0FBQUEsTUFDWixPQUFPLGtCQUFrQjtBQUFBLE1BQ3pCLGFBQWE7QUFBQSxJQUNmO0FBQUEsSUFDQSx3QkFBd0I7QUFBQSxNQUN0QixPQUFPLGtCQUFrQjtBQUFBLE1BQ3pCLGFBQWE7QUFBQSxJQUNmO0FBQUEsRUFDRjtBQUNGLENBQUM7QUFDRCxJQUFJLFNBQVMsSUFBSSxrQkFBa0I7QUFBQSxFQUNqQyxNQUFNO0FBQUEsRUFDTixhQUFhO0FBQUEsRUFDYixRQUFRLE9BQU87QUFBQSxJQUNiLE1BQU07QUFBQSxNQUNKLE1BQU0sSUFBSSxlQUFlLFVBQVU7QUFBQSxNQUNuQyxRQUFRLE1BQU07QUFDWixZQUFJLGFBQWEsSUFBSSxHQUFHO0FBQ3RCLGlCQUFPLFNBQVM7QUFBQSxRQUNsQjtBQUNBLFlBQUksYUFBYSxJQUFJLEdBQUc7QUFDdEIsaUJBQU8sU0FBUztBQUFBLFFBQ2xCO0FBQ0EsWUFBSSxnQkFBZ0IsSUFBSSxHQUFHO0FBQ3pCLGlCQUFPLFNBQVM7QUFBQSxRQUNsQjtBQUNBLFlBQUksWUFBWSxJQUFJLEdBQUc7QUFDckIsaUJBQU8sU0FBUztBQUFBLFFBQ2xCO0FBQ0EsWUFBSSxXQUFXLElBQUksR0FBRztBQUNwQixpQkFBTyxTQUFTO0FBQUEsUUFDbEI7QUFDQSxZQUFJLGtCQUFrQixJQUFJLEdBQUc7QUFDM0IsaUJBQU8sU0FBUztBQUFBLFFBQ2xCO0FBQ0EsWUFBSSxXQUFXLElBQUksR0FBRztBQUNwQixpQkFBTyxTQUFTO0FBQUEsUUFDbEI7QUFDQSxZQUFJLGNBQWMsSUFBSSxHQUFHO0FBQ3ZCLGlCQUFPLFNBQVM7QUFBQSxRQUNsQjtBQUNBLG1CQUFXLE9BQU8scUJBQXFCLFFBQVEsSUFBSSxDQUFDLElBQUk7QUFBQSxNQUMxRDtBQUFBLElBQ0Y7QUFBQSxJQUNBLE1BQU07QUFBQSxNQUNKLE1BQU07QUFBQSxNQUNOLFNBQVMsQ0FBQyxTQUFTLFVBQVUsT0FBTyxLQUFLLE9BQU87QUFBQSxJQUNsRDtBQUFBLElBQ0EsYUFBYTtBQUFBLE1BQ1gsTUFBTTtBQUFBLE1BQ04sU0FBUyxDQUFDO0FBQUE7QUFBQSxRQUVSLGlCQUFpQixPQUFPLEtBQUssY0FBYztBQUFBO0FBQUEsSUFFL0M7QUFBQSxJQUNBLGdCQUFnQjtBQUFBLE1BQ2QsTUFBTTtBQUFBLE1BQ04sU0FBUyxDQUFDLFFBQVEsb0JBQW9CLE1BQU0sSUFBSSxpQkFBaUI7QUFBQSxJQUNuRTtBQUFBLElBQ0EsUUFBUTtBQUFBLE1BQ04sTUFBTSxJQUFJLFlBQVksSUFBSSxlQUFlLE9BQU8sQ0FBQztBQUFBLE1BQ2pELE1BQU07QUFBQSxRQUNKLG1CQUFtQjtBQUFBLFVBQ2pCLE1BQU07QUFBQSxVQUNOLGNBQWM7QUFBQSxRQUNoQjtBQUFBLE1BQ0Y7QUFBQSxNQUNBLFFBQVEsTUFBTSxFQUFFLGtCQUFrQixHQUFHO0FBQ25DLFlBQUksYUFBYSxJQUFJLEtBQUssZ0JBQWdCLElBQUksR0FBRztBQUMvQyxnQkFBTSxTQUFTLE9BQU8sT0FBTyxLQUFLLFVBQVUsQ0FBQztBQUM3QyxpQkFBTyxvQkFBb0IsU0FBUyxPQUFPLE9BQU8sQ0FBQyxVQUFVLE1BQU0scUJBQXFCLElBQUk7QUFBQSxRQUM5RjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsSUFDQSxZQUFZO0FBQUEsTUFDVixNQUFNLElBQUksWUFBWSxJQUFJLGVBQWUsTUFBTSxDQUFDO0FBQUEsTUFDaEQsUUFBUSxNQUFNO0FBQ1osWUFBSSxhQUFhLElBQUksS0FBSyxnQkFBZ0IsSUFBSSxHQUFHO0FBQy9DLGlCQUFPLEtBQUssY0FBYztBQUFBLFFBQzVCO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxJQUNBLGVBQWU7QUFBQSxNQUNiLE1BQU0sSUFBSSxZQUFZLElBQUksZUFBZSxNQUFNLENBQUM7QUFBQSxNQUNoRCxRQUFRLE1BQU0sT0FBTyxVQUFVLEVBQUUsT0FBTyxHQUFHO0FBQ3pDLFlBQUksZUFBZSxJQUFJLEdBQUc7QUFDeEIsaUJBQU8sT0FBTyxpQkFBaUIsSUFBSTtBQUFBLFFBQ3JDO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxJQUNBLFlBQVk7QUFBQSxNQUNWLE1BQU0sSUFBSSxZQUFZLElBQUksZUFBZSxXQUFXLENBQUM7QUFBQSxNQUNyRCxNQUFNO0FBQUEsUUFDSixtQkFBbUI7QUFBQSxVQUNqQixNQUFNO0FBQUEsVUFDTixjQUFjO0FBQUEsUUFDaEI7QUFBQSxNQUNGO0FBQUEsTUFDQSxRQUFRLE1BQU0sRUFBRSxrQkFBa0IsR0FBRztBQUNuQyxZQUFJLFdBQVcsSUFBSSxHQUFHO0FBQ3BCLGdCQUFNLFNBQVMsS0FBSyxVQUFVO0FBQzlCLGlCQUFPLG9CQUFvQixTQUFTLE9BQU8sT0FBTyxDQUFDLFVBQVUsTUFBTSxxQkFBcUIsSUFBSTtBQUFBLFFBQzlGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxJQUNBLGFBQWE7QUFBQSxNQUNYLE1BQU0sSUFBSSxZQUFZLElBQUksZUFBZSxZQUFZLENBQUM7QUFBQSxNQUN0RCxNQUFNO0FBQUEsUUFDSixtQkFBbUI7QUFBQSxVQUNqQixNQUFNO0FBQUEsVUFDTixjQUFjO0FBQUEsUUFDaEI7QUFBQSxNQUNGO0FBQUEsTUFDQSxRQUFRLE1BQU0sRUFBRSxrQkFBa0IsR0FBRztBQUNuQyxZQUFJLGtCQUFrQixJQUFJLEdBQUc7QUFDM0IsZ0JBQU0sU0FBUyxPQUFPLE9BQU8sS0FBSyxVQUFVLENBQUM7QUFDN0MsaUJBQU8sb0JBQW9CLFNBQVMsT0FBTyxPQUFPLENBQUMsVUFBVSxNQUFNLHFCQUFxQixJQUFJO0FBQUEsUUFDOUY7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLElBQ0EsUUFBUTtBQUFBLE1BQ04sTUFBTTtBQUFBLE1BQ04sU0FBUyxDQUFDLFNBQVMsWUFBWSxPQUFPLEtBQUssU0FBUztBQUFBLElBQ3REO0FBQUEsRUFDRjtBQUNGLENBQUM7QUFDRCxJQUFJLFVBQVUsSUFBSSxrQkFBa0I7QUFBQSxFQUNsQyxNQUFNO0FBQUEsRUFDTixhQUFhO0FBQUEsRUFDYixRQUFRLE9BQU87QUFBQSxJQUNiLE1BQU07QUFBQSxNQUNKLE1BQU0sSUFBSSxlQUFlLGFBQWE7QUFBQSxNQUN0QyxTQUFTLENBQUMsVUFBVSxNQUFNO0FBQUEsSUFDNUI7QUFBQSxJQUNBLGFBQWE7QUFBQSxNQUNYLE1BQU07QUFBQSxNQUNOLFNBQVMsQ0FBQyxVQUFVLE1BQU07QUFBQSxJQUM1QjtBQUFBLElBQ0EsTUFBTTtBQUFBLE1BQ0osTUFBTSxJQUFJO0FBQUEsUUFDUixJQUFJLFlBQVksSUFBSSxlQUFlLFlBQVksQ0FBQztBQUFBLE1BQ2xEO0FBQUEsTUFDQSxNQUFNO0FBQUEsUUFDSixtQkFBbUI7QUFBQSxVQUNqQixNQUFNO0FBQUEsVUFDTixjQUFjO0FBQUEsUUFDaEI7QUFBQSxNQUNGO0FBQUEsTUFDQSxRQUFRLE9BQU8sRUFBRSxrQkFBa0IsR0FBRztBQUNwQyxlQUFPLG9CQUFvQixNQUFNLE9BQU8sTUFBTSxLQUFLLE9BQU8sQ0FBQyxRQUFRLElBQUkscUJBQXFCLElBQUk7QUFBQSxNQUNsRztBQUFBLElBQ0Y7QUFBQSxJQUNBLE1BQU07QUFBQSxNQUNKLE1BQU0sSUFBSSxlQUFlLE1BQU07QUFBQSxNQUMvQixTQUFTLENBQUMsVUFBVSxNQUFNO0FBQUEsSUFDNUI7QUFBQSxJQUNBLGNBQWM7QUFBQSxNQUNaLE1BQU0sSUFBSSxlQUFlLGNBQWM7QUFBQSxNQUN2QyxTQUFTLENBQUMsVUFBVSxNQUFNLHFCQUFxQjtBQUFBLElBQ2pEO0FBQUEsSUFDQSxtQkFBbUI7QUFBQSxNQUNqQixNQUFNO0FBQUEsTUFDTixTQUFTLENBQUMsVUFBVSxNQUFNO0FBQUEsSUFDNUI7QUFBQSxFQUNGO0FBQ0YsQ0FBQztBQUNELElBQUksZUFBZSxJQUFJLGtCQUFrQjtBQUFBLEVBQ3ZDLE1BQU07QUFBQSxFQUNOLGFBQWE7QUFBQSxFQUNiLFFBQVEsT0FBTztBQUFBLElBQ2IsTUFBTTtBQUFBLE1BQ0osTUFBTSxJQUFJLGVBQWUsYUFBYTtBQUFBLE1BQ3RDLFNBQVMsQ0FBQyxlQUFlLFdBQVc7QUFBQSxJQUN0QztBQUFBLElBQ0EsYUFBYTtBQUFBLE1BQ1gsTUFBTTtBQUFBLE1BQ04sU0FBUyxDQUFDLGVBQWUsV0FBVztBQUFBLElBQ3RDO0FBQUEsSUFDQSxNQUFNO0FBQUEsTUFDSixNQUFNLElBQUksZUFBZSxNQUFNO0FBQUEsTUFDL0IsU0FBUyxDQUFDLGVBQWUsV0FBVztBQUFBLElBQ3RDO0FBQUEsSUFDQSxjQUFjO0FBQUEsTUFDWixNQUFNO0FBQUEsTUFDTixhQUFhO0FBQUEsTUFDYixRQUFRLFlBQVk7QUFDbEIsY0FBTSxFQUFFLE1BQU0sYUFBYSxJQUFJO0FBQy9CLGNBQU0sV0FBVyxhQUFhLGNBQWMsSUFBSTtBQUNoRCxlQUFPLFdBQVcsTUFBTSxRQUFRLElBQUk7QUFBQSxNQUN0QztBQUFBLElBQ0Y7QUFBQSxJQUNBLGNBQWM7QUFBQSxNQUNaLE1BQU0sSUFBSSxlQUFlLGNBQWM7QUFBQSxNQUN2QyxTQUFTLENBQUMsVUFBVSxNQUFNLHFCQUFxQjtBQUFBLElBQ2pEO0FBQUEsSUFDQSxtQkFBbUI7QUFBQSxNQUNqQixNQUFNO0FBQUEsTUFDTixTQUFTLENBQUMsUUFBUSxJQUFJO0FBQUEsSUFDeEI7QUFBQSxFQUNGO0FBQ0YsQ0FBQztBQUNELElBQUksY0FBYyxJQUFJLGtCQUFrQjtBQUFBLEVBQ3RDLE1BQU07QUFBQSxFQUNOLGFBQWE7QUFBQSxFQUNiLFFBQVEsT0FBTztBQUFBLElBQ2IsTUFBTTtBQUFBLE1BQ0osTUFBTSxJQUFJLGVBQWUsYUFBYTtBQUFBLE1BQ3RDLFNBQVMsQ0FBQyxjQUFjLFVBQVU7QUFBQSxJQUNwQztBQUFBLElBQ0EsYUFBYTtBQUFBLE1BQ1gsTUFBTTtBQUFBLE1BQ04sU0FBUyxDQUFDLGNBQWMsVUFBVTtBQUFBLElBQ3BDO0FBQUEsSUFDQSxjQUFjO0FBQUEsTUFDWixNQUFNLElBQUksZUFBZSxjQUFjO0FBQUEsTUFDdkMsU0FBUyxDQUFDLGNBQWMsVUFBVSxxQkFBcUI7QUFBQSxJQUN6RDtBQUFBLElBQ0EsbUJBQW1CO0FBQUEsTUFDakIsTUFBTTtBQUFBLE1BQ04sU0FBUyxDQUFDLGNBQWMsVUFBVTtBQUFBLElBQ3BDO0FBQUEsRUFDRjtBQUNGLENBQUM7QUFDRCxJQUFJO0FBQUEsQ0FDSCxTQUFTLFdBQVc7QUFDbkIsWUFBVSxRQUFRLElBQUk7QUFDdEIsWUFBVSxRQUFRLElBQUk7QUFDdEIsWUFBVSxXQUFXLElBQUk7QUFDekIsWUFBVSxPQUFPLElBQUk7QUFDckIsWUFBVSxNQUFNLElBQUk7QUFDcEIsWUFBVSxjQUFjLElBQUk7QUFDNUIsWUFBVSxNQUFNLElBQUk7QUFDcEIsWUFBVSxVQUFVLElBQUk7QUFDMUIsR0FBRyxhQUFhLFdBQVcsQ0FBQyxFQUFFO0FBQzlCLElBQUksYUFBYSxJQUFJLGdCQUFnQjtBQUFBLEVBQ25DLE1BQU07QUFBQSxFQUNOLGFBQWE7QUFBQSxFQUNiLFFBQVE7QUFBQSxJQUNOLFFBQVE7QUFBQSxNQUNOLE9BQU8sU0FBUztBQUFBLE1BQ2hCLGFBQWE7QUFBQSxJQUNmO0FBQUEsSUFDQSxRQUFRO0FBQUEsTUFDTixPQUFPLFNBQVM7QUFBQSxNQUNoQixhQUFhO0FBQUEsSUFDZjtBQUFBLElBQ0EsV0FBVztBQUFBLE1BQ1QsT0FBTyxTQUFTO0FBQUEsTUFDaEIsYUFBYTtBQUFBLElBQ2Y7QUFBQSxJQUNBLE9BQU87QUFBQSxNQUNMLE9BQU8sU0FBUztBQUFBLE1BQ2hCLGFBQWE7QUFBQSxJQUNmO0FBQUEsSUFDQSxNQUFNO0FBQUEsTUFDSixPQUFPLFNBQVM7QUFBQSxNQUNoQixhQUFhO0FBQUEsSUFDZjtBQUFBLElBQ0EsY0FBYztBQUFBLE1BQ1osT0FBTyxTQUFTO0FBQUEsTUFDaEIsYUFBYTtBQUFBLElBQ2Y7QUFBQSxJQUNBLE1BQU07QUFBQSxNQUNKLE9BQU8sU0FBUztBQUFBLE1BQ2hCLGFBQWE7QUFBQSxJQUNmO0FBQUEsSUFDQSxVQUFVO0FBQUEsTUFDUixPQUFPLFNBQVM7QUFBQSxNQUNoQixhQUFhO0FBQUEsSUFDZjtBQUFBLEVBQ0Y7QUFDRixDQUFDO0FBQ0QsSUFBSSxxQkFBcUI7QUFBQSxFQUN2QixNQUFNO0FBQUEsRUFDTixNQUFNLElBQUksZUFBZSxRQUFRO0FBQUEsRUFDakMsYUFBYTtBQUFBLEVBQ2IsTUFBTSxDQUFDO0FBQUEsRUFDUCxTQUFTLENBQUMsU0FBUyxPQUFPLFVBQVUsRUFBRSxPQUFPLE1BQU07QUFBQSxFQUNuRCxtQkFBbUI7QUFBQSxFQUNuQixZQUE0Qix1QkFBTyxPQUFPLElBQUk7QUFBQSxFQUM5QyxTQUFTO0FBQ1g7QUFDQSxJQUFJLG1CQUFtQjtBQUFBLEVBQ3JCLE1BQU07QUFBQSxFQUNOLE1BQU07QUFBQSxFQUNOLGFBQWE7QUFBQSxFQUNiLE1BQU07QUFBQSxJQUNKO0FBQUEsTUFDRSxNQUFNO0FBQUEsTUFDTixhQUFhO0FBQUEsTUFDYixNQUFNLElBQUksZUFBZSxhQUFhO0FBQUEsTUFDdEMsY0FBYztBQUFBLE1BQ2QsbUJBQW1CO0FBQUEsTUFDbkIsWUFBNEIsdUJBQU8sT0FBTyxJQUFJO0FBQUEsTUFDOUMsU0FBUztBQUFBLElBQ1g7QUFBQSxFQUNGO0FBQUEsRUFDQSxTQUFTLENBQUMsU0FBUyxFQUFFLEtBQUssR0FBRyxVQUFVLEVBQUUsT0FBTyxNQUFNLE9BQU8sUUFBUSxJQUFJO0FBQUEsRUFDekUsbUJBQW1CO0FBQUEsRUFDbkIsWUFBNEIsdUJBQU8sT0FBTyxJQUFJO0FBQUEsRUFDOUMsU0FBUztBQUNYO0FBQ0EsSUFBSSx1QkFBdUI7QUFBQSxFQUN6QixNQUFNO0FBQUEsRUFDTixNQUFNLElBQUksZUFBZSxhQUFhO0FBQUEsRUFDdEMsYUFBYTtBQUFBLEVBQ2IsTUFBTSxDQUFDO0FBQUEsRUFDUCxTQUFTLENBQUMsU0FBUyxPQUFPLFVBQVUsRUFBRSxXQUFXLE1BQU0sV0FBVztBQUFBLEVBQ2xFLG1CQUFtQjtBQUFBLEVBQ25CLFlBQTRCLHVCQUFPLE9BQU8sSUFBSTtBQUFBLEVBQzlDLFNBQVM7QUFDWDtBQUNBLElBQUkscUJBQXFCLE9BQU8sT0FBTztBQUFBLEVBQ3JDO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUNGLENBQUM7QUFHRCxTQUFTLFlBQVksUUFBUSxVQUFVO0FBQ3JDLFVBQVEsU0FBUyxNQUFNO0FBQUEsSUFDckIsS0FBSyxLQUFLLFdBQVc7QUFDbkIsWUFBTSxZQUFZLFlBQVksUUFBUSxTQUFTLElBQUk7QUFDbkQsYUFBTyxhQUFhLElBQUksWUFBWSxTQUFTO0FBQUEsSUFDL0M7QUFBQSxJQUNBLEtBQUssS0FBSyxlQUFlO0FBQ3ZCLFlBQU0sWUFBWSxZQUFZLFFBQVEsU0FBUyxJQUFJO0FBQ25ELGFBQU8sYUFBYSxJQUFJLGVBQWUsU0FBUztBQUFBLElBQ2xEO0FBQUEsSUFDQSxLQUFLLEtBQUs7QUFDUixhQUFPLE9BQU8sUUFBUSxTQUFTLEtBQUssS0FBSztBQUFBLEVBQzdDO0FBQ0Y7QUFHQSxTQUFTLDJCQUEyQixNQUFNO0FBQ3hDLFNBQU8sS0FBSyxTQUFTLEtBQUssd0JBQXdCLEtBQUssU0FBUyxLQUFLO0FBQ3ZFO0FBQ0EsU0FBUywyQkFBMkIsTUFBTTtBQUN4QyxTQUFPLEtBQUssU0FBUyxLQUFLLHFCQUFxQixxQkFBcUIsSUFBSSxLQUFLLEtBQUssU0FBUyxLQUFLO0FBQ2xHO0FBQ0EsU0FBUyxxQkFBcUIsTUFBTTtBQUNsQyxTQUFPLEtBQUssU0FBUyxLQUFLLDBCQUEwQixLQUFLLFNBQVMsS0FBSywwQkFBMEIsS0FBSyxTQUFTLEtBQUssNkJBQTZCLEtBQUssU0FBUyxLQUFLLHlCQUF5QixLQUFLLFNBQVMsS0FBSyx3QkFBd0IsS0FBSyxTQUFTLEtBQUs7QUFDN1A7QUFDQSxTQUFTLDBCQUEwQixNQUFNO0FBQ3ZDLFNBQU8sS0FBSyxTQUFTLEtBQUssb0JBQW9CLG9CQUFvQixJQUFJO0FBQ3hFO0FBQ0EsU0FBUyxvQkFBb0IsTUFBTTtBQUNqQyxTQUFPLEtBQUssU0FBUyxLQUFLLHlCQUF5QixLQUFLLFNBQVMsS0FBSyx5QkFBeUIsS0FBSyxTQUFTLEtBQUssNEJBQTRCLEtBQUssU0FBUyxLQUFLLHdCQUF3QixLQUFLLFNBQVMsS0FBSyx1QkFBdUIsS0FBSyxTQUFTLEtBQUs7QUFDeFA7QUFHQSxTQUFTLDBCQUEwQixTQUFTO0FBQzFDLFNBQU87QUFBQSxJQUNMLFNBQVMsTUFBTTtBQUNiLGlCQUFXLGNBQWMsS0FBSyxhQUFhO0FBQ3pDLFlBQUksQ0FBQywyQkFBMkIsVUFBVSxHQUFHO0FBQzNDLGdCQUFNLFVBQVUsV0FBVyxTQUFTLEtBQUsscUJBQXFCLFdBQVcsU0FBUyxLQUFLLG1CQUFtQixXQUFXLE1BQU0sV0FBVyxLQUFLLFFBQVE7QUFDbkosa0JBQVE7QUFBQSxZQUNOLElBQUksYUFBYSxPQUFPLE9BQU8sa0NBQWtDO0FBQUEsY0FDL0QsT0FBTztBQUFBLFlBQ1QsQ0FBQztBQUFBLFVBQ0g7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUNGO0FBR0EsU0FBUyx3QkFBd0IsU0FBUztBQUN4QyxTQUFPO0FBQUEsSUFDTCxNQUFNLE1BQU07QUFDVixZQUFNLE9BQU8sUUFBUSxjQUFjO0FBQ25DLFVBQUksTUFBTTtBQUNSLGNBQU0sV0FBVyxRQUFRLFlBQVk7QUFDckMsWUFBSSxDQUFDLFVBQVU7QUFDYixnQkFBTSxTQUFTLFFBQVEsVUFBVTtBQUNqQyxnQkFBTSxZQUFZLEtBQUssS0FBSztBQUM1QixjQUFJLGFBQWE7QUFBQSxZQUNmO0FBQUEsWUFDQSxzQkFBc0IsUUFBUSxNQUFNLFNBQVM7QUFBQSxVQUMvQztBQUNBLGNBQUksZUFBZSxJQUFJO0FBQ3JCLHlCQUFhLFdBQVcsdUJBQXVCLE1BQU0sU0FBUyxDQUFDO0FBQUEsVUFDakU7QUFDQSxrQkFBUTtBQUFBLFlBQ04sSUFBSTtBQUFBLGNBQ0YsdUJBQXVCLFNBQVMsY0FBYyxLQUFLLElBQUksT0FBTztBQUFBLGNBQzlEO0FBQUEsZ0JBQ0UsT0FBTztBQUFBLGNBQ1Q7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUNBLFNBQVMsc0JBQXNCLFFBQVEsTUFBTSxXQUFXO0FBQ3RELE1BQUksQ0FBQyxlQUFlLElBQUksR0FBRztBQUN6QixXQUFPLENBQUM7QUFBQSxFQUNWO0FBQ0EsUUFBTSxpQkFBaUMsb0JBQUksSUFBSTtBQUMvQyxRQUFNLGFBQTZCLHVCQUFPLE9BQU8sSUFBSTtBQUNyRCxhQUFXLGdCQUFnQixPQUFPLGlCQUFpQixJQUFJLEdBQUc7QUFDeEQsUUFBSSxDQUFDLGFBQWEsVUFBVSxFQUFFLFNBQVMsR0FBRztBQUN4QztBQUFBLElBQ0Y7QUFDQSxtQkFBZSxJQUFJLFlBQVk7QUFDL0IsZUFBVyxhQUFhLElBQUksSUFBSTtBQUNoQyxlQUFXLHFCQUFxQixhQUFhLGNBQWMsR0FBRztBQUM1RCxVQUFJO0FBQ0osVUFBSSxDQUFDLGtCQUFrQixVQUFVLEVBQUUsU0FBUyxHQUFHO0FBQzdDO0FBQUEsTUFDRjtBQUNBLHFCQUFlLElBQUksaUJBQWlCO0FBQ3BDLGlCQUFXLGtCQUFrQixJQUFJLE1BQU0sd0JBQXdCLFdBQVcsa0JBQWtCLElBQUksT0FBTyxRQUFRLDBCQUEwQixTQUFTLHdCQUF3QixLQUFLO0FBQUEsSUFDakw7QUFBQSxFQUNGO0FBQ0EsU0FBTyxDQUFDLEdBQUcsY0FBYyxFQUFFLEtBQUssQ0FBQyxPQUFPLFVBQVU7QUFDaEQsVUFBTSxpQkFBaUIsV0FBVyxNQUFNLElBQUksSUFBSSxXQUFXLE1BQU0sSUFBSTtBQUNyRSxRQUFJLG1CQUFtQixHQUFHO0FBQ3hCLGFBQU87QUFBQSxJQUNUO0FBQ0EsUUFBSSxnQkFBZ0IsS0FBSyxLQUFLLE9BQU8sVUFBVSxPQUFPLEtBQUssR0FBRztBQUM1RCxhQUFPO0FBQUEsSUFDVDtBQUNBLFFBQUksZ0JBQWdCLEtBQUssS0FBSyxPQUFPLFVBQVUsT0FBTyxLQUFLLEdBQUc7QUFDNUQsYUFBTztBQUFBLElBQ1Q7QUFDQSxXQUFPLGVBQWUsTUFBTSxNQUFNLE1BQU0sSUFBSTtBQUFBLEVBQzlDLENBQUMsRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUk7QUFDdEI7QUFDQSxTQUFTLHVCQUF1QixNQUFNLFdBQVc7QUFDL0MsTUFBSSxhQUFhLElBQUksS0FBSyxnQkFBZ0IsSUFBSSxHQUFHO0FBQy9DLFVBQU0scUJBQXFCLE9BQU8sS0FBSyxLQUFLLFVBQVUsQ0FBQztBQUN2RCxXQUFPLGVBQWUsV0FBVyxrQkFBa0I7QUFBQSxFQUNyRDtBQUNBLFNBQU8sQ0FBQztBQUNWO0FBR0EsU0FBUyw4QkFBOEIsU0FBUztBQUM5QyxTQUFPO0FBQUEsSUFDTCxlQUFlLE1BQU07QUFDbkIsWUFBTSxnQkFBZ0IsS0FBSztBQUMzQixVQUFJLGVBQWU7QUFDakIsY0FBTSxPQUFPLFlBQVksUUFBUSxVQUFVLEdBQUcsYUFBYTtBQUMzRCxZQUFJLFFBQVEsQ0FBQyxnQkFBZ0IsSUFBSSxHQUFHO0FBQ2xDLGdCQUFNLFVBQVUsTUFBTSxhQUFhO0FBQ25DLGtCQUFRO0FBQUEsWUFDTixJQUFJO0FBQUEsY0FDRixvREFBb0QsT0FBTztBQUFBLGNBQzNEO0FBQUEsZ0JBQ0UsT0FBTztBQUFBLGNBQ1Q7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLElBQ0EsbUJBQW1CLE1BQU07QUFDdkIsWUFBTSxPQUFPLFlBQVksUUFBUSxVQUFVLEdBQUcsS0FBSyxhQUFhO0FBQ2hFLFVBQUksUUFBUSxDQUFDLGdCQUFnQixJQUFJLEdBQUc7QUFDbEMsY0FBTSxVQUFVLE1BQU0sS0FBSyxhQUFhO0FBQ3hDLGdCQUFRO0FBQUEsVUFDTixJQUFJO0FBQUEsWUFDRixhQUFhLEtBQUssS0FBSyxLQUFLLDZDQUE2QyxPQUFPO0FBQUEsWUFDaEY7QUFBQSxjQUNFLE9BQU8sS0FBSztBQUFBLFlBQ2Q7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGO0FBR0EsU0FBUyx1QkFBdUIsU0FBUztBQUN2QyxTQUFPO0FBQUE7QUFBQSxJQUVMLEdBQUcsbUNBQW1DLE9BQU87QUFBQSxJQUM3QyxTQUFTLFNBQVM7QUFDaEIsWUFBTSxTQUFTLFFBQVEsWUFBWTtBQUNuQyxZQUFNLFdBQVcsUUFBUSxZQUFZO0FBQ3JDLFlBQU0sYUFBYSxRQUFRLGNBQWM7QUFDekMsVUFBSSxDQUFDLFVBQVUsWUFBWSxZQUFZO0FBQ3JDLGNBQU0sVUFBVSxRQUFRLEtBQUs7QUFDN0IsY0FBTSxpQkFBaUIsU0FBUyxLQUFLLElBQUksQ0FBQyxRQUFRLElBQUksSUFBSTtBQUMxRCxjQUFNLGNBQWMsZUFBZSxTQUFTLGNBQWM7QUFDMUQsZ0JBQVE7QUFBQSxVQUNOLElBQUk7QUFBQSxZQUNGLHFCQUFxQixPQUFPLGVBQWUsV0FBVyxJQUFJLElBQUksU0FBUyxJQUFJLE9BQU8sV0FBVyxXQUFXO0FBQUEsWUFDeEc7QUFBQSxjQUNFLE9BQU87QUFBQSxZQUNUO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUNBLFNBQVMsbUNBQW1DLFNBQVM7QUFDbkQsUUFBTSxnQkFBZ0MsdUJBQU8sT0FBTyxJQUFJO0FBQ3hELFFBQU0sU0FBUyxRQUFRLFVBQVU7QUFDakMsUUFBTSxvQkFBb0IsU0FBUyxPQUFPLGNBQWMsSUFBSTtBQUM1RCxhQUFXLGFBQWEsbUJBQW1CO0FBQ3pDLGtCQUFjLFVBQVUsSUFBSSxJQUFJLFVBQVUsS0FBSyxJQUFJLENBQUMsUUFBUSxJQUFJLElBQUk7QUFBQSxFQUN0RTtBQUNBLFFBQU0saUJBQWlCLFFBQVEsWUFBWSxFQUFFO0FBQzdDLGFBQVcsT0FBTyxnQkFBZ0I7QUFDaEMsUUFBSSxJQUFJLFNBQVMsS0FBSyxzQkFBc0I7QUFDMUMsVUFBSTtBQUNKLFlBQU0sYUFBYSxpQkFBaUIsSUFBSSxlQUFlLFFBQVEsbUJBQW1CLFNBQVMsaUJBQWlCLENBQUM7QUFDN0csb0JBQWMsSUFBSSxLQUFLLEtBQUssSUFBSSxVQUFVLElBQUksQ0FBQyxRQUFRLElBQUksS0FBSyxLQUFLO0FBQUEsSUFDdkU7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUFBLElBQ0wsVUFBVSxlQUFlO0FBQ3ZCLFlBQU0sZ0JBQWdCLGNBQWMsS0FBSztBQUN6QyxZQUFNLFlBQVksY0FBYyxhQUFhO0FBQzdDLFVBQUksY0FBYyxhQUFhLFdBQVc7QUFDeEMsbUJBQVcsV0FBVyxjQUFjLFdBQVc7QUFDN0MsZ0JBQU0sVUFBVSxRQUFRLEtBQUs7QUFDN0IsY0FBSSxDQUFDLFVBQVUsU0FBUyxPQUFPLEdBQUc7QUFDaEMsa0JBQU0sY0FBYyxlQUFlLFNBQVMsU0FBUztBQUNyRCxvQkFBUTtBQUFBLGNBQ04sSUFBSTtBQUFBLGdCQUNGLHFCQUFxQixPQUFPLG9CQUFvQixhQUFhLE9BQU8sV0FBVyxXQUFXO0FBQUEsZ0JBQzFGO0FBQUEsa0JBQ0UsT0FBTztBQUFBLGdCQUNUO0FBQUEsY0FDRjtBQUFBLFlBQ0Y7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFDRjtBQUdBLFNBQVMsb0JBQW9CLFNBQVM7QUFDcEMsUUFBTSxlQUErQix1QkFBTyxPQUFPLElBQUk7QUFDdkQsUUFBTSxTQUFTLFFBQVEsVUFBVTtBQUNqQyxRQUFNLG9CQUFvQixTQUFTLE9BQU8sY0FBYyxJQUFJO0FBQzVELGFBQVcsYUFBYSxtQkFBbUI7QUFDekMsaUJBQWEsVUFBVSxJQUFJLElBQUksVUFBVTtBQUFBLEVBQzNDO0FBQ0EsUUFBTSxpQkFBaUIsUUFBUSxZQUFZLEVBQUU7QUFDN0MsYUFBVyxPQUFPLGdCQUFnQjtBQUNoQyxRQUFJLElBQUksU0FBUyxLQUFLLHNCQUFzQjtBQUMxQyxtQkFBYSxJQUFJLEtBQUssS0FBSyxJQUFJLElBQUksVUFBVSxJQUFJLENBQUMsU0FBUyxLQUFLLEtBQUs7QUFBQSxJQUN2RTtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQUEsSUFDTCxVQUFVLE1BQU0sTUFBTSxTQUFTLE9BQU8sV0FBVztBQUMvQyxZQUFNLE9BQU8sS0FBSyxLQUFLO0FBQ3ZCLFlBQU0sWUFBWSxhQUFhLElBQUk7QUFDbkMsVUFBSSxDQUFDLFdBQVc7QUFDZCxnQkFBUTtBQUFBLFVBQ04sSUFBSSxhQUFhLHVCQUF1QixJQUFJLE1BQU07QUFBQSxZQUNoRCxPQUFPO0FBQUEsVUFDVCxDQUFDO0FBQUEsUUFDSDtBQUNBO0FBQUEsTUFDRjtBQUNBLFlBQU0sb0JBQW9CLCtCQUErQixTQUFTO0FBQ2xFLFVBQUkscUJBQXFCLENBQUMsVUFBVSxTQUFTLGlCQUFpQixHQUFHO0FBQy9ELGdCQUFRO0FBQUEsVUFDTixJQUFJO0FBQUEsWUFDRixlQUFlLElBQUksd0JBQXdCLGlCQUFpQjtBQUFBLFlBQzVEO0FBQUEsY0FDRSxPQUFPO0FBQUEsWUFDVDtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0Y7QUFDQSxTQUFTLCtCQUErQixXQUFXO0FBQ2pELFFBQU0sWUFBWSxVQUFVLFVBQVUsU0FBUyxDQUFDO0FBQ2hELFlBQVUsYUFBYSxXQUFXLEtBQUs7QUFDdkMsVUFBUSxVQUFVLE1BQU07QUFBQSxJQUN0QixLQUFLLEtBQUs7QUFDUixhQUFPLGlDQUFpQyxVQUFVLFNBQVM7QUFBQSxJQUM3RCxLQUFLLEtBQUs7QUFDUixhQUFPLGtCQUFrQjtBQUFBLElBQzNCLEtBQUssS0FBSztBQUNSLGFBQU8sa0JBQWtCO0FBQUEsSUFDM0IsS0FBSyxLQUFLO0FBQ1IsYUFBTyxrQkFBa0I7QUFBQSxJQUMzQixLQUFLLEtBQUs7QUFDUixhQUFPLGtCQUFrQjtBQUFBLElBQzNCLEtBQUssS0FBSztBQUNSLGFBQU8sa0JBQWtCO0FBQUEsSUFDM0IsS0FBSyxLQUFLO0FBQUEsSUFDVixLQUFLLEtBQUs7QUFDUixhQUFPLGtCQUFrQjtBQUFBLElBQzNCLEtBQUssS0FBSztBQUFBLElBQ1YsS0FBSyxLQUFLO0FBQ1IsYUFBTyxrQkFBa0I7QUFBQSxJQUMzQixLQUFLLEtBQUs7QUFBQSxJQUNWLEtBQUssS0FBSztBQUNSLGFBQU8sa0JBQWtCO0FBQUEsSUFDM0IsS0FBSyxLQUFLO0FBQ1IsYUFBTyxrQkFBa0I7QUFBQSxJQUMzQixLQUFLLEtBQUs7QUFBQSxJQUNWLEtBQUssS0FBSztBQUNSLGFBQU8sa0JBQWtCO0FBQUEsSUFDM0IsS0FBSyxLQUFLO0FBQUEsSUFDVixLQUFLLEtBQUs7QUFDUixhQUFPLGtCQUFrQjtBQUFBLElBQzNCLEtBQUssS0FBSztBQUFBLElBQ1YsS0FBSyxLQUFLO0FBQ1IsYUFBTyxrQkFBa0I7QUFBQSxJQUMzQixLQUFLLEtBQUs7QUFDUixhQUFPLGtCQUFrQjtBQUFBLElBQzNCLEtBQUssS0FBSztBQUFBLElBQ1YsS0FBSyxLQUFLO0FBQ1IsYUFBTyxrQkFBa0I7QUFBQSxJQUMzQixLQUFLLEtBQUssd0JBQXdCO0FBQ2hDLFlBQU0sYUFBYSxVQUFVLFVBQVUsU0FBUyxDQUFDO0FBQ2pELGdCQUFVLGNBQWMsV0FBVyxLQUFLO0FBQ3hDLGFBQU8sV0FBVyxTQUFTLEtBQUssK0JBQStCLGtCQUFrQix5QkFBeUIsa0JBQWtCO0FBQUEsSUFDOUg7QUFBQSxJQUNBO0FBQ0UsaUJBQVcsT0FBTyxzQkFBc0IsUUFBUSxVQUFVLElBQUksQ0FBQztBQUFBLEVBQ25FO0FBQ0Y7QUFDQSxTQUFTLGlDQUFpQyxXQUFXO0FBQ25ELFVBQVEsV0FBVztBQUFBLElBQ2pCLEtBQUssa0JBQWtCO0FBQ3JCLGFBQU8sa0JBQWtCO0FBQUEsSUFDM0IsS0FBSyxrQkFBa0I7QUFDckIsYUFBTyxrQkFBa0I7QUFBQSxJQUMzQixLQUFLLGtCQUFrQjtBQUNyQixhQUFPLGtCQUFrQjtBQUFBLEVBQzdCO0FBQ0Y7QUFHQSxTQUFTLHVCQUF1QixTQUFTO0FBQ3ZDLFNBQU87QUFBQSxJQUNMLGVBQWUsTUFBTTtBQUNuQixZQUFNLGVBQWUsS0FBSyxLQUFLO0FBQy9CLFlBQU0sV0FBVyxRQUFRLFlBQVksWUFBWTtBQUNqRCxVQUFJLENBQUMsVUFBVTtBQUNiLGdCQUFRO0FBQUEsVUFDTixJQUFJLGFBQWEscUJBQXFCLFlBQVksTUFBTTtBQUFBLFlBQ3RELE9BQU8sS0FBSztBQUFBLFVBQ2QsQ0FBQztBQUFBLFFBQ0g7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUdBLFNBQVMsbUJBQW1CLFNBQVM7QUFDbkMsUUFBTSxTQUFTLFFBQVEsVUFBVTtBQUNqQyxRQUFNLG1CQUFtQixTQUFTLE9BQU8sV0FBVyxJQUFvQix1QkFBTyxPQUFPLElBQUk7QUFDMUYsUUFBTSxlQUErQix1QkFBTyxPQUFPLElBQUk7QUFDdkQsYUFBVyxPQUFPLFFBQVEsWUFBWSxFQUFFLGFBQWE7QUFDbkQsUUFBSSxxQkFBcUIsR0FBRyxHQUFHO0FBQzdCLG1CQUFhLElBQUksS0FBSyxLQUFLLElBQUk7QUFBQSxJQUNqQztBQUFBLEVBQ0Y7QUFDQSxRQUFNLFlBQVk7QUFBQSxJQUNoQixHQUFHLE9BQU8sS0FBSyxnQkFBZ0I7QUFBQSxJQUMvQixHQUFHLE9BQU8sS0FBSyxZQUFZO0FBQUEsRUFDN0I7QUFDQSxTQUFPO0FBQUEsSUFDTCxVQUFVLE1BQU0sSUFBSSxRQUFRLElBQUksV0FBVztBQUN6QyxZQUFNLFdBQVcsS0FBSyxLQUFLO0FBQzNCLFVBQUksQ0FBQyxpQkFBaUIsUUFBUSxLQUFLLENBQUMsYUFBYSxRQUFRLEdBQUc7QUFDMUQsWUFBSTtBQUNKLGNBQU0sa0JBQWtCLGNBQWMsVUFBVSxDQUFDLE9BQU8sUUFBUSxnQkFBZ0IsU0FBUyxjQUFjO0FBQ3ZHLGNBQU0sUUFBUSxrQkFBa0IsUUFBUSxVQUFVLGNBQWM7QUFDaEUsWUFBSSxTQUFTLGtCQUFrQixTQUFTLFFBQVEsR0FBRztBQUNqRDtBQUFBLFFBQ0Y7QUFDQSxjQUFNLGlCQUFpQjtBQUFBLFVBQ3JCO0FBQUEsVUFDQSxRQUFRLGtCQUFrQixPQUFPLFNBQVMsSUFBSTtBQUFBLFFBQ2hEO0FBQ0EsZ0JBQVE7QUFBQSxVQUNOLElBQUk7QUFBQSxZQUNGLGlCQUFpQixRQUFRLE9BQU8sV0FBVyxjQUFjO0FBQUEsWUFDekQ7QUFBQSxjQUNFLE9BQU87QUFBQSxZQUNUO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUNBLElBQUksb0JBQW9CLENBQUMsR0FBRyxzQkFBc0IsR0FBRyxrQkFBa0IsRUFBRTtBQUFBLEVBQ3ZFLENBQUMsU0FBUyxLQUFLO0FBQ2pCO0FBQ0EsU0FBUyxVQUFVLE9BQU87QUFDeEIsU0FBTyxVQUFVLFVBQVUsMkJBQTJCLEtBQUssS0FBSywwQkFBMEIsS0FBSztBQUNqRztBQUdBLFNBQVMsMkJBQTJCLFNBQVM7QUFDM0MsTUFBSSxpQkFBaUI7QUFDckIsU0FBTztBQUFBLElBQ0wsU0FBUyxNQUFNO0FBQ2IsdUJBQWlCLEtBQUssWUFBWTtBQUFBLFFBQ2hDLENBQUMsZUFBZSxXQUFXLFNBQVMsS0FBSztBQUFBLE1BQzNDLEVBQUU7QUFBQSxJQUNKO0FBQUEsSUFDQSxvQkFBb0IsTUFBTTtBQUN4QixVQUFJLENBQUMsS0FBSyxRQUFRLGlCQUFpQixHQUFHO0FBQ3BDLGdCQUFRO0FBQUEsVUFDTixJQUFJO0FBQUEsWUFDRjtBQUFBLFlBQ0E7QUFBQSxjQUNFLE9BQU87QUFBQSxZQUNUO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUdBLFNBQVMseUJBQXlCLFNBQVM7QUFDekMsTUFBSSxNQUFNLE9BQU87QUFDakIsUUFBTSxZQUFZLFFBQVEsVUFBVTtBQUNwQyxRQUFNLGtCQUFrQixRQUFRLFNBQVMscUJBQXFCLGNBQWMsUUFBUSxjQUFjLFNBQVMsU0FBUyxVQUFVLGFBQWEsUUFBUSx1QkFBdUIsU0FBUyxxQkFBcUIsY0FBYyxRQUFRLGNBQWMsU0FBUyxTQUFTLFVBQVUsYUFBYSxPQUFPLFFBQVEsVUFBVSxTQUFTLFFBQVEsY0FBYyxRQUFRLGNBQWMsU0FBUyxTQUFTLFVBQVUsZ0JBQWdCLE9BQU8sUUFBUSxTQUFTLFNBQVMsT0FBTyxjQUFjLFFBQVEsY0FBYyxTQUFTLFNBQVMsVUFBVSxvQkFBb0I7QUFDM2dCLE1BQUkseUJBQXlCO0FBQzdCLFNBQU87QUFBQSxJQUNMLGlCQUFpQixNQUFNO0FBQ3JCLFVBQUksZ0JBQWdCO0FBQ2xCLGdCQUFRO0FBQUEsVUFDTixJQUFJO0FBQUEsWUFDRjtBQUFBLFlBQ0E7QUFBQSxjQUNFLE9BQU87QUFBQSxZQUNUO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFDQTtBQUFBLE1BQ0Y7QUFDQSxVQUFJLHlCQUF5QixHQUFHO0FBQzlCLGdCQUFRO0FBQUEsVUFDTixJQUFJLGFBQWEsNENBQTRDO0FBQUEsWUFDM0QsT0FBTztBQUFBLFVBQ1QsQ0FBQztBQUFBLFFBQ0g7QUFBQSxNQUNGO0FBQ0EsUUFBRTtBQUFBLElBQ0o7QUFBQSxFQUNGO0FBQ0Y7QUFHQSxTQUFTLHFCQUFxQixTQUFTO0FBQ3JDLFFBQU0sZUFBK0IsdUJBQU8sT0FBTyxJQUFJO0FBQ3ZELFFBQU0sYUFBYSxDQUFDO0FBQ3BCLFFBQU0sd0JBQXdDLHVCQUFPLE9BQU8sSUFBSTtBQUNoRSxTQUFPO0FBQUEsSUFDTCxxQkFBcUIsTUFBTTtBQUFBLElBQzNCLG1CQUFtQixNQUFNO0FBQ3ZCLDJCQUFxQixJQUFJO0FBQ3pCLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUNBLFdBQVMscUJBQXFCLFVBQVU7QUFDdEMsUUFBSSxhQUFhLFNBQVMsS0FBSyxLQUFLLEdBQUc7QUFDckM7QUFBQSxJQUNGO0FBQ0EsVUFBTSxlQUFlLFNBQVMsS0FBSztBQUNuQyxpQkFBYSxZQUFZLElBQUk7QUFDN0IsVUFBTSxjQUFjLFFBQVEsbUJBQW1CLFNBQVMsWUFBWTtBQUNwRSxRQUFJLFlBQVksV0FBVyxHQUFHO0FBQzVCO0FBQUEsSUFDRjtBQUNBLDBCQUFzQixZQUFZLElBQUksV0FBVztBQUNqRCxlQUFXLGNBQWMsYUFBYTtBQUNwQyxZQUFNLGFBQWEsV0FBVyxLQUFLO0FBQ25DLFlBQU0sYUFBYSxzQkFBc0IsVUFBVTtBQUNuRCxpQkFBVyxLQUFLLFVBQVU7QUFDMUIsVUFBSSxlQUFlLFFBQVE7QUFDekIsY0FBTSxpQkFBaUIsUUFBUSxZQUFZLFVBQVU7QUFDckQsWUFBSSxnQkFBZ0I7QUFDbEIsK0JBQXFCLGNBQWM7QUFBQSxRQUNyQztBQUFBLE1BQ0YsT0FBTztBQUNMLGNBQU0sWUFBWSxXQUFXLE1BQU0sVUFBVTtBQUM3QyxjQUFNLFVBQVUsVUFBVSxNQUFNLEdBQUcsRUFBRSxFQUFFLElBQUksQ0FBQyxNQUFNLE1BQU0sRUFBRSxLQUFLLFFBQVEsR0FBRyxFQUFFLEtBQUssSUFBSTtBQUNyRixnQkFBUTtBQUFBLFVBQ04sSUFBSTtBQUFBLFlBQ0YsMkJBQTJCLFVBQVUscUJBQXFCLFlBQVksS0FBSyxRQUFRLE9BQU8sTUFBTTtBQUFBLFlBQ2hHO0FBQUEsY0FDRSxPQUFPO0FBQUEsWUFDVDtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBLGlCQUFXLElBQUk7QUFBQSxJQUNqQjtBQUNBLDBCQUFzQixZQUFZLElBQUk7QUFBQSxFQUN4QztBQUNGO0FBR0EsU0FBUyx5QkFBeUIsU0FBUztBQUN6QyxNQUFJLHNCQUFzQyx1QkFBTyxPQUFPLElBQUk7QUFDNUQsU0FBTztBQUFBLElBQ0wscUJBQXFCO0FBQUEsTUFDbkIsUUFBUTtBQUNOLDhCQUFzQyx1QkFBTyxPQUFPLElBQUk7QUFBQSxNQUMxRDtBQUFBLE1BQ0EsTUFBTSxXQUFXO0FBQ2YsY0FBTSxTQUFTLFFBQVEsMkJBQTJCLFNBQVM7QUFDM0QsbUJBQVcsRUFBRSxLQUFLLEtBQUssUUFBUTtBQUM3QixnQkFBTSxVQUFVLEtBQUssS0FBSztBQUMxQixjQUFJLG9CQUFvQixPQUFPLE1BQU0sTUFBTTtBQUN6QyxvQkFBUTtBQUFBLGNBQ04sSUFBSTtBQUFBLGdCQUNGLFVBQVUsT0FBTyxjQUFjLE9BQU8sa0NBQWtDLFVBQVUsS0FBSyxLQUFLLE9BQU8sY0FBYyxPQUFPO0FBQUEsZ0JBQ3hIO0FBQUEsa0JBQ0UsT0FBTyxDQUFDLE1BQU0sU0FBUztBQUFBLGdCQUN6QjtBQUFBLGNBQ0Y7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLElBQ0EsbUJBQW1CLE1BQU07QUFDdkIsMEJBQW9CLEtBQUssU0FBUyxLQUFLLEtBQUssSUFBSTtBQUFBLElBQ2xEO0FBQUEsRUFDRjtBQUNGO0FBR0EsU0FBUyxzQkFBc0IsU0FBUztBQUN0QyxRQUFNLGdCQUFnQixDQUFDO0FBQ3ZCLFFBQU0sZUFBZSxDQUFDO0FBQ3RCLFNBQU87QUFBQSxJQUNMLG9CQUFvQixNQUFNO0FBQ3hCLG9CQUFjLEtBQUssSUFBSTtBQUN2QixhQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EsbUJBQW1CLE1BQU07QUFDdkIsbUJBQWEsS0FBSyxJQUFJO0FBQ3RCLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSxVQUFVO0FBQUEsTUFDUixRQUFRO0FBQ04sY0FBTSxtQkFBbUMsdUJBQU8sT0FBTyxJQUFJO0FBQzNELG1CQUFXLGFBQWEsZUFBZTtBQUNyQyxxQkFBVyxZQUFZLFFBQVE7QUFBQSxZQUM3QjtBQUFBLFVBQ0YsR0FBRztBQUNELDZCQUFpQixTQUFTLEtBQUssS0FBSyxJQUFJO0FBQUEsVUFDMUM7QUFBQSxRQUNGO0FBQ0EsbUJBQVcsZUFBZSxjQUFjO0FBQ3RDLGdCQUFNLFdBQVcsWUFBWSxLQUFLO0FBQ2xDLGNBQUksaUJBQWlCLFFBQVEsTUFBTSxNQUFNO0FBQ3ZDLG9CQUFRO0FBQUEsY0FDTixJQUFJLGFBQWEsYUFBYSxRQUFRLG9CQUFvQjtBQUFBLGdCQUN4RCxPQUFPO0FBQUEsY0FDVCxDQUFDO0FBQUEsWUFDSDtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0Y7QUFHQSxTQUFTLHNCQUFzQixTQUFTO0FBQ3RDLE1BQUksZUFBZSxDQUFDO0FBQ3BCLFNBQU87QUFBQSxJQUNMLHFCQUFxQjtBQUFBLE1BQ25CLFFBQVE7QUFDTix1QkFBZSxDQUFDO0FBQUEsTUFDbEI7QUFBQSxNQUNBLE1BQU0sV0FBVztBQUNmLGNBQU0sbUJBQW1DLHVCQUFPLE9BQU8sSUFBSTtBQUMzRCxjQUFNLFNBQVMsUUFBUSwyQkFBMkIsU0FBUztBQUMzRCxtQkFBVyxFQUFFLEtBQUssS0FBSyxRQUFRO0FBQzdCLDJCQUFpQixLQUFLLEtBQUssS0FBSyxJQUFJO0FBQUEsUUFDdEM7QUFDQSxtQkFBVyxlQUFlLGNBQWM7QUFDdEMsZ0JBQU0sZUFBZSxZQUFZLFNBQVMsS0FBSztBQUMvQyxjQUFJLGlCQUFpQixZQUFZLE1BQU0sTUFBTTtBQUMzQyxvQkFBUTtBQUFBLGNBQ04sSUFBSTtBQUFBLGdCQUNGLFVBQVUsT0FBTyxjQUFjLFlBQVksaUNBQWlDLFVBQVUsS0FBSyxLQUFLLE9BQU8sY0FBYyxZQUFZO0FBQUEsZ0JBQ2pJO0FBQUEsa0JBQ0UsT0FBTztBQUFBLGdCQUNUO0FBQUEsY0FDRjtBQUFBLFlBQ0Y7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsSUFDQSxtQkFBbUIsS0FBSztBQUN0QixtQkFBYSxLQUFLLEdBQUc7QUFBQSxJQUN2QjtBQUFBLEVBQ0Y7QUFDRjtBQUdBLFNBQVMsY0FBYyxXQUFXO0FBQ2hDLFVBQVEsVUFBVSxNQUFNO0FBQUEsSUFDdEIsS0FBSyxLQUFLO0FBQ1IsYUFBTyxFQUFFLEdBQUcsV0FBVyxRQUFRLFdBQVcsVUFBVSxNQUFNLEVBQUU7QUFBQSxJQUM5RCxLQUFLLEtBQUs7QUFDUixhQUFPLEVBQUUsR0FBRyxXQUFXLFFBQVEsVUFBVSxPQUFPLElBQUksYUFBYSxFQUFFO0FBQUEsSUFDckUsS0FBSyxLQUFLO0FBQUEsSUFDVixLQUFLLEtBQUs7QUFBQSxJQUNWLEtBQUssS0FBSztBQUFBLElBQ1YsS0FBSyxLQUFLO0FBQUEsSUFDVixLQUFLLEtBQUs7QUFBQSxJQUNWLEtBQUssS0FBSztBQUFBLElBQ1YsS0FBSyxLQUFLO0FBQ1IsYUFBTztBQUFBLEVBQ1g7QUFDRjtBQUNBLFNBQVMsV0FBVyxRQUFRO0FBQzFCLFNBQU8sT0FBTyxJQUFJLENBQUMsZUFBZTtBQUFBLElBQ2hDLEdBQUc7QUFBQSxJQUNILE9BQU8sY0FBYyxVQUFVLEtBQUs7QUFBQSxFQUN0QyxFQUFFLEVBQUU7QUFBQSxJQUNGLENBQUMsUUFBUSxXQUFXLGVBQWUsT0FBTyxLQUFLLE9BQU8sT0FBTyxLQUFLLEtBQUs7QUFBQSxFQUN6RTtBQUNGO0FBR0EsU0FBUyxjQUFjLFFBQVE7QUFDN0IsTUFBSSxNQUFNLFFBQVEsTUFBTSxHQUFHO0FBQ3pCLFdBQU8sT0FBTztBQUFBLE1BQ1osQ0FBQyxDQUFDLGNBQWMsU0FBUyxNQUFNLGNBQWMsWUFBWSx3QkFBd0IsY0FBYyxTQUFTO0FBQUEsSUFDMUcsRUFBRSxLQUFLLE9BQU87QUFBQSxFQUNoQjtBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMsaUNBQWlDLFNBQVM7QUFDakQsUUFBTSx3QkFBd0IsSUFBSSxRQUFRO0FBQzFDLFFBQU0sK0JBQStDLG9CQUFJLElBQUk7QUFDN0QsU0FBTztBQUFBLElBQ0wsYUFBYSxjQUFjO0FBQ3pCLFlBQU0sWUFBWTtBQUFBLFFBQ2hCO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBLFFBQVEsY0FBYztBQUFBLFFBQ3RCO0FBQUEsTUFDRjtBQUNBLGlCQUFXLENBQUMsQ0FBQyxjQUFjLE1BQU0sR0FBRyxTQUFTLE9BQU8sS0FBSyxXQUFXO0FBQ2xFLGNBQU0sWUFBWSxjQUFjLE1BQU07QUFDdEMsZ0JBQVE7QUFBQSxVQUNOLElBQUk7QUFBQSxZQUNGLFdBQVcsWUFBWSxzQkFBc0IsU0FBUztBQUFBLFlBQ3REO0FBQUEsY0FDRSxPQUFPLFFBQVEsT0FBTyxPQUFPO0FBQUEsWUFDL0I7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGO0FBQ0EsU0FBUyxnQ0FBZ0MsU0FBUyw4QkFBOEIsdUJBQXVCLFlBQVksY0FBYztBQUMvSCxRQUFNLFlBQVksQ0FBQztBQUNuQixRQUFNLENBQUMsVUFBVSxhQUFhLElBQUk7QUFBQSxJQUNoQztBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDQTtBQUFBLElBQ0U7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNBLE1BQUksY0FBYyxXQUFXLEdBQUc7QUFDOUIsYUFBUyxJQUFJLEdBQUcsSUFBSSxjQUFjLFFBQVEsS0FBSztBQUM3QztBQUFBLFFBQ0U7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0EsY0FBYyxDQUFDO0FBQUEsTUFDakI7QUFDQSxlQUFTLElBQUksSUFBSSxHQUFHLElBQUksY0FBYyxRQUFRLEtBQUs7QUFDakQ7QUFBQSxVQUNFO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0EsY0FBYyxDQUFDO0FBQUEsVUFDZixjQUFjLENBQUM7QUFBQSxRQUNqQjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMseUNBQXlDLFNBQVMsV0FBVyw4QkFBOEIsdUJBQXVCLHNCQUFzQixVQUFVLGNBQWM7QUFDdkssUUFBTSxXQUFXLFFBQVEsWUFBWSxZQUFZO0FBQ2pELE1BQUksQ0FBQyxVQUFVO0FBQ2I7QUFBQSxFQUNGO0FBQ0EsUUFBTSxDQUFDLFdBQVcsdUJBQXVCLElBQUk7QUFBQSxJQUMzQztBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNBLE1BQUksYUFBYSxXQUFXO0FBQzFCO0FBQUEsRUFDRjtBQUNBO0FBQUEsSUFDRTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDQSxhQUFXLDBCQUEwQix5QkFBeUI7QUFDNUQsUUFBSSxzQkFBc0I7QUFBQSxNQUN4QjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRixHQUFHO0FBQ0Q7QUFBQSxJQUNGO0FBQ0EsMEJBQXNCO0FBQUEsTUFDcEI7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFDQTtBQUFBLE1BQ0U7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGO0FBQ0EsU0FBUyxpQ0FBaUMsU0FBUyxXQUFXLDhCQUE4Qix1QkFBdUIsc0JBQXNCLGVBQWUsZUFBZTtBQUNySyxNQUFJLGtCQUFrQixlQUFlO0FBQ25DO0FBQUEsRUFDRjtBQUNBLE1BQUksc0JBQXNCO0FBQUEsSUFDeEI7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0YsR0FBRztBQUNEO0FBQUEsRUFDRjtBQUNBLHdCQUFzQixJQUFJLGVBQWUsZUFBZSxvQkFBb0I7QUFDNUUsUUFBTSxZQUFZLFFBQVEsWUFBWSxhQUFhO0FBQ25ELFFBQU0sWUFBWSxRQUFRLFlBQVksYUFBYTtBQUNuRCxNQUFJLENBQUMsYUFBYSxDQUFDLFdBQVc7QUFDNUI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxDQUFDLFdBQVcsd0JBQXdCLElBQUk7QUFBQSxJQUM1QztBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNBLFFBQU0sQ0FBQyxXQUFXLHdCQUF3QixJQUFJO0FBQUEsSUFDNUM7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDQTtBQUFBLElBQ0U7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0EsYUFBVywyQkFBMkIsMEJBQTBCO0FBQzlEO0FBQUEsTUFDRTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsYUFBVywyQkFBMkIsMEJBQTBCO0FBQzlEO0FBQUEsTUFDRTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0Y7QUFDQSxTQUFTLHFDQUFxQyxTQUFTLDhCQUE4Qix1QkFBdUIsc0JBQXNCLGFBQWEsZUFBZSxhQUFhLGVBQWU7QUFDeEwsUUFBTSxZQUFZLENBQUM7QUFDbkIsUUFBTSxDQUFDLFdBQVcsY0FBYyxJQUFJO0FBQUEsSUFDbEM7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0EsUUFBTSxDQUFDLFdBQVcsY0FBYyxJQUFJO0FBQUEsSUFDbEM7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0E7QUFBQSxJQUNFO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNBLGFBQVcsaUJBQWlCLGdCQUFnQjtBQUMxQztBQUFBLE1BQ0U7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLGFBQVcsaUJBQWlCLGdCQUFnQjtBQUMxQztBQUFBLE1BQ0U7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLGFBQVcsaUJBQWlCLGdCQUFnQjtBQUMxQyxlQUFXLGlCQUFpQixnQkFBZ0I7QUFDMUM7QUFBQSxRQUNFO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBQ0EsU0FBUyx1QkFBdUIsU0FBUyxXQUFXLDhCQUE4Qix1QkFBdUIsVUFBVTtBQUNqSCxhQUFXLENBQUMsY0FBYyxNQUFNLEtBQUssT0FBTyxRQUFRLFFBQVEsR0FBRztBQUM3RCxRQUFJLE9BQU8sU0FBUyxHQUFHO0FBQ3JCLGVBQVMsSUFBSSxHQUFHLElBQUksT0FBTyxRQUFRLEtBQUs7QUFDdEMsaUJBQVMsSUFBSSxJQUFJLEdBQUcsSUFBSSxPQUFPLFFBQVEsS0FBSztBQUMxQyxnQkFBTSxXQUFXO0FBQUEsWUFDZjtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBO0FBQUEsWUFFQTtBQUFBLFlBQ0EsT0FBTyxDQUFDO0FBQUEsWUFDUixPQUFPLENBQUM7QUFBQSxVQUNWO0FBQ0EsY0FBSSxVQUFVO0FBQ1osc0JBQVUsS0FBSyxRQUFRO0FBQUEsVUFDekI7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0Y7QUFDQSxTQUFTLHdCQUF3QixTQUFTLFdBQVcsOEJBQThCLHVCQUF1QixrQ0FBa0MsV0FBVyxXQUFXO0FBQ2hLLGFBQVcsQ0FBQyxjQUFjLE9BQU8sS0FBSyxPQUFPLFFBQVEsU0FBUyxHQUFHO0FBQy9ELFVBQU0sVUFBVSxVQUFVLFlBQVk7QUFDdEMsUUFBSSxTQUFTO0FBQ1gsaUJBQVcsVUFBVSxTQUFTO0FBQzVCLG1CQUFXLFVBQVUsU0FBUztBQUM1QixnQkFBTSxXQUFXO0FBQUEsWUFDZjtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFVBQ0Y7QUFDQSxjQUFJLFVBQVU7QUFDWixzQkFBVSxLQUFLLFFBQVE7QUFBQSxVQUN6QjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUNBLFNBQVMsYUFBYSxTQUFTLDhCQUE4Qix1QkFBdUIsa0NBQWtDLGNBQWMsUUFBUSxRQUFRO0FBQ2xKLFFBQU0sQ0FBQyxhQUFhLE9BQU8sSUFBSSxJQUFJO0FBQ25DLFFBQU0sQ0FBQyxhQUFhLE9BQU8sSUFBSSxJQUFJO0FBQ25DLFFBQU0sdUJBQXVCLG9DQUFvQyxnQkFBZ0IsZUFBZSxhQUFhLFdBQVcsS0FBSyxhQUFhLFdBQVc7QUFDckosTUFBSSxDQUFDLHNCQUFzQjtBQUN6QixVQUFNLFFBQVEsTUFBTSxLQUFLO0FBQ3pCLFVBQU0sUUFBUSxNQUFNLEtBQUs7QUFDekIsUUFBSSxVQUFVLE9BQU87QUFDbkIsYUFBTztBQUFBLFFBQ0wsQ0FBQyxjQUFjLElBQUksS0FBSyxVQUFVLEtBQUssd0JBQXdCO0FBQUEsUUFDL0QsQ0FBQyxLQUFLO0FBQUEsUUFDTixDQUFDLEtBQUs7QUFBQSxNQUNSO0FBQUEsSUFDRjtBQUNBLFFBQUksQ0FBQyxjQUFjLE9BQU8sS0FBSyxHQUFHO0FBQ2hDLGFBQU87QUFBQSxRQUNMLENBQUMsY0FBYywrQkFBK0I7QUFBQSxRQUM5QyxDQUFDLEtBQUs7QUFBQSxRQUNOLENBQUMsS0FBSztBQUFBLE1BQ1I7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFFBQU0sUUFBUSxTQUFTLFFBQVEsU0FBUyxTQUFTLFNBQVMsS0FBSztBQUMvRCxRQUFNLFFBQVEsU0FBUyxRQUFRLFNBQVMsU0FBUyxTQUFTLEtBQUs7QUFDL0QsTUFBSSxTQUFTLFNBQVMsZ0JBQWdCLE9BQU8sS0FBSyxHQUFHO0FBQ25ELFdBQU87QUFBQSxNQUNMO0FBQUEsUUFDRTtBQUFBLFFBQ0Esa0NBQWtDLFFBQVEsS0FBSyxDQUFDLFVBQVU7QUFBQSxVQUN4RDtBQUFBLFFBQ0YsQ0FBQztBQUFBLE1BQ0g7QUFBQSxNQUNBLENBQUMsS0FBSztBQUFBLE1BQ04sQ0FBQyxLQUFLO0FBQUEsSUFDUjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLGdCQUFnQixNQUFNO0FBQzVCLFFBQU0sZ0JBQWdCLE1BQU07QUFDNUIsTUFBSSxpQkFBaUIsZUFBZTtBQUNsQyxVQUFNLFlBQVk7QUFBQSxNQUNoQjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0EsYUFBYSxLQUFLO0FBQUEsTUFDbEI7QUFBQSxNQUNBLGFBQWEsS0FBSztBQUFBLE1BQ2xCO0FBQUEsSUFDRjtBQUNBLFdBQU8sa0JBQWtCLFdBQVcsY0FBYyxPQUFPLEtBQUs7QUFBQSxFQUNoRTtBQUNGO0FBQ0EsU0FBUyxjQUFjLE9BQU8sT0FBTztBQUNuQyxRQUFNLFFBQVEsTUFBTTtBQUNwQixRQUFNLFFBQVEsTUFBTTtBQUNwQixNQUFJLFVBQVUsVUFBVSxNQUFNLFdBQVcsR0FBRztBQUMxQyxXQUFPLFVBQVUsVUFBVSxNQUFNLFdBQVc7QUFBQSxFQUM5QztBQUNBLE1BQUksVUFBVSxVQUFVLE1BQU0sV0FBVyxHQUFHO0FBQzFDLFdBQU87QUFBQSxFQUNUO0FBQ0EsTUFBSSxNQUFNLFdBQVcsTUFBTSxRQUFRO0FBQ2pDLFdBQU87QUFBQSxFQUNUO0FBQ0EsUUFBTSxVQUFVLElBQUksSUFBSSxNQUFNLElBQUksQ0FBQyxFQUFFLE1BQU0sTUFBTSxNQUFNLENBQUMsS0FBSyxPQUFPLEtBQUssQ0FBQyxDQUFDO0FBQzNFLFNBQU8sTUFBTSxNQUFNLENBQUMsU0FBUztBQUMzQixVQUFNLFNBQVMsS0FBSztBQUNwQixVQUFNLFNBQVMsUUFBUSxJQUFJLEtBQUssS0FBSyxLQUFLO0FBQzFDLFFBQUksV0FBVyxRQUFRO0FBQ3JCLGFBQU87QUFBQSxJQUNUO0FBQ0EsV0FBTyxlQUFlLE1BQU0sTUFBTSxlQUFlLE1BQU07QUFBQSxFQUN6RCxDQUFDO0FBQ0g7QUFDQSxTQUFTLGVBQWUsT0FBTztBQUM3QixTQUFPLE1BQU0sY0FBYyxLQUFLLENBQUM7QUFDbkM7QUFDQSxTQUFTLGdCQUFnQixPQUFPLE9BQU87QUFDckMsTUFBSSxXQUFXLEtBQUssR0FBRztBQUNyQixXQUFPLFdBQVcsS0FBSyxJQUFJLGdCQUFnQixNQUFNLFFBQVEsTUFBTSxNQUFNLElBQUk7QUFBQSxFQUMzRTtBQUNBLE1BQUksV0FBVyxLQUFLLEdBQUc7QUFDckIsV0FBTztBQUFBLEVBQ1Q7QUFDQSxNQUFJLGNBQWMsS0FBSyxHQUFHO0FBQ3hCLFdBQU8sY0FBYyxLQUFLLElBQUksZ0JBQWdCLE1BQU0sUUFBUSxNQUFNLE1BQU0sSUFBSTtBQUFBLEVBQzlFO0FBQ0EsTUFBSSxjQUFjLEtBQUssR0FBRztBQUN4QixXQUFPO0FBQUEsRUFDVDtBQUNBLE1BQUksV0FBVyxLQUFLLEtBQUssV0FBVyxLQUFLLEdBQUc7QUFDMUMsV0FBTyxVQUFVO0FBQUEsRUFDbkI7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLDBCQUEwQixTQUFTLDhCQUE4QixZQUFZLGNBQWM7QUFDbEcsUUFBTSxTQUFTLDZCQUE2QixJQUFJLFlBQVk7QUFDNUQsTUFBSSxRQUFRO0FBQ1YsV0FBTztBQUFBLEVBQ1Q7QUFDQSxRQUFNLGNBQThCLHVCQUFPLE9BQU8sSUFBSTtBQUN0RCxRQUFNLGdCQUFnQyx1QkFBTyxPQUFPLElBQUk7QUFDeEQ7QUFBQSxJQUNFO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDQSxRQUFNLFNBQVMsQ0FBQyxhQUFhLE9BQU8sS0FBSyxhQUFhLENBQUM7QUFDdkQsK0JBQTZCLElBQUksY0FBYyxNQUFNO0FBQ3JELFNBQU87QUFDVDtBQUNBLFNBQVMsb0NBQW9DLFNBQVMsOEJBQThCLFVBQVU7QUFDNUYsUUFBTSxTQUFTLDZCQUE2QixJQUFJLFNBQVMsWUFBWTtBQUNyRSxNQUFJLFFBQVE7QUFDVixXQUFPO0FBQUEsRUFDVDtBQUNBLFFBQU0sZUFBZSxZQUFZLFFBQVEsVUFBVSxHQUFHLFNBQVMsYUFBYTtBQUM1RSxTQUFPO0FBQUEsSUFDTDtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQSxTQUFTO0FBQUEsRUFDWDtBQUNGO0FBQ0EsU0FBUywrQkFBK0IsU0FBUyxZQUFZLGNBQWMsYUFBYSxlQUFlO0FBQ3JHLGFBQVcsYUFBYSxhQUFhLFlBQVk7QUFDL0MsWUFBUSxVQUFVLE1BQU07QUFBQSxNQUN0QixLQUFLLEtBQUssT0FBTztBQUNmLGNBQU0sWUFBWSxVQUFVLEtBQUs7QUFDakMsWUFBSTtBQUNKLFlBQUksYUFBYSxVQUFVLEtBQUssZ0JBQWdCLFVBQVUsR0FBRztBQUMzRCxxQkFBVyxXQUFXLFVBQVUsRUFBRSxTQUFTO0FBQUEsUUFDN0M7QUFDQSxjQUFNLGVBQWUsVUFBVSxRQUFRLFVBQVUsTUFBTSxRQUFRO0FBQy9ELFlBQUksQ0FBQyxZQUFZLFlBQVksR0FBRztBQUM5QixzQkFBWSxZQUFZLElBQUksQ0FBQztBQUFBLFFBQy9CO0FBQ0Esb0JBQVksWUFBWSxFQUFFLEtBQUssQ0FBQyxZQUFZLFdBQVcsUUFBUSxDQUFDO0FBQ2hFO0FBQUEsTUFDRjtBQUFBLE1BQ0EsS0FBSyxLQUFLO0FBQ1Isc0JBQWMsVUFBVSxLQUFLLEtBQUssSUFBSTtBQUN0QztBQUFBLE1BQ0YsS0FBSyxLQUFLLGlCQUFpQjtBQUN6QixjQUFNLGdCQUFnQixVQUFVO0FBQ2hDLGNBQU0scUJBQXFCLGdCQUFnQixZQUFZLFFBQVEsVUFBVSxHQUFHLGFBQWEsSUFBSTtBQUM3RjtBQUFBLFVBQ0U7QUFBQSxVQUNBO0FBQUEsVUFDQSxVQUFVO0FBQUEsVUFDVjtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQ0E7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUNBLFNBQVMsa0JBQWtCLFdBQVcsY0FBYyxPQUFPLE9BQU87QUFDaEUsTUFBSSxVQUFVLFNBQVMsR0FBRztBQUN4QixXQUFPO0FBQUEsTUFDTCxDQUFDLGNBQWMsVUFBVSxJQUFJLENBQUMsQ0FBQyxNQUFNLE1BQU0sTUFBTSxDQUFDO0FBQUEsTUFDbEQsQ0FBQyxPQUFPLEdBQUcsVUFBVSxJQUFJLENBQUMsQ0FBQyxFQUFFLE9BQU8sTUFBTSxPQUFPLEVBQUUsS0FBSyxDQUFDO0FBQUEsTUFDekQsQ0FBQyxPQUFPLEdBQUcsVUFBVSxJQUFJLENBQUMsQ0FBQyxFQUFFLEVBQUUsT0FBTyxNQUFNLE9BQU8sRUFBRSxLQUFLLENBQUM7QUFBQSxJQUM3RDtBQUFBLEVBQ0Y7QUFDRjtBQUNBLElBQUksVUFBVSxNQUFNO0FBQUEsRUFDbEIsY0FBYztBQUNaLFNBQUssUUFBd0Isb0JBQUksSUFBSTtBQUFBLEVBQ3ZDO0FBQUEsRUFDQSxJQUFJLEdBQUcsR0FBRyxzQkFBc0I7QUFDOUIsUUFBSTtBQUNKLFVBQU0sQ0FBQyxNQUFNLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztBQUMzQyxVQUFNLFVBQVUsa0JBQWtCLEtBQUssTUFBTSxJQUFJLElBQUksT0FBTyxRQUFRLG9CQUFvQixTQUFTLFNBQVMsZ0JBQWdCLElBQUksSUFBSTtBQUNsSSxRQUFJLFdBQVcsUUFBUTtBQUNyQixhQUFPO0FBQUEsSUFDVDtBQUNBLFdBQU8sdUJBQXVCLE9BQU8seUJBQXlCO0FBQUEsRUFDaEU7QUFBQSxFQUNBLElBQUksR0FBRyxHQUFHLHNCQUFzQjtBQUM5QixVQUFNLENBQUMsTUFBTSxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7QUFDM0MsVUFBTSxNQUFNLEtBQUssTUFBTSxJQUFJLElBQUk7QUFDL0IsUUFBSSxRQUFRLFFBQVE7QUFDbEIsV0FBSyxNQUFNLElBQUksTUFBc0Isb0JBQUksSUFBSSxDQUFDLENBQUMsTUFBTSxvQkFBb0IsQ0FBQyxDQUFDLENBQUM7QUFBQSxJQUM5RSxPQUFPO0FBQ0wsVUFBSSxJQUFJLE1BQU0sb0JBQW9CO0FBQUEsSUFDcEM7QUFBQSxFQUNGO0FBQ0Y7QUFHQSxTQUFTLDRCQUE0QixTQUFTO0FBQzVDLFNBQU87QUFBQSxJQUNMLGVBQWUsTUFBTTtBQUNuQixZQUFNLFdBQVcsUUFBUSxRQUFRO0FBQ2pDLFlBQU0sYUFBYSxRQUFRLGNBQWM7QUFDekMsVUFBSSxnQkFBZ0IsUUFBUSxLQUFLLGdCQUFnQixVQUFVLEtBQUssQ0FBQyxlQUFlLFFBQVEsVUFBVSxHQUFHLFVBQVUsVUFBVSxHQUFHO0FBQzFILGNBQU0sZ0JBQWdCLFFBQVEsVUFBVTtBQUN4QyxjQUFNLGNBQWMsUUFBUSxRQUFRO0FBQ3BDLGdCQUFRO0FBQUEsVUFDTixJQUFJO0FBQUEsWUFDRixzREFBc0QsYUFBYSwyQkFBMkIsV0FBVztBQUFBLFlBQ3pHO0FBQUEsY0FDRSxPQUFPO0FBQUEsWUFDVDtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxJQUNBLGVBQWUsTUFBTTtBQUNuQixZQUFNLFdBQVcsS0FBSyxLQUFLO0FBQzNCLFlBQU0sV0FBVyxnQkFBZ0IsU0FBUyxRQUFRO0FBQ2xELFlBQU0sYUFBYSxRQUFRLGNBQWM7QUFDekMsVUFBSSxZQUFZLGNBQWMsQ0FBQyxlQUFlLFFBQVEsVUFBVSxHQUFHLFVBQVUsVUFBVSxHQUFHO0FBQ3hGLGNBQU0sZ0JBQWdCLFFBQVEsVUFBVTtBQUN4QyxjQUFNLGNBQWMsUUFBUSxRQUFRO0FBQ3BDLGdCQUFRO0FBQUEsVUFDTixJQUFJO0FBQUEsWUFDRixhQUFhLFFBQVEsK0NBQStDLGFBQWEsMkJBQTJCLFdBQVc7QUFBQSxZQUN2SDtBQUFBLGNBQ0UsT0FBTztBQUFBLFlBQ1Q7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGO0FBQ0EsU0FBUyxnQkFBZ0IsU0FBUyxNQUFNO0FBQ3RDLFFBQU0sT0FBTyxRQUFRLFlBQVksSUFBSTtBQUNyQyxNQUFJLE1BQU07QUFDUixVQUFNLE9BQU8sWUFBWSxRQUFRLFVBQVUsR0FBRyxLQUFLLGFBQWE7QUFDaEUsUUFBSSxnQkFBZ0IsSUFBSSxHQUFHO0FBQ3pCLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUNGO0FBR0EsU0FBUywyQkFBMkIsU0FBUztBQUMzQyxRQUFNLFNBQVMsUUFBUSxVQUFVO0FBQ2pDLFFBQU0sZUFBK0IsdUJBQU8sT0FBTyxJQUFJO0FBQ3ZELGFBQVcsT0FBTyxRQUFRLFlBQVksRUFBRSxhQUFhO0FBQ25ELFFBQUkscUJBQXFCLEdBQUcsR0FBRztBQUM3QixtQkFBYSxJQUFJLEtBQUssS0FBSyxJQUFJO0FBQUEsSUFDakM7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUFBLElBQ0wscUJBQXFCO0FBQUEsSUFDckIscUJBQXFCO0FBQUEsSUFDckIsd0JBQXdCO0FBQUEsSUFDeEIsb0JBQW9CO0FBQUEsSUFDcEIsbUJBQW1CO0FBQUEsSUFDbkIsMEJBQTBCO0FBQUEsRUFDNUI7QUFDQSxXQUFTLGVBQWUsTUFBTTtBQUM1QixVQUFNLFdBQVcsS0FBSyxLQUFLO0FBQzNCLFVBQU0sVUFBVSxhQUFhLFFBQVE7QUFDckMsVUFBTSxlQUFlLFdBQVcsUUFBUSxXQUFXLFNBQVMsU0FBUyxPQUFPLFFBQVEsUUFBUTtBQUM1RixRQUFJO0FBQ0osUUFBSSxTQUFTO0FBQ1gscUJBQWUsaUJBQWlCLFFBQVEsSUFBSTtBQUFBLElBQzlDLFdBQVcsY0FBYztBQUN2QixxQkFBZSxjQUFjLFlBQVk7QUFBQSxJQUMzQztBQUNBLFFBQUksY0FBYztBQUNoQixVQUFJLGlCQUFpQixLQUFLLE1BQU07QUFDOUIsY0FBTSxVQUFVLHdCQUF3QixLQUFLLElBQUk7QUFDakQsZ0JBQVE7QUFBQSxVQUNOLElBQUksYUFBYSxxQkFBcUIsT0FBTyxVQUFVLFFBQVEsTUFBTTtBQUFBLFlBQ25FLE9BQU8sVUFBVSxDQUFDLFNBQVMsSUFBSSxJQUFJO0FBQUEsVUFDckMsQ0FBQztBQUFBLFFBQ0g7QUFBQSxNQUNGO0FBQUEsSUFDRixPQUFPO0FBQ0wsWUFBTSxlQUFlLE9BQU8sS0FBSztBQUFBLFFBQy9CLEdBQUc7QUFBQSxRQUNILEdBQUcsV0FBVyxRQUFRLFdBQVcsU0FBUyxTQUFTLE9BQU8sV0FBVztBQUFBLE1BQ3ZFLENBQUM7QUFDRCxZQUFNLGlCQUFpQixlQUFlLFVBQVUsWUFBWTtBQUM1RCxjQUFRO0FBQUEsUUFDTixJQUFJO0FBQUEsVUFDRix1QkFBdUIsUUFBUSxpQ0FBaUMsV0FBVyxjQUFjO0FBQUEsVUFDekY7QUFBQSxZQUNFLE9BQU8sS0FBSztBQUFBLFVBQ2Q7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0Y7QUFDQSxJQUFJLG1CQUFtQjtBQUFBLEVBQ3JCLENBQUMsS0FBSyxzQkFBc0IsR0FBRyxLQUFLO0FBQUEsRUFDcEMsQ0FBQyxLQUFLLHNCQUFzQixHQUFHLEtBQUs7QUFBQSxFQUNwQyxDQUFDLEtBQUsseUJBQXlCLEdBQUcsS0FBSztBQUFBLEVBQ3ZDLENBQUMsS0FBSyxxQkFBcUIsR0FBRyxLQUFLO0FBQUEsRUFDbkMsQ0FBQyxLQUFLLG9CQUFvQixHQUFHLEtBQUs7QUFBQSxFQUNsQyxDQUFDLEtBQUssNEJBQTRCLEdBQUcsS0FBSztBQUM1QztBQUNBLFNBQVMsY0FBYyxNQUFNO0FBQzNCLE1BQUksYUFBYSxJQUFJLEdBQUc7QUFDdEIsV0FBTyxLQUFLO0FBQUEsRUFDZDtBQUNBLE1BQUksYUFBYSxJQUFJLEdBQUc7QUFDdEIsV0FBTyxLQUFLO0FBQUEsRUFDZDtBQUNBLE1BQUksZ0JBQWdCLElBQUksR0FBRztBQUN6QixXQUFPLEtBQUs7QUFBQSxFQUNkO0FBQ0EsTUFBSSxZQUFZLElBQUksR0FBRztBQUNyQixXQUFPLEtBQUs7QUFBQSxFQUNkO0FBQ0EsTUFBSSxXQUFXLElBQUksR0FBRztBQUNwQixXQUFPLEtBQUs7QUFBQSxFQUNkO0FBQ0EsTUFBSSxrQkFBa0IsSUFBSSxHQUFHO0FBQzNCLFdBQU8sS0FBSztBQUFBLEVBQ2Q7QUFDQSxhQUFXLE9BQU8sc0JBQXNCLFFBQVEsSUFBSSxDQUFDO0FBQ3ZEO0FBQ0EsU0FBUyx3QkFBd0IsTUFBTTtBQUNyQyxVQUFRLE1BQU07QUFBQSxJQUNaLEtBQUssS0FBSztBQUNSLGFBQU87QUFBQSxJQUNULEtBQUssS0FBSztBQUNSLGFBQU87QUFBQSxJQUNULEtBQUssS0FBSztBQUNSLGFBQU87QUFBQSxJQUNULEtBQUssS0FBSztBQUNSLGFBQU87QUFBQSxJQUNULEtBQUssS0FBSztBQUNSLGFBQU87QUFBQSxJQUNULEtBQUssS0FBSztBQUNSLGFBQU87QUFBQSxJQUNUO0FBQ0UsaUJBQVcsT0FBTyxzQkFBc0IsUUFBUSxJQUFJLENBQUM7QUFBQSxFQUN6RDtBQUNGO0FBR0EsU0FBUyw4QkFBOEIsU0FBUztBQUM5QyxTQUFPO0FBQUE7QUFBQSxJQUVMLEdBQUcsMENBQTBDLE9BQU87QUFBQSxJQUNwRCxPQUFPO0FBQUE7QUFBQSxNQUVMLE1BQU0sV0FBVztBQUNmLFlBQUk7QUFDSixjQUFNLFdBQVcsUUFBUSxZQUFZO0FBQ3JDLFlBQUksQ0FBQyxVQUFVO0FBQ2IsaUJBQU87QUFBQSxRQUNUO0FBQ0EsY0FBTSxlQUFlLElBQUk7QUFBQTtBQUFBO0FBQUEsV0FHdEIsdUJBQXVCLFVBQVUsZUFBZSxRQUFRLHlCQUF5QixTQUFTLFNBQVMscUJBQXFCLElBQUksQ0FBQyxRQUFRLElBQUksS0FBSyxLQUFLO0FBQUEsUUFDdEo7QUFDQSxtQkFBVyxVQUFVLFNBQVMsTUFBTTtBQUNsQyxjQUFJLENBQUMsYUFBYSxJQUFJLE9BQU8sSUFBSSxLQUFLLG1CQUFtQixNQUFNLEdBQUc7QUFDaEUsa0JBQU0sYUFBYSxRQUFRLE9BQU8sSUFBSTtBQUN0QyxvQkFBUTtBQUFBLGNBQ04sSUFBSTtBQUFBLGdCQUNGLFVBQVUsU0FBUyxJQUFJLGVBQWUsT0FBTyxJQUFJLGNBQWMsVUFBVTtBQUFBLGdCQUN6RTtBQUFBLGtCQUNFLE9BQU87QUFBQSxnQkFDVDtBQUFBLGNBQ0Y7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUNBLFNBQVMsMENBQTBDLFNBQVM7QUFDMUQsTUFBSTtBQUNKLFFBQU0sa0JBQWtDLHVCQUFPLE9BQU8sSUFBSTtBQUMxRCxRQUFNLFNBQVMsUUFBUSxVQUFVO0FBQ2pDLFFBQU0scUJBQXFCLHdCQUF3QixXQUFXLFFBQVEsV0FBVyxTQUFTLFNBQVMsT0FBTyxjQUFjLE9BQU8sUUFBUSwwQkFBMEIsU0FBUyx3QkFBd0I7QUFDbE0sYUFBVyxhQUFhLG1CQUFtQjtBQUN6QyxvQkFBZ0IsVUFBVSxJQUFJLElBQUk7QUFBQSxNQUNoQyxVQUFVLEtBQUssT0FBTyxrQkFBa0I7QUFBQSxNQUN4QyxDQUFDLFFBQVEsSUFBSTtBQUFBLElBQ2Y7QUFBQSxFQUNGO0FBQ0EsUUFBTSxpQkFBaUIsUUFBUSxZQUFZLEVBQUU7QUFDN0MsYUFBVyxPQUFPLGdCQUFnQjtBQUNoQyxRQUFJLElBQUksU0FBUyxLQUFLLHNCQUFzQjtBQUMxQyxVQUFJO0FBQ0osWUFBTSxZQUFZLGlCQUFpQixJQUFJLGVBQWUsUUFBUSxtQkFBbUIsU0FBUyxpQkFBaUIsQ0FBQztBQUM1RyxzQkFBZ0IsSUFBSSxLQUFLLEtBQUssSUFBSTtBQUFBLFFBQ2hDLFNBQVMsT0FBTyxzQkFBc0I7QUFBQSxRQUN0QyxDQUFDLFFBQVEsSUFBSSxLQUFLO0FBQUEsTUFDcEI7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFBQSxJQUNMLFdBQVc7QUFBQTtBQUFBLE1BRVQsTUFBTSxlQUFlO0FBQ25CLGNBQU0sZ0JBQWdCLGNBQWMsS0FBSztBQUN6QyxjQUFNLGVBQWUsZ0JBQWdCLGFBQWE7QUFDbEQsWUFBSSxjQUFjO0FBQ2hCLGNBQUk7QUFDSixnQkFBTSxZQUFZLHdCQUF3QixjQUFjLGVBQWUsUUFBUSwwQkFBMEIsU0FBUyx3QkFBd0IsQ0FBQztBQUMzSSxnQkFBTSxhQUFhLElBQUksSUFBSSxTQUFTLElBQUksQ0FBQyxRQUFRLElBQUksS0FBSyxLQUFLLENBQUM7QUFDaEUscUJBQVcsQ0FBQyxTQUFTLE1BQU0sS0FBSyxPQUFPLFFBQVEsWUFBWSxHQUFHO0FBQzVELGdCQUFJLENBQUMsV0FBVyxJQUFJLE9BQU8sR0FBRztBQUM1QixvQkFBTSxVQUFVLE9BQU8sT0FBTyxJQUFJLElBQUksUUFBUSxPQUFPLElBQUksSUFBSSxNQUFNLE9BQU8sSUFBSTtBQUM5RSxzQkFBUTtBQUFBLGdCQUNOLElBQUk7QUFBQSxrQkFDRixlQUFlLGFBQWEsZUFBZSxPQUFPLGNBQWMsT0FBTztBQUFBLGtCQUN2RTtBQUFBLG9CQUNFLE9BQU87QUFBQSxrQkFDVDtBQUFBLGdCQUNGO0FBQUEsY0FDRjtBQUFBLFlBQ0Y7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGO0FBQ0EsU0FBUyx1QkFBdUIsS0FBSztBQUNuQyxTQUFPLElBQUksS0FBSyxTQUFTLEtBQUssaUJBQWlCLElBQUksZ0JBQWdCO0FBQ3JFO0FBR0EsU0FBUyxnQkFBZ0IsU0FBUztBQUNoQyxTQUFPO0FBQUEsSUFDTCxNQUFNLE1BQU07QUFDVixZQUFNLE9BQU8sUUFBUSxRQUFRO0FBQzdCLFlBQU0sZUFBZSxLQUFLO0FBQzFCLFVBQUksTUFBTTtBQUNSLFlBQUksV0FBVyxhQUFhLElBQUksQ0FBQyxHQUFHO0FBQ2xDLGNBQUksY0FBYztBQUNoQixrQkFBTSxZQUFZLEtBQUssS0FBSztBQUM1QixrQkFBTSxVQUFVLFFBQVEsSUFBSTtBQUM1QixvQkFBUTtBQUFBLGNBQ04sSUFBSTtBQUFBLGdCQUNGLFVBQVUsU0FBUywyQ0FBMkMsT0FBTztBQUFBLGdCQUNyRTtBQUFBLGtCQUNFLE9BQU87QUFBQSxnQkFDVDtBQUFBLGNBQ0Y7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUFBLFFBQ0YsV0FBVyxDQUFDLGNBQWM7QUFDeEIsZ0JBQU0sWUFBWSxLQUFLLEtBQUs7QUFDNUIsZ0JBQU0sVUFBVSxRQUFRLElBQUk7QUFDNUIsa0JBQVE7QUFBQSxZQUNOLElBQUk7QUFBQSxjQUNGLFVBQVUsU0FBUyxjQUFjLE9BQU8sdURBQXVELFNBQVM7QUFBQSxjQUN4RztBQUFBLGdCQUNFLE9BQU87QUFBQSxjQUNUO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0Y7QUFHQSxTQUFTLGFBQWEsV0FBVyxNQUFNLFdBQVc7QUFDaEQsTUFBSSxDQUFDLFdBQVc7QUFDZDtBQUFBLEVBQ0Y7QUFDQSxNQUFJLFVBQVUsU0FBUyxLQUFLLFVBQVU7QUFDcEMsVUFBTSxlQUFlLFVBQVUsS0FBSztBQUNwQyxRQUFJLGFBQWEsUUFBUSxVQUFVLFlBQVksTUFBTSxRQUFRO0FBQzNEO0FBQUEsSUFDRjtBQUNBLFVBQU0sZ0JBQWdCLFVBQVUsWUFBWTtBQUM1QyxRQUFJLGtCQUFrQixRQUFRLGNBQWMsSUFBSSxHQUFHO0FBQ2pEO0FBQUEsSUFDRjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQ0EsTUFBSSxjQUFjLElBQUksR0FBRztBQUN2QixRQUFJLFVBQVUsU0FBUyxLQUFLLE1BQU07QUFDaEM7QUFBQSxJQUNGO0FBQ0EsV0FBTyxhQUFhLFdBQVcsS0FBSyxRQUFRLFNBQVM7QUFBQSxFQUN2RDtBQUNBLE1BQUksVUFBVSxTQUFTLEtBQUssTUFBTTtBQUNoQyxXQUFPO0FBQUEsRUFDVDtBQUNBLE1BQUksV0FBVyxJQUFJLEdBQUc7QUFDcEIsVUFBTSxXQUFXLEtBQUs7QUFDdEIsUUFBSSxVQUFVLFNBQVMsS0FBSyxNQUFNO0FBQ2hDLFlBQU0sZ0JBQWdCLENBQUM7QUFDdkIsaUJBQVcsWUFBWSxVQUFVLFFBQVE7QUFDdkMsWUFBSSxrQkFBa0IsVUFBVSxTQUFTLEdBQUc7QUFDMUMsY0FBSSxjQUFjLFFBQVEsR0FBRztBQUMzQjtBQUFBLFVBQ0Y7QUFDQSx3QkFBYyxLQUFLLElBQUk7QUFBQSxRQUN6QixPQUFPO0FBQ0wsZ0JBQU0sWUFBWSxhQUFhLFVBQVUsVUFBVSxTQUFTO0FBQzVELGNBQUksY0FBYyxRQUFRO0FBQ3hCO0FBQUEsVUFDRjtBQUNBLHdCQUFjLEtBQUssU0FBUztBQUFBLFFBQzlCO0FBQUEsTUFDRjtBQUNBLGFBQU87QUFBQSxJQUNUO0FBQ0EsVUFBTSxlQUFlLGFBQWEsV0FBVyxVQUFVLFNBQVM7QUFDaEUsUUFBSSxpQkFBaUIsUUFBUTtBQUMzQjtBQUFBLElBQ0Y7QUFDQSxXQUFPLENBQUMsWUFBWTtBQUFBLEVBQ3RCO0FBQ0EsTUFBSSxrQkFBa0IsSUFBSSxHQUFHO0FBQzNCLFFBQUksVUFBVSxTQUFTLEtBQUssUUFBUTtBQUNsQztBQUFBLElBQ0Y7QUFDQSxVQUFNLGFBQTZCLHVCQUFPLE9BQU8sSUFBSTtBQUNyRCxVQUFNLGFBQWEsT0FBTyxVQUFVLFFBQVEsQ0FBQyxVQUFVLE1BQU0sS0FBSyxLQUFLO0FBQ3ZFLGVBQVcsU0FBUyxPQUFPLE9BQU8sS0FBSyxVQUFVLENBQUMsR0FBRztBQUNuRCxZQUFNLFlBQVksV0FBVyxNQUFNLElBQUk7QUFDdkMsVUFBSSxDQUFDLGFBQWEsa0JBQWtCLFVBQVUsT0FBTyxTQUFTLEdBQUc7QUFDL0QsWUFBSSxNQUFNLGlCQUFpQixRQUFRO0FBQ2pDLHFCQUFXLE1BQU0sSUFBSSxJQUFJLE1BQU07QUFBQSxRQUNqQyxXQUFXLGNBQWMsTUFBTSxJQUFJLEdBQUc7QUFDcEM7QUFBQSxRQUNGO0FBQ0E7QUFBQSxNQUNGO0FBQ0EsWUFBTSxhQUFhLGFBQWEsVUFBVSxPQUFPLE1BQU0sTUFBTSxTQUFTO0FBQ3RFLFVBQUksZUFBZSxRQUFRO0FBQ3pCO0FBQUEsTUFDRjtBQUNBLGlCQUFXLE1BQU0sSUFBSSxJQUFJO0FBQUEsSUFDM0I7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUNBLE1BQUksV0FBVyxJQUFJLEdBQUc7QUFDcEIsUUFBSTtBQUNKLFFBQUk7QUFDRixlQUFTLEtBQUssYUFBYSxXQUFXLFNBQVM7QUFBQSxJQUNqRCxTQUFTLFFBQVE7QUFDZjtBQUFBLElBQ0Y7QUFDQSxRQUFJLFdBQVcsUUFBUTtBQUNyQjtBQUFBLElBQ0Y7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUNBLGFBQVcsT0FBTyw0QkFBNEIsUUFBUSxJQUFJLENBQUM7QUFDN0Q7QUFDQSxTQUFTLGtCQUFrQixXQUFXLFdBQVc7QUFDL0MsU0FBTyxVQUFVLFNBQVMsS0FBSyxhQUFhLGFBQWEsUUFBUSxVQUFVLFVBQVUsS0FBSyxLQUFLLE1BQU07QUFDdkc7QUFHQSxTQUFTLGtCQUFrQixLQUFLLE1BQU0sZ0JBQWdCO0FBQ3BELE1BQUk7QUFDSixRQUFNLGdCQUFnQixDQUFDO0FBQ3ZCLFFBQU0saUJBQWlCLGtCQUFrQixLQUFLLGVBQWUsUUFBUSxvQkFBb0IsU0FBUyxrQkFBa0IsQ0FBQztBQUNySCxRQUFNLGFBQWEsT0FBTyxlQUFlLENBQUMsUUFBUSxJQUFJLEtBQUssS0FBSztBQUNoRSxhQUFXLFVBQVUsSUFBSSxNQUFNO0FBQzdCLFVBQU0sT0FBTyxPQUFPO0FBQ3BCLFVBQU0sVUFBVSxPQUFPO0FBQ3ZCLFVBQU0sZUFBZSxXQUFXLElBQUk7QUFDcEMsUUFBSSxDQUFDLGNBQWM7QUFDakIsVUFBSSxPQUFPLGlCQUFpQixRQUFRO0FBQ2xDLHNCQUFjLElBQUksSUFBSSxPQUFPO0FBQUEsTUFDL0IsV0FBVyxjQUFjLE9BQU8sR0FBRztBQUNqQyxjQUFNLElBQUk7QUFBQSxVQUNSLGFBQWEsSUFBSSx1QkFBdUIsUUFBUSxPQUFPLENBQUM7QUFBQSxVQUN4RDtBQUFBLFlBQ0UsT0FBTztBQUFBLFVBQ1Q7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBO0FBQUEsSUFDRjtBQUNBLFVBQU0sWUFBWSxhQUFhO0FBQy9CLFFBQUksU0FBUyxVQUFVLFNBQVMsS0FBSztBQUNyQyxRQUFJLFVBQVUsU0FBUyxLQUFLLFVBQVU7QUFDcEMsWUFBTSxlQUFlLFVBQVUsS0FBSztBQUNwQyxVQUFJLGtCQUFrQixRQUFRLENBQUMsZUFBZSxnQkFBZ0IsWUFBWSxHQUFHO0FBQzNFLFlBQUksT0FBTyxpQkFBaUIsUUFBUTtBQUNsQyx3QkFBYyxJQUFJLElBQUksT0FBTztBQUFBLFFBQy9CLFdBQVcsY0FBYyxPQUFPLEdBQUc7QUFDakMsZ0JBQU0sSUFBSTtBQUFBLFlBQ1IsYUFBYSxJQUFJLHVCQUF1QixRQUFRLE9BQU8sQ0FBQyxpQ0FBaUMsWUFBWTtBQUFBLFlBQ3JHO0FBQUEsY0FDRSxPQUFPO0FBQUEsWUFDVDtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQ0E7QUFBQSxNQUNGO0FBQ0EsZUFBUyxlQUFlLFlBQVksS0FBSztBQUFBLElBQzNDO0FBQ0EsUUFBSSxVQUFVLGNBQWMsT0FBTyxHQUFHO0FBQ3BDLFlBQU0sSUFBSTtBQUFBLFFBQ1IsYUFBYSxJQUFJLHVCQUF1QixRQUFRLE9BQU8sQ0FBQztBQUFBLFFBQ3hEO0FBQUEsVUFDRSxPQUFPO0FBQUEsUUFDVDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsVUFBTSxlQUFlLGFBQWEsV0FBVyxTQUFTLGNBQWM7QUFDcEUsUUFBSSxpQkFBaUIsUUFBUTtBQUMzQixZQUFNLElBQUk7QUFBQSxRQUNSLGFBQWEsSUFBSSx1QkFBdUIsTUFBTSxTQUFTLENBQUM7QUFBQSxRQUN4RDtBQUFBLFVBQ0UsT0FBTztBQUFBLFFBQ1Q7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLGtCQUFjLElBQUksSUFBSTtBQUFBLEVBQ3hCO0FBQ0EsU0FBTztBQUNUO0FBQ0EsU0FBUyxtQkFBbUIsY0FBYyxNQUFNLGdCQUFnQjtBQUM5RCxNQUFJO0FBQ0osUUFBTSxpQkFBaUIsbUJBQW1CLEtBQUssZ0JBQWdCLFFBQVEscUJBQXFCLFNBQVMsU0FBUyxpQkFBaUI7QUFBQSxJQUM3SCxDQUFDLGNBQWMsVUFBVSxLQUFLLFVBQVUsYUFBYTtBQUFBLEVBQ3ZEO0FBQ0EsTUFBSSxlQUFlO0FBQ2pCLFdBQU8sa0JBQWtCLGNBQWMsZUFBZSxjQUFjO0FBQUEsRUFDdEU7QUFDRjtBQUNBLFNBQVMsZUFBZSxLQUFLLE1BQU07QUFDakMsU0FBTyxPQUFPLFVBQVUsZUFBZSxLQUFLLEtBQUssSUFBSTtBQUN2RDtBQUdBLFNBQVMsY0FBYyxRQUFRLFdBQVcsZ0JBQWdCLGFBQWEsY0FBYztBQUNuRixRQUFNLFNBQXlCLG9CQUFJLElBQUk7QUFDdkM7QUFBQSxJQUNFO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNnQixvQkFBSSxJQUFJO0FBQUEsRUFDMUI7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLGlCQUFpQixRQUFRLFdBQVcsZ0JBQWdCLFlBQVksWUFBWTtBQUNuRixRQUFNLGdCQUFnQyxvQkFBSSxJQUFJO0FBQzlDLFFBQU0sdUJBQXVDLG9CQUFJLElBQUk7QUFDckQsYUFBVyxRQUFRLFlBQVk7QUFDN0IsUUFBSSxLQUFLLGNBQWM7QUFDckI7QUFBQSxRQUNFO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQSxLQUFLO0FBQUEsUUFDTDtBQUFBLFFBQ0E7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLGtCQUFrQixRQUFRLFdBQVcsZ0JBQWdCLGFBQWEsY0FBYyxRQUFRLHNCQUFzQjtBQUNySCxhQUFXLGFBQWEsYUFBYSxZQUFZO0FBQy9DLFlBQVEsVUFBVSxNQUFNO0FBQUEsTUFDdEIsS0FBSyxLQUFLLE9BQU87QUFDZixZQUFJLENBQUMsa0JBQWtCLGdCQUFnQixTQUFTLEdBQUc7QUFDakQ7QUFBQSxRQUNGO0FBQ0EsY0FBTSxPQUFPLGlCQUFpQixTQUFTO0FBQ3ZDLGNBQU0sWUFBWSxPQUFPLElBQUksSUFBSTtBQUNqQyxZQUFJLGNBQWMsUUFBUTtBQUN4QixvQkFBVSxLQUFLLFNBQVM7QUFBQSxRQUMxQixPQUFPO0FBQ0wsaUJBQU8sSUFBSSxNQUFNLENBQUMsU0FBUyxDQUFDO0FBQUEsUUFDOUI7QUFDQTtBQUFBLE1BQ0Y7QUFBQSxNQUNBLEtBQUssS0FBSyxpQkFBaUI7QUFDekIsWUFBSSxDQUFDLGtCQUFrQixnQkFBZ0IsU0FBUyxLQUFLLENBQUMsMkJBQTJCLFFBQVEsV0FBVyxXQUFXLEdBQUc7QUFDaEg7QUFBQSxRQUNGO0FBQ0E7QUFBQSxVQUNFO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQSxVQUFVO0FBQUEsVUFDVjtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQ0E7QUFBQSxNQUNGO0FBQUEsTUFDQSxLQUFLLEtBQUssaUJBQWlCO0FBQ3pCLGNBQU0sV0FBVyxVQUFVLEtBQUs7QUFDaEMsWUFBSSxxQkFBcUIsSUFBSSxRQUFRLEtBQUssQ0FBQyxrQkFBa0IsZ0JBQWdCLFNBQVMsR0FBRztBQUN2RjtBQUFBLFFBQ0Y7QUFDQSw2QkFBcUIsSUFBSSxRQUFRO0FBQ2pDLGNBQU0sV0FBVyxVQUFVLFFBQVE7QUFDbkMsWUFBSSxDQUFDLFlBQVksQ0FBQywyQkFBMkIsUUFBUSxVQUFVLFdBQVcsR0FBRztBQUMzRTtBQUFBLFFBQ0Y7QUFDQTtBQUFBLFVBQ0U7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBLFNBQVM7QUFBQSxVQUNUO0FBQUEsVUFDQTtBQUFBLFFBQ0Y7QUFDQTtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGO0FBQ0EsU0FBUyxrQkFBa0IsZ0JBQWdCLE1BQU07QUFDL0MsUUFBTSxPQUFPLG1CQUFtQixzQkFBc0IsTUFBTSxjQUFjO0FBQzFFLE9BQUssU0FBUyxRQUFRLFNBQVMsU0FBUyxTQUFTLEtBQUssUUFBUSxNQUFNO0FBQ2xFLFdBQU87QUFBQSxFQUNUO0FBQ0EsUUFBTSxVQUFVO0FBQUEsSUFDZDtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNBLE9BQUssWUFBWSxRQUFRLFlBQVksU0FBUyxTQUFTLFFBQVEsUUFBUSxPQUFPO0FBQzVFLFdBQU87QUFBQSxFQUNUO0FBQ0EsU0FBTztBQUNUO0FBQ0EsU0FBUywyQkFBMkIsUUFBUSxVQUFVLE1BQU07QUFDMUQsUUFBTSxvQkFBb0IsU0FBUztBQUNuQyxNQUFJLENBQUMsbUJBQW1CO0FBQ3RCLFdBQU87QUFBQSxFQUNUO0FBQ0EsUUFBTSxrQkFBa0IsWUFBWSxRQUFRLGlCQUFpQjtBQUM3RCxNQUFJLG9CQUFvQixNQUFNO0FBQzVCLFdBQU87QUFBQSxFQUNUO0FBQ0EsTUFBSSxlQUFlLGVBQWUsR0FBRztBQUNuQyxXQUFPLE9BQU8sVUFBVSxpQkFBaUIsSUFBSTtBQUFBLEVBQy9DO0FBQ0EsU0FBTztBQUNUO0FBQ0EsU0FBUyxpQkFBaUIsTUFBTTtBQUM5QixTQUFPLEtBQUssUUFBUSxLQUFLLE1BQU0sUUFBUSxLQUFLLEtBQUs7QUFDbkQ7QUFHQSxTQUFTLDZCQUE2QixTQUFTO0FBQzdDLFNBQU87QUFBQSxJQUNMLG9CQUFvQixNQUFNO0FBQ3hCLFVBQUksS0FBSyxjQUFjLGdCQUFnQjtBQUNyQyxjQUFNLFNBQVMsUUFBUSxVQUFVO0FBQ2pDLGNBQU0sbUJBQW1CLE9BQU8sb0JBQW9CO0FBQ3BELFlBQUksa0JBQWtCO0FBQ3BCLGdCQUFNLGdCQUFnQixLQUFLLE9BQU8sS0FBSyxLQUFLLFFBQVE7QUFDcEQsZ0JBQU0saUJBQWlDLHVCQUFPLE9BQU8sSUFBSTtBQUN6RCxnQkFBTSxZQUFZLFFBQVEsWUFBWTtBQUN0QyxnQkFBTSxZQUE0Qix1QkFBTyxPQUFPLElBQUk7QUFDcEQscUJBQVcsY0FBYyxVQUFVLGFBQWE7QUFDOUMsZ0JBQUksV0FBVyxTQUFTLEtBQUsscUJBQXFCO0FBQ2hELHdCQUFVLFdBQVcsS0FBSyxLQUFLLElBQUk7QUFBQSxZQUNyQztBQUFBLFVBQ0Y7QUFDQSxnQkFBTSxTQUFTO0FBQUEsWUFDYjtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0EsS0FBSztBQUFBLFVBQ1A7QUFDQSxjQUFJLE9BQU8sT0FBTyxHQUFHO0FBQ25CLGtCQUFNLHNCQUFzQixDQUFDLEdBQUcsT0FBTyxPQUFPLENBQUM7QUFDL0Msa0JBQU0sMkJBQTJCLG9CQUFvQixNQUFNLENBQUM7QUFDNUQsa0JBQU0sdUJBQXVCLHlCQUF5QixLQUFLO0FBQzNELG9CQUFRO0FBQUEsY0FDTixJQUFJO0FBQUEsZ0JBQ0YsaUJBQWlCLE9BQU8saUJBQWlCLGFBQWEsNENBQTRDO0FBQUEsZ0JBQ2xHO0FBQUEsa0JBQ0UsT0FBTztBQUFBLGdCQUNUO0FBQUEsY0FDRjtBQUFBLFlBQ0Y7QUFBQSxVQUNGO0FBQ0EscUJBQVcsY0FBYyxPQUFPLE9BQU8sR0FBRztBQUN4QyxrQkFBTSxRQUFRLFdBQVcsQ0FBQztBQUMxQixrQkFBTSxZQUFZLE1BQU0sS0FBSztBQUM3QixnQkFBSSxVQUFVLFdBQVcsSUFBSSxHQUFHO0FBQzlCLHNCQUFRO0FBQUEsZ0JBQ04sSUFBSTtBQUFBLGtCQUNGLGlCQUFpQixPQUFPLGlCQUFpQixhQUFhLHdEQUF3RDtBQUFBLGtCQUM5RztBQUFBLG9CQUNFLE9BQU87QUFBQSxrQkFDVDtBQUFBLGdCQUNGO0FBQUEsY0FDRjtBQUFBLFlBQ0Y7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGO0FBR0EsU0FBUyxRQUFRLE1BQU0sT0FBTztBQUM1QixRQUFNLFNBQXlCLG9CQUFJLElBQUk7QUFDdkMsYUFBVyxRQUFRLE1BQU07QUFDdkIsVUFBTSxNQUFNLE1BQU0sSUFBSTtBQUN0QixVQUFNLFFBQVEsT0FBTyxJQUFJLEdBQUc7QUFDNUIsUUFBSSxVQUFVLFFBQVE7QUFDcEIsYUFBTyxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUM7QUFBQSxJQUN4QixPQUFPO0FBQ0wsWUFBTSxLQUFLLElBQUk7QUFBQSxJQUNqQjtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFHQSxTQUFTLGtDQUFrQyxTQUFTO0FBQ2xELFNBQU87QUFBQSxJQUNMLG9CQUFvQixlQUFlO0FBQ2pDLFVBQUk7QUFDSixZQUFNLGlCQUFpQix3QkFBd0IsY0FBYyxlQUFlLFFBQVEsMEJBQTBCLFNBQVMsd0JBQXdCLENBQUM7QUFDaEosYUFBTyxtQkFBbUIsSUFBSSxjQUFjLEtBQUssS0FBSyxJQUFJLGFBQWE7QUFBQSxJQUN6RTtBQUFBLElBQ0EseUJBQXlCO0FBQUEsSUFDekIsd0JBQXdCO0FBQUEsSUFDeEIsc0JBQXNCO0FBQUEsSUFDdEIscUJBQXFCO0FBQUEsRUFDdkI7QUFDQSxXQUFTLDJCQUEyQixVQUFVO0FBQzVDLFFBQUk7QUFDSixVQUFNLFdBQVcsU0FBUyxLQUFLO0FBQy9CLFVBQU0sY0FBYyxtQkFBbUIsU0FBUyxZQUFZLFFBQVEscUJBQXFCLFNBQVMsbUJBQW1CLENBQUM7QUFDdEgsZUFBVyxZQUFZLFlBQVk7QUFDakMsVUFBSTtBQUNKLFlBQU0sWUFBWSxTQUFTLEtBQUs7QUFDaEMsWUFBTSxpQkFBaUIsc0JBQXNCLFNBQVMsZUFBZSxRQUFRLHdCQUF3QixTQUFTLHNCQUFzQixDQUFDO0FBQ3JJLHlCQUFtQixHQUFHLFFBQVEsSUFBSSxTQUFTLElBQUksYUFBYTtBQUFBLElBQzlEO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDQSxXQUFTLG1CQUFtQixZQUFZLGVBQWU7QUFDckQsVUFBTSxXQUFXLFFBQVEsZUFBZSxDQUFDLFFBQVEsSUFBSSxLQUFLLEtBQUs7QUFDL0QsZUFBVyxDQUFDLFNBQVMsUUFBUSxLQUFLLFVBQVU7QUFDMUMsVUFBSSxTQUFTLFNBQVMsR0FBRztBQUN2QixnQkFBUTtBQUFBLFVBQ04sSUFBSTtBQUFBLFlBQ0YsYUFBYSxVQUFVLElBQUksT0FBTztBQUFBLFlBQ2xDO0FBQUEsY0FDRSxPQUFPLFNBQVMsSUFBSSxDQUFDLFNBQVMsS0FBSyxJQUFJO0FBQUEsWUFDekM7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUdBLFNBQVMsd0JBQXdCLFNBQVM7QUFDeEMsU0FBTztBQUFBLElBQ0wsT0FBTztBQUFBLElBQ1AsV0FBVztBQUFBLEVBQ2I7QUFDQSxXQUFTLG1CQUFtQixZQUFZO0FBQ3RDLFFBQUk7QUFDSixVQUFNLGlCQUFpQix3QkFBd0IsV0FBVyxlQUFlLFFBQVEsMEJBQTBCLFNBQVMsd0JBQXdCLENBQUM7QUFDN0ksVUFBTSxXQUFXLFFBQVEsZUFBZSxDQUFDLFFBQVEsSUFBSSxLQUFLLEtBQUs7QUFDL0QsZUFBVyxDQUFDLFNBQVMsUUFBUSxLQUFLLFVBQVU7QUFDMUMsVUFBSSxTQUFTLFNBQVMsR0FBRztBQUN2QixnQkFBUTtBQUFBLFVBQ04sSUFBSTtBQUFBLFlBQ0YseUNBQXlDLE9BQU87QUFBQSxZQUNoRDtBQUFBLGNBQ0UsT0FBTyxTQUFTLElBQUksQ0FBQyxTQUFTLEtBQUssSUFBSTtBQUFBLFlBQ3pDO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUdBLFNBQVMseUJBQXlCLFNBQVM7QUFDekMsUUFBTSxzQkFBc0MsdUJBQU8sT0FBTyxJQUFJO0FBQzlELFFBQU0sU0FBUyxRQUFRLFVBQVU7QUFDakMsU0FBTztBQUFBLElBQ0wsb0JBQW9CLE1BQU07QUFDeEIsWUFBTSxnQkFBZ0IsS0FBSyxLQUFLO0FBQ2hDLFVBQUksV0FBVyxRQUFRLFdBQVcsVUFBVSxPQUFPLGFBQWEsYUFBYSxHQUFHO0FBQzlFLGdCQUFRO0FBQUEsVUFDTixJQUFJO0FBQUEsWUFDRixlQUFlLGFBQWE7QUFBQSxZQUM1QjtBQUFBLGNBQ0UsT0FBTyxLQUFLO0FBQUEsWUFDZDtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQ0E7QUFBQSxNQUNGO0FBQ0EsVUFBSSxvQkFBb0IsYUFBYSxHQUFHO0FBQ3RDLGdCQUFRO0FBQUEsVUFDTixJQUFJO0FBQUEsWUFDRiwyQ0FBMkMsYUFBYTtBQUFBLFlBQ3hEO0FBQUEsY0FDRSxPQUFPLENBQUMsb0JBQW9CLGFBQWEsR0FBRyxLQUFLLElBQUk7QUFBQSxZQUN2RDtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRixPQUFPO0FBQ0wsNEJBQW9CLGFBQWEsSUFBSSxLQUFLO0FBQUEsTUFDNUM7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFDRjtBQUdBLFNBQVMsZ0NBQWdDLFNBQVM7QUFDaEQsUUFBTSxxQkFBcUMsdUJBQU8sT0FBTyxJQUFJO0FBQzdELFFBQU0sU0FBUyxRQUFRLFVBQVU7QUFDakMsUUFBTSxvQkFBb0IsU0FBUyxPQUFPLGNBQWMsSUFBSTtBQUM1RCxhQUFXLGFBQWEsbUJBQW1CO0FBQ3pDLHVCQUFtQixVQUFVLElBQUksSUFBSSxDQUFDLFVBQVU7QUFBQSxFQUNsRDtBQUNBLFFBQU0saUJBQWlCLFFBQVEsWUFBWSxFQUFFO0FBQzdDLGFBQVcsT0FBTyxnQkFBZ0I7QUFDaEMsUUFBSSxJQUFJLFNBQVMsS0FBSyxzQkFBc0I7QUFDMUMseUJBQW1CLElBQUksS0FBSyxLQUFLLElBQUksQ0FBQyxJQUFJO0FBQUEsSUFDNUM7QUFBQSxFQUNGO0FBQ0EsUUFBTSxtQkFBbUMsdUJBQU8sT0FBTyxJQUFJO0FBQzNELFFBQU0sb0JBQW9DLHVCQUFPLE9BQU8sSUFBSTtBQUM1RCxTQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFJTCxNQUFNLE1BQU07QUFDVixVQUFJLEVBQUUsZ0JBQWdCLFNBQVMsQ0FBQyxLQUFLLFlBQVk7QUFDL0M7QUFBQSxNQUNGO0FBQ0EsVUFBSTtBQUNKLFVBQUksS0FBSyxTQUFTLEtBQUsscUJBQXFCLEtBQUssU0FBUyxLQUFLLGtCQUFrQjtBQUMvRSx5QkFBaUI7QUFBQSxNQUNuQixXQUFXLHFCQUFxQixJQUFJLEtBQUssb0JBQW9CLElBQUksR0FBRztBQUNsRSxjQUFNLFdBQVcsS0FBSyxLQUFLO0FBQzNCLHlCQUFpQixrQkFBa0IsUUFBUTtBQUMzQyxZQUFJLG1CQUFtQixRQUFRO0FBQzdCLDRCQUFrQixRQUFRLElBQUksaUJBQWlDLHVCQUFPLE9BQU8sSUFBSTtBQUFBLFFBQ25GO0FBQUEsTUFDRixPQUFPO0FBQ0wseUJBQWlDLHVCQUFPLE9BQU8sSUFBSTtBQUFBLE1BQ3JEO0FBQ0EsaUJBQVcsYUFBYSxLQUFLLFlBQVk7QUFDdkMsY0FBTSxnQkFBZ0IsVUFBVSxLQUFLO0FBQ3JDLFlBQUksbUJBQW1CLGFBQWEsR0FBRztBQUNyQyxjQUFJLGVBQWUsYUFBYSxHQUFHO0FBQ2pDLG9CQUFRO0FBQUEsY0FDTixJQUFJO0FBQUEsZ0JBQ0YsbUJBQW1CLGFBQWE7QUFBQSxnQkFDaEM7QUFBQSxrQkFDRSxPQUFPLENBQUMsZUFBZSxhQUFhLEdBQUcsU0FBUztBQUFBLGdCQUNsRDtBQUFBLGNBQ0Y7QUFBQSxZQUNGO0FBQUEsVUFDRixPQUFPO0FBQ0wsMkJBQWUsYUFBYSxJQUFJO0FBQUEsVUFDbEM7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0Y7QUFHQSxTQUFTLHlCQUF5QixTQUFTO0FBQ3pDLFFBQU0sU0FBUyxRQUFRLFVBQVU7QUFDakMsUUFBTSxrQkFBa0IsU0FBUyxPQUFPLFdBQVcsSUFBb0IsdUJBQU8sT0FBTyxJQUFJO0FBQ3pGLFFBQU0sa0JBQWtDLHVCQUFPLE9BQU8sSUFBSTtBQUMxRCxTQUFPO0FBQUEsSUFDTCxvQkFBb0I7QUFBQSxJQUNwQixtQkFBbUI7QUFBQSxFQUNyQjtBQUNBLFdBQVMscUJBQXFCLE1BQU07QUFDbEMsUUFBSTtBQUNKLFVBQU0sV0FBVyxLQUFLLEtBQUs7QUFDM0IsUUFBSSxDQUFDLGdCQUFnQixRQUFRLEdBQUc7QUFDOUIsc0JBQWdCLFFBQVEsSUFBb0IsdUJBQU8sT0FBTyxJQUFJO0FBQUEsSUFDaEU7QUFDQSxVQUFNLGNBQWMsZUFBZSxLQUFLLFlBQVksUUFBUSxpQkFBaUIsU0FBUyxlQUFlLENBQUM7QUFDdEcsVUFBTSxhQUFhLGdCQUFnQixRQUFRO0FBQzNDLGVBQVcsWUFBWSxZQUFZO0FBQ2pDLFlBQU0sWUFBWSxTQUFTLEtBQUs7QUFDaEMsWUFBTSxlQUFlLGdCQUFnQixRQUFRO0FBQzdDLFVBQUksV0FBVyxZQUFZLEtBQUssYUFBYSxTQUFTLFNBQVMsR0FBRztBQUNoRSxnQkFBUTtBQUFBLFVBQ04sSUFBSTtBQUFBLFlBQ0YsZUFBZSxRQUFRLElBQUksU0FBUztBQUFBLFlBQ3BDO0FBQUEsY0FDRSxPQUFPLFNBQVM7QUFBQSxZQUNsQjtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRixXQUFXLFdBQVcsU0FBUyxHQUFHO0FBQ2hDLGdCQUFRO0FBQUEsVUFDTixJQUFJO0FBQUEsWUFDRixlQUFlLFFBQVEsSUFBSSxTQUFTO0FBQUEsWUFDcEM7QUFBQSxjQUNFLE9BQU8sQ0FBQyxXQUFXLFNBQVMsR0FBRyxTQUFTLElBQUk7QUFBQSxZQUM5QztBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRixPQUFPO0FBQ0wsbUJBQVcsU0FBUyxJQUFJLFNBQVM7QUFBQSxNQUNuQztBQUFBLElBQ0Y7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUNGO0FBR0EsU0FBUywrQkFBK0IsU0FBUztBQUMvQyxRQUFNLFNBQVMsUUFBUSxVQUFVO0FBQ2pDLFFBQU0sa0JBQWtCLFNBQVMsT0FBTyxXQUFXLElBQW9CLHVCQUFPLE9BQU8sSUFBSTtBQUN6RixRQUFNLGtCQUFrQyx1QkFBTyxPQUFPLElBQUk7QUFDMUQsU0FBTztBQUFBLElBQ0wsMkJBQTJCO0FBQUEsSUFDM0IsMEJBQTBCO0FBQUEsSUFDMUIseUJBQXlCO0FBQUEsSUFDekIsd0JBQXdCO0FBQUEsSUFDeEIsc0JBQXNCO0FBQUEsSUFDdEIscUJBQXFCO0FBQUEsRUFDdkI7QUFDQSxXQUFTLHFCQUFxQixNQUFNO0FBQ2xDLFFBQUk7QUFDSixVQUFNLFdBQVcsS0FBSyxLQUFLO0FBQzNCLFFBQUksQ0FBQyxnQkFBZ0IsUUFBUSxHQUFHO0FBQzlCLHNCQUFnQixRQUFRLElBQW9CLHVCQUFPLE9BQU8sSUFBSTtBQUFBLElBQ2hFO0FBQ0EsVUFBTSxjQUFjLGVBQWUsS0FBSyxZQUFZLFFBQVEsaUJBQWlCLFNBQVMsZUFBZSxDQUFDO0FBQ3RHLFVBQU0sYUFBYSxnQkFBZ0IsUUFBUTtBQUMzQyxlQUFXLFlBQVksWUFBWTtBQUNqQyxZQUFNLFlBQVksU0FBUyxLQUFLO0FBQ2hDLFVBQUksU0FBUyxnQkFBZ0IsUUFBUSxHQUFHLFNBQVMsR0FBRztBQUNsRCxnQkFBUTtBQUFBLFVBQ04sSUFBSTtBQUFBLFlBQ0YsVUFBVSxRQUFRLElBQUksU0FBUztBQUFBLFlBQy9CO0FBQUEsY0FDRSxPQUFPLFNBQVM7QUFBQSxZQUNsQjtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRixXQUFXLFdBQVcsU0FBUyxHQUFHO0FBQ2hDLGdCQUFRO0FBQUEsVUFDTixJQUFJO0FBQUEsWUFDRixVQUFVLFFBQVEsSUFBSSxTQUFTO0FBQUEsWUFDL0I7QUFBQSxjQUNFLE9BQU8sQ0FBQyxXQUFXLFNBQVMsR0FBRyxTQUFTLElBQUk7QUFBQSxZQUM5QztBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRixPQUFPO0FBQ0wsbUJBQVcsU0FBUyxJQUFJLFNBQVM7QUFBQSxNQUNuQztBQUFBLElBQ0Y7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUNGO0FBQ0EsU0FBUyxTQUFTLE1BQU0sV0FBVztBQUNqQyxNQUFJLGFBQWEsSUFBSSxLQUFLLGdCQUFnQixJQUFJLEtBQUssa0JBQWtCLElBQUksR0FBRztBQUMxRSxXQUFPLEtBQUssVUFBVSxFQUFFLFNBQVMsS0FBSztBQUFBLEVBQ3hDO0FBQ0EsU0FBTztBQUNUO0FBR0EsU0FBUyx3QkFBd0IsU0FBUztBQUN4QyxRQUFNLHFCQUFxQyx1QkFBTyxPQUFPLElBQUk7QUFDN0QsU0FBTztBQUFBLElBQ0wscUJBQXFCLE1BQU07QUFBQSxJQUMzQixtQkFBbUIsTUFBTTtBQUN2QixZQUFNLGVBQWUsS0FBSyxLQUFLO0FBQy9CLFVBQUksbUJBQW1CLFlBQVksR0FBRztBQUNwQyxnQkFBUTtBQUFBLFVBQ04sSUFBSTtBQUFBLFlBQ0YseUNBQXlDLFlBQVk7QUFBQSxZQUNyRDtBQUFBLGNBQ0UsT0FBTyxDQUFDLG1CQUFtQixZQUFZLEdBQUcsS0FBSyxJQUFJO0FBQUEsWUFDckQ7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0YsT0FBTztBQUNMLDJCQUFtQixZQUFZLElBQUksS0FBSztBQUFBLE1BQzFDO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBQ0Y7QUFHQSxTQUFTLDBCQUEwQixTQUFTO0FBQzFDLFFBQU0saUJBQWlCLENBQUM7QUFDeEIsTUFBSSxhQUE2Qix1QkFBTyxPQUFPLElBQUk7QUFDbkQsU0FBTztBQUFBLElBQ0wsYUFBYTtBQUFBLE1BQ1gsUUFBUTtBQUNOLHVCQUFlLEtBQUssVUFBVTtBQUM5QixxQkFBNkIsdUJBQU8sT0FBTyxJQUFJO0FBQUEsTUFDakQ7QUFBQSxNQUNBLFFBQVE7QUFDTixjQUFNLGlCQUFpQixlQUFlLElBQUk7QUFDMUMsMEJBQWtCLFdBQVcsS0FBSztBQUNsQyxxQkFBYTtBQUFBLE1BQ2Y7QUFBQSxJQUNGO0FBQUEsSUFDQSxZQUFZLE1BQU07QUFDaEIsWUFBTSxZQUFZLEtBQUssS0FBSztBQUM1QixVQUFJLFdBQVcsU0FBUyxHQUFHO0FBQ3pCLGdCQUFRO0FBQUEsVUFDTixJQUFJO0FBQUEsWUFDRiw0Q0FBNEMsU0FBUztBQUFBLFlBQ3JEO0FBQUEsY0FDRSxPQUFPLENBQUMsV0FBVyxTQUFTLEdBQUcsS0FBSyxJQUFJO0FBQUEsWUFDMUM7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0YsT0FBTztBQUNMLG1CQUFXLFNBQVMsSUFBSSxLQUFLO0FBQUEsTUFDL0I7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGO0FBR0EsU0FBUyx5QkFBeUIsU0FBUztBQUN6QyxRQUFNLHNCQUFzQyx1QkFBTyxPQUFPLElBQUk7QUFDOUQsU0FBTztBQUFBLElBQ0wsb0JBQW9CLE1BQU07QUFDeEIsWUFBTSxnQkFBZ0IsS0FBSztBQUMzQixVQUFJLGVBQWU7QUFDakIsWUFBSSxvQkFBb0IsY0FBYyxLQUFLLEdBQUc7QUFDNUMsa0JBQVE7QUFBQSxZQUNOLElBQUk7QUFBQSxjQUNGLDBDQUEwQyxjQUFjLEtBQUs7QUFBQSxjQUM3RDtBQUFBLGdCQUNFLE9BQU87QUFBQSxrQkFDTCxvQkFBb0IsY0FBYyxLQUFLO0FBQUEsa0JBQ3ZDO0FBQUEsZ0JBQ0Y7QUFBQSxjQUNGO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFBQSxRQUNGLE9BQU87QUFDTCw4QkFBb0IsY0FBYyxLQUFLLElBQUk7QUFBQSxRQUM3QztBQUFBLE1BQ0Y7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0Esb0JBQW9CLE1BQU07QUFBQSxFQUM1QjtBQUNGO0FBR0EsU0FBUyx5QkFBeUIsU0FBUztBQUN6QyxRQUFNLFNBQVMsUUFBUSxVQUFVO0FBQ2pDLFFBQU0sd0JBQXdDLHVCQUFPLE9BQU8sSUFBSTtBQUNoRSxRQUFNLHlCQUF5QixTQUFTO0FBQUEsSUFDdEMsT0FBTyxPQUFPLGFBQWE7QUFBQSxJQUMzQixVQUFVLE9BQU8sZ0JBQWdCO0FBQUEsSUFDakMsY0FBYyxPQUFPLG9CQUFvQjtBQUFBLEVBQzNDLElBQUksQ0FBQztBQUNMLFNBQU87QUFBQSxJQUNMLGtCQUFrQjtBQUFBLElBQ2xCLGlCQUFpQjtBQUFBLEVBQ25CO0FBQ0EsV0FBUyxvQkFBb0IsTUFBTTtBQUNqQyxRQUFJO0FBQ0osVUFBTSx1QkFBdUIsdUJBQXVCLEtBQUssb0JBQW9CLFFBQVEseUJBQXlCLFNBQVMsdUJBQXVCLENBQUM7QUFDL0ksZUFBVyxpQkFBaUIscUJBQXFCO0FBQy9DLFlBQU0sWUFBWSxjQUFjO0FBQ2hDLFlBQU0sOEJBQThCLHNCQUFzQixTQUFTO0FBQ25FLFVBQUksdUJBQXVCLFNBQVMsR0FBRztBQUNyQyxnQkFBUTtBQUFBLFVBQ04sSUFBSTtBQUFBLFlBQ0YsWUFBWSxTQUFTO0FBQUEsWUFDckI7QUFBQSxjQUNFLE9BQU87QUFBQSxZQUNUO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGLFdBQVcsNkJBQTZCO0FBQ3RDLGdCQUFRO0FBQUEsVUFDTixJQUFJO0FBQUEsWUFDRix5QkFBeUIsU0FBUztBQUFBLFlBQ2xDO0FBQUEsY0FDRSxPQUFPLENBQUMsNkJBQTZCLGFBQWE7QUFBQSxZQUNwRDtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRixPQUFPO0FBQ0wsOEJBQXNCLFNBQVMsSUFBSTtBQUFBLE1BQ3JDO0FBQUEsSUFDRjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQ0Y7QUFHQSxTQUFTLG9CQUFvQixTQUFTO0FBQ3BDLFFBQU0saUJBQWlDLHVCQUFPLE9BQU8sSUFBSTtBQUN6RCxRQUFNLFNBQVMsUUFBUSxVQUFVO0FBQ2pDLFNBQU87QUFBQSxJQUNMLHNCQUFzQjtBQUFBLElBQ3RCLHNCQUFzQjtBQUFBLElBQ3RCLHlCQUF5QjtBQUFBLElBQ3pCLHFCQUFxQjtBQUFBLElBQ3JCLG9CQUFvQjtBQUFBLElBQ3BCLDJCQUEyQjtBQUFBLEVBQzdCO0FBQ0EsV0FBUyxjQUFjLE1BQU07QUFDM0IsVUFBTSxXQUFXLEtBQUssS0FBSztBQUMzQixRQUFJLFdBQVcsUUFBUSxXQUFXLFVBQVUsT0FBTyxRQUFRLFFBQVEsR0FBRztBQUNwRSxjQUFRO0FBQUEsUUFDTixJQUFJO0FBQUEsVUFDRixTQUFTLFFBQVE7QUFBQSxVQUNqQjtBQUFBLFlBQ0UsT0FBTyxLQUFLO0FBQUEsVUFDZDtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQ0E7QUFBQSxJQUNGO0FBQ0EsUUFBSSxlQUFlLFFBQVEsR0FBRztBQUM1QixjQUFRO0FBQUEsUUFDTixJQUFJLGFBQWEscUNBQXFDLFFBQVEsTUFBTTtBQUFBLFVBQ2xFLE9BQU8sQ0FBQyxlQUFlLFFBQVEsR0FBRyxLQUFLLElBQUk7QUFBQSxRQUM3QyxDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0YsT0FBTztBQUNMLHFCQUFlLFFBQVEsSUFBSSxLQUFLO0FBQUEsSUFDbEM7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUNGO0FBR0EsU0FBUyx3QkFBd0IsU0FBUztBQUN4QyxTQUFPO0FBQUEsSUFDTCxvQkFBb0IsZUFBZTtBQUNqQyxVQUFJO0FBQ0osWUFBTSx1QkFBdUIsd0JBQXdCLGNBQWMseUJBQXlCLFFBQVEsMEJBQTBCLFNBQVMsd0JBQXdCLENBQUM7QUFDaEssWUFBTSwwQkFBMEI7QUFBQSxRQUM5QjtBQUFBLFFBQ0EsQ0FBQyxTQUFTLEtBQUssU0FBUyxLQUFLO0FBQUEsTUFDL0I7QUFDQSxpQkFBVyxDQUFDLGNBQWMsYUFBYSxLQUFLLHlCQUF5QjtBQUNuRSxZQUFJLGNBQWMsU0FBUyxHQUFHO0FBQzVCLGtCQUFRO0FBQUEsWUFDTixJQUFJO0FBQUEsY0FDRiwwQ0FBMEMsWUFBWTtBQUFBLGNBQ3REO0FBQUEsZ0JBQ0UsT0FBTyxjQUFjLElBQUksQ0FBQyxTQUFTLEtBQUssU0FBUyxJQUFJO0FBQUEsY0FDdkQ7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUdBLFNBQVMsd0JBQXdCLFNBQVM7QUFDeEMsU0FBTztBQUFBLElBQ0wsVUFBVSxNQUFNO0FBQ2QsWUFBTSxPQUFPLGdCQUFnQixRQUFRLG1CQUFtQixDQUFDO0FBQ3pELFVBQUksQ0FBQyxXQUFXLElBQUksR0FBRztBQUNyQix5QkFBaUIsU0FBUyxJQUFJO0FBQzlCLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUFBLElBQ0EsWUFBWSxNQUFNO0FBQ2hCLFlBQU0sT0FBTyxhQUFhLFFBQVEsYUFBYSxDQUFDO0FBQ2hELFVBQUksQ0FBQyxrQkFBa0IsSUFBSSxHQUFHO0FBQzVCLHlCQUFpQixTQUFTLElBQUk7QUFDOUIsZUFBTztBQUFBLE1BQ1Q7QUFDQSxZQUFNLGVBQWUsT0FBTyxLQUFLLFFBQVEsQ0FBQyxVQUFVLE1BQU0sS0FBSyxLQUFLO0FBQ3BFLGlCQUFXLFlBQVksT0FBTyxPQUFPLEtBQUssVUFBVSxDQUFDLEdBQUc7QUFDdEQsY0FBTSxZQUFZLGFBQWEsU0FBUyxJQUFJO0FBQzVDLFlBQUksQ0FBQyxhQUFhLHFCQUFxQixRQUFRLEdBQUc7QUFDaEQsZ0JBQU0sVUFBVSxRQUFRLFNBQVMsSUFBSTtBQUNyQyxrQkFBUTtBQUFBLFlBQ04sSUFBSTtBQUFBLGNBQ0YsVUFBVSxLQUFLLElBQUksSUFBSSxTQUFTLElBQUksdUJBQXVCLE9BQU87QUFBQSxjQUNsRTtBQUFBLGdCQUNFLE9BQU87QUFBQSxjQUNUO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxJQUNBLFlBQVksTUFBTTtBQUNoQixZQUFNLGFBQWEsYUFBYSxRQUFRLG1CQUFtQixDQUFDO0FBQzVELFlBQU0sWUFBWSxRQUFRLGFBQWE7QUFDdkMsVUFBSSxDQUFDLGFBQWEsa0JBQWtCLFVBQVUsR0FBRztBQUMvQyxjQUFNLGNBQWM7QUFBQSxVQUNsQixLQUFLLEtBQUs7QUFBQSxVQUNWLE9BQU8sS0FBSyxXQUFXLFVBQVUsQ0FBQztBQUFBLFFBQ3BDO0FBQ0EsZ0JBQVE7QUFBQSxVQUNOLElBQUk7QUFBQSxZQUNGLFVBQVUsS0FBSyxLQUFLLEtBQUssNkJBQTZCLFdBQVcsSUFBSSxPQUFPLFdBQVcsV0FBVztBQUFBLFlBQ2xHO0FBQUEsY0FDRSxPQUFPO0FBQUEsWUFDVDtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxJQUNBLFVBQVUsTUFBTTtBQUNkLFlBQU0sT0FBTyxRQUFRLGFBQWE7QUFDbEMsVUFBSSxjQUFjLElBQUksR0FBRztBQUN2QixnQkFBUTtBQUFBLFVBQ04sSUFBSTtBQUFBLFlBQ0YsMkJBQTJCLFFBQVEsSUFBSSxDQUFDLFlBQVksTUFBTSxJQUFJLENBQUM7QUFBQSxZQUMvRDtBQUFBLGNBQ0UsT0FBTztBQUFBLFlBQ1Q7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsSUFDQSxXQUFXLENBQUMsU0FBUyxpQkFBaUIsU0FBUyxJQUFJO0FBQUEsSUFDbkQsVUFBVSxDQUFDLFNBQVMsaUJBQWlCLFNBQVMsSUFBSTtBQUFBLElBQ2xELFlBQVksQ0FBQyxTQUFTLGlCQUFpQixTQUFTLElBQUk7QUFBQSxJQUNwRCxhQUFhLENBQUMsU0FBUyxpQkFBaUIsU0FBUyxJQUFJO0FBQUEsSUFDckQsY0FBYyxDQUFDLFNBQVMsaUJBQWlCLFNBQVMsSUFBSTtBQUFBLEVBQ3hEO0FBQ0Y7QUFDQSxTQUFTLGlCQUFpQixTQUFTLE1BQU07QUFDdkMsUUFBTSxlQUFlLFFBQVEsYUFBYTtBQUMxQyxNQUFJLENBQUMsY0FBYztBQUNqQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLE9BQU8sYUFBYSxZQUFZO0FBQ3RDLE1BQUksQ0FBQyxXQUFXLElBQUksR0FBRztBQUNyQixVQUFNLFVBQVUsUUFBUSxZQUFZO0FBQ3BDLFlBQVE7QUFBQSxNQUNOLElBQUk7QUFBQSxRQUNGLDJCQUEyQixPQUFPLFlBQVksTUFBTSxJQUFJLENBQUM7QUFBQSxRQUN6RDtBQUFBLFVBQ0UsT0FBTztBQUFBLFFBQ1Q7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBO0FBQUEsRUFDRjtBQUNBLE1BQUk7QUFDRixVQUFNLGNBQWMsS0FBSztBQUFBLE1BQ3ZCO0FBQUEsTUFDQTtBQUFBO0FBQUEsSUFFRjtBQUNBLFFBQUksZ0JBQWdCLFFBQVE7QUFDMUIsWUFBTSxVQUFVLFFBQVEsWUFBWTtBQUNwQyxjQUFRO0FBQUEsUUFDTixJQUFJO0FBQUEsVUFDRiwyQkFBMkIsT0FBTyxZQUFZLE1BQU0sSUFBSSxDQUFDO0FBQUEsVUFDekQ7QUFBQSxZQUNFLE9BQU87QUFBQSxVQUNUO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRixTQUFTLE9BQU87QUFDZCxVQUFNLFVBQVUsUUFBUSxZQUFZO0FBQ3BDLFFBQUksaUJBQWlCLGNBQWM7QUFDakMsY0FBUSxZQUFZLEtBQUs7QUFBQSxJQUMzQixPQUFPO0FBQ0wsY0FBUTtBQUFBLFFBQ04sSUFBSTtBQUFBLFVBQ0YsMkJBQTJCLE9BQU8sWUFBWSxNQUFNLElBQUksQ0FBQyxPQUFPLE1BQU07QUFBQSxVQUN0RTtBQUFBLFlBQ0UsT0FBTztBQUFBLFlBQ1AsZUFBZTtBQUFBLFVBQ2pCO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGO0FBR0EsU0FBUywyQkFBMkIsU0FBUztBQUMzQyxTQUFPO0FBQUEsSUFDTCxtQkFBbUIsTUFBTTtBQUN2QixZQUFNLE9BQU8sWUFBWSxRQUFRLFVBQVUsR0FBRyxLQUFLLElBQUk7QUFDdkQsVUFBSSxTQUFTLFVBQVUsQ0FBQyxZQUFZLElBQUksR0FBRztBQUN6QyxjQUFNLGVBQWUsS0FBSyxTQUFTLEtBQUs7QUFDeEMsY0FBTSxXQUFXLE1BQU0sS0FBSyxJQUFJO0FBQ2hDLGdCQUFRO0FBQUEsVUFDTixJQUFJO0FBQUEsWUFDRixjQUFjLFlBQVksK0JBQStCLFFBQVE7QUFBQSxZQUNqRTtBQUFBLGNBQ0UsT0FBTyxLQUFLO0FBQUEsWUFDZDtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0Y7QUFHQSxTQUFTLCtCQUErQixTQUFTO0FBQy9DLE1BQUksWUFBNEIsdUJBQU8sT0FBTyxJQUFJO0FBQ2xELFNBQU87QUFBQSxJQUNMLHFCQUFxQjtBQUFBLE1BQ25CLFFBQVE7QUFDTixvQkFBNEIsdUJBQU8sT0FBTyxJQUFJO0FBQUEsTUFDaEQ7QUFBQSxNQUNBLE1BQU0sV0FBVztBQUNmLGNBQU0sU0FBUyxRQUFRLDJCQUEyQixTQUFTO0FBQzNELG1CQUFXLEVBQUUsTUFBTSxNQUFNLGFBQWEsS0FBSyxRQUFRO0FBQ2pELGdCQUFNLFVBQVUsS0FBSyxLQUFLO0FBQzFCLGdCQUFNLFNBQVMsVUFBVSxPQUFPO0FBQ2hDLGNBQUksVUFBVSxNQUFNO0FBQ2xCLGtCQUFNLFNBQVMsUUFBUSxVQUFVO0FBQ2pDLGtCQUFNLFVBQVUsWUFBWSxRQUFRLE9BQU8sSUFBSTtBQUMvQyxnQkFBSSxXQUFXLENBQUM7QUFBQSxjQUNkO0FBQUEsY0FDQTtBQUFBLGNBQ0EsT0FBTztBQUFBLGNBQ1A7QUFBQSxjQUNBO0FBQUEsWUFDRixHQUFHO0FBQ0Qsb0JBQU0sYUFBYSxRQUFRLE9BQU87QUFDbEMsb0JBQU0sVUFBVSxRQUFRLElBQUk7QUFDNUIsc0JBQVE7QUFBQSxnQkFDTixJQUFJO0FBQUEsa0JBQ0YsY0FBYyxPQUFPLGNBQWMsVUFBVSxzQ0FBc0MsT0FBTztBQUFBLGtCQUMxRjtBQUFBLG9CQUNFLE9BQU8sQ0FBQyxRQUFRLElBQUk7QUFBQSxrQkFDdEI7QUFBQSxnQkFDRjtBQUFBLGNBQ0Y7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLElBQ0EsbUJBQW1CLE1BQU07QUFDdkIsZ0JBQVUsS0FBSyxTQUFTLEtBQUssS0FBSyxJQUFJO0FBQUEsSUFDeEM7QUFBQSxFQUNGO0FBQ0Y7QUFDQSxTQUFTLHFCQUFxQixRQUFRLFNBQVMsaUJBQWlCLGNBQWMsc0JBQXNCO0FBQ2xHLE1BQUksY0FBYyxZQUFZLEtBQUssQ0FBQyxjQUFjLE9BQU8sR0FBRztBQUMxRCxVQUFNLGlDQUFpQyxtQkFBbUIsUUFBUSxnQkFBZ0IsU0FBUyxLQUFLO0FBQ2hHLFVBQU0sMEJBQTBCLHlCQUF5QjtBQUN6RCxRQUFJLENBQUMsa0NBQWtDLENBQUMseUJBQXlCO0FBQy9ELGFBQU87QUFBQSxJQUNUO0FBQ0EsVUFBTSx1QkFBdUIsYUFBYTtBQUMxQyxXQUFPLGdCQUFnQixRQUFRLFNBQVMsb0JBQW9CO0FBQUEsRUFDOUQ7QUFDQSxTQUFPLGdCQUFnQixRQUFRLFNBQVMsWUFBWTtBQUN0RDtBQUdBLElBQUksaUJBQWlCLE9BQU8sT0FBTztBQUFBLEVBQ2pDO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUNGLENBQUM7QUFDRCxJQUFJLG9CQUFvQixPQUFPLE9BQU87QUFBQSxFQUNwQztBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQ0YsQ0FBQztBQUdELFNBQVMsU0FBUyxJQUFJO0FBQ3BCLE1BQUk7QUFDSixTQUFPLFNBQVMsU0FBUyxJQUFJLElBQUksSUFBSTtBQUNuQyxRQUFJLFdBQVcsUUFBUTtBQUNyQixlQUF5QixvQkFBSSxRQUFRO0FBQUEsSUFDdkM7QUFDQSxRQUFJLFNBQVMsT0FBTyxJQUFJLEVBQUU7QUFDMUIsUUFBSSxXQUFXLFFBQVE7QUFDckIsZUFBeUIsb0JBQUksUUFBUTtBQUNyQyxhQUFPLElBQUksSUFBSSxNQUFNO0FBQUEsSUFDdkI7QUFDQSxRQUFJLFNBQVMsT0FBTyxJQUFJLEVBQUU7QUFDMUIsUUFBSSxXQUFXLFFBQVE7QUFDckIsZUFBeUIsb0JBQUksUUFBUTtBQUNyQyxhQUFPLElBQUksSUFBSSxNQUFNO0FBQUEsSUFDdkI7QUFDQSxRQUFJLFdBQVcsT0FBTyxJQUFJLEVBQUU7QUFDNUIsUUFBSSxhQUFhLFFBQVE7QUFDdkIsaUJBQVcsR0FBRyxJQUFJLElBQUksRUFBRTtBQUN4QixhQUFPLElBQUksSUFBSSxRQUFRO0FBQUEsSUFDekI7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUNGO0FBR0EsSUFBSSxvQkFBb0I7QUFBQSxFQUN0QixDQUFDLFlBQVksWUFBWSxlQUFlO0FBQUEsSUFDdEMsV0FBVztBQUFBLElBQ1gsV0FBVztBQUFBLElBQ1gsV0FBVztBQUFBLElBQ1g7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNGO0FBR0EsSUFBSSxhQUFhO0FBQUEsRUFDZixDQUFDLEdBQUcsc0JBQXNCLEdBQUcsa0JBQWtCO0FBQUEsRUFDL0MsQ0FBQyxTQUFTLEtBQUs7QUFDakI7QUFHQSxJQUFJO0FBQUEsQ0FDSCxTQUFTLHFCQUFxQjtBQUM3QixzQkFBb0IsY0FBYyxJQUFJO0FBQ3RDLHNCQUFvQixtQkFBbUIsSUFBSTtBQUMzQyxzQkFBb0IseUJBQXlCLElBQUk7QUFDakQsc0JBQW9CLHlCQUF5QixJQUFJO0FBQ2pELHNCQUFvQiw0QkFBNEIsSUFBSTtBQUNwRCxzQkFBb0IsK0JBQStCLElBQUk7QUFDdkQsc0JBQW9CLGVBQWUsSUFBSTtBQUN2QyxzQkFBb0Isb0JBQW9CLElBQUk7QUFDNUMsc0JBQW9CLG9CQUFvQixJQUFJO0FBQzVDLHNCQUFvQixhQUFhLElBQUk7QUFDckMsc0JBQW9CLGtCQUFrQixJQUFJO0FBQzFDLHNCQUFvQixtQkFBbUIsSUFBSTtBQUMzQyxzQkFBb0IsdUJBQXVCLElBQUk7QUFDL0Msc0JBQW9CLDhCQUE4QixJQUFJO0FBQ3RELHNCQUFvQiw4QkFBOEIsSUFBSTtBQUN0RCxzQkFBb0IsNEJBQTRCLElBQUk7QUFDdEQsR0FBRyx1QkFBdUIscUJBQXFCLENBQUMsRUFBRTtBQUNsRCxJQUFJO0FBQUEsQ0FDSCxTQUFTLHNCQUFzQjtBQUM5Qix1QkFBcUIscUJBQXFCLElBQUk7QUFDOUMsdUJBQXFCLHFCQUFxQixJQUFJO0FBQzlDLHVCQUFxQiw0QkFBNEIsSUFBSTtBQUNyRCx1QkFBcUIsb0JBQW9CLElBQUk7QUFDN0MsdUJBQXFCLDZCQUE2QixJQUFJO0FBQ3RELHVCQUFxQiwwQkFBMEIsSUFBSTtBQUNyRCxHQUFHLHdCQUF3QixzQkFBc0IsQ0FBQyxFQUFFO0FBR3BELFNBQVMsVUFBVSxPQUFPO0FBQ3hCLE1BQUk7QUFDRixXQUFPLEtBQUssTUFBTSxLQUFLO0FBQUEsRUFDekIsU0FBUyxPQUFPO0FBQ2QsV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUdBLElBQUksWUFBWSxPQUFPO0FBQ3ZCLElBQUksYUFBYSxPQUFPO0FBQ3hCLElBQUksb0JBQW9CLE9BQU87QUFDL0IsSUFBSSxxQkFBcUIsT0FBTztBQUNoQyxJQUFJLGdCQUFnQixPQUFPO0FBQzNCLElBQUksZ0JBQWdCLE9BQU8sVUFBVTtBQUNyQyxJQUFJLGNBQWMsQ0FBQyxJQUFJLFFBQVEsU0FBUyxZQUFZO0FBQ2xELFNBQU8sUUFBUSxHQUFHLEdBQUcsbUJBQW1CLEVBQUUsRUFBRSxDQUFDLENBQUMsSUFBSSxNQUFNLEVBQUUsU0FBUyxDQUFDLEVBQUUsR0FBRyxTQUFTLEdBQUcsR0FBRyxJQUFJO0FBQzlGO0FBQ0EsSUFBSSxlQUFlLENBQUMsSUFBSSxNQUFNLFFBQVEsU0FBUztBQUM3QyxNQUFJLFFBQVEsT0FBTyxTQUFTLFlBQVksT0FBTyxTQUFTLFlBQVk7QUFDbEUsYUFBUyxPQUFPLG1CQUFtQixJQUFJO0FBQ3JDLFVBQUksQ0FBQyxjQUFjLEtBQUssSUFBSSxHQUFHLEtBQUssUUFBUTtBQUMxQyxtQkFBVyxJQUFJLEtBQUssRUFBRSxLQUFLLE1BQU0sS0FBSyxHQUFHLEdBQUcsWUFBWSxFQUFFLE9BQU8sa0JBQWtCLE1BQU0sR0FBRyxNQUFNLEtBQUssV0FBVyxDQUFDO0FBQUEsRUFDekg7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxJQUFJLFdBQVcsQ0FBQyxLQUFLLFlBQVksWUFBWSxTQUFTLE9BQU8sT0FBTyxVQUFVLGNBQWMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUt0RyxjQUFjLENBQUMsT0FBTyxDQUFDLElBQUksYUFBYSxXQUFXLFFBQVEsV0FBVyxFQUFFLE9BQU8sS0FBSyxZQUFZLEtBQUssQ0FBQyxJQUFJO0FBQUEsRUFDMUc7QUFDRjtBQUNBLElBQUkscUJBQXFCLFlBQVk7QUFBQSxFQUNuQyxtREFBbUQsU0FBUyxRQUFRO0FBQ2xFO0FBQ0EsUUFBSSxzQkFBc0I7QUFBQSxNQUN4QixjQUFjO0FBQUEsTUFDZCxLQUFLO0FBQUEsTUFDTCxRQUFRO0FBQUEsSUFDVjtBQUNBLGFBQVMsaUJBQWlCLEtBQUs7QUFDN0IsYUFBTyxPQUFPLFFBQVEsWUFBWSxDQUFDLENBQUMsSUFBSSxLQUFLO0FBQUEsSUFDL0M7QUFDQSxhQUFTLFlBQVksZ0JBQWdCLFNBQVM7QUFDNUMsVUFBSSxRQUFRLGVBQWUsTUFBTSxHQUFHLEVBQUUsT0FBTyxnQkFBZ0I7QUFDN0QsVUFBSSxtQkFBbUIsTUFBTSxNQUFNO0FBQ25DLFVBQUksU0FBUyxtQkFBbUIsZ0JBQWdCO0FBQ2hELFVBQUksT0FBTyxPQUFPO0FBQ2xCLFVBQUksUUFBUSxPQUFPO0FBQ25CLGdCQUFVLFVBQVUsT0FBTyxPQUFPLENBQUMsR0FBRyxxQkFBcUIsT0FBTyxJQUFJO0FBQ3RFLFVBQUk7QUFDRixnQkFBUSxRQUFRLGVBQWUsbUJBQW1CLEtBQUssSUFBSTtBQUFBLE1BQzdELFNBQVMsR0FBRztBQUNWLGdCQUFRO0FBQUEsVUFDTixnRkFBZ0YsUUFBUTtBQUFBLFVBQ3hGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQSxVQUFJLFNBQVM7QUFBQSxRQUNYO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFDQSxZQUFNLFFBQVEsU0FBUyxNQUFNO0FBQzNCLFlBQUksUUFBUSxLQUFLLE1BQU0sR0FBRztBQUMxQixZQUFJLE1BQU0sTUFBTSxNQUFNLEVBQUUsU0FBUyxFQUFFLFlBQVk7QUFDL0MsWUFBSSxTQUFTLE1BQU0sS0FBSyxHQUFHO0FBQzNCLFlBQUksUUFBUSxXQUFXO0FBQ3JCLGlCQUFPLFVBQVUsSUFBSSxLQUFLLE1BQU07QUFBQSxRQUNsQyxXQUFXLFFBQVEsV0FBVztBQUM1QixpQkFBTyxTQUFTLFNBQVMsUUFBUSxFQUFFO0FBQUEsUUFDckMsV0FBVyxRQUFRLFVBQVU7QUFDM0IsaUJBQU8sU0FBUztBQUFBLFFBQ2xCLFdBQVcsUUFBUSxZQUFZO0FBQzdCLGlCQUFPLFdBQVc7QUFBQSxRQUNwQixXQUFXLFFBQVEsWUFBWTtBQUM3QixpQkFBTyxXQUFXO0FBQUEsUUFDcEIsT0FBTztBQUNMLGlCQUFPLEdBQUcsSUFBSTtBQUFBLFFBQ2hCO0FBQUEsTUFDRixDQUFDO0FBQ0QsYUFBTztBQUFBLElBQ1Q7QUFDQSxhQUFTLG1CQUFtQixrQkFBa0I7QUFDNUMsVUFBSSxPQUFPO0FBQ1gsVUFBSSxRQUFRO0FBQ1osVUFBSSxlQUFlLGlCQUFpQixNQUFNLEdBQUc7QUFDN0MsVUFBSSxhQUFhLFNBQVMsR0FBRztBQUMzQixlQUFPLGFBQWEsTUFBTTtBQUMxQixnQkFBUSxhQUFhLEtBQUssR0FBRztBQUFBLE1BQy9CLE9BQU87QUFDTCxnQkFBUTtBQUFBLE1BQ1Y7QUFDQSxhQUFPLEVBQUUsTUFBTSxNQUFNO0FBQUEsSUFDdkI7QUFDQSxhQUFTLE9BQU8sT0FBTyxTQUFTO0FBQzlCLGdCQUFVLFVBQVUsT0FBTyxPQUFPLENBQUMsR0FBRyxxQkFBcUIsT0FBTyxJQUFJO0FBQ3RFLFVBQUksQ0FBQyxPQUFPO0FBQ1YsWUFBSSxDQUFDLFFBQVEsS0FBSztBQUNoQixpQkFBTyxDQUFDO0FBQUEsUUFDVixPQUFPO0FBQ0wsaUJBQU8sQ0FBQztBQUFBLFFBQ1Y7QUFBQSxNQUNGO0FBQ0EsVUFBSSxNQUFNLFNBQVM7QUFDakIsWUFBSSxPQUFPLE1BQU0sUUFBUSxpQkFBaUIsWUFBWTtBQUNwRCxrQkFBUSxNQUFNLFFBQVEsYUFBYTtBQUFBLFFBQ3JDLFdBQVcsTUFBTSxRQUFRLFlBQVksR0FBRztBQUN0QyxrQkFBUSxNQUFNLFFBQVEsWUFBWTtBQUFBLFFBQ3BDLE9BQU87QUFDTCxjQUFJLE1BQU0sTUFBTSxRQUFRLE9BQU8sS0FBSyxNQUFNLE9BQU8sRUFBRSxLQUFLLFNBQVMsS0FBSztBQUNwRSxtQkFBTyxJQUFJLFlBQVksTUFBTTtBQUFBLFVBQy9CLENBQUMsQ0FBQztBQUNGLGNBQUksQ0FBQyxPQUFPLE1BQU0sUUFBUSxVQUFVLENBQUMsUUFBUSxRQUFRO0FBQ25ELG9CQUFRO0FBQUEsY0FDTjtBQUFBLFlBQ0Y7QUFBQSxVQUNGO0FBQ0Esa0JBQVE7QUFBQSxRQUNWO0FBQUEsTUFDRjtBQUNBLFVBQUksQ0FBQyxNQUFNLFFBQVEsS0FBSyxHQUFHO0FBQ3pCLGdCQUFRLENBQUMsS0FBSztBQUFBLE1BQ2hCO0FBQ0EsZ0JBQVUsVUFBVSxPQUFPLE9BQU8sQ0FBQyxHQUFHLHFCQUFxQixPQUFPLElBQUk7QUFDdEUsVUFBSSxDQUFDLFFBQVEsS0FBSztBQUNoQixlQUFPLE1BQU0sT0FBTyxnQkFBZ0IsRUFBRSxJQUFJLFNBQVMsS0FBSztBQUN0RCxpQkFBTyxZQUFZLEtBQUssT0FBTztBQUFBLFFBQ2pDLENBQUM7QUFBQSxNQUNILE9BQU87QUFDTCxZQUFJLFVBQVUsQ0FBQztBQUNmLGVBQU8sTUFBTSxPQUFPLGdCQUFnQixFQUFFLE9BQU8sU0FBUyxVQUFVLEtBQUs7QUFDbkUsY0FBSSxTQUFTLFlBQVksS0FBSyxPQUFPO0FBQ3JDLG1CQUFTLE9BQU8sSUFBSSxJQUFJO0FBQ3hCLGlCQUFPO0FBQUEsUUFDVCxHQUFHLE9BQU87QUFBQSxNQUNaO0FBQUEsSUFDRjtBQUNBLGFBQVMsb0JBQW9CLGVBQWU7QUFDMUMsVUFBSSxNQUFNLFFBQVEsYUFBYSxHQUFHO0FBQ2hDLGVBQU87QUFBQSxNQUNUO0FBQ0EsVUFBSSxPQUFPLGtCQUFrQixVQUFVO0FBQ3JDLGVBQU8sQ0FBQztBQUFBLE1BQ1Y7QUFDQSxVQUFJLGlCQUFpQixDQUFDO0FBQ3RCLFVBQUksTUFBTTtBQUNWLFVBQUk7QUFDSixVQUFJO0FBQ0osVUFBSTtBQUNKLFVBQUk7QUFDSixVQUFJO0FBQ0osZUFBUyxpQkFBaUI7QUFDeEIsZUFBTyxNQUFNLGNBQWMsVUFBVSxLQUFLLEtBQUssY0FBYyxPQUFPLEdBQUcsQ0FBQyxHQUFHO0FBQ3pFLGlCQUFPO0FBQUEsUUFDVDtBQUNBLGVBQU8sTUFBTSxjQUFjO0FBQUEsTUFDN0I7QUFDQSxlQUFTLGlCQUFpQjtBQUN4QixhQUFLLGNBQWMsT0FBTyxHQUFHO0FBQzdCLGVBQU8sT0FBTyxPQUFPLE9BQU8sT0FBTyxPQUFPO0FBQUEsTUFDNUM7QUFDQSxhQUFPLE1BQU0sY0FBYyxRQUFRO0FBQ2pDLGdCQUFRO0FBQ1IsZ0NBQXdCO0FBQ3hCLGVBQU8sZUFBZSxHQUFHO0FBQ3ZCLGVBQUssY0FBYyxPQUFPLEdBQUc7QUFDN0IsY0FBSSxPQUFPLEtBQUs7QUFDZCx3QkFBWTtBQUNaLG1CQUFPO0FBQ1AsMkJBQWU7QUFDZix3QkFBWTtBQUNaLG1CQUFPLE1BQU0sY0FBYyxVQUFVLGVBQWUsR0FBRztBQUNyRCxxQkFBTztBQUFBLFlBQ1Q7QUFDQSxnQkFBSSxNQUFNLGNBQWMsVUFBVSxjQUFjLE9BQU8sR0FBRyxNQUFNLEtBQUs7QUFDbkUsc0NBQXdCO0FBQ3hCLG9CQUFNO0FBQ04sNkJBQWUsS0FBSyxjQUFjLFVBQVUsT0FBTyxTQUFTLENBQUM7QUFDN0Qsc0JBQVE7QUFBQSxZQUNWLE9BQU87QUFDTCxvQkFBTSxZQUFZO0FBQUEsWUFDcEI7QUFBQSxVQUNGLE9BQU87QUFDTCxtQkFBTztBQUFBLFVBQ1Q7QUFBQSxRQUNGO0FBQ0EsWUFBSSxDQUFDLHlCQUF5QixPQUFPLGNBQWMsUUFBUTtBQUN6RCx5QkFBZSxLQUFLLGNBQWMsVUFBVSxPQUFPLGNBQWMsTUFBTSxDQUFDO0FBQUEsUUFDMUU7QUFBQSxNQUNGO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFDQSxXQUFPLFVBQVU7QUFDakIsV0FBTyxRQUFRLFFBQVE7QUFDdkIsV0FBTyxRQUFRLGNBQWM7QUFDN0IsV0FBTyxRQUFRLHFCQUFxQjtBQUFBLEVBQ3RDO0FBQ0YsQ0FBQztBQUNELElBQUksMkJBQTJCLFNBQVMsbUJBQW1CLENBQUM7QUFDNUQsSUFBSSw2QkFBNkI7QUFDakMsU0FBUyxvQkFBb0IsTUFBTTtBQUNqQyxNQUFJLDJCQUEyQixLQUFLLElBQUksS0FBSyxLQUFLLEtBQUssTUFBTSxJQUFJO0FBQy9ELFVBQU0sSUFBSSxVQUFVLHdDQUF3QztBQUFBLEVBQzlEO0FBQ0EsU0FBTyxLQUFLLEtBQUssRUFBRSxZQUFZO0FBQ2pDO0FBQ0EsSUFBSSxvQkFBb0I7QUFBQSxFQUN0QixPQUFPLGFBQWEsRUFBRTtBQUFBLEVBQ3RCLE9BQU8sYUFBYSxFQUFFO0FBQUEsRUFDdEIsT0FBTyxhQUFhLENBQUM7QUFBQSxFQUNyQixPQUFPLGFBQWEsRUFBRTtBQUN4QjtBQUNBLElBQUksNkJBQTZCLElBQUk7QUFBQSxFQUNuQyxNQUFNLGtCQUFrQixLQUFLLEVBQUUsQ0FBQyxPQUFPLGtCQUFrQixLQUFLLEVBQUUsQ0FBQztBQUFBLEVBQ2pFO0FBQ0Y7QUFDQSxTQUFTLHFCQUFxQixPQUFPO0FBQ25DLFFBQU0sWUFBWSxNQUFNLFFBQVEsNEJBQTRCLEVBQUU7QUFDOUQsU0FBTztBQUNUO0FBQ0EsU0FBUyxrQkFBa0IsT0FBTztBQUNoQyxNQUFJLE9BQU8sVUFBVSxVQUFVO0FBQzdCLFdBQU87QUFBQSxFQUNUO0FBQ0EsTUFBSSxNQUFNLFdBQVcsR0FBRztBQUN0QixXQUFPO0FBQUEsRUFDVDtBQUNBLFdBQVMsSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEtBQUs7QUFDckMsVUFBTSxZQUFZLE1BQU0sV0FBVyxDQUFDO0FBQ3BDLFFBQUksWUFBWSxPQUFPLENBQUMsUUFBUSxTQUFTLEdBQUc7QUFDMUMsYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBQ0EsU0FBUyxRQUFRLE9BQU87QUFDdEIsU0FBTyxDQUFDO0FBQUEsSUFDTjtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0YsRUFBRSxTQUFTLEtBQUs7QUFDbEI7QUFDQSxTQUFTLG1CQUFtQixPQUFPO0FBQ2pDLE1BQUksT0FBTyxVQUFVLFVBQVU7QUFDN0IsV0FBTztBQUFBLEVBQ1Q7QUFDQSxNQUFJLE1BQU0sS0FBSyxNQUFNLE9BQU87QUFDMUIsV0FBTztBQUFBLEVBQ1Q7QUFDQSxXQUFTLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxLQUFLO0FBQ3JDLFVBQU0sWUFBWSxNQUFNLFdBQVcsQ0FBQztBQUNwQztBQUFBO0FBQUEsTUFFRSxjQUFjO0FBQUEsTUFDZCxjQUFjLE1BQU0sY0FBYztBQUFBLE1BQ2xDO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBQ0EsSUFBSSxxQkFBcUIsT0FBTyxtQkFBbUI7QUFDbkQsSUFBSSxtQkFBbUIsT0FBTyxnQkFBZ0I7QUFDOUMsSUFBSSx5QkFBeUI7QUFDN0IsSUFBSTtBQUNKLElBQUk7QUFDSixJQUFJLFdBQVcsTUFBTSxTQUFTO0FBQUEsRUFDNUIsWUFBWSxNQUFNO0FBQ2hCLFNBQUssRUFBRSxJQUFJLENBQUM7QUFDWixTQUFLLEVBQUUsSUFBb0Isb0JBQUksSUFBSTtBQUNuQyxRQUFJLENBQUMsV0FBVyxpQkFBaUIsRUFBRSxTQUFTLFFBQVEsT0FBTyxTQUFTLEtBQUssWUFBWSxJQUFJLEtBQUssZ0JBQWdCLFlBQVksT0FBTyxXQUFXLFlBQVksZUFBZSxnQkFBZ0IsV0FBVyxTQUFTO0FBQ3pNLFlBQU0saUJBQWlCO0FBQ3ZCLHFCQUFlLFFBQVEsQ0FBQyxPQUFPLFNBQVM7QUFDdEMsYUFBSyxPQUFPLE1BQU0sS0FBSztBQUFBLE1BQ3pCLEdBQUcsSUFBSTtBQUFBLElBQ1QsV0FBVyxNQUFNLFFBQVEsSUFBSSxHQUFHO0FBQzlCLFdBQUssUUFBUSxDQUFDLENBQUMsTUFBTSxLQUFLLE1BQU07QUFDOUIsYUFBSztBQUFBLFVBQ0g7QUFBQSxVQUNBLE1BQU0sUUFBUSxLQUFLLElBQUksTUFBTSxLQUFLLHNCQUFzQixJQUFJO0FBQUEsUUFDOUQ7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNILFdBQVcsTUFBTTtBQUNmLGFBQU8sb0JBQW9CLElBQUksRUFBRSxRQUFRLENBQUMsU0FBUztBQUNqRCxjQUFNLFFBQVEsS0FBSyxJQUFJO0FBQ3ZCLGFBQUs7QUFBQSxVQUNIO0FBQUEsVUFDQSxNQUFNLFFBQVEsS0FBSyxJQUFJLE1BQU0sS0FBSyxzQkFBc0IsSUFBSTtBQUFBLFFBQzlEO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFBQSxFQUNBLEVBQUUsS0FBSyxvQkFBb0IsS0FBSyxrQkFBa0IsT0FBTyxTQUFTLElBQUk7QUFDcEUsV0FBTyxLQUFLLFFBQVE7QUFBQSxFQUN0QjtBQUFBLEVBQ0EsQ0FBQyxPQUFPO0FBQ04sZUFBVyxDQUFDLElBQUksS0FBSyxLQUFLLFFBQVEsR0FBRztBQUNuQyxZQUFNO0FBQUEsSUFDUjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLENBQUMsU0FBUztBQUNSLGVBQVcsQ0FBQyxFQUFFLEtBQUssS0FBSyxLQUFLLFFBQVEsR0FBRztBQUN0QyxZQUFNO0FBQUEsSUFDUjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLENBQUMsVUFBVTtBQUNULFFBQUksYUFBYSxPQUFPLEtBQUssS0FBSyxrQkFBa0IsQ0FBQyxFQUFFO0FBQUEsTUFDckQsQ0FBQyxHQUFHLE1BQU0sRUFBRSxjQUFjLENBQUM7QUFBQSxJQUM3QjtBQUNBLGVBQVcsUUFBUSxZQUFZO0FBQzdCLFVBQUksU0FBUyxjQUFjO0FBQ3pCLG1CQUFXLFNBQVMsS0FBSyxhQUFhLEdBQUc7QUFDdkMsZ0JBQU0sQ0FBQyxNQUFNLEtBQUs7QUFBQSxRQUNwQjtBQUFBLE1BQ0YsT0FBTztBQUNMLGNBQU0sQ0FBQyxNQUFNLEtBQUssSUFBSSxJQUFJLENBQUM7QUFBQSxNQUM3QjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSxJQUFJLE1BQU07QUFDUixRQUFJLENBQUMsa0JBQWtCLElBQUksR0FBRztBQUM1QixZQUFNLElBQUksVUFBVSx3QkFBd0IsSUFBSSxHQUFHO0FBQUEsSUFDckQ7QUFDQSxXQUFPLEtBQUssa0JBQWtCLEVBQUUsZUFBZSxvQkFBb0IsSUFBSSxDQUFDO0FBQUEsRUFDMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLElBQUksTUFBTTtBQUNSLFFBQUksQ0FBQyxrQkFBa0IsSUFBSSxHQUFHO0FBQzVCLFlBQU0sVUFBVSx3QkFBd0IsSUFBSSxHQUFHO0FBQUEsSUFDakQ7QUFDQSxXQUFPLEtBQUssa0JBQWtCLEVBQUUsb0JBQW9CLElBQUksQ0FBQyxLQUFLO0FBQUEsRUFDaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLElBQUksTUFBTSxPQUFPO0FBQ2YsUUFBSSxDQUFDLGtCQUFrQixJQUFJLEtBQUssQ0FBQyxtQkFBbUIsS0FBSyxHQUFHO0FBQzFEO0FBQUEsSUFDRjtBQUNBLFVBQU0saUJBQWlCLG9CQUFvQixJQUFJO0FBQy9DLFVBQU0sa0JBQWtCLHFCQUFxQixLQUFLO0FBQ2xELFNBQUssa0JBQWtCLEVBQUUsY0FBYyxJQUFJLHFCQUFxQixlQUFlO0FBQy9FLFNBQUssZ0JBQWdCLEVBQUUsSUFBSSxnQkFBZ0IsSUFBSTtBQUFBLEVBQ2pEO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSxPQUFPLE1BQU0sT0FBTztBQUNsQixRQUFJLENBQUMsa0JBQWtCLElBQUksS0FBSyxDQUFDLG1CQUFtQixLQUFLLEdBQUc7QUFDMUQ7QUFBQSxJQUNGO0FBQ0EsVUFBTSxpQkFBaUIsb0JBQW9CLElBQUk7QUFDL0MsVUFBTSxrQkFBa0IscUJBQXFCLEtBQUs7QUFDbEQsUUFBSSxnQkFBZ0IsS0FBSyxJQUFJLGNBQWMsSUFBSSxHQUFHLEtBQUssSUFBSSxjQUFjLENBQUMsS0FBSyxlQUFlLEtBQUs7QUFDbkcsU0FBSyxJQUFJLE1BQU0sYUFBYTtBQUFBLEVBQzlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSxPQUFPLE1BQU07QUFDWCxRQUFJLENBQUMsa0JBQWtCLElBQUksR0FBRztBQUM1QjtBQUFBLElBQ0Y7QUFDQSxRQUFJLENBQUMsS0FBSyxJQUFJLElBQUksR0FBRztBQUNuQjtBQUFBLElBQ0Y7QUFDQSxVQUFNLGlCQUFpQixvQkFBb0IsSUFBSTtBQUMvQyxXQUFPLEtBQUssa0JBQWtCLEVBQUUsY0FBYztBQUM5QyxTQUFLLGdCQUFnQixFQUFFLE9BQU8sY0FBYztBQUFBLEVBQzlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUtBLFFBQVEsVUFBVSxTQUFTO0FBQ3pCLGVBQVcsQ0FBQyxNQUFNLEtBQUssS0FBSyxLQUFLLFFBQVEsR0FBRztBQUMxQyxlQUFTLEtBQUssU0FBUyxPQUFPLE1BQU0sSUFBSTtBQUFBLElBQzFDO0FBQUEsRUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLGVBQWU7QUFDYixVQUFNLGtCQUFrQixLQUFLLElBQUksWUFBWTtBQUM3QyxRQUFJLG9CQUFvQixNQUFNO0FBQzVCLGFBQU8sQ0FBQztBQUFBLElBQ1Y7QUFDQSxRQUFJLG9CQUFvQixJQUFJO0FBQzFCLGFBQU8sQ0FBQyxFQUFFO0FBQUEsSUFDWjtBQUNBLFlBQVEsR0FBRyx5QkFBeUIsb0JBQW9CLGVBQWU7QUFBQSxFQUN6RTtBQUNGO0FBQ0EsU0FBUyxnQkFBZ0IsS0FBSztBQUM1QixRQUFNLFFBQVEsSUFBSSxLQUFLLEVBQUUsTUFBTSxTQUFTO0FBQ3hDLFNBQU8sTUFBTSxPQUFPLENBQUMsU0FBUyxTQUFTO0FBQ3JDLFFBQUksS0FBSyxLQUFLLE1BQU0sSUFBSTtBQUN0QixhQUFPO0FBQUEsSUFDVDtBQUNBLFVBQU0sUUFBUSxLQUFLLE1BQU0sSUFBSTtBQUM3QixVQUFNLE9BQU8sTUFBTSxNQUFNO0FBQ3pCLFVBQU0sUUFBUSxNQUFNLEtBQUssSUFBSTtBQUM3QixZQUFRLE9BQU8sTUFBTSxLQUFLO0FBQzFCLFdBQU87QUFBQSxFQUNULEdBQUcsSUFBSSxTQUFTLENBQUM7QUFDbkI7QUFHQSxTQUFTLG9CQUFvQixlQUFlO0FBQzFDLE1BQUksS0FBSztBQUNULFFBQU0sVUFBVSxnQkFBZ0IsYUFBYTtBQUM3QyxRQUFNLGNBQWMsUUFBUSxJQUFJLGNBQWMsS0FBSztBQUNuRCxRQUFNLGNBQWMsUUFBUSxJQUFJLHFCQUFxQjtBQUNyRCxNQUFJLENBQUMsYUFBYTtBQUNoQixVQUFNLElBQUksTUFBTSwyQ0FBMkM7QUFBQSxFQUM3RDtBQUNBLFFBQU0sYUFBYSxZQUFZLE1BQU0sR0FBRyxFQUFFLE9BQU8sQ0FBQyxLQUFLLFVBQVU7QUFDL0QsVUFBTSxDQUFDLE9BQU8sR0FBRyxJQUFJLElBQUksTUFBTSxLQUFLLEVBQUUsTUFBTSxHQUFHO0FBQy9DLFFBQUksS0FBSyxJQUFJLEtBQUssS0FBSyxHQUFHO0FBQzFCLFdBQU87QUFBQSxFQUNULEdBQUcsQ0FBQyxDQUFDO0FBQ0wsUUFBTSxRQUFRLE1BQU0sV0FBVyxTQUFTLE9BQU8sU0FBUyxJQUFJLE1BQU0sR0FBRyxFQUFFO0FBQ3ZFLFFBQU0sWUFBWSxNQUFNLFdBQVcsYUFBYSxPQUFPLFNBQVMsSUFBSSxNQUFNLEdBQUcsRUFBRTtBQUMvRSxTQUFPO0FBQUEsSUFDTDtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNGO0FBQ0EsU0FBUyxtQkFBbUIsTUFBTSxTQUFTO0FBQ3pDLFFBQU0sY0FBYyxXQUFXLE9BQU8sU0FBUyxRQUFRLElBQUksY0FBYztBQUN6RSxNQUFJLENBQUMsYUFBYTtBQUNoQixXQUFPO0FBQUEsRUFDVDtBQUNBLFFBQU0sQ0FBQyxFQUFFLEdBQUcsVUFBVSxJQUFJLFlBQVksTUFBTSxLQUFLO0FBQ2pELFFBQU0sV0FBVyxXQUFXLE9BQU8sQ0FBQyxNQUFNLEVBQUUsV0FBVyxXQUFXLENBQUMsRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLFFBQVEsY0FBYyxFQUFFLENBQUMsRUFBRSxDQUFDO0FBQzlHLE1BQUksQ0FBQyxVQUFVO0FBQ2IsV0FBTztBQUFBLEVBQ1Q7QUFDQSxRQUFNLGlCQUFpQixJQUFJLE9BQU8sTUFBTSxRQUFRLEVBQUU7QUFDbEQsUUFBTSxTQUFTLEtBQUssTUFBTSxjQUFjLEVBQUUsT0FBTyxDQUFDLFVBQVUsTUFBTSxXQUFXLE1BQU0sS0FBSyxNQUFNLFNBQVMsTUFBTSxDQUFDLEVBQUUsSUFBSSxDQUFDLFVBQVUsTUFBTSxVQUFVLEVBQUUsUUFBUSxTQUFTLEVBQUUsQ0FBQztBQUNySyxNQUFJLENBQUMsT0FBTyxRQUFRO0FBQ2xCLFdBQU87QUFBQSxFQUNUO0FBQ0EsUUFBTSxhQUFhLENBQUM7QUFDcEIsTUFBSTtBQUNGLGVBQVcsU0FBUyxRQUFRO0FBQzFCLFlBQU0sQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLElBQUksTUFBTSxNQUFNLFVBQVU7QUFDeEQsWUFBTSxjQUFjLEtBQUssS0FBSyxVQUFVO0FBQ3hDLFlBQU0sRUFBRSxhQUFhLGNBQWMsVUFBVSxLQUFLLElBQUksb0JBQW9CLGNBQWM7QUFDeEYsWUFBTSxRQUFRLGFBQWEsU0FBUyxjQUFjLElBQUksS0FBSyxDQUFDLFdBQVcsR0FBRyxVQUFVLEVBQUUsTUFBTSxhQUFhLENBQUM7QUFDMUcsWUFBTSxjQUFjLFdBQVcsSUFBSTtBQUNuQyxVQUFJLGdCQUFnQixRQUFRO0FBQzFCLG1CQUFXLElBQUksSUFBSTtBQUFBLE1BQ3JCLFdBQVcsTUFBTSxRQUFRLFdBQVcsR0FBRztBQUNyQyxtQkFBVyxJQUFJLElBQUksQ0FBQyxHQUFHLGFBQWEsS0FBSztBQUFBLE1BQzNDLE9BQU87QUFDTCxtQkFBVyxJQUFJLElBQUksQ0FBQyxhQUFhLEtBQUs7QUFBQSxNQUN4QztBQUFBLElBQ0Y7QUFDQSxXQUFPO0FBQUEsRUFDVCxTQUFTLE9BQU87QUFDZCxXQUFPO0FBQUEsRUFDVDtBQUNGO0FBR0EsU0FBUyxrQkFBa0IsTUFBTTtBQUMvQixNQUFJO0FBQ0osUUFBTSxlQUFlLEtBQUssWUFBWSxLQUFLLENBQUMsZUFBZTtBQUN6RCxXQUFPLFdBQVcsU0FBUztBQUFBLEVBQzdCLENBQUM7QUFDRCxTQUFPO0FBQUEsSUFDTCxlQUFlLGdCQUFnQixPQUFPLFNBQVMsYUFBYTtBQUFBLElBQzVELGdCQUFnQixNQUFNLGdCQUFnQixPQUFPLFNBQVMsYUFBYSxTQUFTLE9BQU8sU0FBUyxJQUFJO0FBQUEsRUFDbEc7QUFDRjtBQUNBLFNBQVMsV0FBVyxPQUFPO0FBQ3pCLE1BQUk7QUFDRixVQUFNLE1BQU0sT0FBTyxLQUFLO0FBQ3hCLFdBQU8sa0JBQWtCLEdBQUc7QUFBQSxFQUM5QixTQUFTLE9BQU87QUFDZCxXQUFPO0FBQUEsRUFDVDtBQUNGO0FBQ0EsU0FBUywwQkFBMEIsV0FBVyxLQUFLLE9BQU87QUFDeEQsUUFBTSxhQUFhLEVBQUUsVUFBVTtBQUMvQixhQUFXLENBQUMsS0FBSyxTQUFTLEtBQUssT0FBTyxRQUFRLEdBQUcsR0FBRztBQUNsRCxRQUFJLEVBQUUsT0FBTyxRQUFRO0FBQ25CLFlBQU0sSUFBSSxNQUFNLGtDQUFrQyxHQUFHLEtBQUs7QUFBQSxJQUM1RDtBQUNBLGVBQVcsV0FBVyxXQUFXO0FBQy9CLFlBQU0sQ0FBQyxVQUFVLEdBQUcsYUFBYSxJQUFJLFFBQVEsTUFBTSxHQUFHLEVBQUUsUUFBUTtBQUNoRSxZQUFNLFFBQVEsY0FBYyxRQUFRO0FBQ3BDLFVBQUksU0FBUztBQUNiLGlCQUFXLFFBQVEsT0FBTztBQUN4QixZQUFJLEVBQUUsUUFBUSxTQUFTO0FBQ3JCLGdCQUFNLElBQUksTUFBTSxhQUFhLEtBQUsseUJBQXlCO0FBQUEsUUFDN0Q7QUFDQSxpQkFBUyxPQUFPLElBQUk7QUFBQSxNQUN0QjtBQUNBLGFBQU8sUUFBUSxJQUFJLE1BQU0sR0FBRztBQUFBLElBQzlCO0FBQUEsRUFDRjtBQUNBLFNBQU8sV0FBVztBQUNwQjtBQUNBLGVBQWUsZ0JBQWdCLFNBQVM7QUFDdEMsTUFBSTtBQUNKLFVBQVEsUUFBUSxRQUFRO0FBQUEsSUFDdEIsS0FBSyxPQUFPO0FBQ1YsWUFBTSxNQUFNLElBQUksSUFBSSxRQUFRLEdBQUc7QUFDL0IsWUFBTSxRQUFRLElBQUksYUFBYSxJQUFJLE9BQU87QUFDMUMsWUFBTSxZQUFZLElBQUksYUFBYSxJQUFJLFdBQVcsS0FBSztBQUN2RCxhQUFPO0FBQUEsUUFDTDtBQUFBLFFBQ0EsV0FBVyxVQUFVLFNBQVM7QUFBQSxNQUNoQztBQUFBLElBQ0Y7QUFBQSxJQUNBLEtBQUssUUFBUTtBQUNYLFlBQU0sZUFBZSxRQUFRLE1BQU07QUFDbkMsV0FBSyxNQUFNLFFBQVEsUUFBUSxJQUFJLGNBQWMsTUFBTSxPQUFPLFNBQVMsSUFBSSxTQUFTLHFCQUFxQixHQUFHO0FBQ3RHLGNBQU0sZUFBZTtBQUFBLFVBQ25CLE1BQU0sYUFBYSxLQUFLO0FBQUEsVUFDeEIsUUFBUTtBQUFBLFFBQ1Y7QUFDQSxZQUFJLENBQUMsY0FBYztBQUNqQixpQkFBTztBQUFBLFFBQ1Q7QUFDQSxjQUFNLEVBQUUsWUFBWSxLQUFLLEdBQUcsTUFBTSxJQUFJO0FBQ3RDLGNBQU0sbUJBQW1CO0FBQUEsVUFDdkI7QUFBQSxRQUNGLEtBQUssQ0FBQztBQUNOLFlBQUksQ0FBQyxpQkFBaUIsT0FBTztBQUMzQixpQkFBTztBQUFBLFFBQ1Q7QUFDQSxjQUFNLFlBQVksVUFBVSxPQUFPLEVBQUUsS0FBSyxDQUFDO0FBQzNDLGNBQU0sWUFBWSxpQkFBaUIsWUFBWTtBQUFBLFVBQzdDLGlCQUFpQjtBQUFBLFVBQ2pCO0FBQUEsVUFDQTtBQUFBLFFBQ0YsSUFBSSxDQUFDO0FBQ0wsZUFBTztBQUFBLFVBQ0wsT0FBTyxpQkFBaUI7QUFBQSxVQUN4QjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQ0EsWUFBTSxjQUFjLE1BQU0sYUFBYSxLQUFLLEVBQUUsTUFBTSxNQUFNLElBQUk7QUFDOUQsVUFBSSxlQUFlLE9BQU8sU0FBUyxZQUFZLE9BQU87QUFDcEQsY0FBTSxFQUFFLE9BQU8sVUFBVSxJQUFJO0FBQzdCLGVBQU87QUFBQSxVQUNMO0FBQUEsVUFDQTtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLElBQ0E7QUFDRSxhQUFPO0FBQUEsRUFDWDtBQUNGO0FBQ0EsZUFBZSxvQkFBb0IsU0FBUztBQUMxQyxRQUFNLFFBQVEsTUFBTSxnQkFBZ0IsT0FBTztBQUMzQyxNQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sT0FBTztBQUMxQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLEVBQUUsT0FBTyxVQUFVLElBQUk7QUFDN0IsUUFBTSxlQUFlLFdBQVcsS0FBSztBQUNyQyxNQUFJLHdCQUF3QixPQUFPO0FBQ2pDLFVBQU0sbUJBQW1CLFlBQVksUUFBUSxHQUFHO0FBQ2hELFVBQU0sSUFBSTtBQUFBLE1BQ1IsU0FBUztBQUFBLFFBQ1A7QUFBQSxRQUNBLFFBQVE7QUFBQSxRQUNSO0FBQUEsUUFDQSxhQUFhO0FBQUEsTUFDZjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUFBLElBQ0wsT0FBTyxNQUFNO0FBQUEsSUFDYixlQUFlLGFBQWE7QUFBQSxJQUM1QixlQUFlLGFBQWE7QUFBQSxJQUM1QjtBQUFBLEVBQ0Y7QUFDRjtBQUdBLFNBQVMsZUFBZSxPQUFPO0FBQzdCLE1BQUksU0FBUyxNQUFNO0FBQ2pCLFdBQU87QUFBQSxFQUNUO0FBQ0EsU0FBTyxPQUFPLFVBQVUsWUFBWSxVQUFVLFNBQVMsaUJBQWlCO0FBQzFFO0FBQ0EsSUFBSSxrQkFBa0IsTUFBTUEseUJBQXdCLGVBQWU7QUFBQSxFQUNqRSxZQUFZLGVBQWUsZUFBZSxVQUFVLFVBQVUsU0FBUztBQUNyRSxRQUFJLHdCQUF3QjtBQUM1QixRQUFJLGVBQWUsYUFBYSxHQUFHO0FBQ2pDLFlBQU0sYUFBYSxrQkFBa0IsYUFBYTtBQUNsRCxVQUFJLFdBQVcsa0JBQWtCLGVBQWU7QUFDOUMsY0FBTSxJQUFJO0FBQUEsVUFDUiwyR0FBMkcsYUFBYSxlQUFlLFdBQVcsYUFBYTtBQUFBLFFBQ2pLO0FBQUEsTUFDRjtBQUNBLFVBQUksQ0FBQyxXQUFXLGVBQWU7QUFDN0IsY0FBTSxJQUFJO0FBQUEsVUFDUjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQ0EsOEJBQXdCLFdBQVc7QUFBQSxJQUNyQztBQUNBLFVBQU0sU0FBUyxrQkFBa0IsUUFBUSxHQUFHLGFBQWEsYUFBYSxTQUFTLFNBQVMsQ0FBQyxNQUFNLEdBQUcsYUFBYSxJQUFJLHFCQUFxQixhQUFhLFNBQVMsU0FBUyxDQUFDO0FBQ3hLLFVBQU07QUFBQSxNQUNKLE1BQU07QUFBQSxRQUNKO0FBQUEsUUFDQTtBQUFBLFFBQ0EsZUFBZTtBQUFBLE1BQ2pCO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGLENBQUM7QUFDRCxrQkFBYyxNQUFNLFVBQVU7QUFDOUIsU0FBSyxXQUFXO0FBQUEsRUFDbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSxNQUFNLGtDQUFrQyxTQUFTO0FBQy9DLFFBQUksQ0FBQ0EsaUJBQWdCLG1CQUFtQixJQUFJLE9BQU8sR0FBRztBQUNwRCxNQUFBQSxpQkFBZ0IsbUJBQW1CO0FBQUEsUUFDakM7QUFBQSxRQUNBLE1BQU0sb0JBQW9CLE9BQU8sRUFBRSxNQUFNLENBQUMsVUFBVTtBQUNsRCxrQkFBUSxNQUFNLEtBQUs7QUFDbkIsaUJBQU87QUFBQSxRQUNULENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRjtBQUNBLFdBQU9BLGlCQUFnQixtQkFBbUIsSUFBSSxPQUFPO0FBQUEsRUFDdkQ7QUFBQSxFQUNBLE1BQU0sTUFBTSxNQUFNO0FBQ2hCLFVBQU0sU0FBUyxnQkFBZ0IsSUFBSSxJQUFJLEtBQUssUUFBUSxHQUFHLEdBQUcsS0FBSyxRQUFRO0FBQ3ZFLFVBQU0sVUFBVSxxQkFBcUIsS0FBSyxPQUFPO0FBQ2pELFFBQUksQ0FBQyxPQUFPLFNBQVM7QUFDbkIsYUFBTyxFQUFFLE9BQU8sUUFBUSxRQUFRO0FBQUEsSUFDbEM7QUFDQSxVQUFNLGVBQWUsTUFBTSxLQUFLO0FBQUEsTUFDOUIsS0FBSztBQUFBLElBQ1A7QUFDQSxRQUFJLE9BQU8saUJBQWlCLGFBQWE7QUFDdkMsYUFBTyxFQUFFLE9BQU8sUUFBUSxRQUFRO0FBQUEsSUFDbEM7QUFDQSxXQUFPO0FBQUEsTUFDTCxPQUFPO0FBQUEsTUFDUDtBQUFBLE1BQ0EsT0FBTyxhQUFhO0FBQUEsTUFDcEIsZUFBZSxhQUFhO0FBQUEsTUFDNUIsZUFBZSxhQUFhO0FBQUEsTUFDNUIsV0FBVyxhQUFhO0FBQUEsSUFDMUI7QUFBQSxFQUNGO0FBQUEsRUFDQSxVQUFVLE1BQU07QUFDZCxRQUFJLEtBQUssYUFBYSxrQkFBa0IsUUFBUTtBQUM5QyxhQUFPO0FBQUEsSUFDVDtBQUNBLFFBQUksQ0FBQyxLQUFLLGFBQWEsaUJBQWlCLEtBQUssS0FBSyxrQkFBa0IsT0FBTztBQUN6RSxZQUFNLFlBQVksWUFBWSxLQUFLLFFBQVEsR0FBRztBQUM5QyxlQUFTLEtBQUssNkNBQTZDLEtBQUssUUFBUSxNQUFNLElBQUksU0FBUztBQUFBO0FBQUEsNE5BRTJIO0FBQ3ROLGFBQU87QUFBQSxJQUNUO0FBQ0EsVUFBTSwyQkFBMkIsS0FBSyxLQUFLLGtCQUFrQixTQUFTLEtBQUssYUFBYSxrQkFBa0IsS0FBSyxLQUFLO0FBQ3BILFVBQU0sMkJBQTJCLEtBQUssS0FBSyx5QkFBeUIsU0FBUyxLQUFLLEtBQUssY0FBYyxLQUFLLEtBQUssYUFBYSxpQkFBaUIsRUFBRSxJQUFJLEtBQUssYUFBYSxrQkFBa0IsS0FBSyxLQUFLO0FBQ2pNLFdBQU8sS0FBSyxhQUFhLE1BQU0sV0FBVyw0QkFBNEI7QUFBQSxFQUN4RTtBQUFBLEVBQ0EsbUJBQW1CLE1BQU07QUFDdkIsV0FBTztBQUFBLE1BQ0wsT0FBTyxLQUFLLGFBQWEsU0FBUztBQUFBLE1BQ2xDLGVBQWUsS0FBSyxhQUFhLGlCQUFpQjtBQUFBLE1BQ2xELFdBQVcsS0FBSyxhQUFhLGFBQWEsQ0FBQztBQUFBLE1BQzNDLFNBQVMsS0FBSyxhQUFhO0FBQUEsSUFDN0I7QUFBQSxFQUNGO0FBQUEsRUFDQSxNQUFNLElBQUksTUFBTTtBQUNkLFVBQU0sZ0JBQWdCLE1BQU0saUJBQWlCLEtBQUssT0FBTztBQUN6RCxVQUFNLGlCQUFpQixNQUFNLGtCQUFrQixLQUFLLFFBQVE7QUFDNUQsVUFBTSxjQUFjLG1CQUFtQixlQUFlLE1BQU07QUFDNUQsVUFBTSxjQUFjLEtBQUssYUFBYSxnQkFBZ0IsR0FBRyxLQUFLLGFBQWEsYUFBYSxJQUFJLEtBQUssYUFBYSxhQUFhLEtBQUssYUFBYSxLQUFLLGFBQWEsYUFBYTtBQUM1SyxZQUFRO0FBQUEsTUFDTixTQUFTO0FBQUEsUUFDUCxHQUFHLGFBQWEsQ0FBQyxJQUFJLFdBQVcsT0FBTyxlQUFlLE1BQU0sSUFBSSxlQUFlLFVBQVU7QUFBQSxNQUMzRjtBQUFBLE1BQ0EsU0FBUyxXQUFXO0FBQUEsTUFDcEI7QUFBQSxJQUNGO0FBQ0EsWUFBUSxJQUFJLFlBQVksYUFBYTtBQUNyQyxZQUFRLElBQUksWUFBWSxJQUFJO0FBQzVCLFlBQVEsSUFBSSxhQUFhLGNBQWM7QUFDdkMsWUFBUSxTQUFTO0FBQUEsRUFDbkI7QUFDRjtBQUNBLGNBQWMsaUJBQWlCLHNCQUFzQyxvQkFBSSxRQUFRLENBQUM7QUFDbEYsSUFBSSxpQkFBaUI7QUFHckIsU0FBUywyQkFBMkIsZUFBZSxLQUFLO0FBQ3RELFNBQU8sQ0FBQyxlQUFlLFVBQVUsVUFBVSxDQUFDLE1BQU07QUFDaEQsV0FBTyxJQUFJO0FBQUEsTUFDVDtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGO0FBQ0EsU0FBUyw4QkFBOEIsS0FBSztBQUMxQyxTQUFPLENBQUMsYUFBYTtBQUNuQixXQUFPLElBQUksZUFBZSxPQUFPLElBQUksT0FBTyxJQUFJLEdBQUcsS0FBSyxRQUFRO0FBQUEsRUFDbEU7QUFDRjtBQUNBLElBQUksMEJBQTBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVc1QixPQUFPLDJCQUEyQixTQUFTLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFZOUMsVUFBVSwyQkFBMkIsWUFBWSxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVdwRCxXQUFXLDhCQUE4QixHQUFHO0FBQzlDO0FBQ0EsU0FBUyxrQkFBa0IsS0FBSztBQUM5QixTQUFPO0FBQUEsSUFDTCxXQUFXLDhCQUE4QixHQUFHO0FBQUEsSUFDNUMsT0FBTywyQkFBMkIsU0FBUyxHQUFHO0FBQUEsSUFDOUMsVUFBVSwyQkFBMkIsWUFBWSxHQUFHO0FBQUEsRUFDdEQ7QUFDRjtBQUNBLElBQUksV0FBVztBQUFBLEVBQ2IsR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBVUgsTUFBTTtBQUNSO0FBR0EsU0FBUyxXQUFXO0FBQ2xCLFNBQU8sS0FBSyxPQUFPLEVBQUUsU0FBUyxFQUFFLEVBQUUsTUFBTSxDQUFDO0FBQzNDO0FBR0EsSUFBSSxjQUFjLE9BQU8sVUFBVSxZQUFZO0FBQzdDLFFBQU0sU0FBUyxNQUFNLGdCQUFnQjtBQUFBLElBQ25DO0FBQUEsSUFDQSxXQUFXLFNBQVM7QUFBQSxJQUNwQjtBQUFBLEVBQ0YsQ0FBQztBQUNELFNBQU8sVUFBVSxPQUFPLFNBQVMsT0FBTztBQUMxQztBQUdBLElBQUksRUFBRSxTQUFTLFNBQVMsSUFBSTtBQUM1QixTQUFTLHNCQUFzQixPQUFPLENBQUMsR0FBRztBQUN4QyxRQUFNLFVBQVUsUUFBUSxPQUFPLFNBQVMsS0FBSyxXQUFXO0FBQ3hELFFBQU0sY0FBYyxRQUFRLE9BQU8sU0FBUyxLQUFLLGVBQWUsU0FBUyxNQUFNLEtBQUs7QUFDcEYsUUFBTSxVQUFVLElBQUksUUFBUSxRQUFRLE9BQU8sU0FBUyxLQUFLLE9BQU87QUFDaEUsU0FBTztBQUFBLElBQ0wsR0FBRztBQUFBLElBQ0g7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDRjtBQUNBLFNBQVMsaUJBQWlCLFVBQVUsTUFBTTtBQUN4QyxNQUFJO0FBQ0osTUFBSSxLQUFLLE1BQU07QUFDYixXQUFPLGVBQWUsVUFBVSxRQUFRO0FBQUEsTUFDdEMsT0FBTyxLQUFLO0FBQUEsTUFDWixZQUFZO0FBQUEsTUFDWixVQUFVO0FBQUEsSUFDWixDQUFDO0FBQUEsRUFDSDtBQUNBLE1BQUksT0FBTyxhQUFhLGFBQWE7QUFDbkMsVUFBTSxvQkFBb0IsTUFBTSxLQUFLLFFBQVEsSUFBSSxZQUFZLE1BQU0sT0FBTyxTQUFTLElBQUksTUFBTSxHQUFHLE1BQU0sQ0FBQztBQUN2RyxlQUFXLGdCQUFnQixpQkFBaUI7QUFDMUMsZUFBUyxTQUFTO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBR0EsSUFBSSxlQUFlLE1BQU0sc0JBQXNCLFNBQVM7QUFBQSxFQUN0RCxZQUFZLE1BQU0sTUFBTTtBQUN0QixVQUFNLGVBQWUsc0JBQXNCLElBQUk7QUFDL0MsVUFBTSxNQUFNLFlBQVk7QUFDeEIscUJBQWlCLE1BQU0sWUFBWTtBQUFBLEVBQ3JDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFPQSxPQUFPLEtBQUssTUFBTSxNQUFNO0FBQ3RCLFVBQU0sZUFBZSxzQkFBc0IsSUFBSTtBQUMvQyxRQUFJLENBQUMsYUFBYSxRQUFRLElBQUksY0FBYyxHQUFHO0FBQzdDLG1CQUFhLFFBQVEsSUFBSSxnQkFBZ0IsWUFBWTtBQUFBLElBQ3ZEO0FBQ0EsUUFBSSxDQUFDLGFBQWEsUUFBUSxJQUFJLGdCQUFnQixHQUFHO0FBQy9DLG1CQUFhLFFBQVE7QUFBQSxRQUNuQjtBQUFBLFFBQ0EsT0FBTyxLQUFLLE9BQU8sU0FBUyxJQUFJO0FBQUEsTUFDbEM7QUFBQSxJQUNGO0FBQ0EsV0FBTyxJQUFJLGNBQWMsTUFBTSxZQUFZO0FBQUEsRUFDN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU9BLE9BQU8sS0FBSyxNQUFNLE1BQU07QUFDdEIsVUFBTSxlQUFlLHNCQUFzQixJQUFJO0FBQy9DLFFBQUksQ0FBQyxhQUFhLFFBQVEsSUFBSSxjQUFjLEdBQUc7QUFDN0MsbUJBQWEsUUFBUSxJQUFJLGdCQUFnQixrQkFBa0I7QUFBQSxJQUM3RDtBQUNBLFVBQU0sZUFBZSxLQUFLLFVBQVUsSUFBSTtBQUN4QyxRQUFJLENBQUMsYUFBYSxRQUFRLElBQUksZ0JBQWdCLEdBQUc7QUFDL0MsbUJBQWEsUUFBUTtBQUFBLFFBQ25CO0FBQUEsUUFDQSxlQUFlLGFBQWEsT0FBTyxTQUFTLElBQUk7QUFBQSxNQUNsRDtBQUFBLElBQ0Y7QUFDQSxXQUFPLElBQUk7QUFBQSxNQUNUO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFPQSxPQUFPLElBQUksTUFBTSxNQUFNO0FBQ3JCLFVBQU0sZUFBZSxzQkFBc0IsSUFBSTtBQUMvQyxRQUFJLENBQUMsYUFBYSxRQUFRLElBQUksY0FBYyxHQUFHO0FBQzdDLG1CQUFhLFFBQVEsSUFBSSxnQkFBZ0IsVUFBVTtBQUFBLElBQ3JEO0FBQ0EsV0FBTyxJQUFJLGNBQWMsTUFBTSxZQUFZO0FBQUEsRUFDN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVVBLE9BQU8sWUFBWSxNQUFNLE1BQU07QUFDN0IsVUFBTSxlQUFlLHNCQUFzQixJQUFJO0FBQy9DLFFBQUksTUFBTTtBQUNSLG1CQUFhLFFBQVEsSUFBSSxrQkFBa0IsS0FBSyxXQUFXLFNBQVMsQ0FBQztBQUFBLElBQ3ZFO0FBQ0EsV0FBTyxJQUFJLGNBQWMsTUFBTSxZQUFZO0FBQUEsRUFDN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFTQSxPQUFPLFNBQVMsTUFBTSxNQUFNO0FBQzFCLFdBQU8sSUFBSSxjQUFjLE1BQU0sc0JBQXNCLElBQUksQ0FBQztBQUFBLEVBQzVEO0FBQ0Y7QUFHQSxJQUFJLDhCQUE4QjtBQUNsQyxJQUFJLDJCQUEyQjtBQUMvQixJQUFJLDJCQUEyQjtBQUMvQixJQUFJLDRCQUE0QjtBQUNoQyxTQUFTLDJCQUEyQjtBQUNsQyxNQUFJLGNBQWMsR0FBRztBQUNuQixXQUFPO0FBQUEsRUFDVDtBQUNBLFNBQU8sS0FBSztBQUFBLElBQ1YsS0FBSyxPQUFPLEtBQUssMkJBQTJCLDRCQUE0QjtBQUFBLEVBQzFFO0FBQ0Y7QUFDQSxlQUFlLE1BQU0sZ0JBQWdCO0FBQ25DLE1BQUk7QUFDSixNQUFJLE9BQU8sbUJBQW1CLFVBQVU7QUFDdEMsWUFBUSxnQkFBZ0I7QUFBQSxNQUN0QixLQUFLLFlBQVk7QUFDZixvQkFBWTtBQUNaO0FBQUEsTUFDRjtBQUFBLE1BQ0EsS0FBSyxRQUFRO0FBQ1gsb0JBQVkseUJBQXlCO0FBQ3JDO0FBQUEsTUFDRjtBQUFBLE1BQ0EsU0FBUztBQUNQLGNBQU0sSUFBSTtBQUFBLFVBQ1IsbURBQW1ELGNBQWM7QUFBQSxRQUNuRTtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRixXQUFXLE9BQU8sbUJBQW1CLGFBQWE7QUFDaEQsZ0JBQVkseUJBQXlCO0FBQUEsRUFDdkMsT0FBTztBQUNMLFFBQUksaUJBQWlCLDZCQUE2QjtBQUNoRCxZQUFNLElBQUk7QUFBQSxRQUNSLHdEQUF3RCxjQUFjLDREQUE0RCwyQkFBMkI7QUFBQSxNQUMvSjtBQUFBLElBQ0Y7QUFDQSxnQkFBWTtBQUFBLEVBQ2Q7QUFDQSxTQUFPLElBQUksUUFBUSxDQUFDLFlBQVksV0FBVyxTQUFTLFNBQVMsQ0FBQztBQUNoRTtBQUdBLFNBQVMsT0FBTyxPQUFPLE1BQU07QUFDM0IsUUFBTSxVQUFVLGlCQUFpQixVQUFVLFFBQVEsSUFBSSxRQUFRLE9BQU8sSUFBSTtBQUMxRTtBQUFBLElBQ0UsQ0FBQyxRQUFRO0FBQUEsSUFDVDtBQUFBLElBQ0EsUUFBUTtBQUFBLElBQ1IsUUFBUTtBQUFBLEVBQ1Y7QUFDQSxRQUFNLGVBQWUsUUFBUSxNQUFNO0FBQ25DLGVBQWEsUUFBUSxJQUFJLG1CQUFtQixRQUFRO0FBQ3BELFNBQU87QUFDVDtBQUdBLFNBQVMsY0FBYztBQUNyQixTQUFPLElBQUksU0FBUyxNQUFNO0FBQUEsSUFDeEIsUUFBUTtBQUFBLElBQ1IsWUFBWTtBQUFBLElBQ1osU0FBUztBQUFBLE1BQ1AsbUJBQW1CO0FBQUEsSUFDckI7QUFBQSxFQUNGLENBQUM7QUFDSDtBQUdBLGFBQWE7QUFDYjtBQUFBLEVBQ0U7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQSxZQUFZO0FBQUEsRUFDWjtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBO0FBRUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTsiLCJuYW1lcyI6WyJfR3JhcGhRTEhhbmRsZXIiXSwieF9nb29nbGVfaWdub3JlTGlzdCI6WzBdfQ==