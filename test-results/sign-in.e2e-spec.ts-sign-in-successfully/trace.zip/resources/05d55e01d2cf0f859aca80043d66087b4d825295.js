import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/app/orders/orders.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=efc33bbd"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/orders.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=efc33bbd";
import { Helmet } from "/node_modules/.vite/deps/react-helmet-async.js?v=efc33bbd";
import { useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=efc33bbd";
import { z } from "/node_modules/.vite/deps/zod.js?v=efc33bbd";
import { getOrders } from "/src/api/get-orders.ts";
import { Pagination } from "/src/components/pagination.tsx";
import {
  Table,
  TableBody,
  TableHead,
  TableHeader,
  TableRow
} from "/src/components/ui/table.tsx";
import { OrderTableFilters } from "/src/pages/app/orders/order-table-filters.tsx";
import { OrderTableRow } from "/src/pages/app/orders/order-table-row.tsx";
import { OrderTableSkeleton } from "/src/pages/app/orders/order-table-skeleton.tsx";
export function Orders() {
  _s();
  const [searchParams, setSearchParams] = useSearchParams();
  const orderId = searchParams.get("orderId");
  const customerName = searchParams.get("customerName");
  const status = searchParams.get("status");
  const pageIndex = z.coerce.number().transform((page) => page - 1).parse(searchParams.get("page") ?? "1");
  const { data: result, isLoading: isLoadingOrders } = useQuery({
    queryKey: ["orders", pageIndex, orderId, customerName, status],
    queryFn: () => getOrders({
      pageIndex,
      orderId,
      customerName,
      status: status === "all" ? null : status
    })
  });
  function handlePaginate(pageIndex2) {
    setSearchParams((state) => {
      state.set("page", (pageIndex2 + 1).toString());
      return state;
    });
  }
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(Helmet, { title: "Pedidos" }, void 0, false, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/orders.tsx",
      lineNumber: 52,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold  tracking-tight", children: "Pedidos" }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/orders.tsx",
        lineNumber: 54,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2.5", children: [
        /* @__PURE__ */ jsxDEV(OrderTableFilters, {}, void 0, false, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/orders.tsx",
          lineNumber: 57,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "rounded-md border", children: /* @__PURE__ */ jsxDEV(Table, { children: [
          /* @__PURE__ */ jsxDEV(TableHeader, { children: /* @__PURE__ */ jsxDEV(TableRow, { children: [
            /* @__PURE__ */ jsxDEV(TableHead, { className: "w-[64px]" }, void 0, false, {
              fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/orders.tsx",
              lineNumber: 62,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(TableHead, { className: "w-[140px]", children: "Identificador" }, void 0, false, {
              fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/orders.tsx",
              lineNumber: 63,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(TableHead, { className: "w-[180px]", children: "Realizado há" }, void 0, false, {
              fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/orders.tsx",
              lineNumber: 64,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(TableHead, { className: "w-[140px]", children: "Status" }, void 0, false, {
              fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/orders.tsx",
              lineNumber: 65,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(TableHead, { children: "Cliente" }, void 0, false, {
              fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/orders.tsx",
              lineNumber: 66,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(TableHead, { className: "w-[140px]", children: "Total do pedido" }, void 0, false, {
              fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/orders.tsx",
              lineNumber: 67,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(TableHead, { className: "w-[164px]" }, void 0, false, {
              fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/orders.tsx",
              lineNumber: 68,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(TableHead, { className: "w-[132o8px]" }, void 0, false, {
              fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/orders.tsx",
              lineNumber: 69,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/orders.tsx",
            lineNumber: 61,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/orders.tsx",
            lineNumber: 60,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(TableBody, { children: [
            isLoadingOrders && /* @__PURE__ */ jsxDEV(OrderTableSkeleton, {}, void 0, false, {
              fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/orders.tsx",
              lineNumber: 73,
              columnNumber: 37
            }, this),
            result && result.orders.map((order) => {
              return /* @__PURE__ */ jsxDEV(OrderTableRow, { order }, order.orderId, false, {
                fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/orders.tsx",
                lineNumber: 76,
                columnNumber: 26
              }, this);
            })
          ] }, void 0, true, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/orders.tsx",
            lineNumber: 72,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/orders.tsx",
          lineNumber: 59,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/orders.tsx",
          lineNumber: 58,
          columnNumber: 11
        }, this),
        result && /* @__PURE__ */ jsxDEV(
          Pagination,
          {
            onPageChange: handlePaginate,
            pageIndex: result.meta.pageIndex,
            totalCount: result.meta.totalCount,
            perPage: result.meta.perPage
          },
          void 0,
          false,
          {
            fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/orders.tsx",
            lineNumber: 82,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/orders.tsx",
        lineNumber: 56,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/orders.tsx",
      lineNumber: 53,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/orders.tsx",
    lineNumber: 51,
    columnNumber: 5
  }, this);
}
_s(Orders, "nWfvfAtxOuif4HYB1Wmf0wmtOQ8=", false, function() {
  return [useSearchParams, useQuery];
});
_c = Orders;
var _c;
$RefreshReg$(_c, "Orders");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arruday/GitHub/pizzashop/src/pages/app/orders/orders.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0RJLG1CQUNFLGNBREY7MkJBbERKO0FBQWlCLE1BQVEscUJBQXVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ2hELFNBQVNBLGNBQWM7QUFDdkIsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLFNBQVM7QUFFbEIsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLGtCQUFrQjtBQUMzQjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFFUCxTQUFTQyx5QkFBeUI7QUFDbEMsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLDBCQUEwQjtBQUU1QixnQkFBU0MsU0FBUztBQUFBQyxLQUFBO0FBQ3ZCLFFBQU0sQ0FBQ0MsY0FBY0MsZUFBZSxJQUFJZixnQkFBZ0I7QUFFeEQsUUFBTWdCLFVBQVVGLGFBQWFHLElBQUksU0FBUztBQUMxQyxRQUFNQyxlQUFlSixhQUFhRyxJQUFJLGNBQWM7QUFDcEQsUUFBTUUsU0FBU0wsYUFBYUcsSUFBSSxRQUFRO0FBRXhDLFFBQU1HLFlBQVluQixFQUFFb0IsT0FDakJDLE9BQU8sRUFDUEMsVUFBVSxDQUFDQyxTQUFTQSxPQUFPLENBQUMsRUFDNUJDLE1BQU1YLGFBQWFHLElBQUksTUFBTSxLQUFLLEdBQUc7QUFFeEMsUUFBTSxFQUFFUyxNQUFNQyxRQUFRQyxXQUFXQyxnQkFBZ0IsSUFBSUMsU0FBUztBQUFBLElBQzVEQyxVQUFVLENBQUMsVUFBVVgsV0FBV0osU0FBU0UsY0FBY0MsTUFBTTtBQUFBLElBQzdEYSxTQUFTQSxNQUNQOUIsVUFBVTtBQUFBLE1BQ1JrQjtBQUFBQSxNQUNBSjtBQUFBQSxNQUNBRTtBQUFBQSxNQUNBQyxRQUFRQSxXQUFXLFFBQVEsT0FBT0E7QUFBQUEsSUFDcEMsQ0FBQztBQUFBLEVBQ0wsQ0FBQztBQUVELFdBQVNjLGVBQWViLFlBQW1CO0FBQ3pDTCxvQkFBZ0IsQ0FBQ21CLFVBQVU7QUFDekJBLFlBQU1DLElBQUksU0FBU2YsYUFBWSxHQUFHZ0IsU0FBUyxDQUFDO0FBQzVDLGFBQU9GO0FBQUFBLElBQ1QsQ0FBQztBQUFBLEVBQ0g7QUFFQSxTQUNFLG1DQUNFO0FBQUEsMkJBQUMsVUFBTyxPQUFNLGFBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1QjtBQUFBLElBQ3ZCLHVCQUFDLFNBQUksV0FBVSx1QkFDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSxzQ0FBcUMsdUJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEQ7QUFBQSxNQUUxRCx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLCtCQUFDLHVCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0I7QUFBQSxRQUNsQix1QkFBQyxTQUFJLFdBQVUscUJBQ2IsaUNBQUMsU0FDQztBQUFBLGlDQUFDLGVBQ0MsaUNBQUMsWUFDQztBQUFBLG1DQUFDLGFBQVUsV0FBVSxjQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQztBQUFBLFlBQ2hDLHVCQUFDLGFBQVUsV0FBVSxhQUFZLDZCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4QztBQUFBLFlBQzlDLHVCQUFDLGFBQVUsV0FBVSxhQUFZLDRCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2QztBQUFBLFlBQzdDLHVCQUFDLGFBQVUsV0FBVSxhQUFZLHNCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1QztBQUFBLFlBQ3ZDLHVCQUFDLGFBQVUsdUJBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0I7QUFBQSxZQUNsQix1QkFBQyxhQUFVLFdBQVUsYUFBWSwrQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0Q7QUFBQSxZQUNoRCx1QkFBQyxhQUFVLFdBQVUsZUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUM7QUFBQSxZQUNqQyx1QkFBQyxhQUFVLFdBQVUsaUJBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1DO0FBQUEsZUFSckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQSxLQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQSxVQUNBLHVCQUFDLGFBQ0VMO0FBQUFBLCtCQUFtQix1QkFBQyx3QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtQjtBQUFBLFlBQ3RDRixVQUNDQSxPQUFPVSxPQUFPQyxJQUFJLENBQUNDLFVBQVU7QUFDM0IscUJBQU8sdUJBQUMsaUJBQWtDLFNBQWZBLE1BQU12QixTQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnRDtBQUFBLFlBQ3pELENBQUM7QUFBQSxlQUxMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTUE7QUFBQSxhQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0JBLEtBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzQkE7QUFBQSxRQUNDVyxVQUNDO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxjQUFjTTtBQUFBQSxZQUNkLFdBQVdOLE9BQU9hLEtBQUtwQjtBQUFBQSxZQUN2QixZQUFZTyxPQUFPYSxLQUFLQztBQUFBQSxZQUN4QixTQUFTZCxPQUFPYSxLQUFLRTtBQUFBQTtBQUFBQSxVQUp2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJK0I7QUFBQSxXQTlCbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWlDQTtBQUFBLFNBcENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxQ0E7QUFBQSxPQXZDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBd0NBO0FBRUo7QUFBQzdCLEdBekVlRCxRQUFNO0FBQUEsVUFDb0JaLGlCQVdhOEIsUUFBUTtBQUFBO0FBQUFhLEtBWi9DL0I7QUFBTSxJQUFBK0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkhlbG1ldCIsInVzZVNlYXJjaFBhcmFtcyIsInoiLCJnZXRPcmRlcnMiLCJQYWdpbmF0aW9uIiwiVGFibGUiLCJUYWJsZUJvZHkiLCJUYWJsZUhlYWQiLCJUYWJsZUhlYWRlciIsIlRhYmxlUm93IiwiT3JkZXJUYWJsZUZpbHRlcnMiLCJPcmRlclRhYmxlUm93IiwiT3JkZXJUYWJsZVNrZWxldG9uIiwiT3JkZXJzIiwiX3MiLCJzZWFyY2hQYXJhbXMiLCJzZXRTZWFyY2hQYXJhbXMiLCJvcmRlcklkIiwiZ2V0IiwiY3VzdG9tZXJOYW1lIiwic3RhdHVzIiwicGFnZUluZGV4IiwiY29lcmNlIiwibnVtYmVyIiwidHJhbnNmb3JtIiwicGFnZSIsInBhcnNlIiwiZGF0YSIsInJlc3VsdCIsImlzTG9hZGluZyIsImlzTG9hZGluZ09yZGVycyIsInVzZVF1ZXJ5IiwicXVlcnlLZXkiLCJxdWVyeUZuIiwiaGFuZGxlUGFnaW5hdGUiLCJzdGF0ZSIsInNldCIsInRvU3RyaW5nIiwib3JkZXJzIiwibWFwIiwib3JkZXIiLCJtZXRhIiwidG90YWxDb3VudCIsInBlclBhZ2UiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIm9yZGVycy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUXVlcnkgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG5pbXBvcnQgeyBIZWxtZXQgfSBmcm9tICdyZWFjdC1oZWxtZXQtYXN5bmMnXG5pbXBvcnQgeyB1c2VTZWFyY2hQYXJhbXMgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuaW1wb3J0IHsgeiB9IGZyb20gJ3pvZCdcblxuaW1wb3J0IHsgZ2V0T3JkZXJzIH0gZnJvbSAnQC9hcGkvZ2V0LW9yZGVycydcbmltcG9ydCB7IFBhZ2luYXRpb24gfSBmcm9tICdAL2NvbXBvbmVudHMvcGFnaW5hdGlvbidcbmltcG9ydCB7XG4gIFRhYmxlLFxuICBUYWJsZUJvZHksXG4gIFRhYmxlSGVhZCxcbiAgVGFibGVIZWFkZXIsXG4gIFRhYmxlUm93LFxufSBmcm9tICdAL2NvbXBvbmVudHMvdWkvdGFibGUnXG5cbmltcG9ydCB7IE9yZGVyVGFibGVGaWx0ZXJzIH0gZnJvbSAnLi9vcmRlci10YWJsZS1maWx0ZXJzJ1xuaW1wb3J0IHsgT3JkZXJUYWJsZVJvdyB9IGZyb20gJy4vb3JkZXItdGFibGUtcm93J1xuaW1wb3J0IHsgT3JkZXJUYWJsZVNrZWxldG9uIH0gZnJvbSAnLi9vcmRlci10YWJsZS1za2VsZXRvbidcblxuZXhwb3J0IGZ1bmN0aW9uIE9yZGVycygpIHtcbiAgY29uc3QgW3NlYXJjaFBhcmFtcywgc2V0U2VhcmNoUGFyYW1zXSA9IHVzZVNlYXJjaFBhcmFtcygpXG5cbiAgY29uc3Qgb3JkZXJJZCA9IHNlYXJjaFBhcmFtcy5nZXQoJ29yZGVySWQnKVxuICBjb25zdCBjdXN0b21lck5hbWUgPSBzZWFyY2hQYXJhbXMuZ2V0KCdjdXN0b21lck5hbWUnKVxuICBjb25zdCBzdGF0dXMgPSBzZWFyY2hQYXJhbXMuZ2V0KCdzdGF0dXMnKVxuXG4gIGNvbnN0IHBhZ2VJbmRleCA9IHouY29lcmNlXG4gICAgLm51bWJlcigpXG4gICAgLnRyYW5zZm9ybSgocGFnZSkgPT4gcGFnZSAtIDEpXG4gICAgLnBhcnNlKHNlYXJjaFBhcmFtcy5nZXQoJ3BhZ2UnKSA/PyAnMScpXG5cbiAgY29uc3QgeyBkYXRhOiByZXN1bHQsIGlzTG9hZGluZzogaXNMb2FkaW5nT3JkZXJzIH0gPSB1c2VRdWVyeSh7XG4gICAgcXVlcnlLZXk6IFsnb3JkZXJzJywgcGFnZUluZGV4LCBvcmRlcklkLCBjdXN0b21lck5hbWUsIHN0YXR1c10sXG4gICAgcXVlcnlGbjogKCkgPT5cbiAgICAgIGdldE9yZGVycyh7XG4gICAgICAgIHBhZ2VJbmRleCxcbiAgICAgICAgb3JkZXJJZCxcbiAgICAgICAgY3VzdG9tZXJOYW1lLFxuICAgICAgICBzdGF0dXM6IHN0YXR1cyA9PT0gJ2FsbCcgPyBudWxsIDogc3RhdHVzLFxuICAgICAgfSksXG4gIH0pXG5cbiAgZnVuY3Rpb24gaGFuZGxlUGFnaW5hdGUocGFnZUluZGV4OiBudW1iZXIpIHtcbiAgICBzZXRTZWFyY2hQYXJhbXMoKHN0YXRlKSA9PiB7XG4gICAgICBzdGF0ZS5zZXQoJ3BhZ2UnLCAocGFnZUluZGV4ICsgMSkudG9TdHJpbmcoKSlcbiAgICAgIHJldHVybiBzdGF0ZVxuICAgIH0pXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8SGVsbWV0IHRpdGxlPVwiUGVkaWRvc1wiIC8+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTRcIj5cbiAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCAgdHJhY2tpbmctdGlnaHRcIj5QZWRpZG9zPC9oMT5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMi41XCI+XG4gICAgICAgICAgPE9yZGVyVGFibGVGaWx0ZXJzIC8+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlclwiPlxuICAgICAgICAgICAgPFRhYmxlPlxuICAgICAgICAgICAgICA8VGFibGVIZWFkZXI+XG4gICAgICAgICAgICAgICAgPFRhYmxlUm93PlxuICAgICAgICAgICAgICAgICAgPFRhYmxlSGVhZCBjbGFzc05hbWU9XCJ3LVs2NHB4XVwiPjwvVGFibGVIZWFkPlxuICAgICAgICAgICAgICAgICAgPFRhYmxlSGVhZCBjbGFzc05hbWU9XCJ3LVsxNDBweF1cIj5JZGVudGlmaWNhZG9yPC9UYWJsZUhlYWQ+XG4gICAgICAgICAgICAgICAgICA8VGFibGVIZWFkIGNsYXNzTmFtZT1cInctWzE4MHB4XVwiPlJlYWxpemFkbyBow6E8L1RhYmxlSGVhZD5cbiAgICAgICAgICAgICAgICAgIDxUYWJsZUhlYWQgY2xhc3NOYW1lPVwidy1bMTQwcHhdXCI+U3RhdHVzPC9UYWJsZUhlYWQ+XG4gICAgICAgICAgICAgICAgICA8VGFibGVIZWFkPkNsaWVudGU8L1RhYmxlSGVhZD5cbiAgICAgICAgICAgICAgICAgIDxUYWJsZUhlYWQgY2xhc3NOYW1lPVwidy1bMTQwcHhdXCI+VG90YWwgZG8gcGVkaWRvPC9UYWJsZUhlYWQ+XG4gICAgICAgICAgICAgICAgICA8VGFibGVIZWFkIGNsYXNzTmFtZT1cInctWzE2NHB4XVwiPjwvVGFibGVIZWFkPlxuICAgICAgICAgICAgICAgICAgPFRhYmxlSGVhZCBjbGFzc05hbWU9XCJ3LVsxMzJvOHB4XVwiPjwvVGFibGVIZWFkPlxuICAgICAgICAgICAgICAgIDwvVGFibGVSb3c+XG4gICAgICAgICAgICAgIDwvVGFibGVIZWFkZXI+XG4gICAgICAgICAgICAgIDxUYWJsZUJvZHk+XG4gICAgICAgICAgICAgICAge2lzTG9hZGluZ09yZGVycyAmJiA8T3JkZXJUYWJsZVNrZWxldG9uIC8+fVxuICAgICAgICAgICAgICAgIHtyZXN1bHQgJiZcbiAgICAgICAgICAgICAgICAgIHJlc3VsdC5vcmRlcnMubWFwKChvcmRlcikgPT4ge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gPE9yZGVyVGFibGVSb3cga2V5PXtvcmRlci5vcmRlcklkfSBvcmRlcj17b3JkZXJ9IC8+XG4gICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgPC9UYWJsZUJvZHk+XG4gICAgICAgICAgICA8L1RhYmxlPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIHtyZXN1bHQgJiYgKFxuICAgICAgICAgICAgPFBhZ2luYXRpb25cbiAgICAgICAgICAgICAgb25QYWdlQ2hhbmdlPXtoYW5kbGVQYWdpbmF0ZX1cbiAgICAgICAgICAgICAgcGFnZUluZGV4PXtyZXN1bHQubWV0YS5wYWdlSW5kZXh9XG4gICAgICAgICAgICAgIHRvdGFsQ291bnQ9e3Jlc3VsdC5tZXRhLnRvdGFsQ291bnR9XG4gICAgICAgICAgICAgIHBlclBhZ2U9e3Jlc3VsdC5tZXRhLnBlclBhZ2V9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC8+XG4gIClcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2FycnVkYXkvR2l0SHViL3Bpenphc2hvcC9zcmMvcGFnZXMvYXBwL29yZGVycy9vcmRlcnMudHN4In0=