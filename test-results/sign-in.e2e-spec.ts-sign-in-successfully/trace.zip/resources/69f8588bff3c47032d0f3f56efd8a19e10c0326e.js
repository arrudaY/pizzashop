import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/table.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=efc33bbd"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/arruday/GitHub/pizzashop/src/components/ui/table.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=efc33bbd"; const React = __vite__cjsImport3_react;
import { cn } from "/src/lib/utils.ts";
const Table = React.forwardRef(
  _c = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV("div", { className: "relative w-full overflow-auto", children: /* @__PURE__ */ jsxDEV(
    "table",
    {
      ref,
      className: cn("w-full caption-bottom text-sm", className),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/arruday/GitHub/pizzashop/src/components/ui/table.tsx",
      lineNumber: 10,
      columnNumber: 5
    },
    this
  ) }, void 0, false, {
    fileName: "/Users/arruday/GitHub/pizzashop/src/components/ui/table.tsx",
    lineNumber: 9,
    columnNumber: 1
  }, this)
);
_c2 = Table;
Table.displayName = "Table";
const TableHeader = React.forwardRef(
  _c3 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV("thead", { ref, className: cn("[&_tr]:border-b", className), ...props }, void 0, false, {
    fileName: "/Users/arruday/GitHub/pizzashop/src/components/ui/table.tsx",
    lineNumber: 23,
    columnNumber: 1
  }, this)
);
_c4 = TableHeader;
TableHeader.displayName = "TableHeader";
const TableBody = React.forwardRef(
  _c5 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    "tbody",
    {
      ref,
      className: cn("[&_tr:last-child]:border-0", className),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/arruday/GitHub/pizzashop/src/components/ui/table.tsx",
      lineNumber: 31,
      columnNumber: 1
    },
    this
  )
);
_c6 = TableBody;
TableBody.displayName = "TableBody";
const TableFooter = React.forwardRef(
  _c7 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    "tfoot",
    {
      ref,
      className: cn(
        "border-t bg-muted/50 font-medium [&>tr]:last:border-b-0",
        className
      ),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/arruday/GitHub/pizzashop/src/components/ui/table.tsx",
      lineNumber: 43,
      columnNumber: 1
    },
    this
  )
);
_c8 = TableFooter;
TableFooter.displayName = "TableFooter";
const TableRow = React.forwardRef(
  _c9 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    "tr",
    {
      ref,
      className: cn(
        "border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted",
        className
      ),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/arruday/GitHub/pizzashop/src/components/ui/table.tsx",
      lineNumber: 58,
      columnNumber: 1
    },
    this
  )
);
_c10 = TableRow;
TableRow.displayName = "TableRow";
const TableHead = React.forwardRef(
  _c11 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    "th",
    {
      ref,
      className: cn(
        "h-12 px-4 text-left align-middle font-medium text-muted-foreground [&:has([role=checkbox])]:pr-0",
        className
      ),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/arruday/GitHub/pizzashop/src/components/ui/table.tsx",
      lineNumber: 73,
      columnNumber: 1
    },
    this
  )
);
_c12 = TableHead;
TableHead.displayName = "TableHead";
const TableCell = React.forwardRef(
  _c13 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    "td",
    {
      ref,
      className: cn("p-4 align-middle [&:has([role=checkbox])]:pr-0", className),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/arruday/GitHub/pizzashop/src/components/ui/table.tsx",
      lineNumber: 88,
      columnNumber: 1
    },
    this
  )
);
_c14 = TableCell;
TableCell.displayName = "TableCell";
const TableCaption = React.forwardRef(
  _c15 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    "caption",
    {
      ref,
      className: cn("mt-4 text-sm text-muted-foreground", className),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/arruday/GitHub/pizzashop/src/components/ui/table.tsx",
      lineNumber: 100,
      columnNumber: 1
    },
    this
  )
);
_c16 = TableCaption;
TableCaption.displayName = "TableCaption";
export {
  Table,
  TableHeader,
  TableBody,
  TableFooter,
  TableHead,
  TableRow,
  TableCell,
  TableCaption
};
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11, _c12, _c13, _c14, _c15, _c16;
$RefreshReg$(_c, "Table$React.forwardRef");
$RefreshReg$(_c2, "Table");
$RefreshReg$(_c3, "TableHeader$React.forwardRef");
$RefreshReg$(_c4, "TableHeader");
$RefreshReg$(_c5, "TableBody$React.forwardRef");
$RefreshReg$(_c6, "TableBody");
$RefreshReg$(_c7, "TableFooter$React.forwardRef");
$RefreshReg$(_c8, "TableFooter");
$RefreshReg$(_c9, "TableRow$React.forwardRef");
$RefreshReg$(_c10, "TableRow");
$RefreshReg$(_c11, "TableHead$React.forwardRef");
$RefreshReg$(_c12, "TableHead");
$RefreshReg$(_c13, "TableCell$React.forwardRef");
$RefreshReg$(_c14, "TableCell");
$RefreshReg$(_c15, "TableCaption$React.forwardRef");
$RefreshReg$(_c16, "TableCaption");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arruday/GitHub/pizzashop/src/components/ui/table.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU0k7QUFUSixPQUFPLG9CQUFnQjtBQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUU5QixTQUFTQSxVQUFVO0FBRW5CLE1BQU1DLFFBQVFDLE1BQU1DO0FBQUFBLEVBR25CQyxLQUFDQSxDQUFDLEVBQUVDLFdBQVcsR0FBR0MsTUFBTSxHQUFHQyxRQUMxQix1QkFBQyxTQUFJLFdBQVUsaUNBQ2I7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDO0FBQUEsTUFDQSxXQUFXUCxHQUFHLGlDQUFpQ0ssU0FBUztBQUFBLE1BQ3hELEdBQUlDO0FBQUFBO0FBQUFBLElBSE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBR1ksS0FKZDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBTUE7QUFDRDtBQUFDRSxNQVhJUDtBQVlOQSxNQUFNUSxjQUFjO0FBRXBCLE1BQU1DLGNBQWNSLE1BQU1DO0FBQUFBLEVBR3pCUSxNQUFDQSxDQUFDLEVBQUVOLFdBQVcsR0FBR0MsTUFBTSxHQUFHQyxRQUMxQix1QkFBQyxXQUFNLEtBQVUsV0FBV1AsR0FBRyxtQkFBbUJLLFNBQVMsR0FBRyxHQUFJQyxTQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXdFO0FBQ3pFO0FBQUNNLE1BTElGO0FBTU5BLFlBQVlELGNBQWM7QUFFMUIsTUFBTUksWUFBWVgsTUFBTUM7QUFBQUEsRUFHdkJXLE1BQUNBLENBQUMsRUFBRVQsV0FBVyxHQUFHQyxNQUFNLEdBQUdDLFFBQzFCO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQztBQUFBLE1BQ0EsV0FBV1AsR0FBRyw4QkFBOEJLLFNBQVM7QUFBQSxNQUNyRCxHQUFJQztBQUFBQTtBQUFBQSxJQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUdZO0FBRWI7QUFBQ1MsTUFUSUY7QUFVTkEsVUFBVUosY0FBYztBQUV4QixNQUFNTyxjQUFjZCxNQUFNQztBQUFBQSxFQUd6QmMsTUFBQ0EsQ0FBQyxFQUFFWixXQUFXLEdBQUdDLE1BQU0sR0FBR0MsUUFDMUI7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDO0FBQUEsTUFDQSxXQUFXUDtBQUFBQSxRQUNUO0FBQUEsUUFDQUs7QUFBQUEsTUFDRjtBQUFBLE1BQ0EsR0FBSUM7QUFBQUE7QUFBQUEsSUFOTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNWTtBQUViO0FBQUNZLE1BWklGO0FBYU5BLFlBQVlQLGNBQWM7QUFFMUIsTUFBTVUsV0FBV2pCLE1BQU1DO0FBQUFBLEVBR3RCaUIsTUFBQ0EsQ0FBQyxFQUFFZixXQUFXLEdBQUdDLE1BQU0sR0FBR0MsUUFDMUI7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDO0FBQUEsTUFDQSxXQUFXUDtBQUFBQSxRQUNUO0FBQUEsUUFDQUs7QUFBQUEsTUFDRjtBQUFBLE1BQ0EsR0FBSUM7QUFBQUE7QUFBQUEsSUFOTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNWTtBQUViO0FBQUNlLE9BWklGO0FBYU5BLFNBQVNWLGNBQWM7QUFFdkIsTUFBTWEsWUFBWXBCLE1BQU1DO0FBQUFBLEVBR3ZCb0IsT0FBQ0EsQ0FBQyxFQUFFbEIsV0FBVyxHQUFHQyxNQUFNLEdBQUdDLFFBQzFCO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQztBQUFBLE1BQ0EsV0FBV1A7QUFBQUEsUUFDVDtBQUFBLFFBQ0FLO0FBQUFBLE1BQ0Y7QUFBQSxNQUNBLEdBQUlDO0FBQUFBO0FBQUFBLElBTk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTVk7QUFFYjtBQUFDa0IsT0FaSUY7QUFhTkEsVUFBVWIsY0FBYztBQUV4QixNQUFNZ0IsWUFBWXZCLE1BQU1DO0FBQUFBLEVBR3ZCdUIsT0FBQ0EsQ0FBQyxFQUFFckIsV0FBVyxHQUFHQyxNQUFNLEdBQUdDLFFBQzFCO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQztBQUFBLE1BQ0EsV0FBV1AsR0FBRyxrREFBa0RLLFNBQVM7QUFBQSxNQUN6RSxHQUFJQztBQUFBQTtBQUFBQSxJQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUdZO0FBRWI7QUFBQ3FCLE9BVElGO0FBVU5BLFVBQVVoQixjQUFjO0FBRXhCLE1BQU1tQixlQUFlMUIsTUFBTUM7QUFBQUEsRUFHMUIwQixPQUFDQSxDQUFDLEVBQUV4QixXQUFXLEdBQUdDLE1BQU0sR0FBR0MsUUFDMUI7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDO0FBQUEsTUFDQSxXQUFXUCxHQUFHLHNDQUFzQ0ssU0FBUztBQUFBLE1BQzdELEdBQUlDO0FBQUFBO0FBQUFBLElBSE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBR1k7QUFFYjtBQUFDd0IsT0FUSUY7QUFVTkEsYUFBYW5CLGNBQWM7QUFFM0I7QUFBQSxFQUNFUjtBQUFBQSxFQUNBUztBQUFBQSxFQUNBRztBQUFBQSxFQUNBRztBQUFBQSxFQUNBTTtBQUFBQSxFQUNBSDtBQUFBQSxFQUNBTTtBQUFBQSxFQUNBRztBQUFBQTtBQUNELElBQUF4QixJQUFBSSxLQUFBRyxLQUFBQyxLQUFBRSxLQUFBQyxLQUFBRSxLQUFBQyxLQUFBRSxLQUFBQyxNQUFBRSxNQUFBQyxNQUFBRSxNQUFBQyxNQUFBRSxNQUFBQztBQUFBQyxhQUFBM0IsSUFBQTtBQUFBMkIsYUFBQXZCLEtBQUE7QUFBQXVCLGFBQUFwQixLQUFBO0FBQUFvQixhQUFBbkIsS0FBQTtBQUFBbUIsYUFBQWpCLEtBQUE7QUFBQWlCLGFBQUFoQixLQUFBO0FBQUFnQixhQUFBZCxLQUFBO0FBQUFjLGFBQUFiLEtBQUE7QUFBQWEsYUFBQVgsS0FBQTtBQUFBVyxhQUFBVixNQUFBO0FBQUFVLGFBQUFSLE1BQUE7QUFBQVEsYUFBQVAsTUFBQTtBQUFBTyxhQUFBTCxNQUFBO0FBQUFLLGFBQUFKLE1BQUE7QUFBQUksYUFBQUYsTUFBQTtBQUFBRSxhQUFBRCxNQUFBIiwibmFtZXMiOlsiY24iLCJUYWJsZSIsIlJlYWN0IiwiZm9yd2FyZFJlZiIsIl9jIiwiY2xhc3NOYW1lIiwicHJvcHMiLCJyZWYiLCJfYzIiLCJkaXNwbGF5TmFtZSIsIlRhYmxlSGVhZGVyIiwiX2MzIiwiX2M0IiwiVGFibGVCb2R5IiwiX2M1IiwiX2M2IiwiVGFibGVGb290ZXIiLCJfYzciLCJfYzgiLCJUYWJsZVJvdyIsIl9jOSIsIl9jMTAiLCJUYWJsZUhlYWQiLCJfYzExIiwiX2MxMiIsIlRhYmxlQ2VsbCIsIl9jMTMiLCJfYzE0IiwiVGFibGVDYXB0aW9uIiwiX2MxNSIsIl9jMTYiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJ0YWJsZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCJcblxuaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvdXRpbHNcIlxuXG5jb25zdCBUYWJsZSA9IFJlYWN0LmZvcndhcmRSZWY8XG4gIEhUTUxUYWJsZUVsZW1lbnQsXG4gIFJlYWN0LkhUTUxBdHRyaWJ1dGVzPEhUTUxUYWJsZUVsZW1lbnQ+XG4+KCh7IGNsYXNzTmFtZSwgLi4ucHJvcHMgfSwgcmVmKSA9PiAoXG4gIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1mdWxsIG92ZXJmbG93LWF1dG9cIj5cbiAgICA8dGFibGVcbiAgICAgIHJlZj17cmVmfVxuICAgICAgY2xhc3NOYW1lPXtjbihcInctZnVsbCBjYXB0aW9uLWJvdHRvbSB0ZXh0LXNtXCIsIGNsYXNzTmFtZSl9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgLz5cbiAgPC9kaXY+XG4pKVxuVGFibGUuZGlzcGxheU5hbWUgPSBcIlRhYmxlXCJcblxuY29uc3QgVGFibGVIZWFkZXIgPSBSZWFjdC5mb3J3YXJkUmVmPFxuICBIVE1MVGFibGVTZWN0aW9uRWxlbWVudCxcbiAgUmVhY3QuSFRNTEF0dHJpYnV0ZXM8SFRNTFRhYmxlU2VjdGlvbkVsZW1lbnQ+XG4+KCh7IGNsYXNzTmFtZSwgLi4ucHJvcHMgfSwgcmVmKSA9PiAoXG4gIDx0aGVhZCByZWY9e3JlZn0gY2xhc3NOYW1lPXtjbihcIlsmX3RyXTpib3JkZXItYlwiLCBjbGFzc05hbWUpfSB7Li4ucHJvcHN9IC8+XG4pKVxuVGFibGVIZWFkZXIuZGlzcGxheU5hbWUgPSBcIlRhYmxlSGVhZGVyXCJcblxuY29uc3QgVGFibGVCb2R5ID0gUmVhY3QuZm9yd2FyZFJlZjxcbiAgSFRNTFRhYmxlU2VjdGlvbkVsZW1lbnQsXG4gIFJlYWN0LkhUTUxBdHRyaWJ1dGVzPEhUTUxUYWJsZVNlY3Rpb25FbGVtZW50PlxuPigoeyBjbGFzc05hbWUsIC4uLnByb3BzIH0sIHJlZikgPT4gKFxuICA8dGJvZHlcbiAgICByZWY9e3JlZn1cbiAgICBjbGFzc05hbWU9e2NuKFwiWyZfdHI6bGFzdC1jaGlsZF06Ym9yZGVyLTBcIiwgY2xhc3NOYW1lKX1cbiAgICB7Li4ucHJvcHN9XG4gIC8+XG4pKVxuVGFibGVCb2R5LmRpc3BsYXlOYW1lID0gXCJUYWJsZUJvZHlcIlxuXG5jb25zdCBUYWJsZUZvb3RlciA9IFJlYWN0LmZvcndhcmRSZWY8XG4gIEhUTUxUYWJsZVNlY3Rpb25FbGVtZW50LFxuICBSZWFjdC5IVE1MQXR0cmlidXRlczxIVE1MVGFibGVTZWN0aW9uRWxlbWVudD5cbj4oKHsgY2xhc3NOYW1lLCAuLi5wcm9wcyB9LCByZWYpID0+IChcbiAgPHRmb290XG4gICAgcmVmPXtyZWZ9XG4gICAgY2xhc3NOYW1lPXtjbihcbiAgICAgIFwiYm9yZGVyLXQgYmctbXV0ZWQvNTAgZm9udC1tZWRpdW0gWyY+dHJdOmxhc3Q6Ym9yZGVyLWItMFwiLFxuICAgICAgY2xhc3NOYW1lXG4gICAgKX1cbiAgICB7Li4ucHJvcHN9XG4gIC8+XG4pKVxuVGFibGVGb290ZXIuZGlzcGxheU5hbWUgPSBcIlRhYmxlRm9vdGVyXCJcblxuY29uc3QgVGFibGVSb3cgPSBSZWFjdC5mb3J3YXJkUmVmPFxuICBIVE1MVGFibGVSb3dFbGVtZW50LFxuICBSZWFjdC5IVE1MQXR0cmlidXRlczxIVE1MVGFibGVSb3dFbGVtZW50PlxuPigoeyBjbGFzc05hbWUsIC4uLnByb3BzIH0sIHJlZikgPT4gKFxuICA8dHJcbiAgICByZWY9e3JlZn1cbiAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgXCJib3JkZXItYiB0cmFuc2l0aW9uLWNvbG9ycyBob3ZlcjpiZy1tdXRlZC81MCBkYXRhLVtzdGF0ZT1zZWxlY3RlZF06YmctbXV0ZWRcIixcbiAgICAgIGNsYXNzTmFtZVxuICAgICl9XG4gICAgey4uLnByb3BzfVxuICAvPlxuKSlcblRhYmxlUm93LmRpc3BsYXlOYW1lID0gXCJUYWJsZVJvd1wiXG5cbmNvbnN0IFRhYmxlSGVhZCA9IFJlYWN0LmZvcndhcmRSZWY8XG4gIEhUTUxUYWJsZUNlbGxFbGVtZW50LFxuICBSZWFjdC5UaEhUTUxBdHRyaWJ1dGVzPEhUTUxUYWJsZUNlbGxFbGVtZW50PlxuPigoeyBjbGFzc05hbWUsIC4uLnByb3BzIH0sIHJlZikgPT4gKFxuICA8dGhcbiAgICByZWY9e3JlZn1cbiAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgXCJoLTEyIHB4LTQgdGV4dC1sZWZ0IGFsaWduLW1pZGRsZSBmb250LW1lZGl1bSB0ZXh0LW11dGVkLWZvcmVncm91bmQgWyY6aGFzKFtyb2xlPWNoZWNrYm94XSldOnByLTBcIixcbiAgICAgIGNsYXNzTmFtZVxuICAgICl9XG4gICAgey4uLnByb3BzfVxuICAvPlxuKSlcblRhYmxlSGVhZC5kaXNwbGF5TmFtZSA9IFwiVGFibGVIZWFkXCJcblxuY29uc3QgVGFibGVDZWxsID0gUmVhY3QuZm9yd2FyZFJlZjxcbiAgSFRNTFRhYmxlQ2VsbEVsZW1lbnQsXG4gIFJlYWN0LlRkSFRNTEF0dHJpYnV0ZXM8SFRNTFRhYmxlQ2VsbEVsZW1lbnQ+XG4+KCh7IGNsYXNzTmFtZSwgLi4ucHJvcHMgfSwgcmVmKSA9PiAoXG4gIDx0ZFxuICAgIHJlZj17cmVmfVxuICAgIGNsYXNzTmFtZT17Y24oXCJwLTQgYWxpZ24tbWlkZGxlIFsmOmhhcyhbcm9sZT1jaGVja2JveF0pXTpwci0wXCIsIGNsYXNzTmFtZSl9XG4gICAgey4uLnByb3BzfVxuICAvPlxuKSlcblRhYmxlQ2VsbC5kaXNwbGF5TmFtZSA9IFwiVGFibGVDZWxsXCJcblxuY29uc3QgVGFibGVDYXB0aW9uID0gUmVhY3QuZm9yd2FyZFJlZjxcbiAgSFRNTFRhYmxlQ2FwdGlvbkVsZW1lbnQsXG4gIFJlYWN0LkhUTUxBdHRyaWJ1dGVzPEhUTUxUYWJsZUNhcHRpb25FbGVtZW50PlxuPigoeyBjbGFzc05hbWUsIC4uLnByb3BzIH0sIHJlZikgPT4gKFxuICA8Y2FwdGlvblxuICAgIHJlZj17cmVmfVxuICAgIGNsYXNzTmFtZT17Y24oXCJtdC00IHRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCIsIGNsYXNzTmFtZSl9XG4gICAgey4uLnByb3BzfVxuICAvPlxuKSlcblRhYmxlQ2FwdGlvbi5kaXNwbGF5TmFtZSA9IFwiVGFibGVDYXB0aW9uXCJcblxuZXhwb3J0IHtcbiAgVGFibGUsXG4gIFRhYmxlSGVhZGVyLFxuICBUYWJsZUJvZHksXG4gIFRhYmxlRm9vdGVyLFxuICBUYWJsZUhlYWQsXG4gIFRhYmxlUm93LFxuICBUYWJsZUNlbGwsXG4gIFRhYmxlQ2FwdGlvbixcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2FycnVkYXkvR2l0SHViL3Bpenphc2hvcC9zcmMvY29tcG9uZW50cy91aS90YWJsZS50c3gifQ==