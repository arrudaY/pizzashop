import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/nav-link.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=efc33bbd"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/arruday/GitHub/pizzashop/src/components/nav-link.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Link, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=efc33bbd";
export function NavLink(props) {
  _s();
  const { pathname } = useLocation();
  return /* @__PURE__ */ jsxDEV(
    Link,
    {
      "data-current": pathname === props.to,
      className: "flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-foreground data-[current=true]:text-foreground",
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/arruday/GitHub/pizzashop/src/components/nav-link.tsx",
      lineNumber: 9,
      columnNumber: 5
    },
    this
  );
}
_s(NavLink, "qVMqkCpYCjknUqSjfMln5RFSkbo=", false, function() {
  return [useLocation];
});
_c = NavLink;
var _c;
$RefreshReg$(_c, "NavLink");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arruday/GitHub/pizzashop/src/components/nav-link.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBUUk7MkJBUko7QUFBZUEsTUFBV0MsY0FBVyxPQUFRLHNCQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUl4RCxnQkFBU0MsUUFBUUMsT0FBcUI7QUFBQUMsS0FBQTtBQUMzQyxRQUFNLEVBQUVDLFNBQVMsSUFBSUosWUFBWTtBQUVqQyxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxnQkFBY0ksYUFBYUYsTUFBTUc7QUFBQUEsTUFDakMsV0FBVTtBQUFBLE1BQ1YsR0FBSUg7QUFBQUE7QUFBQUEsSUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFHWTtBQUdoQjtBQUFDQyxHQVZlRixTQUFPO0FBQUEsVUFDQUQsV0FBVztBQUFBO0FBQUFNLEtBRGxCTDtBQUFPLElBQUFLO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJMaW5rUHJvcHMiLCJ1c2VMb2NhdGlvbiIsIk5hdkxpbmsiLCJwcm9wcyIsIl9zIiwicGF0aG5hbWUiLCJ0byIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsibmF2LWxpbmsudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmssIExpbmtQcm9wcywgdXNlTG9jYXRpb24gfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuXG5leHBvcnQgdHlwZSBOYXZMaW5rUHJvcHMgPSBMaW5rUHJvcHNcblxuZXhwb3J0IGZ1bmN0aW9uIE5hdkxpbmsocHJvcHM6IE5hdkxpbmtQcm9wcykge1xuICBjb25zdCB7IHBhdGhuYW1lIH0gPSB1c2VMb2NhdGlvbigpXG5cbiAgcmV0dXJuIChcbiAgICA8TGlua1xuICAgICAgZGF0YS1jdXJyZW50PXtwYXRobmFtZSA9PT0gcHJvcHMudG99XG4gICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIGhvdmVyOnRleHQtZm9yZWdyb3VuZCBkYXRhLVtjdXJyZW50PXRydWVdOnRleHQtZm9yZWdyb3VuZFwiXG4gICAgICB7Li4ucHJvcHN9XG4gICAgLz5cbiAgKVxufVxuIl0sImZpbGUiOiIvVXNlcnMvYXJydWRheS9HaXRIdWIvcGl6emFzaG9wL3NyYy9jb21wb25lbnRzL25hdi1saW5rLnRzeCJ9