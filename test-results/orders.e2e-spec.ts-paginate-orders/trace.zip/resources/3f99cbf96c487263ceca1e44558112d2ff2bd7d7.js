import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/header.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=efc33bbd"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/arruday/GitHub/pizzashop/src/components/header.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Home, Pizza, UtensilsCrossed } from "/node_modules/.vite/deps/lucide-react.js?v=efc33bbd";
import { AccountMenu } from "/src/components/account-menu.tsx";
import { NavLink } from "/src/components/nav-link.tsx";
import { ThemeToggle } from "/src/components/theme/theme-toggle.tsx";
import { Separator } from "/src/components/ui/separator.tsx";
export function Header() {
  return /* @__PURE__ */ jsxDEV("header", { className: "border-b", children: /* @__PURE__ */ jsxDEV("div", { className: "flex h-16 items-center gap-6 px-6", children: [
    /* @__PURE__ */ jsxDEV(Pizza, { className: "h-6 w-6" }, void 0, false, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/components/header.tsx",
      lineNumber: 12,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Separator, { orientation: "vertical", className: "h-6" }, void 0, false, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/components/header.tsx",
      lineNumber: 13,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("nav", { className: "flex items-center space-x-4 lg:space-x-6", children: [
      /* @__PURE__ */ jsxDEV(NavLink, { to: "/", children: [
        /* @__PURE__ */ jsxDEV(Home, { className: "h-4 w-4" }, void 0, false, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/components/header.tsx",
          lineNumber: 16,
          columnNumber: 13
        }, this),
        "Início"
      ] }, void 0, true, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/components/header.tsx",
        lineNumber: 15,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(NavLink, { to: "/orders", children: [
        /* @__PURE__ */ jsxDEV(UtensilsCrossed, { className: "h-4 w-4" }, void 0, false, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/components/header.tsx",
          lineNumber: 20,
          columnNumber: 13
        }, this),
        "Pedidos"
      ] }, void 0, true, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/components/header.tsx",
        lineNumber: 19,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/components/header.tsx",
      lineNumber: 14,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "ml-auto flex items-center gap-2 ", children: [
      /* @__PURE__ */ jsxDEV(ThemeToggle, {}, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/components/header.tsx",
        lineNumber: 25,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(AccountMenu, {}, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/components/header.tsx",
        lineNumber: 26,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/components/header.tsx",
      lineNumber: 24,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/arruday/GitHub/pizzashop/src/components/header.tsx",
    lineNumber: 11,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/arruday/GitHub/pizzashop/src/components/header.tsx",
    lineNumber: 10,
    columnNumber: 5
  }, this);
}
_c = Header;
var _c;
$RefreshReg$(_c, "Header");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arruday/GitHub/pizzashop/src/components/header.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV1E7QUFYUiwyQkFBc0JBO0FBQXVCLG9CQUFjO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUUzRCxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsaUJBQWlCO0FBRW5CLGdCQUFTQyxTQUFTO0FBQ3ZCLFNBQ0UsdUJBQUMsWUFBTyxXQUFVLFlBQ2hCLGlDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLDJCQUFDLFNBQU0sV0FBVSxhQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBCO0FBQUEsSUFDMUIsdUJBQUMsYUFBVSxhQUFZLFlBQVcsV0FBVSxTQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlEO0FBQUEsSUFDakQsdUJBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUEsNkJBQUMsV0FBUSxJQUFHLEtBQ1Y7QUFBQSwrQkFBQyxRQUFLLFdBQVUsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QjtBQUFBO0FBQUEsV0FEM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxXQUFRLElBQUcsV0FDVjtBQUFBLCtCQUFDLG1CQUFnQixXQUFVLGFBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0M7QUFBQTtBQUFBLFdBRHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVUsb0NBQ2I7QUFBQSw2QkFBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVk7QUFBQSxNQUNaLHVCQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBWTtBQUFBLFNBRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsT0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlCQSxLQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbUJBO0FBRUo7QUFBQ0MsS0F2QmVEO0FBQU0sSUFBQUM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlV0ZW5zaWxzQ3Jvc3NlZCIsIkFjY291bnRNZW51IiwiTmF2TGluayIsIlRoZW1lVG9nZ2xlIiwiU2VwYXJhdG9yIiwiSGVhZGVyIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJoZWFkZXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEhvbWUsIFBpenphLCBVdGVuc2lsc0Nyb3NzZWQgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5cbmltcG9ydCB7IEFjY291bnRNZW51IH0gZnJvbSAnLi9hY2NvdW50LW1lbnUnXG5pbXBvcnQgeyBOYXZMaW5rIH0gZnJvbSAnLi9uYXYtbGluaydcbmltcG9ydCB7IFRoZW1lVG9nZ2xlIH0gZnJvbSAnLi90aGVtZS90aGVtZS10b2dnbGUnXG5pbXBvcnQgeyBTZXBhcmF0b3IgfSBmcm9tICcuL3VpL3NlcGFyYXRvcidcblxuZXhwb3J0IGZ1bmN0aW9uIEhlYWRlcigpIHtcbiAgcmV0dXJuIChcbiAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImJvcmRlci1iXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC0xNiBpdGVtcy1jZW50ZXIgZ2FwLTYgcHgtNlwiPlxuICAgICAgICA8UGl6emEgY2xhc3NOYW1lPVwiaC02IHctNlwiIC8+XG4gICAgICAgIDxTZXBhcmF0b3Igb3JpZW50YXRpb249XCJ2ZXJ0aWNhbFwiIGNsYXNzTmFtZT1cImgtNlwiIC8+XG4gICAgICAgIDxuYXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC00IGxnOnNwYWNlLXgtNlwiPlxuICAgICAgICAgIDxOYXZMaW5rIHRvPVwiL1wiPlxuICAgICAgICAgICAgPEhvbWUgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICBJbsOtY2lvXG4gICAgICAgICAgPC9OYXZMaW5rPlxuICAgICAgICAgIDxOYXZMaW5rIHRvPVwiL29yZGVyc1wiPlxuICAgICAgICAgICAgPFV0ZW5zaWxzQ3Jvc3NlZCBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICAgIFBlZGlkb3NcbiAgICAgICAgICA8L05hdkxpbms+XG4gICAgICAgIDwvbmF2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1sLWF1dG8gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgXCI+XG4gICAgICAgICAgPFRoZW1lVG9nZ2xlIC8+XG4gICAgICAgICAgPEFjY291bnRNZW51IC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9oZWFkZXI+XG4gIClcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2FycnVkYXkvR2l0SHViL3Bpenphc2hvcC9zcmMvY29tcG9uZW50cy9oZWFkZXIudHN4In0=