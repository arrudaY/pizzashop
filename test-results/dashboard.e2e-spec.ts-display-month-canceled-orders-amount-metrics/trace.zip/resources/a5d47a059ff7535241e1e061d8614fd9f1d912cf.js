import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/app/dashboard/popular-products-chart.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=efc33bbd"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/popular-products-chart.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=efc33bbd";
import { BarChart, Loader2 } from "/node_modules/.vite/deps/lucide-react.js?v=efc33bbd";
import { Cell, Pie, PieChart, ResponsiveContainer } from "/node_modules/.vite/deps/recharts.js?v=efc33bbd";
import __vite__cjsImport6_tailwindcss_colors from "/node_modules/.vite/deps/tailwindcss_colors.js?v=efc33bbd"; const colors = __vite__cjsImport6_tailwindcss_colors.__esModule ? __vite__cjsImport6_tailwindcss_colors.default : __vite__cjsImport6_tailwindcss_colors;
import { getPopularProducts } from "/src/api/get-popular-products.ts";
import { Card, CardContent, CardHeader, CardTitle } from "/src/components/ui/card.tsx";
const COLORS = [
  colors.sky[500],
  colors.amber[500],
  colors.violet[500],
  colors.emerald[500],
  colors.rose[500]
];
export function PopularProductChart() {
  _s();
  const { data: popularProducts } = useQuery({
    queryKey: ["metrics", "popular-products"],
    queryFn: getPopularProducts
  });
  return /* @__PURE__ */ jsxDEV(Card, { className: "col-span-3", children: [
    /* @__PURE__ */ jsxDEV(CardHeader, { className: "pb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxDEV(CardTitle, { className: "text-base font-medium", children: "Produtos populares" }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/popular-products-chart.tsx",
        lineNumber: 26,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(BarChart, { className: "h-4 w-4 text-muted-foreground" }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/popular-products-chart.tsx",
        lineNumber: 29,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/popular-products-chart.tsx",
      lineNumber: 25,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/popular-products-chart.tsx",
      lineNumber: 24,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(CardContent, { children: popularProducts ? /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: 240, children: /* @__PURE__ */ jsxDEV(PieChart, { style: { fontSize: 12 }, children: /* @__PURE__ */ jsxDEV(
      Pie,
      {
        data: popularProducts,
        dataKey: "amount",
        nameKey: "product",
        cx: "50%",
        cy: "50%",
        outerRadius: 86,
        innerRadius: 64,
        strokeWidth: 8,
        labelLine: false,
        label: ({
          cx,
          cy,
          midAngle,
          innerRadius,
          outerRadius,
          value,
          index
        }) => {
          const RADIAN = Math.PI / 180;
          const radius = 12 + innerRadius + (outerRadius - innerRadius);
          const x = cx + radius * Math.cos(-midAngle * RADIAN);
          const y = cy + radius * Math.sin(-midAngle * RADIAN);
          return /* @__PURE__ */ jsxDEV(
            "text",
            {
              x,
              y,
              className: "fill-muted-foreground text-xs",
              textAnchor: x > cx ? "start" : "end",
              dominantBaseline: "central",
              children: [
                popularProducts[index].product.length > 12 ? popularProducts[index].product.substring(0, 12).concat("...") : popularProducts[index].product,
                " ",
                "(",
                value,
                ")"
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/popular-products-chart.tsx",
              lineNumber: 61,
              columnNumber: 19
            },
            this
          );
        },
        children: popularProducts.map((_, index) => {
          return /* @__PURE__ */ jsxDEV(
            Cell,
            {
              fill: COLORS[index],
              className: "stroke-background hover:opacity-80"
            },
            `cell-${index}`,
            false,
            {
              fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/popular-products-chart.tsx",
              lineNumber: 80,
              columnNumber: 19
            },
            this
          );
        })
      },
      void 0,
      false,
      {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/popular-products-chart.tsx",
        lineNumber: 36,
        columnNumber: 15
      },
      this
    ) }, void 0, false, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/popular-products-chart.tsx",
      lineNumber: 35,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/popular-products-chart.tsx",
      lineNumber: 34,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex h-[240px] w-full items-center justify-center", children: /* @__PURE__ */ jsxDEV(Loader2, { className: "h-8 w-8 animate-spin text-muted-foreground" }, void 0, false, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/popular-products-chart.tsx",
      lineNumber: 92,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/popular-products-chart.tsx",
      lineNumber: 91,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/popular-products-chart.tsx",
      lineNumber: 32,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/popular-products-chart.tsx",
    lineNumber: 23,
    columnNumber: 5
  }, this);
}
_s(PopularProductChart, "1VWf+RDj40U5IZM+Hb2KH8yVG/Y=", false, function() {
  return [useQuery];
});
_c = PopularProductChart;
var _c;
$RefreshReg$(_c, "PopularProductChart");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/popular-products-chart.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUJVOzJCQXpCVjtBQUFpQixNQUFRLHFCQUF1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNoRCxTQUFTQSxVQUFVQyxlQUFlO0FBQ2xDLFNBQVNDLE1BQU1DLEtBQUtDLFVBQVVDLDJCQUEyQjtBQUN6RCxPQUFPQyxZQUFZO0FBRW5CLFNBQVNDLDBCQUEwQjtBQUNuQyxTQUFTQyxNQUFNQyxhQUFhQyxZQUFZQyxpQkFBaUI7QUFFekQsTUFBTUMsU0FBUztBQUFBLEVBQ2JOLE9BQU9PLElBQUksR0FBRztBQUFBLEVBQ2RQLE9BQU9RLE1BQU0sR0FBRztBQUFBLEVBQ2hCUixPQUFPUyxPQUFPLEdBQUc7QUFBQSxFQUNqQlQsT0FBT1UsUUFBUSxHQUFHO0FBQUEsRUFDbEJWLE9BQU9XLEtBQUssR0FBRztBQUFDO0FBR1gsZ0JBQVNDLHNCQUFzQjtBQUFBQyxLQUFBO0FBQ3BDLFFBQU0sRUFBRUMsTUFBTUMsZ0JBQWdCLElBQUlDLFNBQVM7QUFBQSxJQUN6Q0MsVUFBVSxDQUFDLFdBQVcsa0JBQWtCO0FBQUEsSUFDeENDLFNBQVNqQjtBQUFBQSxFQUNYLENBQUM7QUFDRCxTQUNFLHVCQUFDLFFBQUssV0FBVSxjQUNkO0FBQUEsMkJBQUMsY0FBVyxXQUFVLFFBQ3BCLGlDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLDZCQUFDLGFBQVUsV0FBVSx5QkFBdUIsa0NBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsWUFBUyxXQUFVLG1DQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1EO0FBQUEsU0FKckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsSUFDQSx1QkFBQyxlQUNFYyw0QkFDQyx1QkFBQyx1QkFBb0IsT0FBTSxRQUFPLFFBQVEsS0FDeEMsaUNBQUMsWUFBUyxPQUFPLEVBQUVJLFVBQVUsR0FBRyxHQUM5QjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTUo7QUFBQUEsUUFDTixTQUFRO0FBQUEsUUFDUixTQUFRO0FBQUEsUUFDUixJQUFHO0FBQUEsUUFDSCxJQUFHO0FBQUEsUUFDSCxhQUFhO0FBQUEsUUFDYixhQUFhO0FBQUEsUUFDYixhQUFhO0FBQUEsUUFDYixXQUFXO0FBQUEsUUFDWCxPQUFPLENBQUM7QUFBQSxVQUNOSztBQUFBQSxVQUNBQztBQUFBQSxVQUNBQztBQUFBQSxVQUNBQztBQUFBQSxVQUNBQztBQUFBQSxVQUNBQztBQUFBQSxVQUNBQztBQUFBQSxRQUNGLE1BQU07QUFDSixnQkFBTUMsU0FBU0MsS0FBS0MsS0FBSztBQUN6QixnQkFBTUMsU0FBUyxLQUFLUCxlQUFlQyxjQUFjRDtBQUNqRCxnQkFBTVEsSUFBSVgsS0FBS1UsU0FBU0YsS0FBS0ksSUFBSSxDQUFDVixXQUFXSyxNQUFNO0FBQ25ELGdCQUFNTSxJQUFJWixLQUFLUyxTQUFTRixLQUFLTSxJQUFJLENBQUNaLFdBQVdLLE1BQU07QUFFbkQsaUJBQ0U7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDO0FBQUEsY0FDQTtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBQ1YsWUFBWUksSUFBSVgsS0FBSyxVQUFVO0FBQUEsY0FDL0Isa0JBQWlCO0FBQUEsY0FFaEJMO0FBQUFBLGdDQUFnQlcsS0FBSyxFQUFFUyxRQUFRQyxTQUFTLEtBQ3JDckIsZ0JBQWdCVyxLQUFLLEVBQUVTLFFBQ3BCRSxVQUFVLEdBQUcsRUFBRSxFQUNmQyxPQUFPLEtBQUssSUFDZnZCLGdCQUFnQlcsS0FBSyxFQUFFUztBQUFBQSxnQkFBUztBQUFBLGdCQUFHO0FBQUEsZ0JBQ3JDVjtBQUFBQSxnQkFBTTtBQUFBO0FBQUE7QUFBQSxZQVpWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWFBO0FBQUEsUUFFSjtBQUFBLFFBRUNWLDBCQUFnQndCLElBQUksQ0FBQ0MsR0FBR2QsVUFBVTtBQUNqQyxpQkFDRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsTUFBTXBCLE9BQU9vQixLQUFLO0FBQUEsY0FDbEIsV0FBVTtBQUFBO0FBQUEsWUFGSixRQUFPQSxLQUFNO0FBQUEsWUFEckI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUdnRDtBQUFBLFFBR3BELENBQUM7QUFBQTtBQUFBLE1BbERIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQW1EQSxLQXBERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcURBLEtBdERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1REEsSUFFQSx1QkFBQyxTQUFJLFdBQVUscURBQ2IsaUNBQUMsV0FBUSxXQUFVLGdEQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStELEtBRGpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxLQTdESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBK0RBO0FBQUEsT0F4RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXlFQTtBQUVKO0FBQUNiLEdBakZlRCxxQkFBbUI7QUFBQSxVQUNDSSxRQUFRO0FBQUE7QUFBQXlCLEtBRDVCN0I7QUFBbUIsSUFBQTZCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJCYXJDaGFydCIsIkxvYWRlcjIiLCJDZWxsIiwiUGllIiwiUGllQ2hhcnQiLCJSZXNwb25zaXZlQ29udGFpbmVyIiwiY29sb3JzIiwiZ2V0UG9wdWxhclByb2R1Y3RzIiwiQ2FyZCIsIkNhcmRDb250ZW50IiwiQ2FyZEhlYWRlciIsIkNhcmRUaXRsZSIsIkNPTE9SUyIsInNreSIsImFtYmVyIiwidmlvbGV0IiwiZW1lcmFsZCIsInJvc2UiLCJQb3B1bGFyUHJvZHVjdENoYXJ0IiwiX3MiLCJkYXRhIiwicG9wdWxhclByb2R1Y3RzIiwidXNlUXVlcnkiLCJxdWVyeUtleSIsInF1ZXJ5Rm4iLCJmb250U2l6ZSIsImN4IiwiY3kiLCJtaWRBbmdsZSIsImlubmVyUmFkaXVzIiwib3V0ZXJSYWRpdXMiLCJ2YWx1ZSIsImluZGV4IiwiUkFESUFOIiwiTWF0aCIsIlBJIiwicmFkaXVzIiwieCIsImNvcyIsInkiLCJzaW4iLCJwcm9kdWN0IiwibGVuZ3RoIiwic3Vic3RyaW5nIiwiY29uY2F0IiwibWFwIiwiXyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsicG9wdWxhci1wcm9kdWN0cy1jaGFydC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUXVlcnkgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG5pbXBvcnQgeyBCYXJDaGFydCwgTG9hZGVyMiB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcbmltcG9ydCB7IENlbGwsIFBpZSwgUGllQ2hhcnQsIFJlc3BvbnNpdmVDb250YWluZXIgfSBmcm9tICdyZWNoYXJ0cydcbmltcG9ydCBjb2xvcnMgZnJvbSAndGFpbHdpbmRjc3MvY29sb3JzJ1xuXG5pbXBvcnQgeyBnZXRQb3B1bGFyUHJvZHVjdHMgfSBmcm9tICdAL2FwaS9nZXQtcG9wdWxhci1wcm9kdWN0cydcbmltcG9ydCB7IENhcmQsIENhcmRDb250ZW50LCBDYXJkSGVhZGVyLCBDYXJkVGl0bGUgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvY2FyZCdcblxuY29uc3QgQ09MT1JTID0gW1xuICBjb2xvcnMuc2t5WzUwMF0sXG4gIGNvbG9ycy5hbWJlcls1MDBdLFxuICBjb2xvcnMudmlvbGV0WzUwMF0sXG4gIGNvbG9ycy5lbWVyYWxkWzUwMF0sXG4gIGNvbG9ycy5yb3NlWzUwMF0sXG5dXG5cbmV4cG9ydCBmdW5jdGlvbiBQb3B1bGFyUHJvZHVjdENoYXJ0KCkge1xuICBjb25zdCB7IGRhdGE6IHBvcHVsYXJQcm9kdWN0cyB9ID0gdXNlUXVlcnkoe1xuICAgIHF1ZXJ5S2V5OiBbJ21ldHJpY3MnLCAncG9wdWxhci1wcm9kdWN0cyddLFxuICAgIHF1ZXJ5Rm46IGdldFBvcHVsYXJQcm9kdWN0cyxcbiAgfSlcbiAgcmV0dXJuIChcbiAgICA8Q2FyZCBjbGFzc05hbWU9XCJjb2wtc3Bhbi0zXCI+XG4gICAgICA8Q2FyZEhlYWRlciBjbGFzc05hbWU9XCJwYi04XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgPENhcmRUaXRsZSBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgIFByb2R1dG9zIHBvcHVsYXJlc1xuICAgICAgICAgIDwvQ2FyZFRpdGxlPlxuICAgICAgICAgIDxCYXJDaGFydCBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9DYXJkSGVhZGVyPlxuICAgICAgPENhcmRDb250ZW50PlxuICAgICAgICB7cG9wdWxhclByb2R1Y3RzID8gKFxuICAgICAgICAgIDxSZXNwb25zaXZlQ29udGFpbmVyIHdpZHRoPVwiMTAwJVwiIGhlaWdodD17MjQwfT5cbiAgICAgICAgICAgIDxQaWVDaGFydCBzdHlsZT17eyBmb250U2l6ZTogMTIgfX0+XG4gICAgICAgICAgICAgIDxQaWVcbiAgICAgICAgICAgICAgICBkYXRhPXtwb3B1bGFyUHJvZHVjdHN9XG4gICAgICAgICAgICAgICAgZGF0YUtleT1cImFtb3VudFwiXG4gICAgICAgICAgICAgICAgbmFtZUtleT1cInByb2R1Y3RcIlxuICAgICAgICAgICAgICAgIGN4PVwiNTAlXCJcbiAgICAgICAgICAgICAgICBjeT1cIjUwJVwiXG4gICAgICAgICAgICAgICAgb3V0ZXJSYWRpdXM9ezg2fVxuICAgICAgICAgICAgICAgIGlubmVyUmFkaXVzPXs2NH1cbiAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD17OH1cbiAgICAgICAgICAgICAgICBsYWJlbExpbmU9e2ZhbHNlfVxuICAgICAgICAgICAgICAgIGxhYmVsPXsoe1xuICAgICAgICAgICAgICAgICAgY3gsXG4gICAgICAgICAgICAgICAgICBjeSxcbiAgICAgICAgICAgICAgICAgIG1pZEFuZ2xlLFxuICAgICAgICAgICAgICAgICAgaW5uZXJSYWRpdXMsXG4gICAgICAgICAgICAgICAgICBvdXRlclJhZGl1cyxcbiAgICAgICAgICAgICAgICAgIHZhbHVlLFxuICAgICAgICAgICAgICAgICAgaW5kZXgsXG4gICAgICAgICAgICAgICAgfSkgPT4ge1xuICAgICAgICAgICAgICAgICAgY29uc3QgUkFESUFOID0gTWF0aC5QSSAvIDE4MFxuICAgICAgICAgICAgICAgICAgY29uc3QgcmFkaXVzID0gMTIgKyBpbm5lclJhZGl1cyArIChvdXRlclJhZGl1cyAtIGlubmVyUmFkaXVzKVxuICAgICAgICAgICAgICAgICAgY29uc3QgeCA9IGN4ICsgcmFkaXVzICogTWF0aC5jb3MoLW1pZEFuZ2xlICogUkFESUFOKVxuICAgICAgICAgICAgICAgICAgY29uc3QgeSA9IGN5ICsgcmFkaXVzICogTWF0aC5zaW4oLW1pZEFuZ2xlICogUkFESUFOKVxuXG4gICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICA8dGV4dFxuICAgICAgICAgICAgICAgICAgICAgIHg9e3h9XG4gICAgICAgICAgICAgICAgICAgICAgeT17eX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmaWxsLW11dGVkLWZvcmVncm91bmQgdGV4dC14c1wiXG4gICAgICAgICAgICAgICAgICAgICAgdGV4dEFuY2hvcj17eCA+IGN4ID8gJ3N0YXJ0JyA6ICdlbmQnfVxuICAgICAgICAgICAgICAgICAgICAgIGRvbWluYW50QmFzZWxpbmU9XCJjZW50cmFsXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIHtwb3B1bGFyUHJvZHVjdHNbaW5kZXhdLnByb2R1Y3QubGVuZ3RoID4gMTJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gcG9wdWxhclByb2R1Y3RzW2luZGV4XS5wcm9kdWN0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnN1YnN0cmluZygwLCAxMilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuY29uY2F0KCcuLi4nKVxuICAgICAgICAgICAgICAgICAgICAgICAgOiBwb3B1bGFyUHJvZHVjdHNbaW5kZXhdLnByb2R1Y3R9eycgJ31cbiAgICAgICAgICAgICAgICAgICAgICAoe3ZhbHVlfSlcbiAgICAgICAgICAgICAgICAgICAgPC90ZXh0PlxuICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7cG9wdWxhclByb2R1Y3RzLm1hcCgoXywgaW5kZXgpID0+IHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgIDxDZWxsXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtgY2VsbC0ke2luZGV4fWB9XG4gICAgICAgICAgICAgICAgICAgICAgZmlsbD17Q09MT1JTW2luZGV4XX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzdHJva2UtYmFja2dyb3VuZCBob3ZlcjpvcGFjaXR5LTgwXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgPC9QaWU+XG4gICAgICAgICAgICA8L1BpZUNoYXJ0PlxuICAgICAgICAgIDwvUmVzcG9uc2l2ZUNvbnRhaW5lcj5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC1bMjQwcHhdIHctZnVsbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgIDxMb2FkZXIyIGNsYXNzTmFtZT1cImgtOCB3LTggYW5pbWF0ZS1zcGluIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG4gICAgICA8L0NhcmRDb250ZW50PlxuICAgIDwvQ2FyZD5cbiAgKVxufVxuIl0sImZpbGUiOiIvVXNlcnMvYXJydWRheS9HaXRIdWIvcGl6emFzaG9wL3NyYy9wYWdlcy9hcHAvZGFzaGJvYXJkL3BvcHVsYXItcHJvZHVjdHMtY2hhcnQudHN4In0=