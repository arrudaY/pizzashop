import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=efc33bbd"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { createBrowserRouter } from "/node_modules/.vite/deps/react-router-dom.js?v=efc33bbd";
import { AppLayout } from "/src/pages/_layouts/app.tsx";
import { AuthLayout } from "/src/pages/_layouts/auth.tsx";
import { NotFound } from "/src/pages/404.tsx";
import { Dashboard } from "/src/pages/app/dashboard/dashboard.tsx";
import { Orders } from "/src/pages/app/orders/orders.tsx";
import { SignIn } from "/src/pages/auth/sign-in.tsx";
import { SignUp } from "/src/pages/auth/sign-up.tsx";
import { Error } from "/src/pages/error.tsx";
export const router = createBrowserRouter(
  [
    {
      path: "/",
      element: /* @__PURE__ */ jsxDEV(AppLayout, {}, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/routes.tsx",
        lineNumber: 15,
        columnNumber: 12
      }, this),
      errorElement: /* @__PURE__ */ jsxDEV(Error, {}, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/routes.tsx",
        lineNumber: 16,
        columnNumber: 17
      }, this),
      children: [
        { path: "/", element: /* @__PURE__ */ jsxDEV(Dashboard, {}, void 0, false, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/routes.tsx",
          lineNumber: 18,
          columnNumber: 25
        }, this) },
        { path: "/orders", element: /* @__PURE__ */ jsxDEV(Orders, {}, void 0, false, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/routes.tsx",
          lineNumber: 19,
          columnNumber: 31
        }, this) }
      ]
    },
    {
      path: "/",
      element: /* @__PURE__ */ jsxDEV(AuthLayout, {}, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/routes.tsx",
        lineNumber: 24,
        columnNumber: 12
      }, this),
      children: [
        { path: "/sign-in", element: /* @__PURE__ */ jsxDEV(SignIn, {}, void 0, false, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/routes.tsx",
          lineNumber: 26,
          columnNumber: 32
        }, this) },
        { path: "/sign-up", element: /* @__PURE__ */ jsxDEV(SignUp, {}, void 0, false, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/routes.tsx",
          lineNumber: 27,
          columnNumber: 32
        }, this) }
      ]
    },
    {
      path: "*",
      element: /* @__PURE__ */ jsxDEV(NotFound, {}, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/routes.tsx",
        lineNumber: 32,
        columnNumber: 12
      }, this)
    }
  ]
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBY2E7QUFkYixTQUFTQSwyQkFBMkI7QUFFcEMsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLGFBQWE7QUFFZixhQUFNQyxTQUFTVDtBQUFBQSxFQUFvQjtBQUFBLElBQ3hDO0FBQUEsTUFDRVUsTUFBTTtBQUFBLE1BQ05DLFNBQVMsdUJBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVU7QUFBQSxNQUNuQkMsY0FBYyx1QkFBQyxXQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBTTtBQUFBLE1BQ3BCQyxVQUFVO0FBQUEsUUFDUixFQUFFSCxNQUFNLEtBQUtDLFNBQVMsdUJBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVUsRUFBSTtBQUFBLFFBQ3BDLEVBQUVELE1BQU0sV0FBV0MsU0FBUyx1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBTyxFQUFJO0FBQUEsTUFBQztBQUFBLElBRTVDO0FBQUEsSUFDQTtBQUFBLE1BQ0VELE1BQU07QUFBQSxNQUNOQyxTQUFTLHVCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBVztBQUFBLE1BQ3BCRSxVQUFVO0FBQUEsUUFDUixFQUFFSCxNQUFNLFlBQVlDLFNBQVMsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQU8sRUFBSTtBQUFBLFFBQ3hDLEVBQUVELE1BQU0sWUFBWUMsU0FBUyx1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBTyxFQUFJO0FBQUEsTUFBQztBQUFBLElBRTdDO0FBQUEsSUFDQTtBQUFBLE1BQ0VELE1BQU07QUFBQSxNQUNOQyxTQUFTLHVCQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFTO0FBQUEsSUFDcEI7QUFBQSxFQUFDO0FBQ0YiLCJuYW1lcyI6WyJjcmVhdGVCcm93c2VyUm91dGVyIiwiQXBwTGF5b3V0IiwiQXV0aExheW91dCIsIk5vdEZvdW5kIiwiRGFzaGJvYXJkIiwiT3JkZXJzIiwiU2lnbkluIiwiU2lnblVwIiwiRXJyb3IiLCJyb3V0ZXIiLCJwYXRoIiwiZWxlbWVudCIsImVycm9yRWxlbWVudCIsImNoaWxkcmVuIl0sInNvdXJjZXMiOlsicm91dGVzLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjcmVhdGVCcm93c2VyUm91dGVyIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcblxuaW1wb3J0IHsgQXBwTGF5b3V0IH0gZnJvbSAnLi9fbGF5b3V0cy9hcHAnXG5pbXBvcnQgeyBBdXRoTGF5b3V0IH0gZnJvbSAnLi9fbGF5b3V0cy9hdXRoJ1xuaW1wb3J0IHsgTm90Rm91bmQgfSBmcm9tICcuLzQwNCdcbmltcG9ydCB7IERhc2hib2FyZCB9IGZyb20gJy4vYXBwL2Rhc2hib2FyZC9kYXNoYm9hcmQnXG5pbXBvcnQgeyBPcmRlcnMgfSBmcm9tICcuL2FwcC9vcmRlcnMvb3JkZXJzJ1xuaW1wb3J0IHsgU2lnbkluIH0gZnJvbSAnLi9hdXRoL3NpZ24taW4nXG5pbXBvcnQgeyBTaWduVXAgfSBmcm9tICcuL2F1dGgvc2lnbi11cCdcbmltcG9ydCB7IEVycm9yIH0gZnJvbSAnLi9lcnJvcidcblxuZXhwb3J0IGNvbnN0IHJvdXRlciA9IGNyZWF0ZUJyb3dzZXJSb3V0ZXIoW1xuICB7XG4gICAgcGF0aDogJy8nLFxuICAgIGVsZW1lbnQ6IDxBcHBMYXlvdXQgLz4sXG4gICAgZXJyb3JFbGVtZW50OiA8RXJyb3IgLz4sXG4gICAgY2hpbGRyZW46IFtcbiAgICAgIHsgcGF0aDogJy8nLCBlbGVtZW50OiA8RGFzaGJvYXJkIC8+IH0sXG4gICAgICB7IHBhdGg6ICcvb3JkZXJzJywgZWxlbWVudDogPE9yZGVycyAvPiB9LFxuICAgIF0sXG4gIH0sXG4gIHtcbiAgICBwYXRoOiAnLycsXG4gICAgZWxlbWVudDogPEF1dGhMYXlvdXQgLz4sXG4gICAgY2hpbGRyZW46IFtcbiAgICAgIHsgcGF0aDogJy9zaWduLWluJywgZWxlbWVudDogPFNpZ25JbiAvPiB9LFxuICAgICAgeyBwYXRoOiAnL3NpZ24tdXAnLCBlbGVtZW50OiA8U2lnblVwIC8+IH0sXG4gICAgXSxcbiAgfSxcbiAge1xuICAgIHBhdGg6ICcqJyxcbiAgICBlbGVtZW50OiA8Tm90Rm91bmQgLz4sXG4gIH0sXG5dKVxuIl0sImZpbGUiOiIvVXNlcnMvYXJydWRheS9HaXRIdWIvcGl6emFzaG9wL3NyYy9wYWdlcy9yb3V0ZXMudHN4In0=