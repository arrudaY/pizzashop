import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/account-menu.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=efc33bbd"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/arruday/GitHub/pizzashop/src/components/account-menu.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useMutation, useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=efc33bbd";
import { Building, ChevronDown, LogOut } from "/node_modules/.vite/deps/lucide-react.js?v=efc33bbd";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=efc33bbd";
import { getMenageRestaurant } from "/src/api/get-managed-restaurant.ts";
import { getProfile } from "/src/api/get-profile.ts";
import { signOut } from "/src/api/sign-out.ts";
import { StoreProfileDialog } from "/src/components/store-profile-dialog.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { Dialog, DialogTrigger } from "/src/components/ui/dialog.tsx";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from "/src/components/ui/dropdown-menu.tsx";
import { Skeleton } from "/src/components/ui/skeleton.tsx";
export function AccountMenu() {
  _s();
  const navigate = useNavigate();
  const { data: profile, isLoading: isLoadingProfile } = useQuery({
    queryKey: ["profile"],
    queryFn: getProfile,
    staleTime: Infinity
  });
  const { data: managedRestaurant, isLoading: isLoadingManagedRestaurant } = useQuery({
    queryKey: ["managed-restaurant"],
    queryFn: getMenageRestaurant,
    staleTime: Infinity
  });
  const { mutateAsync: signOutFn, isPending: isSigningOut } = useMutation({
    mutationFn: signOut,
    onSuccess: () => {
      navigate("/sign-in", { replace: true });
    }
  });
  return /* @__PURE__ */ jsxDEV(Dialog, { children: [
    /* @__PURE__ */ jsxDEV(DropdownMenu, { children: [
      /* @__PURE__ */ jsxDEV(DropdownMenuTrigger, { asChild: true, children: /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "outline",
          className: "flex select-none items-center gap-2",
          children: [
            isLoadingManagedRestaurant ? /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-4 w-40" }, void 0, false, {
              fileName: "/Users/arruday/GitHub/pizzashop/src/components/account-menu.tsx",
              lineNumber: 54,
              columnNumber: 13
            }, this) : managedRestaurant?.name,
            /* @__PURE__ */ jsxDEV(ChevronDown, {}, void 0, false, {
              fileName: "/Users/arruday/GitHub/pizzashop/src/components/account-menu.tsx",
              lineNumber: 58,
              columnNumber: 13
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/arruday/GitHub/pizzashop/src/components/account-menu.tsx",
          lineNumber: 49,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/components/account-menu.tsx",
        lineNumber: 48,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DropdownMenuContent, { align: "end", className: "w-56", children: [
        /* @__PURE__ */ jsxDEV(DropdownMenuLabel, { className: "flex flex-col", children: isLoadingProfile ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-4 w-32" }, void 0, false, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/components/account-menu.tsx",
            lineNumber: 65,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-3 w-24" }, void 0, false, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/components/account-menu.tsx",
            lineNumber: 66,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/components/account-menu.tsx",
          lineNumber: 64,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("span", { children: profile?.name }, void 0, false, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/components/account-menu.tsx",
            lineNumber: 70,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-normal text-muted-foreground", children: profile?.email }, void 0, false, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/components/account-menu.tsx",
            lineNumber: 71,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/components/account-menu.tsx",
          lineNumber: 69,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/components/account-menu.tsx",
          lineNumber: 62,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(DropdownMenuSeparator, {}, void 0, false, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/components/account-menu.tsx",
          lineNumber: 77,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(DialogTrigger, { asChild: true, children: /* @__PURE__ */ jsxDEV(DropdownMenuItem, { children: [
          /* @__PURE__ */ jsxDEV(Building, { className: "mr-2 h-4 w-4" }, void 0, false, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/components/account-menu.tsx",
            lineNumber: 80,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: "Perfil da loja" }, void 0, false, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/components/account-menu.tsx",
            lineNumber: 81,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/components/account-menu.tsx",
          lineNumber: 79,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/components/account-menu.tsx",
          lineNumber: 78,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          DropdownMenuItem,
          {
            asChild: true,
            disabled: isSigningOut,
            className: "text-rose-500 dark:text-rose-400",
            children: /* @__PURE__ */ jsxDEV("button", { onClick: () => signOutFn(), className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(LogOut, { className: "mr-2 h-4 w-4" }, void 0, false, {
                fileName: "/Users/arruday/GitHub/pizzashop/src/components/account-menu.tsx",
                lineNumber: 90,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: "Sair" }, void 0, false, {
                fileName: "/Users/arruday/GitHub/pizzashop/src/components/account-menu.tsx",
                lineNumber: 91,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/arruday/GitHub/pizzashop/src/components/account-menu.tsx",
              lineNumber: 89,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/Users/arruday/GitHub/pizzashop/src/components/account-menu.tsx",
            lineNumber: 84,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/components/account-menu.tsx",
        lineNumber: 61,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/components/account-menu.tsx",
      lineNumber: 47,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(StoreProfileDialog, {}, void 0, false, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/components/account-menu.tsx",
      lineNumber: 97,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/arruday/GitHub/pizzashop/src/components/account-menu.tsx",
    lineNumber: 46,
    columnNumber: 5
  }, this);
}
_s(AccountMenu, "Ml3uKNdSghuCAXtIWq0kOtOG4y0=", false, function() {
  return [useNavigate, useQuery, useQuery, useMutation];
});
_c = AccountMenu;
var _c;
$RefreshReg$(_c, "AccountMenu");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arruday/GitHub/pizzashop/src/components/account-menu.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcURjLFNBZUEsVUFmQTsyQkFyRGQ7QUFBb0IsTUFBRUEsY0FBZ0IsNkJBQXVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzdELFNBQVNDLFVBQVVDLGFBQWFDLGNBQWM7QUFDOUMsU0FBU0MsbUJBQW1CO0FBRTVCLFNBQVNDLDJCQUEyQjtBQUNwQyxTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsZUFBZTtBQUV4QixTQUFTQywwQkFBMEI7QUFDbkMsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxRQUFRQyxxQkFBcUI7QUFDdEM7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsU0FBU0MsZ0JBQWdCO0FBRWxCLGdCQUFTQyxjQUFjO0FBQUFDLEtBQUE7QUFDNUIsUUFBTUMsV0FBV2pCLFlBQVk7QUFFN0IsUUFBTSxFQUFFa0IsTUFBTUMsU0FBU0MsV0FBV0MsaUJBQWlCLElBQUl6QixTQUFTO0FBQUEsSUFDOUQwQixVQUFVLENBQUMsU0FBUztBQUFBLElBQ3BCQyxTQUFTckI7QUFBQUEsSUFDVHNCLFdBQVdDO0FBQUFBLEVBQ2IsQ0FBQztBQUVELFFBQU0sRUFBRVAsTUFBTVEsbUJBQW1CTixXQUFXTywyQkFBMkIsSUFDckUvQixTQUFTO0FBQUEsSUFDUDBCLFVBQVUsQ0FBQyxvQkFBb0I7QUFBQSxJQUMvQkMsU0FBU3RCO0FBQUFBLElBQ1R1QixXQUFXQztBQUFBQSxFQUNiLENBQUM7QUFFSCxRQUFNLEVBQUVHLGFBQWFDLFdBQVdDLFdBQVdDLGFBQWEsSUFBSUMsWUFBWTtBQUFBLElBQ3RFQyxZQUFZOUI7QUFBQUEsSUFDWitCLFdBQVdBLE1BQU07QUFDZmpCLGVBQVMsWUFBWSxFQUFFa0IsU0FBUyxLQUFLLENBQUM7QUFBQSxJQUN4QztBQUFBLEVBQ0YsQ0FBQztBQUVELFNBQ0UsdUJBQUMsVUFDQztBQUFBLDJCQUFDLGdCQUNDO0FBQUEsNkJBQUMsdUJBQW9CLFNBQU8sTUFDMUI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVE7QUFBQSxVQUNSLFdBQVU7QUFBQSxVQUVUUjtBQUFBQSx5Q0FDQyx1QkFBQyxZQUFTLFdBQVUsY0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEIsSUFFOUJELG1CQUFtQlU7QUFBQUEsWUFFckIsdUJBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBWTtBQUFBO0FBQUE7QUFBQSxRQVRkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsTUFDQSx1QkFBQyx1QkFBb0IsT0FBTSxPQUFNLFdBQVUsUUFDekM7QUFBQSwrQkFBQyxxQkFBa0IsV0FBVSxpQkFDMUJmLDZCQUNDLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsaUNBQUMsWUFBUyxXQUFVLGNBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThCO0FBQUEsVUFDOUIsdUJBQUMsWUFBUyxXQUFVLGNBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThCO0FBQUEsYUFGaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBLElBRUEsbUNBQ0U7QUFBQSxpQ0FBQyxVQUFNRixtQkFBU2lCLFFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFCO0FBQUEsVUFDckIsdUJBQUMsVUFBSyxXQUFVLDZDQUNiakIsbUJBQVNrQixTQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQSxLQVpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFjQTtBQUFBLFFBQ0EsdUJBQUMsMkJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzQjtBQUFBLFFBQ3RCLHVCQUFDLGlCQUFjLFNBQU8sTUFDcEIsaUNBQUMsb0JBQ0M7QUFBQSxpQ0FBQyxZQUFTLFdBQVUsa0JBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtDO0FBQUEsVUFDbEMsdUJBQUMsVUFBSyw4QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvQjtBQUFBLGFBRnRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQSxVQUFVTjtBQUFBQSxZQUNWLFdBQVU7QUFBQSxZQUVWLGlDQUFDLFlBQU8sU0FBUyxNQUFNRixVQUFVLEdBQUcsV0FBVSxVQUM1QztBQUFBLHFDQUFDLFVBQU8sV0FBVSxrQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0M7QUFBQSxjQUNoQyx1QkFBQyxVQUFLLG9CQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQVU7QUFBQSxpQkFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUE7QUFBQSxVQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVNBO0FBQUEsV0FoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWlDQTtBQUFBLFNBL0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnREE7QUFBQSxJQUVBLHVCQUFDLHdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUI7QUFBQSxPQW5EckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW9EQTtBQUVKO0FBQUNiLEdBOUVlRCxhQUFXO0FBQUEsVUFDUmYsYUFFc0NKLFVBT3JEQSxVQU0wRG9DLFdBQVc7QUFBQTtBQUFBTSxLQWhCekR2QjtBQUFXLElBQUF1QjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlUXVlcnkiLCJCdWlsZGluZyIsIkNoZXZyb25Eb3duIiwiTG9nT3V0IiwidXNlTmF2aWdhdGUiLCJnZXRNZW5hZ2VSZXN0YXVyYW50IiwiZ2V0UHJvZmlsZSIsInNpZ25PdXQiLCJTdG9yZVByb2ZpbGVEaWFsb2ciLCJCdXR0b24iLCJEaWFsb2ciLCJEaWFsb2dUcmlnZ2VyIiwiRHJvcGRvd25NZW51IiwiRHJvcGRvd25NZW51Q29udGVudCIsIkRyb3Bkb3duTWVudUl0ZW0iLCJEcm9wZG93bk1lbnVMYWJlbCIsIkRyb3Bkb3duTWVudVNlcGFyYXRvciIsIkRyb3Bkb3duTWVudVRyaWdnZXIiLCJTa2VsZXRvbiIsIkFjY291bnRNZW51IiwiX3MiLCJuYXZpZ2F0ZSIsImRhdGEiLCJwcm9maWxlIiwiaXNMb2FkaW5nIiwiaXNMb2FkaW5nUHJvZmlsZSIsInF1ZXJ5S2V5IiwicXVlcnlGbiIsInN0YWxlVGltZSIsIkluZmluaXR5IiwibWFuYWdlZFJlc3RhdXJhbnQiLCJpc0xvYWRpbmdNYW5hZ2VkUmVzdGF1cmFudCIsIm11dGF0ZUFzeW5jIiwic2lnbk91dEZuIiwiaXNQZW5kaW5nIiwiaXNTaWduaW5nT3V0IiwidXNlTXV0YXRpb24iLCJtdXRhdGlvbkZuIiwib25TdWNjZXNzIiwicmVwbGFjZSIsIm5hbWUiLCJlbWFpbCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiYWNjb3VudC1tZW51LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VNdXRhdGlvbiwgdXNlUXVlcnkgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG5pbXBvcnQgeyBCdWlsZGluZywgQ2hldnJvbkRvd24sIExvZ091dCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcblxuaW1wb3J0IHsgZ2V0TWVuYWdlUmVzdGF1cmFudCB9IGZyb20gJ0AvYXBpL2dldC1tYW5hZ2VkLXJlc3RhdXJhbnQnXG5pbXBvcnQgeyBnZXRQcm9maWxlIH0gZnJvbSAnQC9hcGkvZ2V0LXByb2ZpbGUnXG5pbXBvcnQgeyBzaWduT3V0IH0gZnJvbSAnQC9hcGkvc2lnbi1vdXQnXG5cbmltcG9ydCB7IFN0b3JlUHJvZmlsZURpYWxvZyB9IGZyb20gJy4vc3RvcmUtcHJvZmlsZS1kaWFsb2cnXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICcuL3VpL2J1dHRvbidcbmltcG9ydCB7IERpYWxvZywgRGlhbG9nVHJpZ2dlciB9IGZyb20gJy4vdWkvZGlhbG9nJ1xuaW1wb3J0IHtcbiAgRHJvcGRvd25NZW51LFxuICBEcm9wZG93bk1lbnVDb250ZW50LFxuICBEcm9wZG93bk1lbnVJdGVtLFxuICBEcm9wZG93bk1lbnVMYWJlbCxcbiAgRHJvcGRvd25NZW51U2VwYXJhdG9yLFxuICBEcm9wZG93bk1lbnVUcmlnZ2VyLFxufSBmcm9tICcuL3VpL2Ryb3Bkb3duLW1lbnUnXG5pbXBvcnQgeyBTa2VsZXRvbiB9IGZyb20gJy4vdWkvc2tlbGV0b24nXG5cbmV4cG9ydCBmdW5jdGlvbiBBY2NvdW50TWVudSgpIHtcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpXG5cbiAgY29uc3QgeyBkYXRhOiBwcm9maWxlLCBpc0xvYWRpbmc6IGlzTG9hZGluZ1Byb2ZpbGUgfSA9IHVzZVF1ZXJ5KHtcbiAgICBxdWVyeUtleTogWydwcm9maWxlJ10sXG4gICAgcXVlcnlGbjogZ2V0UHJvZmlsZSxcbiAgICBzdGFsZVRpbWU6IEluZmluaXR5LFxuICB9KVxuXG4gIGNvbnN0IHsgZGF0YTogbWFuYWdlZFJlc3RhdXJhbnQsIGlzTG9hZGluZzogaXNMb2FkaW5nTWFuYWdlZFJlc3RhdXJhbnQgfSA9XG4gICAgdXNlUXVlcnkoe1xuICAgICAgcXVlcnlLZXk6IFsnbWFuYWdlZC1yZXN0YXVyYW50J10sXG4gICAgICBxdWVyeUZuOiBnZXRNZW5hZ2VSZXN0YXVyYW50LFxuICAgICAgc3RhbGVUaW1lOiBJbmZpbml0eSxcbiAgICB9KVxuXG4gIGNvbnN0IHsgbXV0YXRlQXN5bmM6IHNpZ25PdXRGbiwgaXNQZW5kaW5nOiBpc1NpZ25pbmdPdXQgfSA9IHVzZU11dGF0aW9uKHtcbiAgICBtdXRhdGlvbkZuOiBzaWduT3V0LFxuICAgIG9uU3VjY2VzczogKCkgPT4ge1xuICAgICAgbmF2aWdhdGUoJy9zaWduLWluJywgeyByZXBsYWNlOiB0cnVlIH0pXG4gICAgfSxcbiAgfSlcblxuICByZXR1cm4gKFxuICAgIDxEaWFsb2c+XG4gICAgICA8RHJvcGRvd25NZW51PlxuICAgICAgICA8RHJvcGRvd25NZW51VHJpZ2dlciBhc0NoaWxkPlxuICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggc2VsZWN0LW5vbmUgaXRlbXMtY2VudGVyIGdhcC0yXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICB7aXNMb2FkaW5nTWFuYWdlZFJlc3RhdXJhbnQgPyAoXG4gICAgICAgICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJoLTQgdy00MFwiIC8+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICBtYW5hZ2VkUmVzdGF1cmFudD8ubmFtZVxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDxDaGV2cm9uRG93biAvPlxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICA8L0Ryb3Bkb3duTWVudVRyaWdnZXI+XG4gICAgICAgIDxEcm9wZG93bk1lbnVDb250ZW50IGFsaWduPVwiZW5kXCIgY2xhc3NOYW1lPVwidy01NlwiPlxuICAgICAgICAgIDxEcm9wZG93bk1lbnVMYWJlbCBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XG4gICAgICAgICAgICB7aXNMb2FkaW5nUHJvZmlsZSA/IChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJoLTQgdy0zMlwiIC8+XG4gICAgICAgICAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtMyB3LTI0XCIgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgIDxzcGFuPntwcm9maWxlPy5uYW1lfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbm9ybWFsIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAgICAge3Byb2ZpbGU/LmVtYWlsfVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvRHJvcGRvd25NZW51TGFiZWw+XG4gICAgICAgICAgPERyb3Bkb3duTWVudVNlcGFyYXRvciAvPlxuICAgICAgICAgIDxEaWFsb2dUcmlnZ2VyIGFzQ2hpbGQ+XG4gICAgICAgICAgICA8RHJvcGRvd25NZW51SXRlbT5cbiAgICAgICAgICAgICAgPEJ1aWxkaW5nIGNsYXNzTmFtZT1cIm1yLTIgaC00IHctNFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPlBlcmZpbCBkYSBsb2phPC9zcGFuPlxuICAgICAgICAgICAgPC9Ecm9wZG93bk1lbnVJdGVtPlxuICAgICAgICAgIDwvRGlhbG9nVHJpZ2dlcj5cbiAgICAgICAgICA8RHJvcGRvd25NZW51SXRlbVxuICAgICAgICAgICAgYXNDaGlsZFxuICAgICAgICAgICAgZGlzYWJsZWQ9e2lzU2lnbmluZ091dH1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcm9zZS01MDAgZGFyazp0ZXh0LXJvc2UtNDAwXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNpZ25PdXRGbigpfSBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cbiAgICAgICAgICAgICAgPExvZ091dCBjbGFzc05hbWU9XCJtci0yIGgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICA8c3Bhbj5TYWlyPC9zcGFuPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9Ecm9wZG93bk1lbnVJdGVtPlxuICAgICAgICA8L0Ryb3Bkb3duTWVudUNvbnRlbnQ+XG4gICAgICA8L0Ryb3Bkb3duTWVudT5cblxuICAgICAgPFN0b3JlUHJvZmlsZURpYWxvZyAvPlxuICAgIDwvRGlhbG9nPlxuICApXG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9hcnJ1ZGF5L0dpdEh1Yi9waXp6YXNob3Avc3JjL2NvbXBvbmVudHMvYWNjb3VudC1tZW51LnRzeCJ9