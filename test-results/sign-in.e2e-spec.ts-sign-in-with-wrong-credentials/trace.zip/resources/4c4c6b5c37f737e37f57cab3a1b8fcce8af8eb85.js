import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/error.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=efc33bbd"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/arruday/GitHub/pizzashop/src/pages/error.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Link, useRouteError } from "/node_modules/.vite/deps/react-router-dom.js?v=efc33bbd";
export function Error() {
  _s();
  const error = useRouteError();
  return /* @__PURE__ */ jsxDEV("div", { className: "flex h-screen flex-col items-center justify-center gap-2", children: [
    /* @__PURE__ */ jsxDEV("h1", { className: "text-4xl font-bold", children: "Whoops, algo aconteceu!" }, void 0, false, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/error.tsx",
      lineNumber: 8,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "text-accent-foreground", children: "Um erro aconteceu na aplicação, abaixo você encontra mais detalhes:" }, void 0, false, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/error.tsx",
      lineNumber: 9,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("pre", { children: error?.message || JSON.stringify(error) }, void 0, false, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/error.tsx",
      lineNumber: 12,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("pre", { className: "text-accent-foreground", children: [
      "Voltra para o",
      " ",
      /* @__PURE__ */ jsxDEV(Link, { to: "/", className: "text-sky-500 dark:text-sky-400", children: "Dashboard" }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/error.tsx",
        lineNumber: 15,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/error.tsx",
      lineNumber: 13,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/arruday/GitHub/pizzashop/src/pages/error.tsx",
    lineNumber: 7,
    columnNumber: 5
  }, this);
}
_s(Error, "YDkf/bojC730qvJxOiv5VT1rhKY=", false, function() {
  return [useRouteError];
});
_c = Error;
var _c;
$RefreshReg$(_c, "Error");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arruday/GitHub/pizzashop/src/pages/error.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT007MkJBUE47QUFBZUEsb0JBQXFCLDZCQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUUvQyxnQkFBU0MsUUFBUTtBQUFBQyxLQUFBO0FBQ3RCLFFBQU1DLFFBQVFILGNBQWM7QUFFNUIsU0FDRSx1QkFBQyxTQUFJLFdBQVUsNERBQ2I7QUFBQSwyQkFBQyxRQUFHLFdBQVUsc0JBQXFCLHVDQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBEO0FBQUEsSUFDMUQsdUJBQUMsT0FBRSxXQUFVLDBCQUF3QixtRkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxTQUFLRyxpQkFBT0MsV0FBV0MsS0FBS0MsVUFBVUgsS0FBSyxLQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThDO0FBQUEsSUFDOUMsdUJBQUMsU0FBSSxXQUFVLDBCQUF3QjtBQUFBO0FBQUEsTUFDdkI7QUFBQSxNQUNkLHVCQUFDLFFBQUssSUFBSSxLQUFLLFdBQVUsa0NBQWdDLHlCQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLE9BWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVlBO0FBRUo7QUFBQ0QsR0FsQmVELE9BQUs7QUFBQSxVQUNMRCxhQUFhO0FBQUE7QUFBQU8sS0FEYk47QUFBSyxJQUFBTTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlUm91dGVFcnJvciIsIkVycm9yIiwiX3MiLCJlcnJvciIsIm1lc3NhZ2UiLCJKU09OIiwic3RyaW5naWZ5IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJlcnJvci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTGluaywgdXNlUm91dGVFcnJvciB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5cbmV4cG9ydCBmdW5jdGlvbiBFcnJvcigpIHtcbiAgY29uc3QgZXJyb3IgPSB1c2VSb3V0ZUVycm9yKCkgYXMgRXJyb3JcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLXNjcmVlbiBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTR4bCBmb250LWJvbGRcIj5XaG9vcHMsIGFsZ28gYWNvbnRlY2V1ITwvaDE+XG4gICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWFjY2VudC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgIFVtIGVycm8gYWNvbnRlY2V1IG5hIGFwbGljYcOnw6NvLCBhYmFpeG8gdm9jw6ogZW5jb250cmEgbWFpcyBkZXRhbGhlczpcbiAgICAgIDwvcD5cbiAgICAgIDxwcmU+e2Vycm9yPy5tZXNzYWdlIHx8IEpTT04uc3RyaW5naWZ5KGVycm9yKX08L3ByZT5cbiAgICAgIDxwcmUgY2xhc3NOYW1lPVwidGV4dC1hY2NlbnQtZm9yZWdyb3VuZFwiPlxuICAgICAgICBWb2x0cmEgcGFyYSBveycgJ31cbiAgICAgICAgPExpbmsgdG89eycvJ30gY2xhc3NOYW1lPVwidGV4dC1za3ktNTAwIGRhcms6dGV4dC1za3ktNDAwXCI+XG4gICAgICAgICAgRGFzaGJvYXJkXG4gICAgICAgIDwvTGluaz5cbiAgICAgIDwvcHJlPlxuICAgIDwvZGl2PlxuICApXG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9hcnJ1ZGF5L0dpdEh1Yi9waXp6YXNob3Avc3JjL3BhZ2VzL2Vycm9yLnRzeCJ9