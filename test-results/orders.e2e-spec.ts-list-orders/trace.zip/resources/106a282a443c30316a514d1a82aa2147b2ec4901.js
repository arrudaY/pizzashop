import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/app/dashboard/day-orders-amount-card.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=efc33bbd"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/day-orders-amount-card.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=efc33bbd";
import { Utensils } from "/node_modules/.vite/deps/lucide-react.js?v=efc33bbd";
import { getDayOrdersAmount } from "/src/api/get-day-orders-amount.ts";
import { Card, CardContent, CardHeader, CardTitle } from "/src/components/ui/card.tsx";
import { MetricCardSkeleton } from "/src/pages/app/dashboard/metric-card-skeleton.tsx";
export function DayOrdersAmountCard() {
  _s();
  const { data: dayOrdersAmount } = useQuery({
    queryKey: ["metrics", "day-orders-amount"],
    queryFn: getDayOrdersAmount
  });
  return /* @__PURE__ */ jsxDEV(Card, { children: [
    /* @__PURE__ */ jsxDEV(CardHeader, { className: "flex-row items-center justify-between space-y-0 pb-2", children: [
      /* @__PURE__ */ jsxDEV(CardTitle, { className: "text-base font-semibold", children: "Pedidos (dia)" }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/day-orders-amount-card.tsx",
        lineNumber: 17,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Utensils, { className: "h-4 w-4 text-muted-foreground" }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/day-orders-amount-card.tsx",
        lineNumber: 18,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/day-orders-amount-card.tsx",
      lineNumber: 16,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(CardContent, { className: "space-y-1", children: dayOrdersAmount ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("span", { className: "racking-tight font-mono text-2xl font-bold", children: dayOrdersAmount.amount.toLocaleString("pt-BR") }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/day-orders-amount-card.tsx",
        lineNumber: 23,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-muted-foreground", children: dayOrdersAmount.diffFromYesterday >= 0 ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-emerald-500 dark:text-emerald-400", children: [
          "+",
          dayOrdersAmount.diffFromYesterday,
          "%"
        ] }, void 0, true, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/day-orders-amount-card.tsx",
          lineNumber: 29,
          columnNumber: 19
        }, this),
        " ",
        "em relação a ontem"
      ] }, void 0, true, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/day-orders-amount-card.tsx",
        lineNumber: 28,
        columnNumber: 13
      }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-rose-500 dark:text-rose-400", children: [
          dayOrdersAmount.diffFromYesterday,
          "%"
        ] }, void 0, true, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/day-orders-amount-card.tsx",
          lineNumber: 36,
          columnNumber: 19
        }, this),
        " ",
        "em relação a ontem"
      ] }, void 0, true, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/day-orders-amount-card.tsx",
        lineNumber: 35,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/day-orders-amount-card.tsx",
        lineNumber: 26,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/day-orders-amount-card.tsx",
      lineNumber: 22,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV(MetricCardSkeleton, {}, void 0, false, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/day-orders-amount-card.tsx",
      lineNumber: 45,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/day-orders-amount-card.tsx",
      lineNumber: 20,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/day-orders-amount-card.tsx",
    lineNumber: 15,
    columnNumber: 5
  }, this);
}
_s(DayOrdersAmountCard, "X4ooPoWX1BlcuKkrK9Waaxl5Cfg=", false, function() {
  return [useQuery];
});
_c = DayOrdersAmountCard;
var _c;
$RefreshReg$(_c, "DayOrdersAmountCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/day-orders-amount-card.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JRLFNBV1EsVUFYUjsyQkFoQlI7QUFBaUIsTUFBUSxxQkFBdUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDaEQsU0FBU0EsZ0JBQWdCO0FBRXpCLFNBQVNDLDBCQUEwQjtBQUNuQyxTQUFTQyxNQUFNQyxhQUFhQyxZQUFZQyxpQkFBaUI7QUFFekQsU0FBU0MsMEJBQTBCO0FBRTVCLGdCQUFTQyxzQkFBc0I7QUFBQUMsS0FBQTtBQUNwQyxRQUFNLEVBQUVDLE1BQU1DLGdCQUFnQixJQUFJQyxTQUFTO0FBQUEsSUFDekNDLFVBQVUsQ0FBQyxXQUFXLG1CQUFtQjtBQUFBLElBQ3pDQyxTQUFTWjtBQUFBQSxFQUNYLENBQUM7QUFDRCxTQUNFLHVCQUFDLFFBQ0M7QUFBQSwyQkFBQyxjQUFXLFdBQVUsd0RBQ3BCO0FBQUEsNkJBQUMsYUFBVSxXQUFVLDJCQUEwQiw2QkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0RDtBQUFBLE1BQzVELHVCQUFDLFlBQVMsV0FBVSxtQ0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRDtBQUFBLFNBRnJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBQ0EsdUJBQUMsZUFBWSxXQUFVLGFBQ3BCUyw0QkFDQyxtQ0FDRTtBQUFBLDZCQUFDLFVBQUssV0FBVSw4Q0FDYkEsMEJBQWdCSSxPQUFPQyxlQUFlLE9BQU8sS0FEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxPQUFFLFdBQVUsaUNBQ1ZMLDBCQUFnQk0scUJBQXFCLElBQ3BDLG1DQUNFO0FBQUEsK0JBQUMsVUFBSyxXQUFVLG9EQUFrRDtBQUFBO0FBQUEsVUFDOUROLGdCQUFnQk07QUFBQUEsVUFBa0I7QUFBQSxhQUR0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUFRO0FBQUEsUUFBRztBQUFBLFdBSGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBLElBRUEsbUNBQ0U7QUFBQSwrQkFBQyxVQUFLLFdBQVUsOENBQ2JOO0FBQUFBLDBCQUFnQk07QUFBQUEsVUFBa0I7QUFBQSxhQURyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUFRO0FBQUEsUUFBRztBQUFBLFdBSGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBLEtBZEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdCQTtBQUFBLFNBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxQkEsSUFFQSx1QkFBQyx3QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1CLEtBekJ2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMkJBO0FBQUEsT0FoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlDQTtBQUVKO0FBQUNSLEdBekNlRCxxQkFBbUI7QUFBQSxVQUNDSSxRQUFRO0FBQUE7QUFBQU0sS0FENUJWO0FBQW1CLElBQUFVO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJVdGVuc2lscyIsImdldERheU9yZGVyc0Ftb3VudCIsIkNhcmQiLCJDYXJkQ29udGVudCIsIkNhcmRIZWFkZXIiLCJDYXJkVGl0bGUiLCJNZXRyaWNDYXJkU2tlbGV0b24iLCJEYXlPcmRlcnNBbW91bnRDYXJkIiwiX3MiLCJkYXRhIiwiZGF5T3JkZXJzQW1vdW50IiwidXNlUXVlcnkiLCJxdWVyeUtleSIsInF1ZXJ5Rm4iLCJhbW91bnQiLCJ0b0xvY2FsZVN0cmluZyIsImRpZmZGcm9tWWVzdGVyZGF5IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJkYXktb3JkZXJzLWFtb3VudC1jYXJkLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VRdWVyeSB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbmltcG9ydCB7IFV0ZW5zaWxzIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuXG5pbXBvcnQgeyBnZXREYXlPcmRlcnNBbW91bnQgfSBmcm9tICdAL2FwaS9nZXQtZGF5LW9yZGVycy1hbW91bnQnXG5pbXBvcnQgeyBDYXJkLCBDYXJkQ29udGVudCwgQ2FyZEhlYWRlciwgQ2FyZFRpdGxlIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2NhcmQnXG5cbmltcG9ydCB7IE1ldHJpY0NhcmRTa2VsZXRvbiB9IGZyb20gJy4vbWV0cmljLWNhcmQtc2tlbGV0b24nXG5cbmV4cG9ydCBmdW5jdGlvbiBEYXlPcmRlcnNBbW91bnRDYXJkKCkge1xuICBjb25zdCB7IGRhdGE6IGRheU9yZGVyc0Ftb3VudCB9ID0gdXNlUXVlcnkoe1xuICAgIHF1ZXJ5S2V5OiBbJ21ldHJpY3MnLCAnZGF5LW9yZGVycy1hbW91bnQnXSxcbiAgICBxdWVyeUZuOiBnZXREYXlPcmRlcnNBbW91bnQsXG4gIH0pXG4gIHJldHVybiAoXG4gICAgPENhcmQ+XG4gICAgICA8Q2FyZEhlYWRlciBjbGFzc05hbWU9XCJmbGV4LXJvdyBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXktMCBwYi0yXCI+XG4gICAgICAgIDxDYXJkVGl0bGUgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtc2VtaWJvbGRcIj5QZWRpZG9zIChkaWEpPC9DYXJkVGl0bGU+XG4gICAgICAgIDxVdGVuc2lscyBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiIC8+XG4gICAgICA8L0NhcmRIZWFkZXI+XG4gICAgICA8Q2FyZENvbnRlbnQgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgIHtkYXlPcmRlcnNBbW91bnQgPyAoXG4gICAgICAgICAgPD5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJhY2tpbmctdGlnaHQgZm9udC1tb25vIHRleHQtMnhsIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICB7ZGF5T3JkZXJzQW1vdW50LmFtb3VudC50b0xvY2FsZVN0cmluZygncHQtQlInKX1cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgIHtkYXlPcmRlcnNBbW91bnQuZGlmZkZyb21ZZXN0ZXJkYXkgPj0gMCA/IChcbiAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZW1lcmFsZC01MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICt7ZGF5T3JkZXJzQW1vdW50LmRpZmZGcm9tWWVzdGVyZGF5fSVcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj57JyAnfVxuICAgICAgICAgICAgICAgICAgZW0gcmVsYcOnw6NvIGEgb250ZW1cbiAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtcm9zZS01MDAgZGFyazp0ZXh0LXJvc2UtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIHtkYXlPcmRlcnNBbW91bnQuZGlmZkZyb21ZZXN0ZXJkYXl9JVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPnsnICd9XG4gICAgICAgICAgICAgICAgICBlbSByZWxhw6fDo28gYSBvbnRlbVxuICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgIDwvPlxuICAgICAgICApIDogKFxuICAgICAgICAgIDxNZXRyaWNDYXJkU2tlbGV0b24gLz5cbiAgICAgICAgKX1cbiAgICAgIDwvQ2FyZENvbnRlbnQ+XG4gICAgPC9DYXJkPlxuICApXG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9hcnJ1ZGF5L0dpdEh1Yi9waXp6YXNob3Avc3JjL3BhZ2VzL2FwcC9kYXNoYm9hcmQvZGF5LW9yZGVycy1hbW91bnQtY2FyZC50c3gifQ==