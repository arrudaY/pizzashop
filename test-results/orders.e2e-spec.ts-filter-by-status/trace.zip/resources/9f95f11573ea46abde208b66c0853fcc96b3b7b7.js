import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/app/orders/order-details.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=efc33bbd"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=efc33bbd";
import { formatDistanceToNow } from "/node_modules/.vite/deps/date-fns.js?v=efc33bbd";
import { ptBR } from "/node_modules/.vite/deps/date-fns_locale.js?v=efc33bbd";
import { getOrderDetails } from "/src/api/get-order-details.ts";
import { OrderStatus } from "/src/components/order-status.tsx";
import {
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle
} from "/src/components/ui/dialog.tsx";
import {
  Table,
  TableBody,
  TableCell,
  TableFooter,
  TableHead,
  TableHeader,
  TableRow
} from "/src/components/ui/table.tsx";
import { OrderDetailsSkeleton } from "/src/pages/app/orders/order-details-skeleton.tsx";
export function OrderDetails({ orderId, open }) {
  _s();
  const { data: order } = useQuery({
    queryKey: ["order", orderId],
    queryFn: () => getOrderDetails({ orderId }),
    enabled: open
  });
  return /* @__PURE__ */ jsxDEV(DialogContent, { children: [
    /* @__PURE__ */ jsxDEV(DialogHeader, { children: [
      /* @__PURE__ */ jsxDEV(DialogTitle, { children: [
        "Pedido: ",
        orderId
      ] }, void 0, true, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
        lineNumber: 40,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DialogDescription, { children: "Detalhes do pedido:" }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
        lineNumber: 41,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
      lineNumber: 39,
      columnNumber: 7
    }, this),
    order ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
      /* @__PURE__ */ jsxDEV(Table, { children: /* @__PURE__ */ jsxDEV(TableBody, { children: [
        /* @__PURE__ */ jsxDEV(TableRow, { children: [
          /* @__PURE__ */ jsxDEV(TableCell, { className: "text-muted-foreground", children: "Status" }, void 0, false, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
            lineNumber: 49,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { className: "flex flex-1 justify-end", children: /* @__PURE__ */ jsxDEV(OrderStatus, { status: order.status }, void 0, false, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
            lineNumber: 51,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
            lineNumber: 50,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
          lineNumber: 48,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(TableRow, { children: [
          /* @__PURE__ */ jsxDEV(TableCell, { className: "text-muted-foreground", children: "Cliente" }, void 0, false, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
            lineNumber: 56,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { className: "flex justify-end", children: order.customer.name }, void 0, false, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
            lineNumber: 57,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
          lineNumber: 55,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(TableRow, { children: [
          /* @__PURE__ */ jsxDEV(TableCell, { className: "text-muted-foreground", children: "Telefone" }, void 0, false, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
            lineNumber: 63,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { className: "flex justify-end", children: order.customer.phone ?? "Não informado" }, void 0, false, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
            lineNumber: 66,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
          lineNumber: 62,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(TableRow, { children: [
          /* @__PURE__ */ jsxDEV(TableCell, { className: "text-muted-foreground", children: "E-mail" }, void 0, false, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
            lineNumber: 72,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { className: "flex justify-end", children: order.customer.email }, void 0, false, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
            lineNumber: 73,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
          lineNumber: 71,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(TableRow, { children: [
          /* @__PURE__ */ jsxDEV(TableCell, { className: "text-muted-foreground", children: "Realizado há" }, void 0, false, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
            lineNumber: 79,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { className: "flex justify-end", children: formatDistanceToNow(order.createdAt, {
            locale: ptBR
          }) }, void 0, false, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
            lineNumber: 82,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
          lineNumber: 78,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
        lineNumber: 47,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
        lineNumber: 46,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Table, { children: [
        /* @__PURE__ */ jsxDEV(TableHeader, { children: /* @__PURE__ */ jsxDEV(TableRow, { children: [
          /* @__PURE__ */ jsxDEV(TableHead, { children: "Produto" }, void 0, false, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
            lineNumber: 94,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(TableHead, { className: "text-right", children: "Qtd." }, void 0, false, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
            lineNumber: 95,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(TableHead, { className: "text-right", children: "Preço" }, void 0, false, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
            lineNumber: 96,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(TableHead, { className: "text-right", children: "Subtotal" }, void 0, false, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
            lineNumber: 97,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
          lineNumber: 93,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
          lineNumber: 92,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(TableBody, { children: order.orderItems.map((item) => {
          return /* @__PURE__ */ jsxDEV(TableRow, { children: [
            /* @__PURE__ */ jsxDEV(TableCell, { children: item.product.name }, void 0, false, {
              fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
              lineNumber: 104,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(TableCell, { className: "text-right", children: item.quantity }, void 0, false, {
              fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
              lineNumber: 105,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(TableCell, { className: "text-right font-mono", children: (item.priceInCents / 100).toLocaleString("pt-BR", {
              style: "currency",
              currency: "BRL"
            }) }, void 0, false, {
              fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
              lineNumber: 108,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(TableCell, { className: "text-right font-mono", children: (item.priceInCents * item.quantity / 100).toLocaleString("pt-BR", {
              style: "currency",
              currency: "BRL"
            }) }, void 0, false, {
              fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
              lineNumber: 114,
              columnNumber: 21
            }, this)
          ] }, item.id, true, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
            lineNumber: 103,
            columnNumber: 17
          }, this);
        }) }, void 0, false, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
          lineNumber: 100,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(TableFooter, { children: /* @__PURE__ */ jsxDEV(TableRow, { children: [
          /* @__PURE__ */ jsxDEV(TableCell, { colSpan: 3, children: "Total do pedido" }, void 0, false, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
            lineNumber: 129,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { className: "text-right font-mono", children: (order.totalInCents / 100).toLocaleString("pt-BR", {
            style: "currency",
            currency: "BRL"
          }) }, void 0, false, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
            lineNumber: 130,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
          lineNumber: 128,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
          lineNumber: 127,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
        lineNumber: 91,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
      lineNumber: 45,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV(OrderDetailsSkeleton, {}, void 0, false, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
      lineNumber: 141,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx",
    lineNumber: 38,
    columnNumber: 5
  }, this);
}
_s(OrderDetails, "LYyi1ST3wC5wfyvY9hAfo240uP0=", false, function() {
  return [useQuery];
});
_c = OrderDetails;
var _c;
$RefreshReg$(_c, "OrderDetails");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-details.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUNROzJCQXZDUjtBQUFpQixNQUFRLHFCQUF1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNoRCxTQUFTQSwyQkFBMkI7QUFDcEMsU0FBU0MsWUFBWTtBQUVyQixTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsbUJBQW1CO0FBQzVCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUVQLFNBQVNDLDRCQUE0QjtBQU85QixnQkFBU0MsYUFBYSxFQUFFQyxTQUFTQyxLQUF3QixHQUFHO0FBQUFDLEtBQUE7QUFDakUsUUFBTSxFQUFFQyxNQUFNQyxNQUFNLElBQUlDLFNBQVM7QUFBQSxJQUMvQkMsVUFBVSxDQUFDLFNBQVNOLE9BQU87QUFBQSxJQUMzQk8sU0FBU0EsTUFBTXRCLGdCQUFnQixFQUFFZSxRQUFRLENBQUM7QUFBQSxJQUMxQ1EsU0FBU1A7QUFBQUEsRUFDWCxDQUFDO0FBRUQsU0FDRSx1QkFBQyxpQkFDQztBQUFBLDJCQUFDLGdCQUNDO0FBQUEsNkJBQUMsZUFBWTtBQUFBO0FBQUEsUUFBU0Q7QUFBQUEsV0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4QjtBQUFBLE1BQzlCLHVCQUFDLHFCQUFrQixtQ0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzQztBQUFBLFNBRnhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBRUNJLFFBQ0MsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSw2QkFBQyxTQUNDLGlDQUFDLGFBQ0M7QUFBQSwrQkFBQyxZQUNDO0FBQUEsaUNBQUMsYUFBVSxXQUFVLHlCQUF3QixzQkFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUQ7QUFBQSxVQUNuRCx1QkFBQyxhQUFVLFdBQVUsMkJBQ25CLGlDQUFDLGVBQVksUUFBUUEsTUFBTUssVUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0MsS0FEcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFFQSx1QkFBQyxZQUNDO0FBQUEsaUNBQUMsYUFBVSxXQUFVLHlCQUF3Qix1QkFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Q7QUFBQSxVQUNwRCx1QkFBQyxhQUFVLFdBQVUsb0JBQ2xCTCxnQkFBTU0sU0FBU0MsUUFEbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFFQSx1QkFBQyxZQUNDO0FBQUEsaUNBQUMsYUFBVSxXQUFVLHlCQUF1Qix3QkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsYUFBVSxXQUFVLG9CQUNsQlAsZ0JBQU1NLFNBQVNFLFNBQVMsbUJBRDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBRUEsdUJBQUMsWUFDQztBQUFBLGlDQUFDLGFBQVUsV0FBVSx5QkFBd0Isc0JBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1EO0FBQUEsVUFDbkQsdUJBQUMsYUFBVSxXQUFVLG9CQUNsQlIsZ0JBQU1NLFNBQVNHLFNBRGxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFFBRUEsdUJBQUMsWUFDQztBQUFBLGlDQUFDLGFBQVUsV0FBVSx5QkFBdUIsNEJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLGFBQVUsV0FBVSxvQkFDbEI5Qiw4QkFBb0JxQixNQUFNVSxXQUFXO0FBQUEsWUFDcENDLFFBQVEvQjtBQUFBQSxVQUNWLENBQUMsS0FISDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsYUFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxXQXhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeUNBLEtBMUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyQ0E7QUFBQSxNQUVBLHVCQUFDLFNBQ0M7QUFBQSwrQkFBQyxlQUNDLGlDQUFDLFlBQ0M7QUFBQSxpQ0FBQyxhQUFVLHVCQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtCO0FBQUEsVUFDbEIsdUJBQUMsYUFBVSxXQUFVLGNBQWEsb0JBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNDO0FBQUEsVUFDdEMsdUJBQUMsYUFBVSxXQUFVLGNBQWEscUJBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVDO0FBQUEsVUFDdkMsdUJBQUMsYUFBVSxXQUFVLGNBQWEsd0JBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBDO0FBQUEsYUFKNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFDQSx1QkFBQyxhQUNFb0IsZ0JBQU1ZLFdBQVdDLElBQUksQ0FBQ0MsU0FBUztBQUM5QixpQkFDRSx1QkFBQyxZQUNDO0FBQUEsbUNBQUMsYUFBV0EsZUFBS0MsUUFBUVIsUUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEI7QUFBQSxZQUM5Qix1QkFBQyxhQUFVLFdBQVUsY0FDbEJPLGVBQUtFLFlBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsYUFBVSxXQUFVLHdCQUNqQkYsZ0JBQUtHLGVBQWUsS0FBS0MsZUFBZSxTQUFTO0FBQUEsY0FDakRDLE9BQU87QUFBQSxjQUNQQyxVQUFVO0FBQUEsWUFDWixDQUFDLEtBSkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBQ0EsdUJBQUMsYUFBVSxXQUFVLHdCQUVoQk4sZ0JBQUtHLGVBQWVILEtBQUtFLFdBQzFCLEtBQ0FFLGVBQWUsU0FBUztBQUFBLGNBQ3hCQyxPQUFPO0FBQUEsY0FDUEMsVUFBVTtBQUFBLFlBQ1osQ0FBQyxLQVBIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxlQW5CYU4sS0FBS08sSUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvQkE7QUFBQSxRQUVKLENBQUMsS0F6Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBCQTtBQUFBLFFBQ0EsdUJBQUMsZUFDQyxpQ0FBQyxZQUNDO0FBQUEsaUNBQUMsYUFBVSxTQUFTLEdBQUcsK0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNDO0FBQUEsVUFDdEMsdUJBQUMsYUFBVSxXQUFVLHdCQUNqQnJCLGlCQUFNc0IsZUFBZSxLQUFLSixlQUFlLFNBQVM7QUFBQSxZQUNsREMsT0FBTztBQUFBLFlBQ1BDLFVBQVU7QUFBQSxVQUNaLENBQUMsS0FKSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsYUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxXQTlDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBK0NBO0FBQUEsU0E3RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThGQSxJQUVBLHVCQUFDLDBCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcUI7QUFBQSxPQXZHekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXlHQTtBQUVKO0FBQUN0QixHQW5IZUgsY0FBWTtBQUFBLFVBQ0ZNLFFBQVE7QUFBQTtBQUFBc0IsS0FEbEI1QjtBQUFZLElBQUE0QjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiZm9ybWF0RGlzdGFuY2VUb05vdyIsInB0QlIiLCJnZXRPcmRlckRldGFpbHMiLCJPcmRlclN0YXR1cyIsIkRpYWxvZ0NvbnRlbnQiLCJEaWFsb2dEZXNjcmlwdGlvbiIsIkRpYWxvZ0hlYWRlciIsIkRpYWxvZ1RpdGxlIiwiVGFibGUiLCJUYWJsZUJvZHkiLCJUYWJsZUNlbGwiLCJUYWJsZUZvb3RlciIsIlRhYmxlSGVhZCIsIlRhYmxlSGVhZGVyIiwiVGFibGVSb3ciLCJPcmRlckRldGFpbHNTa2VsZXRvbiIsIk9yZGVyRGV0YWlscyIsIm9yZGVySWQiLCJvcGVuIiwiX3MiLCJkYXRhIiwib3JkZXIiLCJ1c2VRdWVyeSIsInF1ZXJ5S2V5IiwicXVlcnlGbiIsImVuYWJsZWQiLCJzdGF0dXMiLCJjdXN0b21lciIsIm5hbWUiLCJwaG9uZSIsImVtYWlsIiwiY3JlYXRlZEF0IiwibG9jYWxlIiwib3JkZXJJdGVtcyIsIm1hcCIsIml0ZW0iLCJwcm9kdWN0IiwicXVhbnRpdHkiLCJwcmljZUluQ2VudHMiLCJ0b0xvY2FsZVN0cmluZyIsInN0eWxlIiwiY3VycmVuY3kiLCJpZCIsInRvdGFsSW5DZW50cyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsib3JkZXItZGV0YWlscy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUXVlcnkgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG5pbXBvcnQgeyBmb3JtYXREaXN0YW5jZVRvTm93IH0gZnJvbSAnZGF0ZS1mbnMnXG5pbXBvcnQgeyBwdEJSIH0gZnJvbSAnZGF0ZS1mbnMvbG9jYWxlJ1xuXG5pbXBvcnQgeyBnZXRPcmRlckRldGFpbHMgfSBmcm9tICdAL2FwaS9nZXQtb3JkZXItZGV0YWlscydcbmltcG9ydCB7IE9yZGVyU3RhdHVzIH0gZnJvbSAnQC9jb21wb25lbnRzL29yZGVyLXN0YXR1cydcbmltcG9ydCB7XG4gIERpYWxvZ0NvbnRlbnQsXG4gIERpYWxvZ0Rlc2NyaXB0aW9uLFxuICBEaWFsb2dIZWFkZXIsXG4gIERpYWxvZ1RpdGxlLFxufSBmcm9tICdAL2NvbXBvbmVudHMvdWkvZGlhbG9nJ1xuaW1wb3J0IHtcbiAgVGFibGUsXG4gIFRhYmxlQm9keSxcbiAgVGFibGVDZWxsLFxuICBUYWJsZUZvb3RlcixcbiAgVGFibGVIZWFkLFxuICBUYWJsZUhlYWRlcixcbiAgVGFibGVSb3csXG59IGZyb20gJ0AvY29tcG9uZW50cy91aS90YWJsZSdcblxuaW1wb3J0IHsgT3JkZXJEZXRhaWxzU2tlbGV0b24gfSBmcm9tICcuL29yZGVyLWRldGFpbHMtc2tlbGV0b24nXG5cbmV4cG9ydCBpbnRlcmZhY2UgT3JkZXJEZXRhaWxzUHJvcHMge1xuICBvcmRlcklkOiBzdHJpbmdcbiAgb3BlbjogYm9vbGVhblxufVxuXG5leHBvcnQgZnVuY3Rpb24gT3JkZXJEZXRhaWxzKHsgb3JkZXJJZCwgb3BlbiB9OiBPcmRlckRldGFpbHNQcm9wcykge1xuICBjb25zdCB7IGRhdGE6IG9yZGVyIH0gPSB1c2VRdWVyeSh7XG4gICAgcXVlcnlLZXk6IFsnb3JkZXInLCBvcmRlcklkXSxcbiAgICBxdWVyeUZuOiAoKSA9PiBnZXRPcmRlckRldGFpbHMoeyBvcmRlcklkIH0pLFxuICAgIGVuYWJsZWQ6IG9wZW4sXG4gIH0pXG5cbiAgcmV0dXJuIChcbiAgICA8RGlhbG9nQ29udGVudD5cbiAgICAgIDxEaWFsb2dIZWFkZXI+XG4gICAgICAgIDxEaWFsb2dUaXRsZT5QZWRpZG86IHtvcmRlcklkfTwvRGlhbG9nVGl0bGU+XG4gICAgICAgIDxEaWFsb2dEZXNjcmlwdGlvbj5EZXRhbGhlcyBkbyBwZWRpZG86PC9EaWFsb2dEZXNjcmlwdGlvbj5cbiAgICAgIDwvRGlhbG9nSGVhZGVyPlxuXG4gICAgICB7b3JkZXIgPyAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICAgICAgPFRhYmxlPlxuICAgICAgICAgICAgPFRhYmxlQm9keT5cbiAgICAgICAgICAgICAgPFRhYmxlUm93PlxuICAgICAgICAgICAgICAgIDxUYWJsZUNlbGwgY2xhc3NOYW1lPVwidGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+U3RhdHVzPC9UYWJsZUNlbGw+XG4gICAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJmbGV4IGZsZXgtMSBqdXN0aWZ5LWVuZFwiPlxuICAgICAgICAgICAgICAgICAgPE9yZGVyU3RhdHVzIHN0YXR1cz17b3JkZXIuc3RhdHVzfSAvPlxuICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICA8L1RhYmxlUm93PlxuXG4gICAgICAgICAgICAgIDxUYWJsZVJvdz5cbiAgICAgICAgICAgICAgICA8VGFibGVDZWxsIGNsYXNzTmFtZT1cInRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPkNsaWVudGU8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICA8VGFibGVDZWxsIGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmRcIj5cbiAgICAgICAgICAgICAgICAgIHtvcmRlci5jdXN0b21lci5uYW1lfVxuICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICA8L1RhYmxlUm93PlxuXG4gICAgICAgICAgICAgIDxUYWJsZVJvdz5cbiAgICAgICAgICAgICAgICA8VGFibGVDZWxsIGNsYXNzTmFtZT1cInRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAgICAgVGVsZWZvbmVcbiAgICAgICAgICAgICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICA8VGFibGVDZWxsIGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmRcIj5cbiAgICAgICAgICAgICAgICAgIHtvcmRlci5jdXN0b21lci5waG9uZSA/PyAnTsOjbyBpbmZvcm1hZG8nfVxuICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICA8L1RhYmxlUm93PlxuXG4gICAgICAgICAgICAgIDxUYWJsZVJvdz5cbiAgICAgICAgICAgICAgICA8VGFibGVDZWxsIGNsYXNzTmFtZT1cInRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPkUtbWFpbDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgIDxUYWJsZUNlbGwgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZFwiPlxuICAgICAgICAgICAgICAgICAge29yZGVyLmN1c3RvbWVyLmVtYWlsfVxuICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICA8L1RhYmxlUm93PlxuXG4gICAgICAgICAgICAgIDxUYWJsZVJvdz5cbiAgICAgICAgICAgICAgICA8VGFibGVDZWxsIGNsYXNzTmFtZT1cInRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAgICAgUmVhbGl6YWRvIGjDoVxuICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgIDxUYWJsZUNlbGwgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZFwiPlxuICAgICAgICAgICAgICAgICAge2Zvcm1hdERpc3RhbmNlVG9Ob3cob3JkZXIuY3JlYXRlZEF0LCB7XG4gICAgICAgICAgICAgICAgICAgIGxvY2FsZTogcHRCUixcbiAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICA8L1RhYmxlUm93PlxuICAgICAgICAgICAgPC9UYWJsZUJvZHk+XG4gICAgICAgICAgPC9UYWJsZT5cblxuICAgICAgICAgIDxUYWJsZT5cbiAgICAgICAgICAgIDxUYWJsZUhlYWRlcj5cbiAgICAgICAgICAgICAgPFRhYmxlUm93PlxuICAgICAgICAgICAgICAgIDxUYWJsZUhlYWQ+UHJvZHV0bzwvVGFibGVIZWFkPlxuICAgICAgICAgICAgICAgIDxUYWJsZUhlYWQgY2xhc3NOYW1lPVwidGV4dC1yaWdodFwiPlF0ZC48L1RhYmxlSGVhZD5cbiAgICAgICAgICAgICAgICA8VGFibGVIZWFkIGNsYXNzTmFtZT1cInRleHQtcmlnaHRcIj5QcmXDp288L1RhYmxlSGVhZD5cbiAgICAgICAgICAgICAgICA8VGFibGVIZWFkIGNsYXNzTmFtZT1cInRleHQtcmlnaHRcIj5TdWJ0b3RhbDwvVGFibGVIZWFkPlxuICAgICAgICAgICAgICA8L1RhYmxlUm93PlxuICAgICAgICAgICAgPC9UYWJsZUhlYWRlcj5cbiAgICAgICAgICAgIDxUYWJsZUJvZHk+XG4gICAgICAgICAgICAgIHtvcmRlci5vcmRlckl0ZW1zLm1hcCgoaXRlbSkgPT4ge1xuICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICA8VGFibGVSb3cga2V5PXtpdGVtLmlkfT5cbiAgICAgICAgICAgICAgICAgICAgPFRhYmxlQ2VsbD57aXRlbS5wcm9kdWN0Lm5hbWV9PC9UYWJsZUNlbGw+XG4gICAgICAgICAgICAgICAgICAgIDxUYWJsZUNlbGwgY2xhc3NOYW1lPVwidGV4dC1yaWdodFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnF1YW50aXR5fVxuICAgICAgICAgICAgICAgICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0IGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICAgICAgICAgIHsoaXRlbS5wcmljZUluQ2VudHMgLyAxMDApLnRvTG9jYWxlU3RyaW5nKCdwdC1CUicsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlOiAnY3VycmVuY3knLFxuICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVuY3k6ICdCUkwnLFxuICAgICAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0IGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICAgICAgICAgIHsoXG4gICAgICAgICAgICAgICAgICAgICAgICAoaXRlbS5wcmljZUluQ2VudHMgKiBpdGVtLnF1YW50aXR5KSAvXG4gICAgICAgICAgICAgICAgICAgICAgICAxMDBcbiAgICAgICAgICAgICAgICAgICAgICApLnRvTG9jYWxlU3RyaW5nKCdwdC1CUicsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlOiAnY3VycmVuY3knLFxuICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVuY3k6ICdCUkwnLFxuICAgICAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICAgIDwvVGFibGVSb3c+XG4gICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgIDwvVGFibGVCb2R5PlxuICAgICAgICAgICAgPFRhYmxlRm9vdGVyPlxuICAgICAgICAgICAgICA8VGFibGVSb3c+XG4gICAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBjb2xTcGFuPXszfT5Ub3RhbCBkbyBwZWRpZG88L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICA8VGFibGVDZWxsIGNsYXNzTmFtZT1cInRleHQtcmlnaHQgZm9udC1tb25vXCI+XG4gICAgICAgICAgICAgICAgICB7KG9yZGVyLnRvdGFsSW5DZW50cyAvIDEwMCkudG9Mb2NhbGVTdHJpbmcoJ3B0LUJSJywge1xuICAgICAgICAgICAgICAgICAgICBzdHlsZTogJ2N1cnJlbmN5JyxcbiAgICAgICAgICAgICAgICAgICAgY3VycmVuY3k6ICdCUkwnLFxuICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgPC9UYWJsZUNlbGw+XG4gICAgICAgICAgICAgIDwvVGFibGVSb3c+XG4gICAgICAgICAgICA8L1RhYmxlRm9vdGVyPlxuICAgICAgICAgIDwvVGFibGU+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKSA6IChcbiAgICAgICAgPE9yZGVyRGV0YWlsc1NrZWxldG9uIC8+XG4gICAgICApfVxuICAgIDwvRGlhbG9nQ29udGVudD5cbiAgKVxufVxuIl0sImZpbGUiOiIvVXNlcnMvYXJydWRheS9HaXRIdWIvcGl6emFzaG9wL3NyYy9wYWdlcy9hcHAvb3JkZXJzL29yZGVyLWRldGFpbHMudHN4In0=