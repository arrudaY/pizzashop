import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/button.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=efc33bbd"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/arruday/GitHub/pizzashop/src/components/ui/button.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Slot } from "/node_modules/.vite/deps/@radix-ui_react-slot.js?v=efc33bbd";
import { cva } from "/node_modules/.vite/deps/class-variance-authority.js?v=efc33bbd";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=efc33bbd"; const React = __vite__cjsImport5_react;
import { cn } from "/src/lib/utils.ts";
const buttonVariants = cva(
  "inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground hover:bg-primary/90",
        destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
        success: "bg-emerald-500 text-white hover:bg-emarald-500/90 dark:bg-emerald-600 dark:hover:bg-emerald-600/80",
        outline: "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
        secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline"
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-9 rounded-md px-3",
        xs: "h-8 px-2.5",
        lg: "h-11 rounded-md px-8",
        icon: "h-10 w-10"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
);
const Button = React.forwardRef(
  _c = ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return /* @__PURE__ */ jsxDEV(
      Comp,
      {
        className: cn(buttonVariants({ variant, size, className })),
        ref,
        ...props
      },
      void 0,
      false,
      {
        fileName: "/Users/arruday/GitHub/pizzashop/src/components/ui/button.tsx",
        lineNumber: 49,
        columnNumber: 5
      },
      this
    );
  }
);
_c2 = Button;
Button.displayName = "Button";
export { Button, buttonVariants };
var _c, _c2;
$RefreshReg$(_c, "Button$React.forwardRef");
$RefreshReg$(_c2, "Button");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arruday/GitHub/pizzashop/src/components/ui/button.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0RNO0FBaEROLDJCQUFxQjtBQUFzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDM0MsU0FBU0EsV0FBOEI7QUFDdkMsWUFBWUMsV0FBVztBQUV2QixTQUFTQyxVQUFVO0FBRW5CLE1BQU1DLGlCQUFpQkg7QUFBQUEsRUFDckI7QUFBQSxFQUNBO0FBQUEsSUFDRUksVUFBVTtBQUFBLE1BQ1JDLFNBQVM7QUFBQSxRQUNQQyxTQUFTO0FBQUEsUUFDVEMsYUFDRTtBQUFBLFFBQ0ZDLFNBQ0U7QUFBQSxRQUNGQyxTQUNFO0FBQUEsUUFDRkMsV0FDRTtBQUFBLFFBQ0ZDLE9BQU87QUFBQSxRQUNQQyxNQUFNO0FBQUEsTUFDUjtBQUFBLE1BQ0FDLE1BQU07QUFBQSxRQUNKUCxTQUFTO0FBQUEsUUFDVFEsSUFBSTtBQUFBLFFBQ0pDLElBQUk7QUFBQSxRQUNKQyxJQUFJO0FBQUEsUUFDSkMsTUFBTTtBQUFBLE1BQ1I7QUFBQSxJQUNGO0FBQUEsSUFDQUMsaUJBQWlCO0FBQUEsTUFDZmIsU0FBUztBQUFBLE1BQ1RRLE1BQU07QUFBQSxJQUNSO0FBQUEsRUFDRjtBQUNGO0FBUUEsTUFBTU0sU0FBU2xCLE1BQU1tQjtBQUFBQSxFQUEwQ0MsS0FDN0RBLENBQUMsRUFBRUMsV0FBV2pCLFNBQVNRLE1BQU1VLFVBQVUsT0FBTyxHQUFHQyxNQUFNLEdBQUdDLFFBQVE7QUFDaEUsVUFBTUMsT0FBT0gsVUFBVUksT0FBTztBQUM5QixXQUNFO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFXekIsR0FBR0MsZUFBZSxFQUFFRSxTQUFTUSxNQUFNUyxVQUFVLENBQUMsQ0FBQztBQUFBLFFBQzFEO0FBQUEsUUFDQSxHQUFJRTtBQUFBQTtBQUFBQSxNQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUdZO0FBQUEsRUFHaEI7QUFDRjtBQUFDSSxNQVhLVDtBQVlOQSxPQUFPVSxjQUFjO0FBRXJCLFNBQVNWLFFBQVFoQjtBQUFnQixJQUFBa0IsSUFBQU87QUFBQUUsYUFBQVQsSUFBQTtBQUFBUyxhQUFBRixLQUFBIiwibmFtZXMiOlsiY3ZhIiwiUmVhY3QiLCJjbiIsImJ1dHRvblZhcmlhbnRzIiwidmFyaWFudHMiLCJ2YXJpYW50IiwiZGVmYXVsdCIsImRlc3RydWN0aXZlIiwic3VjY2VzcyIsIm91dGxpbmUiLCJzZWNvbmRhcnkiLCJnaG9zdCIsImxpbmsiLCJzaXplIiwic20iLCJ4cyIsImxnIiwiaWNvbiIsImRlZmF1bHRWYXJpYW50cyIsIkJ1dHRvbiIsImZvcndhcmRSZWYiLCJfYyIsImNsYXNzTmFtZSIsImFzQ2hpbGQiLCJwcm9wcyIsInJlZiIsIkNvbXAiLCJTbG90IiwiX2MyIiwiZGlzcGxheU5hbWUiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJidXR0b24udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFNsb3QgfSBmcm9tICdAcmFkaXgtdWkvcmVhY3Qtc2xvdCdcbmltcG9ydCB7IGN2YSwgdHlwZSBWYXJpYW50UHJvcHMgfSBmcm9tICdjbGFzcy12YXJpYW5jZS1hdXRob3JpdHknXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCdcblxuaW1wb3J0IHsgY24gfSBmcm9tICdAL2xpYi91dGlscydcblxuY29uc3QgYnV0dG9uVmFyaWFudHMgPSBjdmEoXG4gICdpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgd2hpdGVzcGFjZS1ub3dyYXAgcm91bmRlZC1tZCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHJpbmctb2Zmc2V0LWJhY2tncm91bmQgdHJhbnNpdGlvbi1jb2xvcnMgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLW5vbmUgZm9jdXMtdmlzaWJsZTpyaW5nLTIgZm9jdXMtdmlzaWJsZTpyaW5nLXJpbmcgZm9jdXMtdmlzaWJsZTpyaW5nLW9mZnNldC0yIGRpc2FibGVkOnBvaW50ZXItZXZlbnRzLW5vbmUgZGlzYWJsZWQ6b3BhY2l0eS01MCcsXG4gIHtcbiAgICB2YXJpYW50czoge1xuICAgICAgdmFyaWFudDoge1xuICAgICAgICBkZWZhdWx0OiAnYmctcHJpbWFyeSB0ZXh0LXByaW1hcnktZm9yZWdyb3VuZCBob3ZlcjpiZy1wcmltYXJ5LzkwJyxcbiAgICAgICAgZGVzdHJ1Y3RpdmU6XG4gICAgICAgICAgJ2JnLWRlc3RydWN0aXZlIHRleHQtZGVzdHJ1Y3RpdmUtZm9yZWdyb3VuZCBob3ZlcjpiZy1kZXN0cnVjdGl2ZS85MCcsXG4gICAgICAgIHN1Y2Nlc3M6XG4gICAgICAgICAgJ2JnLWVtZXJhbGQtNTAwIHRleHQtd2hpdGUgaG92ZXI6YmctZW1hcmFsZC01MDAvOTAgZGFyazpiZy1lbWVyYWxkLTYwMCBkYXJrOmhvdmVyOmJnLWVtZXJhbGQtNjAwLzgwJyxcbiAgICAgICAgb3V0bGluZTpcbiAgICAgICAgICAnYm9yZGVyIGJvcmRlci1pbnB1dCBiZy1iYWNrZ3JvdW5kIGhvdmVyOmJnLWFjY2VudCBob3Zlcjp0ZXh0LWFjY2VudC1mb3JlZ3JvdW5kJyxcbiAgICAgICAgc2Vjb25kYXJ5OlxuICAgICAgICAgICdiZy1zZWNvbmRhcnkgdGV4dC1zZWNvbmRhcnktZm9yZWdyb3VuZCBob3ZlcjpiZy1zZWNvbmRhcnkvODAnLFxuICAgICAgICBnaG9zdDogJ2hvdmVyOmJnLWFjY2VudCBob3Zlcjp0ZXh0LWFjY2VudC1mb3JlZ3JvdW5kJyxcbiAgICAgICAgbGluazogJ3RleHQtcHJpbWFyeSB1bmRlcmxpbmUtb2Zmc2V0LTQgaG92ZXI6dW5kZXJsaW5lJyxcbiAgICAgIH0sXG4gICAgICBzaXplOiB7XG4gICAgICAgIGRlZmF1bHQ6ICdoLTEwIHB4LTQgcHktMicsXG4gICAgICAgIHNtOiAnaC05IHJvdW5kZWQtbWQgcHgtMycsXG4gICAgICAgIHhzOiAnaC04IHB4LTIuNScsXG4gICAgICAgIGxnOiAnaC0xMSByb3VuZGVkLW1kIHB4LTgnLFxuICAgICAgICBpY29uOiAnaC0xMCB3LTEwJyxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBkZWZhdWx0VmFyaWFudHM6IHtcbiAgICAgIHZhcmlhbnQ6ICdkZWZhdWx0JyxcbiAgICAgIHNpemU6ICdkZWZhdWx0JyxcbiAgICB9LFxuICB9LFxuKVxuXG5leHBvcnQgaW50ZXJmYWNlIEJ1dHRvblByb3BzXG4gIGV4dGVuZHMgUmVhY3QuQnV0dG9uSFRNTEF0dHJpYnV0ZXM8SFRNTEJ1dHRvbkVsZW1lbnQ+LFxuICAgIFZhcmlhbnRQcm9wczx0eXBlb2YgYnV0dG9uVmFyaWFudHM+IHtcbiAgYXNDaGlsZD86IGJvb2xlYW5cbn1cblxuY29uc3QgQnV0dG9uID0gUmVhY3QuZm9yd2FyZFJlZjxIVE1MQnV0dG9uRWxlbWVudCwgQnV0dG9uUHJvcHM+KFxuICAoeyBjbGFzc05hbWUsIHZhcmlhbnQsIHNpemUsIGFzQ2hpbGQgPSBmYWxzZSwgLi4ucHJvcHMgfSwgcmVmKSA9PiB7XG4gICAgY29uc3QgQ29tcCA9IGFzQ2hpbGQgPyBTbG90IDogJ2J1dHRvbidcbiAgICByZXR1cm4gKFxuICAgICAgPENvbXBcbiAgICAgICAgY2xhc3NOYW1lPXtjbihidXR0b25WYXJpYW50cyh7IHZhcmlhbnQsIHNpemUsIGNsYXNzTmFtZSB9KSl9XG4gICAgICAgIHJlZj17cmVmfVxuICAgICAgICB7Li4ucHJvcHN9XG4gICAgICAvPlxuICAgIClcbiAgfSxcbilcbkJ1dHRvbi5kaXNwbGF5TmFtZSA9ICdCdXR0b24nXG5cbmV4cG9ydCB7IEJ1dHRvbiwgYnV0dG9uVmFyaWFudHMgfVxuIl0sImZpbGUiOiIvVXNlcnMvYXJydWRheS9HaXRIdWIvcGl6emFzaG9wL3NyYy9jb21wb25lbnRzL3VpL2J1dHRvbi50c3gifQ==