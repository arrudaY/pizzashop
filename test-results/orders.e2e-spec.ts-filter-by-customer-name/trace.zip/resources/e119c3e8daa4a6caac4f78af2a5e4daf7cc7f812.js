import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/_layouts/auth.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=efc33bbd"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/arruday/GitHub/pizzashop/src/pages/_layouts/auth.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Pizza } from "/node_modules/.vite/deps/lucide-react.js?v=efc33bbd";
import { Outlet } from "/node_modules/.vite/deps/react-router-dom.js?v=efc33bbd";
export function AuthLayout() {
  return /* @__PURE__ */ jsxDEV("div", { className: "grid min-h-screen grid-cols-2 antialiased", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex h-full flex-col justify-between border-r border-foreground/5 bg-muted p-10 text-muted-foreground", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 text-lg font-medium text-foreground", children: [
        /* @__PURE__ */ jsxDEV(Pizza, { className: "h-5 w-5" }, void 0, false, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/_layouts/auth.tsx",
          lineNumber: 9,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "pizza.shop" }, void 0, false, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/_layouts/auth.tsx",
          lineNumber: 10,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/_layouts/auth.tsx",
        lineNumber: 8,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("footer", { className: "text-sm", children: [
        "Painel do parceiro © pizza.shop - ",
        (/* @__PURE__ */ new Date()).getFullYear()
      ] }, void 0, true, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/_layouts/auth.tsx",
        lineNumber: 12,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/_layouts/auth.tsx",
      lineNumber: 7,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "relative flex flex-col items-center justify-center", children: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/_layouts/auth.tsx",
      lineNumber: 18,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/_layouts/auth.tsx",
      lineNumber: 17,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/arruday/GitHub/pizzashop/src/pages/_layouts/auth.tsx",
    lineNumber: 6,
    columnNumber: 5
  }, this);
}
_c = AuthLayout;
var _c;
$RefreshReg$(_c, "AuthLayout");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arruday/GitHub/pizzashop/src/pages/_layouts/auth.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBUVU7QUFSViwyQkFBc0I7QUFBYztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDcEMsU0FBU0EsY0FBYztBQUVoQixnQkFBU0MsYUFBYTtBQUMzQixTQUNFLHVCQUFDLFNBQUksV0FBVSw2Q0FDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSx5R0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSwrREFDYjtBQUFBLCtCQUFDLFNBQU0sV0FBVSxhQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBCO0FBQUEsUUFDMUIsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQiwwQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQztBQUFBLFdBRjVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsWUFBTyxXQUFVLFdBQVM7QUFBQTtBQUFBLFNBQ2Usb0JBQUlDLEtBQUssR0FBRUMsWUFBWTtBQUFBLFdBRGpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsc0RBQ2IsaUNBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU8sS0FEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxPQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FjQTtBQUVKO0FBQUNDLEtBbEJlSDtBQUFVLElBQUFHO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJPdXRsZXQiLCJBdXRoTGF5b3V0IiwiRGF0ZSIsImdldEZ1bGxZZWFyIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJhdXRoLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBQaXp6YSB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcbmltcG9ydCB7IE91dGxldCB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5cbmV4cG9ydCBmdW5jdGlvbiBBdXRoTGF5b3V0KCkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBtaW4taC1zY3JlZW4gZ3JpZC1jb2xzLTIgYW50aWFsaWFzZWRcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLWZ1bGwgZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1yIGJvcmRlci1mb3JlZ3JvdW5kLzUgYmctbXV0ZWQgcC0xMCB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyB0ZXh0LWxnIGZvbnQtbWVkaXVtIHRleHQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgIDxQaXp6YSBjbGFzc05hbWU9XCJoLTUgdy01XCIgLz5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+cGl6emEuc2hvcDwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxmb290ZXIgY2xhc3NOYW1lPVwidGV4dC1zbVwiPlxuICAgICAgICAgIFBhaW5lbCBkbyBwYXJjZWlybyAmY29weTsgcGl6emEuc2hvcCAtIHtuZXcgRGF0ZSgpLmdldEZ1bGxZZWFyKCl9XG4gICAgICAgIDwvZm9vdGVyPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgPE91dGxldCAvPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2FycnVkYXkvR2l0SHViL3Bpenphc2hvcC9zcmMvcGFnZXMvX2xheW91dHMvYXV0aC50c3gifQ==