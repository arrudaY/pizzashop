import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/auth/sign-in.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=efc33bbd"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/arruday/GitHub/pizzashop/src/pages/auth/sign-in.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useMutation } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=efc33bbd";
import { Helmet } from "/node_modules/.vite/deps/react-helmet-async.js?v=efc33bbd";
import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=efc33bbd";
import { Link, useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=efc33bbd";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=efc33bbd";
import { z } from "/node_modules/.vite/deps/zod.js?v=efc33bbd";
import { signIn } from "/src/api/sign-in.ts";
import { Button } from "/src/components/ui/button.tsx";
import { Input } from "/src/components/ui/input.tsx";
import { Label } from "/src/components/ui/label.tsx";
const signInForm = z.object({
  email: z.string().email()
});
export function SignIn() {
  _s();
  const [searchParams] = useSearchParams();
  const {
    register,
    handleSubmit,
    formState: { isSubmitting }
  } = useForm({
    defaultValues: {
      email: searchParams.get("email") ?? ""
    }
  });
  const { mutateAsync: authenticate } = useMutation({
    mutationFn: signIn
  });
  async function handleSignIn(data) {
    try {
      await authenticate({ email: data.email });
      toast.success("Enviamos um link de autenticação para seu e-mail.", {
        action: {
          label: "Reenviar",
          onClick: () => handleSignIn(data)
        }
      });
    } catch {
      toast.error("Credenciais inválidas.");
    }
  }
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(Helmet, { title: "Login" }, void 0, false, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/auth/sign-in.tsx",
      lineNumber: 53,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p-8", children: [
      /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", asChild: true, className: "absolute right-8 top-8", children: /* @__PURE__ */ jsxDEV(Link, { to: "/sign-up", children: "Novo estabelecimento" }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/auth/sign-in.tsx",
        lineNumber: 56,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/auth/sign-in.tsx",
        lineNumber: 55,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex w-[350px] flex-col justify-center gap-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-2 text-center", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold tracking-tight", children: "Acessar painel" }, void 0, false, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/pages/auth/sign-in.tsx",
            lineNumber: 60,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-muted-foreground", children: "Acompanhe suas vendas pelo painel do parceiro!" }, void 0, false, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/pages/auth/sign-in.tsx",
            lineNumber: 63,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/auth/sign-in.tsx",
          lineNumber: 59,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit(handleSignIn), className: "space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV(Label, { htmlFor: "email", children: "Seu e-mail" }, void 0, false, {
              fileName: "/Users/arruday/GitHub/pizzashop/src/pages/auth/sign-in.tsx",
              lineNumber: 69,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(Input, { id: "email", type: "email", ...register("email") }, void 0, false, {
              fileName: "/Users/arruday/GitHub/pizzashop/src/pages/auth/sign-in.tsx",
              lineNumber: 70,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/pages/auth/sign-in.tsx",
            lineNumber: 68,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { disabled: isSubmitting, type: "submit", className: "w-full", children: "Acessar painel" }, void 0, false, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/pages/auth/sign-in.tsx",
            lineNumber: 72,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/auth/sign-in.tsx",
          lineNumber: 67,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/auth/sign-in.tsx",
        lineNumber: 58,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/auth/sign-in.tsx",
      lineNumber: 54,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/arruday/GitHub/pizzashop/src/pages/auth/sign-in.tsx",
    lineNumber: 52,
    columnNumber: 5
  }, this);
}
_s(SignIn, "l6gBc5MjCmq4qlusf52YI0BJ7b4=", false, function() {
  return [useSearchParams, useForm, useMutation];
});
_c = SignIn;
var _c;
$RefreshReg$(_c, "SignIn");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arruday/GitHub/pizzashop/src/pages/auth/sign-in.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbURJLG1CQUNFLGNBREY7MkJBbkRKO0FBQW9CLG9CQUFRLDZCQUF1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNuRCxTQUFTQSxjQUFjO0FBQ3ZCLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsTUFBTUMsdUJBQXVCO0FBQ3RDLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsU0FBUztBQUVsQixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxhQUFhO0FBRXRCLE1BQU1DLGFBQWFMLEVBQUVNLE9BQU87QUFBQSxFQUMxQkMsT0FBT1AsRUFBRVEsT0FBTyxFQUFFRCxNQUFNO0FBQzFCLENBQUM7QUFJTSxnQkFBU0UsU0FBUztBQUFBQyxLQUFBO0FBQ3ZCLFFBQU0sQ0FBQ0MsWUFBWSxJQUFJYixnQkFBZ0I7QUFFdkMsUUFBTTtBQUFBLElBQ0pjO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDLFdBQVcsRUFBRUMsYUFBYTtBQUFBLEVBQzVCLElBQUluQixRQUFvQjtBQUFBLElBQ3RCb0IsZUFBZTtBQUFBLE1BQ2JULE9BQU9JLGFBQWFNLElBQUksT0FBTyxLQUFLO0FBQUEsSUFDdEM7QUFBQSxFQUNGLENBQUM7QUFFRCxRQUFNLEVBQUVDLGFBQWFDLGFBQWEsSUFBSUMsWUFBWTtBQUFBLElBQ2hEQyxZQUFZcEI7QUFBQUEsRUFDZCxDQUFDO0FBRUQsaUJBQWVxQixhQUFhQyxNQUFrQjtBQUM1QyxRQUFJO0FBQ0YsWUFBTUosYUFBYSxFQUFFWixPQUFPZ0IsS0FBS2hCLE1BQU0sQ0FBQztBQUV4Q1IsWUFBTXlCLFFBQVEscURBQXFEO0FBQUEsUUFDakVDLFFBQVE7QUFBQSxVQUNOQyxPQUFPO0FBQUEsVUFDUEMsU0FBU0EsTUFBTUwsYUFBYUMsSUFBSTtBQUFBLFFBQ2xDO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSCxRQUFRO0FBQ054QixZQUFNNkIsTUFBTSx3QkFBd0I7QUFBQSxJQUN0QztBQUFBLEVBQ0Y7QUFFQSxTQUNFLG1DQUNFO0FBQUEsMkJBQUMsVUFBTyxPQUFNLFdBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxQjtBQUFBLElBQ3JCLHVCQUFDLFNBQUksV0FBVSxPQUNiO0FBQUEsNkJBQUMsVUFBTyxTQUFRLFNBQVEsU0FBTyxNQUFDLFdBQVUsMEJBQ3hDLGlDQUFDLFFBQUssSUFBRyxZQUFXLG9DQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdDLEtBRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGdEQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLG1DQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHlDQUF1Qyw4QkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLGlDQUErQiw4REFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFDQSx1QkFBQyxVQUFLLFVBQVVmLGFBQWFTLFlBQVksR0FBRyxXQUFVLGFBQ3BEO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxtQ0FBQyxTQUFNLFNBQVEsU0FBUSwwQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUM7QUFBQSxZQUNqQyx1QkFBQyxTQUFNLElBQUcsU0FBUSxNQUFLLFNBQVEsR0FBSVYsU0FBUyxPQUFPLEtBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFEO0FBQUEsZUFGdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsVUFBTyxVQUFVRyxjQUFjLE1BQUssVUFBUyxXQUFVLFVBQVEsOEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFdBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrQkE7QUFBQSxTQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUJBO0FBQUEsT0F6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTBCQTtBQUVKO0FBQUNMLEdBN0RlRCxRQUFNO0FBQUEsVUFDR1gsaUJBTW5CRixTQU1rQ3dCLFdBQVc7QUFBQTtBQUFBUyxLQWJuQ3BCO0FBQU0sSUFBQW9CO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJIZWxtZXQiLCJ1c2VGb3JtIiwiTGluayIsInVzZVNlYXJjaFBhcmFtcyIsInRvYXN0IiwieiIsInNpZ25JbiIsIkJ1dHRvbiIsIklucHV0IiwiTGFiZWwiLCJzaWduSW5Gb3JtIiwib2JqZWN0IiwiZW1haWwiLCJzdHJpbmciLCJTaWduSW4iLCJfcyIsInNlYXJjaFBhcmFtcyIsInJlZ2lzdGVyIiwiaGFuZGxlU3VibWl0IiwiZm9ybVN0YXRlIiwiaXNTdWJtaXR0aW5nIiwiZGVmYXVsdFZhbHVlcyIsImdldCIsIm11dGF0ZUFzeW5jIiwiYXV0aGVudGljYXRlIiwidXNlTXV0YXRpb24iLCJtdXRhdGlvbkZuIiwiaGFuZGxlU2lnbkluIiwiZGF0YSIsInN1Y2Nlc3MiLCJhY3Rpb24iLCJsYWJlbCIsIm9uQ2xpY2siLCJlcnJvciIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsic2lnbi1pbi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlTXV0YXRpb24gfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG5pbXBvcnQgeyBIZWxtZXQgfSBmcm9tICdyZWFjdC1oZWxtZXQtYXN5bmMnXG5pbXBvcnQgeyB1c2VGb3JtIH0gZnJvbSAncmVhY3QtaG9vay1mb3JtJ1xuaW1wb3J0IHsgTGluaywgdXNlU2VhcmNoUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSAnc29ubmVyJ1xuaW1wb3J0IHsgeiB9IGZyb20gJ3pvZCdcblxuaW1wb3J0IHsgc2lnbkluIH0gZnJvbSAnQC9hcGkvc2lnbi1pbidcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9idXR0b24nXG5pbXBvcnQgeyBJbnB1dCB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9pbnB1dCdcbmltcG9ydCB7IExhYmVsIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2xhYmVsJ1xuXG5jb25zdCBzaWduSW5Gb3JtID0gei5vYmplY3Qoe1xuICBlbWFpbDogei5zdHJpbmcoKS5lbWFpbCgpLFxufSlcblxudHlwZSBTaWduSW5Gb3JtID0gei5pbmZlcjx0eXBlb2Ygc2lnbkluRm9ybT5cblxuZXhwb3J0IGZ1bmN0aW9uIFNpZ25JbigpIHtcbiAgY29uc3QgW3NlYXJjaFBhcmFtc10gPSB1c2VTZWFyY2hQYXJhbXMoKVxuXG4gIGNvbnN0IHtcbiAgICByZWdpc3RlcixcbiAgICBoYW5kbGVTdWJtaXQsXG4gICAgZm9ybVN0YXRlOiB7IGlzU3VibWl0dGluZyB9LFxuICB9ID0gdXNlRm9ybTxTaWduSW5Gb3JtPih7XG4gICAgZGVmYXVsdFZhbHVlczoge1xuICAgICAgZW1haWw6IHNlYXJjaFBhcmFtcy5nZXQoJ2VtYWlsJykgPz8gJycsXG4gICAgfSxcbiAgfSlcblxuICBjb25zdCB7IG11dGF0ZUFzeW5jOiBhdXRoZW50aWNhdGUgfSA9IHVzZU11dGF0aW9uKHtcbiAgICBtdXRhdGlvbkZuOiBzaWduSW4sXG4gIH0pXG5cbiAgYXN5bmMgZnVuY3Rpb24gaGFuZGxlU2lnbkluKGRhdGE6IFNpZ25JbkZvcm0pIHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgYXV0aGVudGljYXRlKHsgZW1haWw6IGRhdGEuZW1haWwgfSlcblxuICAgICAgdG9hc3Quc3VjY2VzcygnRW52aWFtb3MgdW0gbGluayBkZSBhdXRlbnRpY2HDp8OjbyBwYXJhIHNldSBlLW1haWwuJywge1xuICAgICAgICBhY3Rpb246IHtcbiAgICAgICAgICBsYWJlbDogJ1JlZW52aWFyJyxcbiAgICAgICAgICBvbkNsaWNrOiAoKSA9PiBoYW5kbGVTaWduSW4oZGF0YSksXG4gICAgICAgIH0sXG4gICAgICB9KVxuICAgIH0gY2F0Y2gge1xuICAgICAgdG9hc3QuZXJyb3IoJ0NyZWRlbmNpYWlzIGludsOhbGlkYXMuJylcbiAgICB9XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8SGVsbWV0IHRpdGxlPVwiTG9naW5cIiAvPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLThcIj5cbiAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIiBhc0NoaWxkIGNsYXNzTmFtZT1cImFic29sdXRlIHJpZ2h0LTggdG9wLThcIj5cbiAgICAgICAgICA8TGluayB0bz1cIi9zaWduLXVwXCI+Tm92byBlc3RhYmVsZWNpbWVudG88L0xpbms+XG4gICAgICAgIDwvQnV0dG9uPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggdy1bMzUwcHhdIGZsZXgtY29sIGp1c3RpZnktY2VudGVyIGdhcC02XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0yIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodFwiPlxuICAgICAgICAgICAgICBBY2Vzc2FyIHBhaW5lbFxuICAgICAgICAgICAgPC9oMT5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgIEFjb21wYW5oZSBzdWFzIHZlbmRhcyBwZWxvIHBhaW5lbCBkbyBwYXJjZWlybyFcbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0KGhhbmRsZVNpZ25Jbil9IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgPExhYmVsIGh0bWxGb3I9XCJlbWFpbFwiPlNldSBlLW1haWw8L0xhYmVsPlxuICAgICAgICAgICAgICA8SW5wdXQgaWQ9XCJlbWFpbFwiIHR5cGU9XCJlbWFpbFwiIHsuLi5yZWdpc3RlcignZW1haWwnKX0gLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPEJ1dHRvbiBkaXNhYmxlZD17aXNTdWJtaXR0aW5nfSB0eXBlPVwic3VibWl0XCIgY2xhc3NOYW1lPVwidy1mdWxsXCI+XG4gICAgICAgICAgICAgIEFjZXNzYXIgcGFpbmVsXG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC8+XG4gIClcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2FycnVkYXkvR2l0SHViL3Bpenphc2hvcC9zcmMvcGFnZXMvYXV0aC9zaWduLWluLnRzeCJ9