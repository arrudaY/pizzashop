import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/store-profile-dialog.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=efc33bbd"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/arruday/GitHub/pizzashop/src/components/store-profile-dialog.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=efc33bbd";
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=efc33bbd";
import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=efc33bbd";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=efc33bbd";
import { z } from "/node_modules/.vite/deps/zod.js?v=efc33bbd";
import {
  getMenageRestaurant
} from "/src/api/get-managed-restaurant.ts";
import { updateProfile } from "/src/api/update-profile.ts";
import { Button } from "/src/components/ui/button.tsx";
import {
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from "/src/components/ui/dialog.tsx";
import { Input } from "/src/components/ui/input.tsx";
import { Label } from "/src/components/ui/label.tsx";
import { Textarea } from "/src/components/ui/textarea.tsx";
const storeProfileSchema = z.object({
  name: z.string().min(1),
  description: z.string().nullable()
});
export function StoreProfileDialog() {
  _s();
  const queryClient = useQueryClient();
  const { data: managedRestaurant } = useQuery({
    queryKey: ["managed-restaurant"],
    queryFn: getMenageRestaurant,
    staleTime: Infinity
  });
  const {
    register,
    handleSubmit,
    formState: { isSubmitting }
  } = useForm({
    resolver: zodResolver(storeProfileSchema),
    values: {
      name: managedRestaurant?.name ?? "",
      description: managedRestaurant?.description ?? ""
    }
  });
  function updateManagedRestaurantCache({
    name,
    description
  }) {
    const cached = queryClient.getQueryData(
      [
        "managed-restaurant"
      ]
    );
    if (cached) {
      queryClient.setQueryData(
        ["managed-restaurant"],
        {
          ...cached,
          name,
          description
        }
      );
    }
    return { cached };
  }
  const { mutateAsync: updateProfileFn } = useMutation({
    mutationFn: updateProfile,
    onMutate({ name, description }) {
      const { cached } = updateManagedRestaurantCache({ name, description });
      return { previousProfile: cached };
    },
    onError(_, __, context) {
      if (context?.previousProfile) {
        updateManagedRestaurantCache(context.previousProfile);
      }
    }
  });
  async function handleUpdateProfile(data) {
    try {
      await updateProfileFn({
        name: data.name,
        description: data.description ?? ""
      });
      toast.success("Perfil atualizado com sucesso.");
    } catch {
      toast.error("Falha ao atualizar o perfil, tente novamente.");
    }
  }
  return /* @__PURE__ */ jsxDEV(DialogContent, { children: [
    /* @__PURE__ */ jsxDEV(DialogHeader, { children: [
      /* @__PURE__ */ jsxDEV(DialogTitle, { children: "Perfil da loja" }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/components/store-profile-dialog.tsx",
        lineNumber: 103,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DialogDescription, { children: "Atualize as informações do seu estabelecimento visíveis ao seu cliente" }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/components/store-profile-dialog.tsx",
        lineNumber: 104,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/components/store-profile-dialog.tsx",
      lineNumber: 102,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit(handleUpdateProfile), children: [
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-4 py-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-4 items-center gap-4", children: [
          /* @__PURE__ */ jsxDEV(Label, { className: "text-right", htmlFor: "name", children: "Nome" }, void 0, false, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/components/store-profile-dialog.tsx",
            lineNumber: 112,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { className: "col-span-3", id: "name", ...register("name") }, void 0, false, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/components/store-profile-dialog.tsx",
            lineNumber: 115,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/components/store-profile-dialog.tsx",
          lineNumber: 111,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-4 items-center gap-4", children: [
          /* @__PURE__ */ jsxDEV(Label, { className: "text-right", htmlFor: "description", children: "Descrição" }, void 0, false, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/components/store-profile-dialog.tsx",
            lineNumber: 118,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Textarea,
            {
              className: "col-span-3",
              id: "description",
              ...register("description")
            },
            void 0,
            false,
            {
              fileName: "/Users/arruday/GitHub/pizzashop/src/components/store-profile-dialog.tsx",
              lineNumber: 121,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/components/store-profile-dialog.tsx",
          lineNumber: 117,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/components/store-profile-dialog.tsx",
        lineNumber: 110,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DialogFooter, { children: [
        /* @__PURE__ */ jsxDEV(DialogClose, { asChild: true, children: /* @__PURE__ */ jsxDEV(Button, { type: "button", variant: "ghost", children: "Cancelar" }, void 0, false, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/components/store-profile-dialog.tsx",
          lineNumber: 130,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/components/store-profile-dialog.tsx",
          lineNumber: 129,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { type: "submit", variant: "success", disabled: isSubmitting, children: "Salvar" }, void 0, false, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/components/store-profile-dialog.tsx",
          lineNumber: 135,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/components/store-profile-dialog.tsx",
        lineNumber: 128,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/components/store-profile-dialog.tsx",
      lineNumber: 109,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/arruday/GitHub/pizzashop/src/components/store-profile-dialog.tsx",
    lineNumber: 101,
    columnNumber: 5
  }, this);
}
_s(StoreProfileDialog, "jK6TgGd2ajBFfdSbR3yGKWsI/nw=", false, function() {
  return [useQueryClient, useQuery, useForm, useMutation];
});
_c = StoreProfileDialog;
var _c;
$RefreshReg$(_c, "StoreProfileDialog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arruday/GitHub/pizzashop/src/components/store-profile-dialog.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0dROzJCQXRHUjtBQUFvQixvQkFBUSw2QkFBeUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDckQsU0FBU0EsYUFBYUMsVUFBVUMsc0JBQXNCO0FBQ3RELFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxTQUFTO0FBRWxCO0FBQUEsRUFFRUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLHFCQUFxQjtBQUU5QixTQUFTQyxjQUFjO0FBQ3ZCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxnQkFBZ0I7QUFFekIsTUFBTUMscUJBQXFCYixFQUFFYyxPQUFPO0FBQUEsRUFDbENDLE1BQU1mLEVBQUVnQixPQUFPLEVBQUVDLElBQUksQ0FBQztBQUFBLEVBQ3RCQyxhQUFhbEIsRUFBRWdCLE9BQU8sRUFBRUcsU0FBUztBQUNuQyxDQUFDO0FBSU0sZ0JBQVNDLHFCQUFxQjtBQUFBQyxLQUFBO0FBQ25DLFFBQU1DLGNBQWN6QixlQUFlO0FBRW5DLFFBQU0sRUFBRTBCLE1BQU1DLGtCQUFrQixJQUFJNUIsU0FBUztBQUFBLElBQzNDNkIsVUFBVSxDQUFDLG9CQUFvQjtBQUFBLElBQy9CQyxTQUFTekI7QUFBQUEsSUFDVDBCLFdBQVdDO0FBQUFBLEVBQ2IsQ0FBQztBQUVELFFBQU07QUFBQSxJQUNKQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQyxXQUFXLEVBQUVDLGFBQWE7QUFBQSxFQUM1QixJQUFJbEMsUUFBNEI7QUFBQSxJQUM5Qm1DLFVBQVVDLFlBQVlyQixrQkFBa0I7QUFBQSxJQUN4Q3NCLFFBQVE7QUFBQSxNQUNOcEIsTUFBTVMsbUJBQW1CVCxRQUFRO0FBQUEsTUFDakNHLGFBQWFNLG1CQUFtQk4sZUFBZTtBQUFBLElBQ2pEO0FBQUEsRUFDRixDQUFDO0FBRUQsV0FBU2tCLDZCQUE2QjtBQUFBLElBQ3BDckI7QUFBQUEsSUFDQUc7QUFBQUEsRUFDa0IsR0FBRztBQUNyQixVQUFNbUIsU0FBU2YsWUFBWWdCO0FBQUFBLE1BQTJDO0FBQUEsUUFDcEU7QUFBQSxNQUFvQjtBQUFBLElBQ3JCO0FBRUQsUUFBSUQsUUFBUTtBQUNWZixrQkFBWWlCO0FBQUFBLFFBQ1YsQ0FBQyxvQkFBb0I7QUFBQSxRQUNyQjtBQUFBLFVBQ0UsR0FBR0Y7QUFBQUEsVUFDSHRCO0FBQUFBLFVBQ0FHO0FBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFdBQU8sRUFBRW1CLE9BQU87QUFBQSxFQUNsQjtBQUVBLFFBQU0sRUFBRUcsYUFBYUMsZ0JBQWdCLElBQUk5QyxZQUFZO0FBQUEsSUFDbkQrQyxZQUFZeEM7QUFBQUEsSUFDWnlDLFNBQVMsRUFBRTVCLE1BQU1HLFlBQVksR0FBRztBQUM5QixZQUFNLEVBQUVtQixPQUFPLElBQUlELDZCQUE2QixFQUFFckIsTUFBTUcsWUFBWSxDQUFDO0FBQ3JFLGFBQU8sRUFBRTBCLGlCQUFpQlAsT0FBTztBQUFBLElBQ25DO0FBQUEsSUFDQVEsUUFBUUMsR0FBR0MsSUFBSUMsU0FBUztBQUN0QixVQUFJQSxTQUFTSixpQkFBaUI7QUFDNUJSLHFDQUE2QlksUUFBUUosZUFBZTtBQUFBLE1BQ3REO0FBQUEsSUFDRjtBQUFBLEVBQ0YsQ0FBQztBQUVELGlCQUFlSyxvQkFBb0IxQixNQUEwQjtBQUMzRCxRQUFJO0FBQ0YsWUFBTWtCLGdCQUFnQjtBQUFBLFFBQ3BCMUIsTUFBTVEsS0FBS1I7QUFBQUEsUUFDWEcsYUFBYUssS0FBS0wsZUFBZTtBQUFBLE1BQ25DLENBQUM7QUFDRG5CLFlBQU1tRCxRQUFRLGdDQUFnQztBQUFBLElBQ2hELFFBQVE7QUFDTm5ELFlBQU1vRCxNQUFNLCtDQUErQztBQUFBLElBQzdEO0FBQUEsRUFDRjtBQUVBLFNBQ0UsdUJBQUMsaUJBQ0M7QUFBQSwyQkFBQyxnQkFDQztBQUFBLDZCQUFDLGVBQVksOEJBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyQjtBQUFBLE1BQzNCLHVCQUFDLHFCQUFpQixzRkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxJQUVBLHVCQUFDLFVBQUssVUFBVXJCLGFBQWFtQixtQkFBbUIsR0FDOUM7QUFBQSw2QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsdUNBQ2I7QUFBQSxpQ0FBQyxTQUFNLFdBQVUsY0FBYSxTQUFRLFFBQU0sb0JBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFNBQU0sV0FBVSxjQUFhLElBQUcsUUFBTyxHQUFJcEIsU0FBUyxNQUFNLEtBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZEO0FBQUEsYUFKL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsdUNBQ2I7QUFBQSxpQ0FBQyxTQUFNLFdBQVUsY0FBYSxTQUFRLGVBQWEseUJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixJQUFHO0FBQUEsY0FDSCxHQUFJQSxTQUFTLGFBQWE7QUFBQTtBQUFBLFlBSDVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUc4QjtBQUFBLGFBUGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFdBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpQkE7QUFBQSxNQUNBLHVCQUFDLGdCQUNDO0FBQUEsK0JBQUMsZUFBWSxTQUFPLE1BQ2xCLGlDQUFDLFVBQU8sTUFBSyxVQUFTLFNBQVEsU0FBTyx3QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsUUFFQSx1QkFBQyxVQUFPLE1BQUssVUFBUyxTQUFRLFdBQVUsVUFBVUcsY0FBYSxzQkFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxTQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOEJBO0FBQUEsT0F0Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVDQTtBQUVKO0FBQUNYLEdBN0dlRCxvQkFBa0I7QUFBQSxVQUNadkIsZ0JBRWdCRCxVQVVoQ0UsU0E2QnFDSCxXQUFXO0FBQUE7QUFBQXlELEtBMUN0Q2hDO0FBQWtCLElBQUFnQztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlTXV0YXRpb24iLCJ1c2VRdWVyeSIsInVzZVF1ZXJ5Q2xpZW50IiwidXNlRm9ybSIsInRvYXN0IiwieiIsImdldE1lbmFnZVJlc3RhdXJhbnQiLCJ1cGRhdGVQcm9maWxlIiwiQnV0dG9uIiwiRGlhbG9nQ2xvc2UiLCJEaWFsb2dDb250ZW50IiwiRGlhbG9nRGVzY3JpcHRpb24iLCJEaWFsb2dGb290ZXIiLCJEaWFsb2dIZWFkZXIiLCJEaWFsb2dUaXRsZSIsIklucHV0IiwiTGFiZWwiLCJUZXh0YXJlYSIsInN0b3JlUHJvZmlsZVNjaGVtYSIsIm9iamVjdCIsIm5hbWUiLCJzdHJpbmciLCJtaW4iLCJkZXNjcmlwdGlvbiIsIm51bGxhYmxlIiwiU3RvcmVQcm9maWxlRGlhbG9nIiwiX3MiLCJxdWVyeUNsaWVudCIsImRhdGEiLCJtYW5hZ2VkUmVzdGF1cmFudCIsInF1ZXJ5S2V5IiwicXVlcnlGbiIsInN0YWxlVGltZSIsIkluZmluaXR5IiwicmVnaXN0ZXIiLCJoYW5kbGVTdWJtaXQiLCJmb3JtU3RhdGUiLCJpc1N1Ym1pdHRpbmciLCJyZXNvbHZlciIsInpvZFJlc29sdmVyIiwidmFsdWVzIiwidXBkYXRlTWFuYWdlZFJlc3RhdXJhbnRDYWNoZSIsImNhY2hlZCIsImdldFF1ZXJ5RGF0YSIsInNldFF1ZXJ5RGF0YSIsIm11dGF0ZUFzeW5jIiwidXBkYXRlUHJvZmlsZUZuIiwibXV0YXRpb25GbiIsIm9uTXV0YXRlIiwicHJldmlvdXNQcm9maWxlIiwib25FcnJvciIsIl8iLCJfXyIsImNvbnRleHQiLCJoYW5kbGVVcGRhdGVQcm9maWxlIiwic3VjY2VzcyIsImVycm9yIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJzdG9yZS1wcm9maWxlLWRpYWxvZy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgem9kUmVzb2x2ZXIgfSBmcm9tICdAaG9va2Zvcm0vcmVzb2x2ZXJzL3pvZCdcbmltcG9ydCB7IHVzZU11dGF0aW9uLCB1c2VRdWVyeSwgdXNlUXVlcnlDbGllbnQgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG5pbXBvcnQgeyB1c2VGb3JtIH0gZnJvbSAncmVhY3QtaG9vay1mb3JtJ1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tICdzb25uZXInXG5pbXBvcnQgeyB6IH0gZnJvbSAnem9kJ1xuXG5pbXBvcnQge1xuICBHZXRNYW5hZ2VkUmVzdGF1cmFudFJlc3BvbnNlLFxuICBnZXRNZW5hZ2VSZXN0YXVyYW50LFxufSBmcm9tICdAL2FwaS9nZXQtbWFuYWdlZC1yZXN0YXVyYW50J1xuaW1wb3J0IHsgdXBkYXRlUHJvZmlsZSB9IGZyb20gJ0AvYXBpL3VwZGF0ZS1wcm9maWxlJ1xuXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICcuL3VpL2J1dHRvbidcbmltcG9ydCB7XG4gIERpYWxvZ0Nsb3NlLFxuICBEaWFsb2dDb250ZW50LFxuICBEaWFsb2dEZXNjcmlwdGlvbixcbiAgRGlhbG9nRm9vdGVyLFxuICBEaWFsb2dIZWFkZXIsXG4gIERpYWxvZ1RpdGxlLFxufSBmcm9tICcuL3VpL2RpYWxvZydcbmltcG9ydCB7IElucHV0IH0gZnJvbSAnLi91aS9pbnB1dCdcbmltcG9ydCB7IExhYmVsIH0gZnJvbSAnLi91aS9sYWJlbCdcbmltcG9ydCB7IFRleHRhcmVhIH0gZnJvbSAnLi91aS90ZXh0YXJlYSdcblxuY29uc3Qgc3RvcmVQcm9maWxlU2NoZW1hID0gei5vYmplY3Qoe1xuICBuYW1lOiB6LnN0cmluZygpLm1pbigxKSxcbiAgZGVzY3JpcHRpb246IHouc3RyaW5nKCkubnVsbGFibGUoKSxcbn0pXG5cbnR5cGUgU3RvcmVQcm9maWxlU2NoZW1hID0gei5pbmZlcjx0eXBlb2Ygc3RvcmVQcm9maWxlU2NoZW1hPlxuXG5leHBvcnQgZnVuY3Rpb24gU3RvcmVQcm9maWxlRGlhbG9nKCkge1xuICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KClcblxuICBjb25zdCB7IGRhdGE6IG1hbmFnZWRSZXN0YXVyYW50IH0gPSB1c2VRdWVyeSh7XG4gICAgcXVlcnlLZXk6IFsnbWFuYWdlZC1yZXN0YXVyYW50J10sXG4gICAgcXVlcnlGbjogZ2V0TWVuYWdlUmVzdGF1cmFudCxcbiAgICBzdGFsZVRpbWU6IEluZmluaXR5LFxuICB9KVxuXG4gIGNvbnN0IHtcbiAgICByZWdpc3RlcixcbiAgICBoYW5kbGVTdWJtaXQsXG4gICAgZm9ybVN0YXRlOiB7IGlzU3VibWl0dGluZyB9LFxuICB9ID0gdXNlRm9ybTxTdG9yZVByb2ZpbGVTY2hlbWE+KHtcbiAgICByZXNvbHZlcjogem9kUmVzb2x2ZXIoc3RvcmVQcm9maWxlU2NoZW1hKSxcbiAgICB2YWx1ZXM6IHtcbiAgICAgIG5hbWU6IG1hbmFnZWRSZXN0YXVyYW50Py5uYW1lID8/ICcnLFxuICAgICAgZGVzY3JpcHRpb246IG1hbmFnZWRSZXN0YXVyYW50Py5kZXNjcmlwdGlvbiA/PyAnJyxcbiAgICB9LFxuICB9KVxuXG4gIGZ1bmN0aW9uIHVwZGF0ZU1hbmFnZWRSZXN0YXVyYW50Q2FjaGUoe1xuICAgIG5hbWUsXG4gICAgZGVzY3JpcHRpb24sXG4gIH06IFN0b3JlUHJvZmlsZVNjaGVtYSkge1xuICAgIGNvbnN0IGNhY2hlZCA9IHF1ZXJ5Q2xpZW50LmdldFF1ZXJ5RGF0YTxHZXRNYW5hZ2VkUmVzdGF1cmFudFJlc3BvbnNlPihbXG4gICAgICAnbWFuYWdlZC1yZXN0YXVyYW50JyxcbiAgICBdKVxuXG4gICAgaWYgKGNhY2hlZCkge1xuICAgICAgcXVlcnlDbGllbnQuc2V0UXVlcnlEYXRhPEdldE1hbmFnZWRSZXN0YXVyYW50UmVzcG9uc2U+KFxuICAgICAgICBbJ21hbmFnZWQtcmVzdGF1cmFudCddLFxuICAgICAgICB7XG4gICAgICAgICAgLi4uY2FjaGVkLFxuICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgZGVzY3JpcHRpb24sXG4gICAgICAgIH0sXG4gICAgICApXG4gICAgfVxuICAgIHJldHVybiB7IGNhY2hlZCB9XG4gIH1cblxuICBjb25zdCB7IG11dGF0ZUFzeW5jOiB1cGRhdGVQcm9maWxlRm4gfSA9IHVzZU11dGF0aW9uKHtcbiAgICBtdXRhdGlvbkZuOiB1cGRhdGVQcm9maWxlLFxuICAgIG9uTXV0YXRlKHsgbmFtZSwgZGVzY3JpcHRpb24gfSkge1xuICAgICAgY29uc3QgeyBjYWNoZWQgfSA9IHVwZGF0ZU1hbmFnZWRSZXN0YXVyYW50Q2FjaGUoeyBuYW1lLCBkZXNjcmlwdGlvbiB9KVxuICAgICAgcmV0dXJuIHsgcHJldmlvdXNQcm9maWxlOiBjYWNoZWQgfVxuICAgIH0sXG4gICAgb25FcnJvcihfLCBfXywgY29udGV4dCkge1xuICAgICAgaWYgKGNvbnRleHQ/LnByZXZpb3VzUHJvZmlsZSkge1xuICAgICAgICB1cGRhdGVNYW5hZ2VkUmVzdGF1cmFudENhY2hlKGNvbnRleHQucHJldmlvdXNQcm9maWxlKVxuICAgICAgfVxuICAgIH0sXG4gIH0pXG5cbiAgYXN5bmMgZnVuY3Rpb24gaGFuZGxlVXBkYXRlUHJvZmlsZShkYXRhOiBTdG9yZVByb2ZpbGVTY2hlbWEpIHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgdXBkYXRlUHJvZmlsZUZuKHtcbiAgICAgICAgbmFtZTogZGF0YS5uYW1lLFxuICAgICAgICBkZXNjcmlwdGlvbjogZGF0YS5kZXNjcmlwdGlvbiA/PyAnJyxcbiAgICAgIH0pXG4gICAgICB0b2FzdC5zdWNjZXNzKCdQZXJmaWwgYXR1YWxpemFkbyBjb20gc3VjZXNzby4nKVxuICAgIH0gY2F0Y2gge1xuICAgICAgdG9hc3QuZXJyb3IoJ0ZhbGhhIGFvIGF0dWFsaXphciBvIHBlcmZpbCwgdGVudGUgbm92YW1lbnRlLicpXG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8RGlhbG9nQ29udGVudD5cbiAgICAgIDxEaWFsb2dIZWFkZXI+XG4gICAgICAgIDxEaWFsb2dUaXRsZT5QZXJmaWwgZGEgbG9qYTwvRGlhbG9nVGl0bGU+XG4gICAgICAgIDxEaWFsb2dEZXNjcmlwdGlvbj5cbiAgICAgICAgICBBdHVhbGl6ZSBhcyBpbmZvcm1hw6fDtWVzIGRvIHNldSBlc3RhYmVsZWNpbWVudG8gdmlzw612ZWlzIGFvIHNldSBjbGllbnRlXG4gICAgICAgIDwvRGlhbG9nRGVzY3JpcHRpb24+XG4gICAgICA8L0RpYWxvZ0hlYWRlcj5cblxuICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdChoYW5kbGVVcGRhdGVQcm9maWxlKX0+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00IHB5LTRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTQgaXRlbXMtY2VudGVyIGdhcC00XCI+XG4gICAgICAgICAgICA8TGFiZWwgY2xhc3NOYW1lPVwidGV4dC1yaWdodFwiIGh0bWxGb3I9XCJuYW1lXCI+XG4gICAgICAgICAgICAgIE5vbWVcbiAgICAgICAgICAgIDwvTGFiZWw+XG4gICAgICAgICAgICA8SW5wdXQgY2xhc3NOYW1lPVwiY29sLXNwYW4tM1wiIGlkPVwibmFtZVwiIHsuLi5yZWdpc3RlcignbmFtZScpfSAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtNCBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cbiAgICAgICAgICAgIDxMYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0XCIgaHRtbEZvcj1cImRlc2NyaXB0aW9uXCI+XG4gICAgICAgICAgICAgIERlc2NyacOnw6NvXG4gICAgICAgICAgICA8L0xhYmVsPlxuICAgICAgICAgICAgPFRleHRhcmVhXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNvbC1zcGFuLTNcIlxuICAgICAgICAgICAgICBpZD1cImRlc2NyaXB0aW9uXCJcbiAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyKCdkZXNjcmlwdGlvbicpfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxEaWFsb2dGb290ZXI+XG4gICAgICAgICAgPERpYWxvZ0Nsb3NlIGFzQ2hpbGQ+XG4gICAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJidXR0b25cIiB2YXJpYW50PVwiZ2hvc3RcIj5cbiAgICAgICAgICAgICAgQ2FuY2VsYXJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDwvRGlhbG9nQ2xvc2U+XG5cbiAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJzdWJtaXRcIiB2YXJpYW50PVwic3VjY2Vzc1wiIGRpc2FibGVkPXtpc1N1Ym1pdHRpbmd9PlxuICAgICAgICAgICAgU2FsdmFyXG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgIDwvRGlhbG9nRm9vdGVyPlxuICAgICAgPC9mb3JtPlxuICAgIDwvRGlhbG9nQ29udGVudD5cbiAgKVxufVxuIl0sImZpbGUiOiIvVXNlcnMvYXJydWRheS9HaXRIdWIvcGl6emFzaG9wL3NyYy9jb21wb25lbnRzL3N0b3JlLXByb2ZpbGUtZGlhbG9nLnRzeCJ9