import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/theme/theme-provider.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7d79b549"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/arruday/Downloads/pizzashop/src/components/theme/theme-provider.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7d79b549"; const createContext = __vite__cjsImport3_react["createContext"]; const useContext = __vite__cjsImport3_react["useContext"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]




;
const initialState = {
  theme: "system",
  setTheme: () => null
};
const ThemeProviderContext = createContext(initialState);
export function ThemeProvider({
  children,
  defaultTheme = "system",
  storageKey = "vite-ui-theme",
  ...props
}) {
  _s();
  const [theme, setTheme] = useState(
    () => localStorage.getItem(storageKey) || defaultTheme
  );
  useEffect(() => {
    const root = window.document.documentElement;
    root.classList.remove("light", "dark");
    if (theme === "system") {
      const systemTheme = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
      root.classList.add(systemTheme);
      return;
    }
    root.classList.add(theme);
  }, [theme]);
  const value = {
    theme,
    setTheme: (theme2) => {
      localStorage.setItem(storageKey, theme2);
      setTheme(theme2);
    }
  };
  return /* @__PURE__ */ jsxDEV(ThemeProviderContext.Provider, { ...props, value, children }, void 0, false, {
    fileName: "/Users/arruday/Downloads/pizzashop/src/components/theme/theme-provider.tsx",
    lineNumber: 66,
    columnNumber: 5
  }, this);
}
_s(ThemeProvider, "YkY4D08WntVjXLroWjAGi4sfNRs=");
_c = ThemeProvider;
export const useTheme = () => {
  _s2();
  const context = useContext(ThemeProviderContext);
  if (context === void 0)
    throw new Error("useTheme must be used within a ThemeProvider");
  return context;
};
_s2(useTheme, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
$RefreshReg$(_c, "ThemeProvider");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arruday/Downloads/pizzashop/src/components/theme/theme-provider.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUVJOztBQWpFSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQ0VBO0FBQUFBLEVBRUFDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFlUCxNQUFNQyxlQUFtQztBQUFBLEVBQ3ZDQyxPQUFPO0FBQUEsRUFDUEMsVUFBVUEsTUFBTTtBQUNsQjtBQUVBLE1BQU1DLHVCQUF1QlAsY0FBa0NJLFlBQVk7QUFFcEUsZ0JBQVNJLGNBQWM7QUFBQSxFQUM1QkM7QUFBQUEsRUFDQUMsZUFBZTtBQUFBLEVBQ2ZDLGFBQWE7QUFBQSxFQUNiLEdBQUdDO0FBQ2UsR0FBRztBQUFBQyxLQUFBO0FBQ3JCLFFBQU0sQ0FBQ1IsT0FBT0MsUUFBUSxJQUFJSDtBQUFBQSxJQUN4QixNQUFPVyxhQUFhQyxRQUFRSixVQUFVLEtBQWVEO0FBQUFBLEVBQ3ZEO0FBRUFSLFlBQVUsTUFBTTtBQUNkLFVBQU1jLE9BQU9DLE9BQU9DLFNBQVNDO0FBRTdCSCxTQUFLSSxVQUFVQyxPQUFPLFNBQVMsTUFBTTtBQUVyQyxRQUFJaEIsVUFBVSxVQUFVO0FBQ3RCLFlBQU1pQixjQUFjTCxPQUFPTSxXQUFXLDhCQUE4QixFQUNqRUMsVUFDQyxTQUNBO0FBRUpSLFdBQUtJLFVBQVVLLElBQUlILFdBQVc7QUFDOUI7QUFBQSxJQUNGO0FBRUFOLFNBQUtJLFVBQVVLLElBQUlwQixLQUFLO0FBQUEsRUFDMUIsR0FBRyxDQUFDQSxLQUFLLENBQUM7QUFFVixRQUFNcUIsUUFBUTtBQUFBLElBQ1pyQjtBQUFBQSxJQUNBQyxVQUFVQSxDQUFDRCxXQUFpQjtBQUMxQlMsbUJBQWFhLFFBQVFoQixZQUFZTixNQUFLO0FBQ3RDQyxlQUFTRCxNQUFLO0FBQUEsSUFDaEI7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxxQkFBcUIsVUFBckIsRUFBOEIsR0FBSU8sT0FBTyxPQUN2Q0gsWUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUE7QUFFSjtBQUFDSSxHQXpDZUwsZUFBYTtBQUFBb0IsS0FBYnBCO0FBMkNULGFBQU1xQixXQUFXQSxNQUFNO0FBQUFDLE1BQUE7QUFDNUIsUUFBTUMsVUFBVTlCLFdBQVdNLG9CQUFvQjtBQUUvQyxNQUFJd0IsWUFBWUM7QUFDZCxVQUFNLElBQUlDLE1BQU0sOENBQThDO0FBRWhFLFNBQU9GO0FBQ1Q7QUFBQ0QsSUFQWUQsVUFBUTtBQUFBLElBQUFEO0FBQUFNLGFBQUFOLElBQUEiLCJuYW1lcyI6WyJjcmVhdGVDb250ZXh0IiwidXNlQ29udGV4dCIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiaW5pdGlhbFN0YXRlIiwidGhlbWUiLCJzZXRUaGVtZSIsIlRoZW1lUHJvdmlkZXJDb250ZXh0IiwiVGhlbWVQcm92aWRlciIsImNoaWxkcmVuIiwiZGVmYXVsdFRoZW1lIiwic3RvcmFnZUtleSIsInByb3BzIiwiX3MiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwicm9vdCIsIndpbmRvdyIsImRvY3VtZW50IiwiZG9jdW1lbnRFbGVtZW50IiwiY2xhc3NMaXN0IiwicmVtb3ZlIiwic3lzdGVtVGhlbWUiLCJtYXRjaE1lZGlhIiwibWF0Y2hlcyIsImFkZCIsInZhbHVlIiwic2V0SXRlbSIsIl9jIiwidXNlVGhlbWUiLCJfczIiLCJjb250ZXh0IiwidW5kZWZpbmVkIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJ0aGVtZS1wcm92aWRlci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgY3JlYXRlQ29udGV4dCxcbiAgUmVhY3ROb2RlLFxuICB1c2VDb250ZXh0LFxuICB1c2VFZmZlY3QsXG4gIHVzZVN0YXRlLFxufSBmcm9tICdyZWFjdCdcblxudHlwZSBUaGVtZSA9ICdkYXJrJyB8ICdsaWdodCcgfCAnc3lzdGVtJ1xuXG50eXBlIFRoZW1lUHJvdmlkZXJQcm9wcyA9IHtcbiAgY2hpbGRyZW46IFJlYWN0Tm9kZVxuICBkZWZhdWx0VGhlbWU/OiBUaGVtZVxuICBzdG9yYWdlS2V5Pzogc3RyaW5nXG59XG5cbnR5cGUgVGhlbWVQcm92aWRlclN0YXRlID0ge1xuICB0aGVtZTogVGhlbWVcbiAgc2V0VGhlbWU6ICh0aGVtZTogVGhlbWUpID0+IHZvaWRcbn1cblxuY29uc3QgaW5pdGlhbFN0YXRlOiBUaGVtZVByb3ZpZGVyU3RhdGUgPSB7XG4gIHRoZW1lOiAnc3lzdGVtJyxcbiAgc2V0VGhlbWU6ICgpID0+IG51bGwsXG59XG5cbmNvbnN0IFRoZW1lUHJvdmlkZXJDb250ZXh0ID0gY3JlYXRlQ29udGV4dDxUaGVtZVByb3ZpZGVyU3RhdGU+KGluaXRpYWxTdGF0ZSlcblxuZXhwb3J0IGZ1bmN0aW9uIFRoZW1lUHJvdmlkZXIoe1xuICBjaGlsZHJlbixcbiAgZGVmYXVsdFRoZW1lID0gJ3N5c3RlbScsXG4gIHN0b3JhZ2VLZXkgPSAndml0ZS11aS10aGVtZScsXG4gIC4uLnByb3BzXG59OiBUaGVtZVByb3ZpZGVyUHJvcHMpIHtcbiAgY29uc3QgW3RoZW1lLCBzZXRUaGVtZV0gPSB1c2VTdGF0ZTxUaGVtZT4oXG4gICAgKCkgPT4gKGxvY2FsU3RvcmFnZS5nZXRJdGVtKHN0b3JhZ2VLZXkpIGFzIFRoZW1lKSB8fCBkZWZhdWx0VGhlbWUsXG4gIClcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHJvb3QgPSB3aW5kb3cuZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50XG5cbiAgICByb290LmNsYXNzTGlzdC5yZW1vdmUoJ2xpZ2h0JywgJ2RhcmsnKVxuXG4gICAgaWYgKHRoZW1lID09PSAnc3lzdGVtJykge1xuICAgICAgY29uc3Qgc3lzdGVtVGhlbWUgPSB3aW5kb3cubWF0Y2hNZWRpYSgnKHByZWZlcnMtY29sb3Itc2NoZW1lOiBkYXJrKScpXG4gICAgICAgIC5tYXRjaGVzXG4gICAgICAgID8gJ2RhcmsnXG4gICAgICAgIDogJ2xpZ2h0J1xuXG4gICAgICByb290LmNsYXNzTGlzdC5hZGQoc3lzdGVtVGhlbWUpXG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICByb290LmNsYXNzTGlzdC5hZGQodGhlbWUpXG4gIH0sIFt0aGVtZV0pXG5cbiAgY29uc3QgdmFsdWUgPSB7XG4gICAgdGhlbWUsXG4gICAgc2V0VGhlbWU6ICh0aGVtZTogVGhlbWUpID0+IHtcbiAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKHN0b3JhZ2VLZXksIHRoZW1lKVxuICAgICAgc2V0VGhlbWUodGhlbWUpXG4gICAgfSxcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPFRoZW1lUHJvdmlkZXJDb250ZXh0LlByb3ZpZGVyIHsuLi5wcm9wc30gdmFsdWU9e3ZhbHVlfT5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICA8L1RoZW1lUHJvdmlkZXJDb250ZXh0LlByb3ZpZGVyPlxuICApXG59XG5cbmV4cG9ydCBjb25zdCB1c2VUaGVtZSA9ICgpID0+IHtcbiAgY29uc3QgY29udGV4dCA9IHVzZUNvbnRleHQoVGhlbWVQcm92aWRlckNvbnRleHQpXG5cbiAgaWYgKGNvbnRleHQgPT09IHVuZGVmaW5lZClcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ3VzZVRoZW1lIG11c3QgYmUgdXNlZCB3aXRoaW4gYSBUaGVtZVByb3ZpZGVyJylcblxuICByZXR1cm4gY29udGV4dFxufVxuIl0sImZpbGUiOiIvVXNlcnMvYXJydWRheS9Eb3dubG9hZHMvcGl6emFzaG9wL3NyYy9jb21wb25lbnRzL3RoZW1lL3RoZW1lLXByb3ZpZGVyLnRzeCJ9