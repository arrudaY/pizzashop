import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/app/orders/order-table-row.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7d79b549"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/arruday/Downloads/pizzashop/src/pages/app/orders/order-table-row.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useMutation, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=7d79b549";
import { formatDistanceToNow } from "/node_modules/.vite/deps/date-fns.js?v=7d79b549";
import { ptBR } from "/node_modules/.vite/deps/date-fns_locale.js?v=7d79b549";
import { ArrowRight, Search, X } from "/node_modules/.vite/deps/lucide-react.js?v=7d79b549";
import __vite__cjsImport7_react from "/node_modules/.vite/deps/react.js?v=7d79b549"; const useState = __vite__cjsImport7_react["useState"];
import { approveOrder } from "/src/api/approve-order.ts";
import { cancelOrder } from "/src/api/cancel-order.ts";
import { deliverOrder } from "/src/api/deliver-order.ts";
import { dispatchOrder } from "/src/api/dispatch-order.ts";
import { OrderStatus } from "/src/components/order-status.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { Dialog, DialogTrigger } from "/src/components/ui/dialog.tsx";
import { TableCell, TableRow } from "/src/components/ui/table.tsx";
import { OrderDetails } from "/src/pages/app/orders/order-details.tsx";
export function OrderTableRow({ order }) {
  _s();
  const [isDetailsOpen, SetIsDetailsOpen] = useState(false);
  const queryClient = useQueryClient();
  function updateOrderStatusOnCache(orderId, status) {
    const ordersListCache = queryClient.getQueriesData({
      queryKey: ["orders"]
    });
    ordersListCache.forEach(([cacheKey, cacheData]) => {
      if (!cacheData) {
        return;
      }
      queryClient.setQueryData(cacheKey, {
        ...cacheData,
        orders: cacheData.orders.map((order2) => {
          if (order2.orderId === orderId) {
            return { ...order2, status };
          }
          return order2;
        })
      });
    });
  }
  const { mutateAsync: cancelOrderFn, isPending: isCancelingOrder } = useMutation({
    mutationFn: cancelOrder,
    async onSuccess(_, { orderId }) {
      updateOrderStatusOnCache(orderId, "canceled");
    }
  });
  const { mutateAsync: approveOrderFn, isPending: isApprovingOrder } = useMutation({
    mutationFn: approveOrder,
    async onSuccess(_, { orderId }) {
      updateOrderStatusOnCache(orderId, "processing");
    }
  });
  const { mutateAsync: dispatchOrderFn, isPending: isDispatchingOrder } = useMutation({
    mutationFn: dispatchOrder,
    async onSuccess(_, { orderId }) {
      updateOrderStatusOnCache(orderId, "delivering");
    }
  });
  const { mutateAsync: deliverOrderFn, isPending: isDeliveringOrder } = useMutation({
    mutationFn: deliverOrder,
    async onSuccess(_, { orderId }) {
      updateOrderStatusOnCache(orderId, "delivered");
    }
  });
  return /* @__PURE__ */ jsxDEV(TableRow, { children: [
    /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(Dialog, { open: isDetailsOpen, onOpenChange: SetIsDetailsOpen, children: [
      /* @__PURE__ */ jsxDEV(DialogTrigger, { asChild: true, children: /* @__PURE__ */ jsxDEV(Button, { variant: "outline", size: "xs", title: "Detalhes do pedido", children: [
        /* @__PURE__ */ jsxDEV(Search, { className: "h-3 w-3" }, void 0, false, {
          fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/orders/order-table-row.tsx",
          lineNumber: 89,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: "Detalhes do pedido" }, void 0, false, {
          fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/orders/order-table-row.tsx",
          lineNumber: 90,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/orders/order-table-row.tsx",
        lineNumber: 88,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/orders/order-table-row.tsx",
        lineNumber: 87,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(OrderDetails, { open: isDetailsOpen, orderId: order.orderId }, void 0, false, {
        fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/orders/order-table-row.tsx",
        lineNumber: 93,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/orders/order-table-row.tsx",
      lineNumber: 86,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/orders/order-table-row.tsx",
      lineNumber: 85,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TableCell, { className: "font-mono text-xs font-medium", children: order.orderId }, void 0, false, {
      fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/orders/order-table-row.tsx",
      lineNumber: 96,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TableCell, { className: "text-muted-foreground", children: formatDistanceToNow(order.createdAt, {
      locale: ptBR,
      addSuffix: true
    }) }, void 0, false, {
      fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/orders/order-table-row.tsx",
      lineNumber: 99,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(OrderStatus, { status: order.status }, void 0, false, {
      fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/orders/order-table-row.tsx",
      lineNumber: 106,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/orders/order-table-row.tsx",
      lineNumber: 105,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TableCell, { className: "font-medium", children: order.customerName }, void 0, false, {
      fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/orders/order-table-row.tsx",
      lineNumber: 108,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TableCell, { className: "font-mono font-medium", children: (order.total / 100).toLocaleString("pt-BR", {
      style: "currency",
      currency: "BRL"
    }) }, void 0, false, {
      fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/orders/order-table-row.tsx",
      lineNumber: 109,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TableCell, { children: [
      order.status === "pending" && /* @__PURE__ */ jsxDEV(
        Button,
        {
          onClick: () => approveOrderFn({ orderId: order.orderId }),
          variant: "outline",
          size: "xs",
          disabled: isApprovingOrder,
          children: [
            /* @__PURE__ */ jsxDEV(ArrowRight, { className: "mr-2 h-3 w-3" }, void 0, false, {
              fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/orders/order-table-row.tsx",
              lineNumber: 123,
              columnNumber: 13
            }, this),
            "Aprovar"
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/orders/order-table-row.tsx",
          lineNumber: 117,
          columnNumber: 9
        },
        this
      ),
      order.status === "processing" && /* @__PURE__ */ jsxDEV(
        Button,
        {
          onClick: () => dispatchOrderFn({ orderId: order.orderId }),
          variant: "outline",
          size: "xs",
          disabled: isDispatchingOrder,
          children: [
            /* @__PURE__ */ jsxDEV(ArrowRight, { className: "mr-2 h-3 w-3" }, void 0, false, {
              fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/orders/order-table-row.tsx",
              lineNumber: 134,
              columnNumber: 13
            }, this),
            "Em entrega"
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/orders/order-table-row.tsx",
          lineNumber: 128,
          columnNumber: 9
        },
        this
      ),
      order.status === "delivering" && /* @__PURE__ */ jsxDEV(
        Button,
        {
          onClick: () => deliverOrderFn({ orderId: order.orderId }),
          variant: "outline",
          size: "xs",
          disabled: isDeliveringOrder,
          children: [
            /* @__PURE__ */ jsxDEV(ArrowRight, { className: "mr-2 h-3 w-3" }, void 0, false, {
              fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/orders/order-table-row.tsx",
              lineNumber: 145,
              columnNumber: 13
            }, this),
            "Entregue"
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/orders/order-table-row.tsx",
          lineNumber: 139,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/orders/order-table-row.tsx",
      lineNumber: 115,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(
      Button,
      {
        onClick: () => cancelOrderFn({ orderId: order.orderId }),
        disabled: !["pending", "processing"].includes(order.status) || isCancelingOrder,
        variant: "ghost",
        size: "xs",
        children: [
          /* @__PURE__ */ jsxDEV(X, { className: "mr-2 h-3 w-3" }, void 0, false, {
            fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/orders/order-table-row.tsx",
            lineNumber: 160,
            columnNumber: 11
          }, this),
          "Cancelar"
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/orders/order-table-row.tsx",
        lineNumber: 151,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/orders/order-table-row.tsx",
      lineNumber: 150,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/orders/order-table-row.tsx",
    lineNumber: 84,
    columnNumber: 5
  }, this);
}
_s(OrderTableRow, "4R203kNch7bBROWNBUeNpkpT/T8=", false, function() {
  return [useQueryClient, useMutation, useMutation, useMutation, useMutation];
});
_c = OrderTableRow;
var _c;
$RefreshReg$(_c, "OrderTableRow");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arruday/Downloads/pizzashop/src/pages/app/orders/order-table-row.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0ZjOzJCQXhGZDtBQUFvQixNQUFFQSxjQUFjLE9BQVEsc0JBQXVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ25FLFNBQVNDLDJCQUEyQjtBQUNwQyxTQUFTQyxZQUFZO0FBQ3JCLFNBQVNDLFlBQVlDLFFBQVFDLFNBQVM7QUFDdEMsU0FBU0MsZ0JBQWdCO0FBRXpCLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLHFCQUFxQjtBQUU5QixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxRQUFRQyxxQkFBcUI7QUFDdEMsU0FBU0MsV0FBV0MsZ0JBQWdCO0FBRXBDLFNBQVNDLG9CQUFvQjtBQVl0QixnQkFBU0MsY0FBYyxFQUFFQyxNQUEwQixHQUFHO0FBQUFDLEtBQUE7QUFDM0QsUUFBTSxDQUFDQyxlQUFlQyxnQkFBZ0IsSUFBSWhCLFNBQVMsS0FBSztBQUN4RCxRQUFNaUIsY0FBY3ZCLGVBQWU7QUFFbkMsV0FBU3dCLHlCQUF5QkMsU0FBaUJDLFFBQXFCO0FBQ3RFLFVBQU1DLGtCQUFrQkosWUFBWUssZUFBa0M7QUFBQSxNQUNwRUMsVUFBVSxDQUFDLFFBQVE7QUFBQSxJQUNyQixDQUFDO0FBRURGLG9CQUFnQkcsUUFBUSxDQUFDLENBQUNDLFVBQVVDLFNBQVMsTUFBTTtBQUNqRCxVQUFJLENBQUNBLFdBQVc7QUFDZDtBQUFBLE1BQ0Y7QUFDQVQsa0JBQVlVLGFBQWdDRixVQUFVO0FBQUEsUUFDcEQsR0FBR0M7QUFBQUEsUUFDSEUsUUFBUUYsVUFBVUUsT0FBT0MsSUFBSSxDQUFDaEIsV0FBVTtBQUN0QyxjQUFJQSxPQUFNTSxZQUFZQSxTQUFTO0FBQzdCLG1CQUFPLEVBQUUsR0FBR04sUUFBT08sT0FBTztBQUFBLFVBQzVCO0FBQ0EsaUJBQU9QO0FBQUFBLFFBQ1QsQ0FBQztBQUFBLE1BQ0gsQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUFBLEVBQ0g7QUFFQSxRQUFNLEVBQUVpQixhQUFhQyxlQUFlQyxXQUFXQyxpQkFBaUIsSUFDOURDLFlBQVk7QUFBQSxJQUNWQyxZQUFZakM7QUFBQUEsSUFDWixNQUFNa0MsVUFBVUMsR0FBRyxFQUFFbEIsUUFBUSxHQUFHO0FBQzlCRCwrQkFBeUJDLFNBQVMsVUFBVTtBQUFBLElBQzlDO0FBQUEsRUFDRixDQUFDO0FBQ0gsUUFBTSxFQUFFVyxhQUFhUSxnQkFBZ0JOLFdBQVdPLGlCQUFpQixJQUMvREwsWUFBWTtBQUFBLElBQ1ZDLFlBQVlsQztBQUFBQSxJQUNaLE1BQU1tQyxVQUFVQyxHQUFHLEVBQUVsQixRQUFRLEdBQUc7QUFDOUJELCtCQUF5QkMsU0FBUyxZQUFZO0FBQUEsSUFDaEQ7QUFBQSxFQUNGLENBQUM7QUFDSCxRQUFNLEVBQUVXLGFBQWFVLGlCQUFpQlIsV0FBV1MsbUJBQW1CLElBQ2xFUCxZQUFZO0FBQUEsSUFDVkMsWUFBWS9CO0FBQUFBLElBQ1osTUFBTWdDLFVBQVVDLEdBQUcsRUFBRWxCLFFBQVEsR0FBRztBQUM5QkQsK0JBQXlCQyxTQUFTLFlBQVk7QUFBQSxJQUNoRDtBQUFBLEVBQ0YsQ0FBQztBQUNILFFBQU0sRUFBRVcsYUFBYVksZ0JBQWdCVixXQUFXVyxrQkFBa0IsSUFDaEVULFlBQVk7QUFBQSxJQUNWQyxZQUFZaEM7QUFBQUEsSUFDWixNQUFNaUMsVUFBVUMsR0FBRyxFQUFFbEIsUUFBUSxHQUFHO0FBQzlCRCwrQkFBeUJDLFNBQVMsV0FBVztBQUFBLElBQy9DO0FBQUEsRUFDRixDQUFDO0FBRUgsU0FDRSx1QkFBQyxZQUNDO0FBQUEsMkJBQUMsYUFDQyxpQ0FBQyxVQUFPLE1BQU1KLGVBQWUsY0FBY0Msa0JBQ3pDO0FBQUEsNkJBQUMsaUJBQWMsU0FBTyxNQUNwQixpQ0FBQyxVQUFPLFNBQVEsV0FBVSxNQUFLLE1BQUssT0FBTSxzQkFDeEM7QUFBQSwrQkFBQyxVQUFPLFdBQVUsYUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyQjtBQUFBLFFBQzNCLHVCQUFDLFVBQUssV0FBVSxXQUFVLGtDQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRDO0FBQUEsV0FGOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQSx1QkFBQyxnQkFBYSxNQUFNRCxlQUFlLFNBQVNGLE1BQU1NLFdBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEQ7QUFBQSxTQVA1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUE7QUFBQSxJQUNBLHVCQUFDLGFBQVUsV0FBVSxpQ0FDbEJOLGdCQUFNTSxXQURUO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0EsdUJBQUMsYUFBVSxXQUFVLHlCQUNsQnhCLDhCQUFvQmtCLE1BQU0rQixXQUFXO0FBQUEsTUFDcENDLFFBQVFqRDtBQUFBQSxNQUNSa0QsV0FBVztBQUFBLElBQ2IsQ0FBQyxLQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBQ0EsdUJBQUMsYUFDQyxpQ0FBQyxlQUFZLFFBQVFqQyxNQUFNTyxVQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtDLEtBRHBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0EsdUJBQUMsYUFBVSxXQUFVLGVBQWVQLGdCQUFNa0MsZ0JBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUQ7QUFBQSxJQUN2RCx1QkFBQyxhQUFVLFdBQVUseUJBQ2pCbEMsaUJBQU1tQyxRQUFRLEtBQUtDLGVBQWUsU0FBUztBQUFBLE1BQzNDQyxPQUFPO0FBQUEsTUFDUEMsVUFBVTtBQUFBLElBQ1osQ0FBQyxLQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBQ0EsdUJBQUMsYUFDRXRDO0FBQUFBLFlBQU1PLFdBQVcsYUFDaEI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVMsTUFBTWtCLGVBQWUsRUFBRW5CLFNBQVNOLE1BQU1NLFFBQVEsQ0FBQztBQUFBLFVBQ3hELFNBQVE7QUFBQSxVQUNSLE1BQUs7QUFBQSxVQUNMLFVBQVVvQjtBQUFBQSxVQUVWO0FBQUEsbUNBQUMsY0FBVyxXQUFVLGtCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvQztBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTnRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVFBO0FBQUEsTUFFRDFCLE1BQU1PLFdBQVcsZ0JBQ2hCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTLE1BQU1vQixnQkFBZ0IsRUFBRXJCLFNBQVNOLE1BQU1NLFFBQVEsQ0FBQztBQUFBLFVBQ3pELFNBQVE7QUFBQSxVQUNSLE1BQUs7QUFBQSxVQUNMLFVBQVVzQjtBQUFBQSxVQUVWO0FBQUEsbUNBQUMsY0FBVyxXQUFVLGtCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvQztBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTnRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVFBO0FBQUEsTUFFRDVCLE1BQU1PLFdBQVcsZ0JBQ2hCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTLE1BQU1zQixlQUFlLEVBQUV2QixTQUFTTixNQUFNTSxRQUFRLENBQUM7QUFBQSxVQUN4RCxTQUFRO0FBQUEsVUFDUixNQUFLO0FBQUEsVUFDTCxVQUFVd0I7QUFBQUEsVUFFVjtBQUFBLG1DQUFDLGNBQVcsV0FBVSxrQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU50QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFRQTtBQUFBLFNBaENKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrQ0E7QUFBQSxJQUNBLHVCQUFDLGFBQ0M7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFNBQVMsTUFBTVosY0FBYyxFQUFFWixTQUFTTixNQUFNTSxRQUFRLENBQUM7QUFBQSxRQUN2RCxVQUNFLENBQUMsQ0FBQyxXQUFXLFlBQVksRUFBRWlDLFNBQVN2QyxNQUFNTyxNQUFNLEtBQ2hEYTtBQUFBQSxRQUVGLFNBQVE7QUFBQSxRQUNSLE1BQUs7QUFBQSxRQUVMO0FBQUEsaUNBQUMsS0FBRSxXQUFVLGtCQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFUN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBV0EsS0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBYUE7QUFBQSxPQS9FRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZ0ZBO0FBRUo7QUFBQ25CLEdBekllRixlQUFhO0FBQUEsVUFFUGxCLGdCQXdCbEJ3QyxhQU9BQSxhQU9BQSxhQU9BQSxXQUFXO0FBQUE7QUFBQW1CLEtBL0NDekM7QUFBYSxJQUFBeUM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVF1ZXJ5Q2xpZW50IiwiZm9ybWF0RGlzdGFuY2VUb05vdyIsInB0QlIiLCJBcnJvd1JpZ2h0IiwiU2VhcmNoIiwiWCIsInVzZVN0YXRlIiwiYXBwcm92ZU9yZGVyIiwiY2FuY2VsT3JkZXIiLCJkZWxpdmVyT3JkZXIiLCJkaXNwYXRjaE9yZGVyIiwiT3JkZXJTdGF0dXMiLCJCdXR0b24iLCJEaWFsb2ciLCJEaWFsb2dUcmlnZ2VyIiwiVGFibGVDZWxsIiwiVGFibGVSb3ciLCJPcmRlckRldGFpbHMiLCJPcmRlclRhYmxlUm93Iiwib3JkZXIiLCJfcyIsImlzRGV0YWlsc09wZW4iLCJTZXRJc0RldGFpbHNPcGVuIiwicXVlcnlDbGllbnQiLCJ1cGRhdGVPcmRlclN0YXR1c09uQ2FjaGUiLCJvcmRlcklkIiwic3RhdHVzIiwib3JkZXJzTGlzdENhY2hlIiwiZ2V0UXVlcmllc0RhdGEiLCJxdWVyeUtleSIsImZvckVhY2giLCJjYWNoZUtleSIsImNhY2hlRGF0YSIsInNldFF1ZXJ5RGF0YSIsIm9yZGVycyIsIm1hcCIsIm11dGF0ZUFzeW5jIiwiY2FuY2VsT3JkZXJGbiIsImlzUGVuZGluZyIsImlzQ2FuY2VsaW5nT3JkZXIiLCJ1c2VNdXRhdGlvbiIsIm11dGF0aW9uRm4iLCJvblN1Y2Nlc3MiLCJfIiwiYXBwcm92ZU9yZGVyRm4iLCJpc0FwcHJvdmluZ09yZGVyIiwiZGlzcGF0Y2hPcmRlckZuIiwiaXNEaXNwYXRjaGluZ09yZGVyIiwiZGVsaXZlck9yZGVyRm4iLCJpc0RlbGl2ZXJpbmdPcmRlciIsImNyZWF0ZWRBdCIsImxvY2FsZSIsImFkZFN1ZmZpeCIsImN1c3RvbWVyTmFtZSIsInRvdGFsIiwidG9Mb2NhbGVTdHJpbmciLCJzdHlsZSIsImN1cnJlbmN5IiwiaW5jbHVkZXMiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIm9yZGVyLXRhYmxlLXJvdy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuaW1wb3J0IHsgZm9ybWF0RGlzdGFuY2VUb05vdyB9IGZyb20gJ2RhdGUtZm5zJ1xuaW1wb3J0IHsgcHRCUiB9IGZyb20gJ2RhdGUtZm5zL2xvY2FsZSdcbmltcG9ydCB7IEFycm93UmlnaHQsIFNlYXJjaCwgWCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5cbmltcG9ydCB7IGFwcHJvdmVPcmRlciB9IGZyb20gJ0AvYXBpL2FwcHJvdmUtb3JkZXInXG5pbXBvcnQgeyBjYW5jZWxPcmRlciB9IGZyb20gJ0AvYXBpL2NhbmNlbC1vcmRlcidcbmltcG9ydCB7IGRlbGl2ZXJPcmRlciB9IGZyb20gJ0AvYXBpL2RlbGl2ZXItb3JkZXInXG5pbXBvcnQgeyBkaXNwYXRjaE9yZGVyIH0gZnJvbSAnQC9hcGkvZGlzcGF0Y2gtb3JkZXInXG5pbXBvcnQgeyBHZXRPcmRlcnNSZXNwb25zZSB9IGZyb20gJ0AvYXBpL2dldC1vcmRlcnMnXG5pbXBvcnQgeyBPcmRlclN0YXR1cyB9IGZyb20gJ0AvY29tcG9uZW50cy9vcmRlci1zdGF0dXMnXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYnV0dG9uJ1xuaW1wb3J0IHsgRGlhbG9nLCBEaWFsb2dUcmlnZ2VyIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2RpYWxvZydcbmltcG9ydCB7IFRhYmxlQ2VsbCwgVGFibGVSb3cgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvdGFibGUnXG5cbmltcG9ydCB7IE9yZGVyRGV0YWlscyB9IGZyb20gJy4vb3JkZXItZGV0YWlscydcblxuZXhwb3J0IGludGVyZmFjZSBPcmRlclRhYmxlUm93UHJvcHMge1xuICBvcmRlcjoge1xuICAgIG9yZGVySWQ6IHN0cmluZ1xuICAgIGNyZWF0ZWRBdDogc3RyaW5nXG4gICAgc3RhdHVzOiAncGVuZGluZycgfCAnY2FuY2VsZWQnIHwgJ3Byb2Nlc3NpbmcnIHwgJ2RlbGl2ZXJpbmcnIHwgJ2RlbGl2ZXJlZCdcbiAgICBjdXN0b21lck5hbWU6IHN0cmluZ1xuICAgIHRvdGFsOiBudW1iZXJcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gT3JkZXJUYWJsZVJvdyh7IG9yZGVyIH06IE9yZGVyVGFibGVSb3dQcm9wcykge1xuICBjb25zdCBbaXNEZXRhaWxzT3BlbiwgU2V0SXNEZXRhaWxzT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgcXVlcnlDbGllbnQgPSB1c2VRdWVyeUNsaWVudCgpXG5cbiAgZnVuY3Rpb24gdXBkYXRlT3JkZXJTdGF0dXNPbkNhY2hlKG9yZGVySWQ6IHN0cmluZywgc3RhdHVzOiBPcmRlclN0YXR1cykge1xuICAgIGNvbnN0IG9yZGVyc0xpc3RDYWNoZSA9IHF1ZXJ5Q2xpZW50LmdldFF1ZXJpZXNEYXRhPEdldE9yZGVyc1Jlc3BvbnNlPih7XG4gICAgICBxdWVyeUtleTogWydvcmRlcnMnXSxcbiAgICB9KVxuXG4gICAgb3JkZXJzTGlzdENhY2hlLmZvckVhY2goKFtjYWNoZUtleSwgY2FjaGVEYXRhXSkgPT4ge1xuICAgICAgaWYgKCFjYWNoZURhdGEpIHtcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG4gICAgICBxdWVyeUNsaWVudC5zZXRRdWVyeURhdGE8R2V0T3JkZXJzUmVzcG9uc2U+KGNhY2hlS2V5LCB7XG4gICAgICAgIC4uLmNhY2hlRGF0YSxcbiAgICAgICAgb3JkZXJzOiBjYWNoZURhdGEub3JkZXJzLm1hcCgob3JkZXIpID0+IHtcbiAgICAgICAgICBpZiAob3JkZXIub3JkZXJJZCA9PT0gb3JkZXJJZCkge1xuICAgICAgICAgICAgcmV0dXJuIHsgLi4ub3JkZXIsIHN0YXR1cyB9XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiBvcmRlclxuICAgICAgICB9KSxcbiAgICAgIH0pXG4gICAgfSlcbiAgfVxuXG4gIGNvbnN0IHsgbXV0YXRlQXN5bmM6IGNhbmNlbE9yZGVyRm4sIGlzUGVuZGluZzogaXNDYW5jZWxpbmdPcmRlciB9ID1cbiAgICB1c2VNdXRhdGlvbih7XG4gICAgICBtdXRhdGlvbkZuOiBjYW5jZWxPcmRlcixcbiAgICAgIGFzeW5jIG9uU3VjY2VzcyhfLCB7IG9yZGVySWQgfSkge1xuICAgICAgICB1cGRhdGVPcmRlclN0YXR1c09uQ2FjaGUob3JkZXJJZCwgJ2NhbmNlbGVkJylcbiAgICAgIH0sXG4gICAgfSlcbiAgY29uc3QgeyBtdXRhdGVBc3luYzogYXBwcm92ZU9yZGVyRm4sIGlzUGVuZGluZzogaXNBcHByb3ZpbmdPcmRlciB9ID1cbiAgICB1c2VNdXRhdGlvbih7XG4gICAgICBtdXRhdGlvbkZuOiBhcHByb3ZlT3JkZXIsXG4gICAgICBhc3luYyBvblN1Y2Nlc3MoXywgeyBvcmRlcklkIH0pIHtcbiAgICAgICAgdXBkYXRlT3JkZXJTdGF0dXNPbkNhY2hlKG9yZGVySWQsICdwcm9jZXNzaW5nJylcbiAgICAgIH0sXG4gICAgfSlcbiAgY29uc3QgeyBtdXRhdGVBc3luYzogZGlzcGF0Y2hPcmRlckZuLCBpc1BlbmRpbmc6IGlzRGlzcGF0Y2hpbmdPcmRlciB9ID1cbiAgICB1c2VNdXRhdGlvbih7XG4gICAgICBtdXRhdGlvbkZuOiBkaXNwYXRjaE9yZGVyLFxuICAgICAgYXN5bmMgb25TdWNjZXNzKF8sIHsgb3JkZXJJZCB9KSB7XG4gICAgICAgIHVwZGF0ZU9yZGVyU3RhdHVzT25DYWNoZShvcmRlcklkLCAnZGVsaXZlcmluZycpXG4gICAgICB9LFxuICAgIH0pXG4gIGNvbnN0IHsgbXV0YXRlQXN5bmM6IGRlbGl2ZXJPcmRlckZuLCBpc1BlbmRpbmc6IGlzRGVsaXZlcmluZ09yZGVyIH0gPVxuICAgIHVzZU11dGF0aW9uKHtcbiAgICAgIG11dGF0aW9uRm46IGRlbGl2ZXJPcmRlcixcbiAgICAgIGFzeW5jIG9uU3VjY2VzcyhfLCB7IG9yZGVySWQgfSkge1xuICAgICAgICB1cGRhdGVPcmRlclN0YXR1c09uQ2FjaGUob3JkZXJJZCwgJ2RlbGl2ZXJlZCcpXG4gICAgICB9LFxuICAgIH0pXG5cbiAgcmV0dXJuIChcbiAgICA8VGFibGVSb3c+XG4gICAgICA8VGFibGVDZWxsPlxuICAgICAgICA8RGlhbG9nIG9wZW49e2lzRGV0YWlsc09wZW59IG9uT3BlbkNoYW5nZT17U2V0SXNEZXRhaWxzT3Blbn0+XG4gICAgICAgICAgPERpYWxvZ1RyaWdnZXIgYXNDaGlsZD5cbiAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cIm91dGxpbmVcIiBzaXplPVwieHNcIiB0aXRsZT1cIkRldGFsaGVzIGRvIHBlZGlkb1wiPlxuICAgICAgICAgICAgICA8U2VhcmNoIGNsYXNzTmFtZT1cImgtMyB3LTNcIiAvPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzci1vbmx5XCI+RGV0YWxoZXMgZG8gcGVkaWRvPC9zcGFuPlxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgPC9EaWFsb2dUcmlnZ2VyPlxuICAgICAgICAgIDxPcmRlckRldGFpbHMgb3Blbj17aXNEZXRhaWxzT3Blbn0gb3JkZXJJZD17b3JkZXIub3JkZXJJZH0gLz5cbiAgICAgICAgPC9EaWFsb2c+XG4gICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgIDxUYWJsZUNlbGwgY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQteHMgZm9udC1tZWRpdW1cIj5cbiAgICAgICAge29yZGVyLm9yZGVySWR9XG4gICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgIDxUYWJsZUNlbGwgY2xhc3NOYW1lPVwidGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgIHtmb3JtYXREaXN0YW5jZVRvTm93KG9yZGVyLmNyZWF0ZWRBdCwge1xuICAgICAgICAgIGxvY2FsZTogcHRCUixcbiAgICAgICAgICBhZGRTdWZmaXg6IHRydWUsXG4gICAgICAgIH0pfVxuICAgICAgPC9UYWJsZUNlbGw+XG4gICAgICA8VGFibGVDZWxsPlxuICAgICAgICA8T3JkZXJTdGF0dXMgc3RhdHVzPXtvcmRlci5zdGF0dXN9IC8+XG4gICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgIDxUYWJsZUNlbGwgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW1cIj57b3JkZXIuY3VzdG9tZXJOYW1lfTwvVGFibGVDZWxsPlxuICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJmb250LW1vbm8gZm9udC1tZWRpdW1cIj5cbiAgICAgICAgeyhvcmRlci50b3RhbCAvIDEwMCkudG9Mb2NhbGVTdHJpbmcoJ3B0LUJSJywge1xuICAgICAgICAgIHN0eWxlOiAnY3VycmVuY3knLFxuICAgICAgICAgIGN1cnJlbmN5OiAnQlJMJyxcbiAgICAgICAgfSl9XG4gICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgIDxUYWJsZUNlbGw+XG4gICAgICAgIHtvcmRlci5zdGF0dXMgPT09ICdwZW5kaW5nJyAmJiAoXG4gICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gYXBwcm92ZU9yZGVyRm4oeyBvcmRlcklkOiBvcmRlci5vcmRlcklkIH0pfVxuICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxuICAgICAgICAgICAgc2l6ZT1cInhzXCJcbiAgICAgICAgICAgIGRpc2FibGVkPXtpc0FwcHJvdmluZ09yZGVyfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxBcnJvd1JpZ2h0IGNsYXNzTmFtZT1cIm1yLTIgaC0zIHctM1wiIC8+XG4gICAgICAgICAgICBBcHJvdmFyXG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICl9XG4gICAgICAgIHtvcmRlci5zdGF0dXMgPT09ICdwcm9jZXNzaW5nJyAmJiAoXG4gICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gZGlzcGF0Y2hPcmRlckZuKHsgb3JkZXJJZDogb3JkZXIub3JkZXJJZCB9KX1cbiAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcbiAgICAgICAgICAgIHNpemU9XCJ4c1wiXG4gICAgICAgICAgICBkaXNhYmxlZD17aXNEaXNwYXRjaGluZ09yZGVyfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxBcnJvd1JpZ2h0IGNsYXNzTmFtZT1cIm1yLTIgaC0zIHctM1wiIC8+XG4gICAgICAgICAgICBFbSBlbnRyZWdhXG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICl9XG4gICAgICAgIHtvcmRlci5zdGF0dXMgPT09ICdkZWxpdmVyaW5nJyAmJiAoXG4gICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gZGVsaXZlck9yZGVyRm4oeyBvcmRlcklkOiBvcmRlci5vcmRlcklkIH0pfVxuICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxuICAgICAgICAgICAgc2l6ZT1cInhzXCJcbiAgICAgICAgICAgIGRpc2FibGVkPXtpc0RlbGl2ZXJpbmdPcmRlcn1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8QXJyb3dSaWdodCBjbGFzc05hbWU9XCJtci0yIGgtMyB3LTNcIiAvPlxuICAgICAgICAgICAgRW50cmVndWVcbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgKX1cbiAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgPFRhYmxlQ2VsbD5cbiAgICAgICAgPEJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGNhbmNlbE9yZGVyRm4oeyBvcmRlcklkOiBvcmRlci5vcmRlcklkIH0pfVxuICAgICAgICAgIGRpc2FibGVkPXtcbiAgICAgICAgICAgICFbJ3BlbmRpbmcnLCAncHJvY2Vzc2luZyddLmluY2x1ZGVzKG9yZGVyLnN0YXR1cykgfHxcbiAgICAgICAgICAgIGlzQ2FuY2VsaW5nT3JkZXJcbiAgICAgICAgICB9XG4gICAgICAgICAgdmFyaWFudD1cImdob3N0XCJcbiAgICAgICAgICBzaXplPVwieHNcIlxuICAgICAgICA+XG4gICAgICAgICAgPFggY2xhc3NOYW1lPVwibXItMiBoLTMgdy0zXCIgLz5cbiAgICAgICAgICBDYW5jZWxhclxuICAgICAgICA8L0J1dHRvbj5cbiAgICAgIDwvVGFibGVDZWxsPlxuICAgIDwvVGFibGVSb3c+XG4gIClcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2FycnVkYXkvRG93bmxvYWRzL3Bpenphc2hvcC9zcmMvcGFnZXMvYXBwL29yZGVycy9vcmRlci10YWJsZS1yb3cudHN4In0=