import { http, HttpResponse } from "/node_modules/.vite/deps/msw.js?v=7d79b549";
export const updateProfileMock = http.put(
  "/profile",
  async ({ request }) => {
    const { name } = await request.json();
    if (name === "Rocket Pizza") {
      return new HttpResponse(null, { status: 204 });
    }
    return new HttpResponse(null, { status: 400 });
  }
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVwZGF0ZS1wcm9maWxlLW1vY2sudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgaHR0cCwgSHR0cFJlc3BvbnNlIH0gZnJvbSAnbXN3J1xuXG5pbXBvcnQgeyBVcGRhdGVQcm9maWxlQm9keSB9IGZyb20gJy4uL3VwZGF0ZS1wcm9maWxlJ1xuXG5leHBvcnQgY29uc3QgdXBkYXRlUHJvZmlsZU1vY2sgPSBodHRwLnB1dDxuZXZlciwgVXBkYXRlUHJvZmlsZUJvZHk+KFxuICAnL3Byb2ZpbGUnLFxuICBhc3luYyAoeyByZXF1ZXN0IH0pID0+IHtcbiAgICBjb25zdCB7IG5hbWUgfSA9IGF3YWl0IHJlcXVlc3QuanNvbigpXG5cbiAgICBpZiAobmFtZSA9PT0gJ1JvY2tldCBQaXp6YScpIHtcbiAgICAgIHJldHVybiBuZXcgSHR0cFJlc3BvbnNlKG51bGwsIHsgc3RhdHVzOiAyMDQgfSlcbiAgICB9XG5cbiAgICByZXR1cm4gbmV3IEh0dHBSZXNwb25zZShudWxsLCB7IHN0YXR1czogNDAwIH0pXG4gIH0sXG4pXG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsTUFBTSxvQkFBb0I7QUFJNUIsYUFBTSxvQkFBb0IsS0FBSztBQUFBLEVBQ3BDO0FBQUEsRUFDQSxPQUFPLEVBQUUsUUFBUSxNQUFNO0FBQ3JCLFVBQU0sRUFBRSxLQUFLLElBQUksTUFBTSxRQUFRLEtBQUs7QUFFcEMsUUFBSSxTQUFTLGdCQUFnQjtBQUMzQixhQUFPLElBQUksYUFBYSxNQUFNLEVBQUUsUUFBUSxJQUFJLENBQUM7QUFBQSxJQUMvQztBQUVBLFdBQU8sSUFBSSxhQUFhLE1BQU0sRUFBRSxRQUFRLElBQUksQ0FBQztBQUFBLEVBQy9DO0FBQ0Y7IiwibmFtZXMiOltdfQ==