import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/app/dashboard/dashboard.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7d79b549"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/arruday/Downloads/pizzashop/src/pages/app/dashboard/dashboard.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Helmet } from "/node_modules/.vite/deps/react-helmet-async.js?v=7d79b549";
import { DayOrdersAmountCard } from "/src/pages/app/dashboard/day-orders-amount-card.tsx";
import { MonthCanceledOrdersAmountCard } from "/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx";
import { MonthOrdersAmountCard } from "/src/pages/app/dashboard/month-orders-amount-card.tsx";
import { MonthRevenueCard } from "/src/pages/app/dashboard/month-revenue-card.tsx";
import { PopularProductChart } from "/src/pages/app/dashboard/popular-products-chart.tsx";
import { RevenueChart } from "/src/pages/app/dashboard/revenue-chart.tsx";
export function Dashboard() {
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(Helmet, { title: "Dashboard" }, void 0, false, {
      fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/dashboard/dashboard.tsx",
      lineNumber: 13,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold tracking-tight", children: "Dashboard" }, void 0, false, {
        fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/dashboard/dashboard.tsx",
        lineNumber: 15,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-4 gap-4", children: [
        /* @__PURE__ */ jsxDEV(MonthRevenueCard, {}, void 0, false, {
          fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/dashboard/dashboard.tsx",
          lineNumber: 17,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(MonthOrdersAmountCard, {}, void 0, false, {
          fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/dashboard/dashboard.tsx",
          lineNumber: 18,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(DayOrdersAmountCard, {}, void 0, false, {
          fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/dashboard/dashboard.tsx",
          lineNumber: 19,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(MonthCanceledOrdersAmountCard, {}, void 0, false, {
          fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/dashboard/dashboard.tsx",
          lineNumber: 20,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/dashboard/dashboard.tsx",
        lineNumber: 16,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-9 gap-4", children: [
        /* @__PURE__ */ jsxDEV(RevenueChart, {}, void 0, false, {
          fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/dashboard/dashboard.tsx",
          lineNumber: 23,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(PopularProductChart, {}, void 0, false, {
          fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/dashboard/dashboard.tsx",
          lineNumber: 24,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/dashboard/dashboard.tsx",
        lineNumber: 22,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/dashboard/dashboard.tsx",
      lineNumber: 14,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/dashboard/dashboard.tsx",
    lineNumber: 12,
    columnNumber: 5
  }, this);
}
_c = Dashboard;
var _c;
$RefreshReg$(_c, "Dashboard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arruday/Downloads/pizzashop/src/pages/app/dashboard/dashboard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV0ksbUJBQ0UsY0FERjtBQVhKLDJCQUF1QjtBQUFvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFM0MsU0FBU0EsMkJBQTJCO0FBQ3BDLFNBQVNDLHFDQUFxQztBQUM5QyxTQUFTQyw2QkFBNkI7QUFDdEMsU0FBU0Msd0JBQXdCO0FBQ2pDLFNBQVNDLDJCQUEyQjtBQUNwQyxTQUFTQyxvQkFBb0I7QUFFdEIsZ0JBQVNDLFlBQVk7QUFDMUIsU0FDRSxtQ0FDRTtBQUFBLDJCQUFDLFVBQU8sT0FBTSxlQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUI7QUFBQSxJQUN6Qix1QkFBQyxTQUFJLFdBQVUsdUJBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUscUNBQW9DLHlCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJEO0FBQUEsTUFDM0QsdUJBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUEsK0JBQUMsc0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQjtBQUFBLFFBQ2pCLHVCQUFDLDJCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0I7QUFBQSxRQUN0Qix1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9CO0FBQUEsUUFDcEIsdUJBQUMsbUNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4QjtBQUFBLFdBSmhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUEsK0JBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFhO0FBQUEsUUFDYix1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9CO0FBQUEsV0FGdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUE7QUFBQSxPQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FlQTtBQUVKO0FBQUNDLEtBbkJlRDtBQUFTLElBQUFDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJEYXlPcmRlcnNBbW91bnRDYXJkIiwiTW9udGhDYW5jZWxlZE9yZGVyc0Ftb3VudENhcmQiLCJNb250aE9yZGVyc0Ftb3VudENhcmQiLCJNb250aFJldmVudWVDYXJkIiwiUG9wdWxhclByb2R1Y3RDaGFydCIsIlJldmVudWVDaGFydCIsIkRhc2hib2FyZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiZGFzaGJvYXJkLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBIZWxtZXQgfSBmcm9tICdyZWFjdC1oZWxtZXQtYXN5bmMnXG5cbmltcG9ydCB7IERheU9yZGVyc0Ftb3VudENhcmQgfSBmcm9tICcuL2RheS1vcmRlcnMtYW1vdW50LWNhcmQnXG5pbXBvcnQgeyBNb250aENhbmNlbGVkT3JkZXJzQW1vdW50Q2FyZCB9IGZyb20gJy4vbW9udGgtY2FuY2VsZWQtb3JkZXJzLWFtb3VudC1jYXJkJ1xuaW1wb3J0IHsgTW9udGhPcmRlcnNBbW91bnRDYXJkIH0gZnJvbSAnLi9tb250aC1vcmRlcnMtYW1vdW50LWNhcmQnXG5pbXBvcnQgeyBNb250aFJldmVudWVDYXJkIH0gZnJvbSAnLi9tb250aC1yZXZlbnVlLWNhcmQnXG5pbXBvcnQgeyBQb3B1bGFyUHJvZHVjdENoYXJ0IH0gZnJvbSAnLi9wb3B1bGFyLXByb2R1Y3RzLWNoYXJ0J1xuaW1wb3J0IHsgUmV2ZW51ZUNoYXJ0IH0gZnJvbSAnLi9yZXZlbnVlLWNoYXJ0J1xuXG5leHBvcnQgZnVuY3Rpb24gRGFzaGJvYXJkKCkge1xuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8SGVsbWV0IHRpdGxlPVwiRGFzaGJvYXJkXCIgLz5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtNFwiPlxuICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRyYWNraW5nLXRpZ2h0XCI+RGFzaGJvYXJkPC9oMT5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy00IGdhcC00XCI+XG4gICAgICAgICAgPE1vbnRoUmV2ZW51ZUNhcmQgLz5cbiAgICAgICAgICA8TW9udGhPcmRlcnNBbW91bnRDYXJkIC8+XG4gICAgICAgICAgPERheU9yZGVyc0Ftb3VudENhcmQgLz5cbiAgICAgICAgICA8TW9udGhDYW5jZWxlZE9yZGVyc0Ftb3VudENhcmQgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtOSBnYXAtNFwiPlxuICAgICAgICAgIDxSZXZlbnVlQ2hhcnQgLz5cbiAgICAgICAgICA8UG9wdWxhclByb2R1Y3RDaGFydCAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvPlxuICApXG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9hcnJ1ZGF5L0Rvd25sb2Fkcy9waXp6YXNob3Avc3JjL3BhZ2VzL2FwcC9kYXNoYm9hcmQvZGFzaGJvYXJkLnRzeCJ9