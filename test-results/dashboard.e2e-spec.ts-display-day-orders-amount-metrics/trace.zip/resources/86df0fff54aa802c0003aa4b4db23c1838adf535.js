import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7d79b549"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=7d79b549"; const React = __vite__cjsImport1_react.__esModule ? __vite__cjsImport1_react.default : __vite__cjsImport1_react;
import __vite__cjsImport2_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=7d79b549"; const ReactDOM = __vite__cjsImport2_reactDom_client.__esModule ? __vite__cjsImport2_reactDom_client.default : __vite__cjsImport2_reactDom_client;
import { App } from "/src/app.tsx";
import { enableMSW } from "/src/api/mocks/index.ts";
enableMSW().then(() => {
  ReactDOM.createRoot(document.getElementById("root")).render(
    /* @__PURE__ */ jsxDEV(React.StrictMode, { children: /* @__PURE__ */ jsxDEV(App, {}, void 0, false, {
      fileName: "/Users/arruday/Downloads/pizzashop/src/main.tsx",
      lineNumber: 11,
      columnNumber: 7
    }, this) }, void 0, false, {
      fileName: "/Users/arruday/Downloads/pizzashop/src/main.tsx",
      lineNumber: 10,
      columnNumber: 5
    }, this)
  );
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVU07QUFWTixPQUFPQSxXQUFXO0FBQ2xCLE9BQU9DLGNBQWM7QUFFckIsU0FBU0MsV0FBVztBQUVwQixTQUFTQyxpQkFBaUI7QUFFMUJBLFVBQVUsRUFBRUMsS0FBSyxNQUFNO0FBQ3JCSCxXQUFTSSxXQUFXQyxTQUFTQyxlQUFlLE1BQU0sQ0FBRSxFQUFFQztBQUFBQSxJQUNwRCx1QkFBQyxNQUFNLFlBQU4sRUFDQyxpQ0FBQyxTQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBSSxLQUROO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBQ0Y7QUFDRixDQUFDIiwibmFtZXMiOlsiUmVhY3QiLCJSZWFjdERPTSIsIkFwcCIsImVuYWJsZU1TVyIsInRoZW4iLCJjcmVhdGVSb290IiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInJlbmRlciJdLCJzb3VyY2VzIjpbIm1haW4udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCdcbmltcG9ydCBSZWFjdERPTSBmcm9tICdyZWFjdC1kb20vY2xpZW50J1xuXG5pbXBvcnQgeyBBcHAgfSBmcm9tICdAL2FwcC50c3gnXG5cbmltcG9ydCB7IGVuYWJsZU1TVyB9IGZyb20gJy4vYXBpL21vY2tzJ1xuXG5lbmFibGVNU1coKS50aGVuKCgpID0+IHtcbiAgUmVhY3RET00uY3JlYXRlUm9vdChkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncm9vdCcpISkucmVuZGVyKFxuICAgIDxSZWFjdC5TdHJpY3RNb2RlPlxuICAgICAgPEFwcCAvPlxuICAgIDwvUmVhY3QuU3RyaWN0TW9kZT4sXG4gIClcbn0pXG4iXSwiZmlsZSI6Ii9Vc2Vycy9hcnJ1ZGF5L0Rvd25sb2Fkcy9waXp6YXNob3Avc3JjL21haW4udHN4In0=