import { http, HttpResponse } from "/node_modules/.vite/deps/msw.js?v=7d79b549";
export const getProfileMock = http.get(
  "/me",
  () => {
    return HttpResponse.json({
      name: "Felipe Arruda",
      id: "1",
      email: "felipe@mail.com",
      phone: "55999654584",
      role: "manager",
      createdAt: /* @__PURE__ */ new Date(),
      updatedAt: null
    });
  }
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImdldC1wcm9maWxlLW1vY2sudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgaHR0cCwgSHR0cFJlc3BvbnNlIH0gZnJvbSAnbXN3J1xuXG5pbXBvcnQgeyBHZXRQcm9maWxlUmVzcG9uc2UgfSBmcm9tICcuLi9nZXQtcHJvZmlsZSdcblxuZXhwb3J0IGNvbnN0IGdldFByb2ZpbGVNb2NrID0gaHR0cC5nZXQ8bmV2ZXIsIG5ldmVyLCBHZXRQcm9maWxlUmVzcG9uc2U+KFxuICAnL21lJyxcbiAgKCkgPT4ge1xuICAgIHJldHVybiBIdHRwUmVzcG9uc2UuanNvbih7XG4gICAgICBuYW1lOiAnRmVsaXBlIEFycnVkYScsXG4gICAgICBpZDogJzEnLFxuICAgICAgZW1haWw6ICdmZWxpcGVAbWFpbC5jb20nLFxuICAgICAgcGhvbmU6ICc1NTk5OTY1NDU4NCcsXG4gICAgICByb2xlOiAnbWFuYWdlcicsXG4gICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCksXG4gICAgICB1cGRhdGVkQXQ6IG51bGwsXG4gICAgfSlcbiAgfSxcbilcbiJdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxNQUFNLG9CQUFvQjtBQUk1QixhQUFNLGlCQUFpQixLQUFLO0FBQUEsRUFDakM7QUFBQSxFQUNBLE1BQU07QUFDSixXQUFPLGFBQWEsS0FBSztBQUFBLE1BQ3ZCLE1BQU07QUFBQSxNQUNOLElBQUk7QUFBQSxNQUNKLE9BQU87QUFBQSxNQUNQLE9BQU87QUFBQSxNQUNQLE1BQU07QUFBQSxNQUNOLFdBQVcsb0JBQUksS0FBSztBQUFBLE1BQ3BCLFdBQVc7QUFBQSxJQUNiLENBQUM7QUFBQSxFQUNIO0FBQ0Y7IiwibmFtZXMiOltdfQ==