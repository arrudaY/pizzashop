import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/app/dashboard/revenue-chart.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=efc33bbd"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/revenue-chart.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=efc33bbd";
import { subDays } from "/node_modules/.vite/deps/date-fns.js?v=efc33bbd";
import { Loader2 } from "/node_modules/.vite/deps/lucide-react.js?v=efc33bbd";
import __vite__cjsImport6_react from "/node_modules/.vite/deps/react.js?v=efc33bbd"; const useMemo = __vite__cjsImport6_react["useMemo"]; const useState = __vite__cjsImport6_react["useState"];
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  XAxis,
  YAxis
} from "/node_modules/.vite/deps/recharts.js?v=efc33bbd";
import __vite__cjsImport8_tailwindcss_colors from "/node_modules/.vite/deps/tailwindcss_colors.js?v=efc33bbd"; const colors = __vite__cjsImport8_tailwindcss_colors.__esModule ? __vite__cjsImport8_tailwindcss_colors.default : __vite__cjsImport8_tailwindcss_colors;
import { getDailyRevenuInPeriod } from "/src/api/get-daily-revenue-in-period.ts";
import { DateRangePicker } from "/src/components/date-range-picker.tsx";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle
} from "/src/components/ui/card.tsx";
import { Label } from "/src/components/ui/label.tsx";
export function RevenueChart() {
  _s();
  const [dateRange, setDateRange] = useState({
    from: subDays(/* @__PURE__ */ new Date(), 7),
    to: /* @__PURE__ */ new Date()
  });
  const { data: dailyRevenueInPeriod } = useQuery({
    queryKey: ["metrics", "daily-receipt-in-period", dateRange],
    queryFn: () => getDailyRevenuInPeriod({
      from: dateRange?.from,
      to: dateRange?.to
    })
  });
  const chartData = useMemo(() => {
    return dailyRevenueInPeriod?.map((chartItem) => {
      return {
        date: chartItem.date,
        receipt: chartItem.receipt / 100
      };
    });
  }, [dailyRevenueInPeriod]);
  return /* @__PURE__ */ jsxDEV(Card, { className: "col-span-6", children: [
    /* @__PURE__ */ jsxDEV(CardHeader, { className: "flex-row items-center justify-between pb-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-1", children: [
        /* @__PURE__ */ jsxDEV(CardTitle, { className: "text-base font-medium", children: "Receita no período" }, void 0, false, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/revenue-chart.tsx",
          lineNumber: 55,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(CardDescription, { children: "Receita diária no período" }, void 0, false, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/revenue-chart.tsx",
          lineNumber: 58,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/revenue-chart.tsx",
        lineNumber: 54,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV(Label, { children: "Período" }, void 0, false, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/revenue-chart.tsx",
          lineNumber: 61,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(DateRangePicker, { date: dateRange, onDateChange: setDateRange }, void 0, false, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/revenue-chart.tsx",
          lineNumber: 62,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/revenue-chart.tsx",
        lineNumber: 60,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/revenue-chart.tsx",
      lineNumber: 53,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(CardContent, { children: chartData ? /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: 240, children: /* @__PURE__ */ jsxDEV(LineChart, { data: chartData, style: { fontSize: 12 }, children: [
      /* @__PURE__ */ jsxDEV(CartesianGrid, { vertical: false, className: "stroke-muted" }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/revenue-chart.tsx",
        lineNumber: 69,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV(
        Line,
        {
          type: "linear",
          strokeWidth: 2,
          dataKey: "receipt",
          stroke: colors.violet[500]
        },
        void 0,
        false,
        {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/revenue-chart.tsx",
          lineNumber: 71,
          columnNumber: 15
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(XAxis, { dataKey: "date", axisLine: false, tickLine: false, dy: 16 }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/revenue-chart.tsx",
        lineNumber: 78,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV(
        YAxis,
        {
          stroke: "#888",
          axisLine: false,
          tickLine: false,
          width: 80,
          tickFormatter: (value) => value.toLocaleString("pt-BR", {
            style: "currency",
            currency: "BRL"
          })
        },
        void 0,
        false,
        {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/revenue-chart.tsx",
          lineNumber: 80,
          columnNumber: 15
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/revenue-chart.tsx",
      lineNumber: 68,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/revenue-chart.tsx",
      lineNumber: 67,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex h-[240px] w-full items-center justify-center", children: /* @__PURE__ */ jsxDEV(Loader2, { className: "h-8 w-8 animate-spin text-muted-foreground" }, void 0, false, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/revenue-chart.tsx",
      lineNumber: 96,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/revenue-chart.tsx",
      lineNumber: 95,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/revenue-chart.tsx",
      lineNumber: 65,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/revenue-chart.tsx",
    lineNumber: 52,
    columnNumber: 5
  }, this);
}
_s(RevenueChart, "qH02GdDJkGCDHE3sPduyMNerEJw=", false, function() {
  return [useQuery];
});
_c = RevenueChart;
var _c;
$RefreshReg$(_c, "RevenueChart");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/revenue-chart.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0RVOzJCQXREVjtBQUFpQixNQUFRLHFCQUF1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNoRCxTQUFTQSxlQUFlO0FBQ3hCLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsU0FBU0MsZ0JBQWdCO0FBRWxDO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLE9BQU9DLFlBQVk7QUFFbkIsU0FBU0MsOEJBQThCO0FBQ3ZDLFNBQVNDLHVCQUF1QjtBQUNoQztBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxTQUFTQyxhQUFhO0FBRWYsZ0JBQVNDLGVBQWU7QUFBQUMsS0FBQTtBQUM3QixRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSW5CLFNBQWdDO0FBQUEsSUFDaEVvQixNQUFNdkIsUUFBUSxvQkFBSXdCLEtBQUssR0FBRyxDQUFDO0FBQUEsSUFDM0JDLElBQUksb0JBQUlELEtBQUs7QUFBQSxFQUNmLENBQUM7QUFFRCxRQUFNLEVBQUVFLE1BQU1DLHFCQUFxQixJQUFJQyxTQUFTO0FBQUEsSUFDOUNDLFVBQVUsQ0FBQyxXQUFXLDJCQUEyQlIsU0FBUztBQUFBLElBQzFEUyxTQUFTQSxNQUNQbkIsdUJBQXVCO0FBQUEsTUFDckJZLE1BQU1GLFdBQVdFO0FBQUFBLE1BQ2pCRSxJQUFJSixXQUFXSTtBQUFBQSxJQUNqQixDQUFDO0FBQUEsRUFDTCxDQUFDO0FBRUQsUUFBTU0sWUFBWTdCLFFBQVEsTUFBTTtBQUM5QixXQUFPeUIsc0JBQXNCSyxJQUFJLENBQUNDLGNBQWM7QUFDOUMsYUFBTztBQUFBLFFBQ0xDLE1BQU1ELFVBQVVDO0FBQUFBLFFBQ2hCQyxTQUFTRixVQUFVRSxVQUFVO0FBQUEsTUFDL0I7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNILEdBQUcsQ0FBQ1Isb0JBQW9CLENBQUM7QUFFekIsU0FDRSx1QkFBQyxRQUFLLFdBQVUsY0FDZDtBQUFBLDJCQUFDLGNBQVcsV0FBVSw4Q0FDcEI7QUFBQSw2QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtCQUFDLGFBQVUsV0FBVSx5QkFBdUIsa0NBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsbUJBQWdCLHlDQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBDO0FBQUEsV0FKNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSwrQkFBQyxTQUFNLHVCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBYztBQUFBLFFBQ2QsdUJBQUMsbUJBQWdCLE1BQU1OLFdBQVcsY0FBY0MsZ0JBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkQ7QUFBQSxXQUYvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FXQTtBQUFBLElBQ0EsdUJBQUMsZUFDRVMsc0JBQ0MsdUJBQUMsdUJBQW9CLE9BQU0sUUFBTyxRQUFRLEtBQ3hDLGlDQUFDLGFBQVUsTUFBTUEsV0FBVyxPQUFPLEVBQUVLLFVBQVUsR0FBRyxHQUNoRDtBQUFBLDZCQUFDLGlCQUFjLFVBQVUsT0FBTyxXQUFVLGtCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdEO0FBQUEsTUFFeEQ7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLGFBQWE7QUFBQSxVQUNiLFNBQVE7QUFBQSxVQUNSLFFBQVExQixPQUFPMkIsT0FBTyxHQUFHO0FBQUE7QUFBQSxRQUozQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJNkI7QUFBQSxNQUc3Qix1QkFBQyxTQUFNLFNBQVEsUUFBTyxVQUFVLE9BQU8sVUFBVSxPQUFPLElBQUksTUFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErRDtBQUFBLE1BRS9EO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxRQUFPO0FBQUEsVUFDUCxVQUFVO0FBQUEsVUFDVixVQUFVO0FBQUEsVUFDVixPQUFPO0FBQUEsVUFDUCxlQUFlLENBQUNDLFVBQ2RBLE1BQU1DLGVBQWUsU0FBUztBQUFBLFlBQzVCQyxPQUFPO0FBQUEsWUFDUEMsVUFBVTtBQUFBLFVBQ1osQ0FBQztBQUFBO0FBQUEsUUFUTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFVRztBQUFBLFNBdEJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3QkEsS0F6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBCQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxxREFDYixpQ0FBQyxXQUFRLFdBQVUsZ0RBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0QsS0FEakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBLEtBaENKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrQ0E7QUFBQSxPQS9DRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZ0RBO0FBRUo7QUFBQ3JCLEdBM0VlRCxjQUFZO0FBQUEsVUFNYVMsUUFBUTtBQUFBO0FBQUFjLEtBTmpDdkI7QUFBWSxJQUFBdUI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInN1YkRheXMiLCJMb2FkZXIyIiwidXNlTWVtbyIsInVzZVN0YXRlIiwiQ2FydGVzaWFuR3JpZCIsIkxpbmUiLCJMaW5lQ2hhcnQiLCJSZXNwb25zaXZlQ29udGFpbmVyIiwiWEF4aXMiLCJZQXhpcyIsImNvbG9ycyIsImdldERhaWx5UmV2ZW51SW5QZXJpb2QiLCJEYXRlUmFuZ2VQaWNrZXIiLCJDYXJkIiwiQ2FyZENvbnRlbnQiLCJDYXJkRGVzY3JpcHRpb24iLCJDYXJkSGVhZGVyIiwiQ2FyZFRpdGxlIiwiTGFiZWwiLCJSZXZlbnVlQ2hhcnQiLCJfcyIsImRhdGVSYW5nZSIsInNldERhdGVSYW5nZSIsImZyb20iLCJEYXRlIiwidG8iLCJkYXRhIiwiZGFpbHlSZXZlbnVlSW5QZXJpb2QiLCJ1c2VRdWVyeSIsInF1ZXJ5S2V5IiwicXVlcnlGbiIsImNoYXJ0RGF0YSIsIm1hcCIsImNoYXJ0SXRlbSIsImRhdGUiLCJyZWNlaXB0IiwiZm9udFNpemUiLCJ2aW9sZXQiLCJ2YWx1ZSIsInRvTG9jYWxlU3RyaW5nIiwic3R5bGUiLCJjdXJyZW5jeSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsicmV2ZW51ZS1jaGFydC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUXVlcnkgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG5pbXBvcnQgeyBzdWJEYXlzIH0gZnJvbSAnZGF0ZS1mbnMnXG5pbXBvcnQgeyBMb2FkZXIyIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IERhdGVSYW5nZSB9IGZyb20gJ3JlYWN0LWRheS1waWNrZXInXG5pbXBvcnQge1xuICBDYXJ0ZXNpYW5HcmlkLFxuICBMaW5lLFxuICBMaW5lQ2hhcnQsXG4gIFJlc3BvbnNpdmVDb250YWluZXIsXG4gIFhBeGlzLFxuICBZQXhpcyxcbn0gZnJvbSAncmVjaGFydHMnXG5pbXBvcnQgY29sb3JzIGZyb20gJ3RhaWx3aW5kY3NzL2NvbG9ycydcblxuaW1wb3J0IHsgZ2V0RGFpbHlSZXZlbnVJblBlcmlvZCB9IGZyb20gJ0AvYXBpL2dldC1kYWlseS1yZXZlbnVlLWluLXBlcmlvZCdcbmltcG9ydCB7IERhdGVSYW5nZVBpY2tlciB9IGZyb20gJ0AvY29tcG9uZW50cy9kYXRlLXJhbmdlLXBpY2tlcidcbmltcG9ydCB7XG4gIENhcmQsXG4gIENhcmRDb250ZW50LFxuICBDYXJkRGVzY3JpcHRpb24sXG4gIENhcmRIZWFkZXIsXG4gIENhcmRUaXRsZSxcbn0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2NhcmQnXG5pbXBvcnQgeyBMYWJlbCB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9sYWJlbCdcblxuZXhwb3J0IGZ1bmN0aW9uIFJldmVudWVDaGFydCgpIHtcbiAgY29uc3QgW2RhdGVSYW5nZSwgc2V0RGF0ZVJhbmdlXSA9IHVzZVN0YXRlPERhdGVSYW5nZSB8IHVuZGVmaW5lZD4oe1xuICAgIGZyb206IHN1YkRheXMobmV3IERhdGUoKSwgNyksXG4gICAgdG86IG5ldyBEYXRlKCksXG4gIH0pXG5cbiAgY29uc3QgeyBkYXRhOiBkYWlseVJldmVudWVJblBlcmlvZCB9ID0gdXNlUXVlcnkoe1xuICAgIHF1ZXJ5S2V5OiBbJ21ldHJpY3MnLCAnZGFpbHktcmVjZWlwdC1pbi1wZXJpb2QnLCBkYXRlUmFuZ2VdLFxuICAgIHF1ZXJ5Rm46ICgpID0+XG4gICAgICBnZXREYWlseVJldmVudUluUGVyaW9kKHtcbiAgICAgICAgZnJvbTogZGF0ZVJhbmdlPy5mcm9tLFxuICAgICAgICB0bzogZGF0ZVJhbmdlPy50byxcbiAgICAgIH0pLFxuICB9KVxuXG4gIGNvbnN0IGNoYXJ0RGF0YSA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIHJldHVybiBkYWlseVJldmVudWVJblBlcmlvZD8ubWFwKChjaGFydEl0ZW0pID0+IHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGRhdGU6IGNoYXJ0SXRlbS5kYXRlLFxuICAgICAgICByZWNlaXB0OiBjaGFydEl0ZW0ucmVjZWlwdCAvIDEwMCxcbiAgICAgIH1cbiAgICB9KVxuICB9LCBbZGFpbHlSZXZlbnVlSW5QZXJpb2RdKVxuXG4gIHJldHVybiAoXG4gICAgPENhcmQgY2xhc3NOYW1lPVwiY29sLXNwYW4tNlwiPlxuICAgICAgPENhcmRIZWFkZXIgY2xhc3NOYW1lPVwiZmxleC1yb3cgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwYi04XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgICAgPENhcmRUaXRsZSBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgIFJlY2VpdGEgbm8gcGVyw61vZG9cbiAgICAgICAgICA8L0NhcmRUaXRsZT5cbiAgICAgICAgICA8Q2FyZERlc2NyaXB0aW9uPlJlY2VpdGEgZGnDoXJpYSBubyBwZXLDrW9kbzwvQ2FyZERlc2NyaXB0aW9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgIDxMYWJlbD5QZXLDrW9kbzwvTGFiZWw+XG4gICAgICAgICAgPERhdGVSYW5nZVBpY2tlciBkYXRlPXtkYXRlUmFuZ2V9IG9uRGF0ZUNoYW5nZT17c2V0RGF0ZVJhbmdlfSAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvQ2FyZEhlYWRlcj5cbiAgICAgIDxDYXJkQ29udGVudD5cbiAgICAgICAge2NoYXJ0RGF0YSA/IChcbiAgICAgICAgICA8UmVzcG9uc2l2ZUNvbnRhaW5lciB3aWR0aD1cIjEwMCVcIiBoZWlnaHQ9ezI0MH0+XG4gICAgICAgICAgICA8TGluZUNoYXJ0IGRhdGE9e2NoYXJ0RGF0YX0gc3R5bGU9e3sgZm9udFNpemU6IDEyIH19PlxuICAgICAgICAgICAgICA8Q2FydGVzaWFuR3JpZCB2ZXJ0aWNhbD17ZmFsc2V9IGNsYXNzTmFtZT1cInN0cm9rZS1tdXRlZFwiIC8+XG5cbiAgICAgICAgICAgICAgPExpbmVcbiAgICAgICAgICAgICAgICB0eXBlPVwibGluZWFyXCJcbiAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD17Mn1cbiAgICAgICAgICAgICAgICBkYXRhS2V5PVwicmVjZWlwdFwiXG4gICAgICAgICAgICAgICAgc3Ryb2tlPXtjb2xvcnMudmlvbGV0WzUwMF19XG4gICAgICAgICAgICAgIC8+XG5cbiAgICAgICAgICAgICAgPFhBeGlzIGRhdGFLZXk9XCJkYXRlXCIgYXhpc0xpbmU9e2ZhbHNlfSB0aWNrTGluZT17ZmFsc2V9IGR5PXsxNn0gLz5cblxuICAgICAgICAgICAgICA8WUF4aXNcbiAgICAgICAgICAgICAgICBzdHJva2U9XCIjODg4XCJcbiAgICAgICAgICAgICAgICBheGlzTGluZT17ZmFsc2V9XG4gICAgICAgICAgICAgICAgdGlja0xpbmU9e2ZhbHNlfVxuICAgICAgICAgICAgICAgIHdpZHRoPXs4MH1cbiAgICAgICAgICAgICAgICB0aWNrRm9ybWF0dGVyPXsodmFsdWU6IG51bWJlcikgPT5cbiAgICAgICAgICAgICAgICAgIHZhbHVlLnRvTG9jYWxlU3RyaW5nKCdwdC1CUicsIHtcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU6ICdjdXJyZW5jeScsXG4gICAgICAgICAgICAgICAgICAgIGN1cnJlbmN5OiAnQlJMJyxcbiAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9MaW5lQ2hhcnQ+XG4gICAgICAgICAgPC9SZXNwb25zaXZlQ29udGFpbmVyPlxuICAgICAgICApIDogKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLVsyNDBweF0gdy1mdWxsIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgPExvYWRlcjIgY2xhc3NOYW1lPVwiaC04IHctOCBhbmltYXRlLXNwaW4gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvQ2FyZENvbnRlbnQ+XG4gICAgPC9DYXJkPlxuICApXG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9hcnJ1ZGF5L0dpdEh1Yi9waXp6YXNob3Avc3JjL3BhZ2VzL2FwcC9kYXNoYm9hcmQvcmV2ZW51ZS1jaGFydC50c3gifQ==