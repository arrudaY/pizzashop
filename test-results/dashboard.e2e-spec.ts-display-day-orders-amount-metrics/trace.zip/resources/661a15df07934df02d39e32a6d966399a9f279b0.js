import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/404.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7d79b549"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/arruday/Downloads/pizzashop/src/pages/404.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=7d79b549";
export function NotFound() {
  return /* @__PURE__ */ jsxDEV("div", { className: "flex h-screen flex-col items-center justify-center gap-2", children: [
    /* @__PURE__ */ jsxDEV("h1", { className: "text-4xl font-bold", children: "Página não encontrada" }, void 0, false, {
      fileName: "/Users/arruday/Downloads/pizzashop/src/pages/404.tsx",
      lineNumber: 6,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "text-accent-foreground", children: [
      "Voltra para o",
      " ",
      /* @__PURE__ */ jsxDEV(Link, { to: "/", className: "text-sky-500 dark:text-sky-400", children: "Dashboard" }, void 0, false, {
        fileName: "/Users/arruday/Downloads/pizzashop/src/pages/404.tsx",
        lineNumber: 9,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/arruday/Downloads/pizzashop/src/pages/404.tsx",
      lineNumber: 7,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/arruday/Downloads/pizzashop/src/pages/404.tsx",
    lineNumber: 5,
    columnNumber: 5
  }, this);
}
_c = NotFound;
var _c;
$RefreshReg$(_c, "NotFound");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arruday/Downloads/pizzashop/src/pages/404.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBS007QUFMTiwyQkFBcUI7QUFBa0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRWhDLGdCQUFTQSxXQUFXO0FBQ3pCLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLDREQUNiO0FBQUEsMkJBQUMsUUFBRyxXQUFVLHNCQUFxQixxQ0FBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3RDtBQUFBLElBQ3hELHVCQUFDLE9BQUUsV0FBVSwwQkFBd0I7QUFBQTtBQUFBLE1BQ3JCO0FBQUEsTUFDZCx1QkFBQyxRQUFLLElBQUksS0FBSyxXQUFVLGtDQUFnQyx5QkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxPQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FRQTtBQUVKO0FBQUNDLEtBWmVEO0FBQVEsSUFBQUM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIk5vdEZvdW5kIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyI0MDQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuXG5leHBvcnQgZnVuY3Rpb24gTm90Rm91bmQoKSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtc2NyZWVuIGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiPlxuICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtNHhsIGZvbnQtYm9sZFwiPlDDoWdpbmEgbsOjbyBlbmNvbnRyYWRhPC9oMT5cbiAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtYWNjZW50LWZvcmVncm91bmRcIj5cbiAgICAgICAgVm9sdHJhIHBhcmEgb3snICd9XG4gICAgICAgIDxMaW5rIHRvPXsnLyd9IGNsYXNzTmFtZT1cInRleHQtc2t5LTUwMCBkYXJrOnRleHQtc2t5LTQwMFwiPlxuICAgICAgICAgIERhc2hib2FyZFxuICAgICAgICA8L0xpbms+XG4gICAgICA8L3A+XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2FycnVkYXkvRG93bmxvYWRzL3Bpenphc2hvcC9zcmMvcGFnZXMvNDA0LnRzeCJ9