import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/auth/sign-up.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7d79b549"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/arruday/Downloads/pizzashop/src/pages/auth/sign-up.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useMutation } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=7d79b549";
import { Helmet } from "/node_modules/.vite/deps/react-helmet-async.js?v=7d79b549";
import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=7d79b549";
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=7d79b549";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=7d79b549";
import { z } from "/node_modules/.vite/deps/zod.js?v=7d79b549";
import { registerRestaurant } from "/src/api/register-restaurant.ts";
import { Button } from "/src/components/ui/button.tsx";
import { Input } from "/src/components/ui/input.tsx";
import { Label } from "/src/components/ui/label.tsx";
const signUpForm = z.object({
  restaurantName: z.string(),
  managerName: z.string(),
  phone: z.string(),
  email: z.string().email()
});
export function SignUp() {
  _s();
  const navigate = useNavigate();
  const {
    register,
    handleSubmit,
    formState: { isSubmitting }
  } = useForm();
  const { mutateAsync: registerRestaurantFn } = useMutation({
    mutationFn: registerRestaurant
  });
  async function handleSignUp(data) {
    try {
      await registerRestaurantFn({
        restaurantName: data.restaurantName,
        managerName: data.managerName,
        email: data.email,
        phone: data.phone
      });
      toast.success("Restaurante cadastrado com sucesso.", {
        action: {
          label: "Login",
          onClick: () => navigate(`/sign-in?email=${data.email}`)
        }
      });
    } catch {
      toast.error("Erro ao cadastrar estabelecimento.");
    }
  }
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(Helmet, { title: "Cadastro" }, void 0, false, {
      fileName: "/Users/arruday/Downloads/pizzashop/src/pages/auth/sign-up.tsx",
      lineNumber: 57,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p-8", children: [
      /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", asChild: true, className: "absolute right-8 top-8", children: /* @__PURE__ */ jsxDEV(Link, { to: "/sign-in", children: "Fazer login" }, void 0, false, {
        fileName: "/Users/arruday/Downloads/pizzashop/src/pages/auth/sign-up.tsx",
        lineNumber: 60,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/arruday/Downloads/pizzashop/src/pages/auth/sign-up.tsx",
        lineNumber: 59,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex w-[350px] flex-col justify-center gap-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-2 text-center", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold tracking-tight", children: "Criar conta grátis" }, void 0, false, {
            fileName: "/Users/arruday/Downloads/pizzashop/src/pages/auth/sign-up.tsx",
            lineNumber: 64,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-muted-foreground", children: "Seja um parceiro e comece suas vendas!" }, void 0, false, {
            fileName: "/Users/arruday/Downloads/pizzashop/src/pages/auth/sign-up.tsx",
            lineNumber: 67,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/arruday/Downloads/pizzashop/src/pages/auth/sign-up.tsx",
          lineNumber: 63,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit(handleSignUp), className: "space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV(Label, { htmlFor: "restaurantName", children: "Nome do estabelecimento" }, void 0, false, {
              fileName: "/Users/arruday/Downloads/pizzashop/src/pages/auth/sign-up.tsx",
              lineNumber: 73,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                id: "restaurantName",
                type: "text",
                ...register("restaurantName")
              },
              void 0,
              false,
              {
                fileName: "/Users/arruday/Downloads/pizzashop/src/pages/auth/sign-up.tsx",
                lineNumber: 74,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/arruday/Downloads/pizzashop/src/pages/auth/sign-up.tsx",
            lineNumber: 72,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV(Label, { htmlFor: "managerName", children: "Seu nome" }, void 0, false, {
              fileName: "/Users/arruday/Downloads/pizzashop/src/pages/auth/sign-up.tsx",
              lineNumber: 82,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                id: "managerName",
                type: "text",
                ...register("managerName")
              },
              void 0,
              false,
              {
                fileName: "/Users/arruday/Downloads/pizzashop/src/pages/auth/sign-up.tsx",
                lineNumber: 83,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/arruday/Downloads/pizzashop/src/pages/auth/sign-up.tsx",
            lineNumber: 81,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV(Label, { htmlFor: "email", children: "Seu e-mail" }, void 0, false, {
              fileName: "/Users/arruday/Downloads/pizzashop/src/pages/auth/sign-up.tsx",
              lineNumber: 91,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(Input, { id: "email", type: "email", ...register("email") }, void 0, false, {
              fileName: "/Users/arruday/Downloads/pizzashop/src/pages/auth/sign-up.tsx",
              lineNumber: 92,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/arruday/Downloads/pizzashop/src/pages/auth/sign-up.tsx",
            lineNumber: 90,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV(Label, { htmlFor: "phone", children: "Seu celular" }, void 0, false, {
              fileName: "/Users/arruday/Downloads/pizzashop/src/pages/auth/sign-up.tsx",
              lineNumber: 96,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(Input, { id: "phone", type: "tel", ...register("phone") }, void 0, false, {
              fileName: "/Users/arruday/Downloads/pizzashop/src/pages/auth/sign-up.tsx",
              lineNumber: 97,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/arruday/Downloads/pizzashop/src/pages/auth/sign-up.tsx",
            lineNumber: 95,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { disabled: isSubmitting, type: "submit", className: "w-full", children: "Finalizar cadastro" }, void 0, false, {
            fileName: "/Users/arruday/Downloads/pizzashop/src/pages/auth/sign-up.tsx",
            lineNumber: 100,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "px-6 text-center text-sm leading-relaxed text-muted-foreground", children: [
            "Ao continuar, você concordar com os nossos",
            " ",
            /* @__PURE__ */ jsxDEV("a", { href: "", className: "underline underline-offset-4", children: "Termos de serviço" }, void 0, false, {
              fileName: "/Users/arruday/Downloads/pizzashop/src/pages/auth/sign-up.tsx",
              lineNumber: 106,
              columnNumber: 15
            }, this),
            " ",
            "e",
            " ",
            /* @__PURE__ */ jsxDEV("a", { href: "", className: "underline underline-offset-4", children: "Políticas de privacidade" }, void 0, false, {
              fileName: "/Users/arruday/Downloads/pizzashop/src/pages/auth/sign-up.tsx",
              lineNumber: 110,
              columnNumber: 15
            }, this),
            "."
          ] }, void 0, true, {
            fileName: "/Users/arruday/Downloads/pizzashop/src/pages/auth/sign-up.tsx",
            lineNumber: 104,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/arruday/Downloads/pizzashop/src/pages/auth/sign-up.tsx",
          lineNumber: 71,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/arruday/Downloads/pizzashop/src/pages/auth/sign-up.tsx",
        lineNumber: 62,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/arruday/Downloads/pizzashop/src/pages/auth/sign-up.tsx",
      lineNumber: 58,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/arruday/Downloads/pizzashop/src/pages/auth/sign-up.tsx",
    lineNumber: 56,
    columnNumber: 5
  }, this);
}
_s(SignUp, "zTCo5ErmhzsqMvwroFEB3svgwTQ=", false, function() {
  return [useNavigate, useForm, useMutation];
});
_c = SignUp;
var _c;
$RefreshReg$(_c, "SignUp");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arruday/Downloads/pizzashop/src/pages/auth/sign-up.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdURJLG1CQUNFLGNBREY7MkJBdkRKO0FBQW9CLG9CQUFRLDZCQUF1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNuRCxTQUFTQSxjQUFjO0FBQ3ZCLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsTUFBTUMsbUJBQW1CO0FBQ2xDLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsU0FBUztBQUVsQixTQUFTQywwQkFBMEI7QUFDbkMsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLGFBQWE7QUFFdEIsTUFBTUMsYUFBYUwsRUFBRU0sT0FBTztBQUFBLEVBQzFCQyxnQkFBZ0JQLEVBQUVRLE9BQU87QUFBQSxFQUN6QkMsYUFBYVQsRUFBRVEsT0FBTztBQUFBLEVBQ3RCRSxPQUFPVixFQUFFUSxPQUFPO0FBQUEsRUFDaEJHLE9BQU9YLEVBQUVRLE9BQU8sRUFBRUcsTUFBTTtBQUMxQixDQUFDO0FBSU0sZ0JBQVNDLFNBQVM7QUFBQUMsS0FBQTtBQUN2QixRQUFNQyxXQUFXaEIsWUFBWTtBQUU3QixRQUFNO0FBQUEsSUFDSmlCO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDLFdBQVcsRUFBRUMsYUFBYTtBQUFBLEVBQzVCLElBQUl0QixRQUFvQjtBQUV4QixRQUFNLEVBQUV1QixhQUFhQyxxQkFBcUIsSUFBSUMsWUFBWTtBQUFBLElBQ3hEQyxZQUFZckI7QUFBQUEsRUFDZCxDQUFDO0FBRUQsaUJBQWVzQixhQUFhQyxNQUFrQjtBQUM1QyxRQUFJO0FBQ0YsWUFBTUoscUJBQXFCO0FBQUEsUUFDekJiLGdCQUFnQmlCLEtBQUtqQjtBQUFBQSxRQUNyQkUsYUFBYWUsS0FBS2Y7QUFBQUEsUUFDbEJFLE9BQU9hLEtBQUtiO0FBQUFBLFFBQ1pELE9BQU9jLEtBQUtkO0FBQUFBLE1BQ2QsQ0FBQztBQUVEWCxZQUFNMEIsUUFBUSx1Q0FBdUM7QUFBQSxRQUNuREMsUUFBUTtBQUFBLFVBQ05DLE9BQU87QUFBQSxVQUNQQyxTQUFTQSxNQUFNZCxTQUFVLGtCQUFpQlUsS0FBS2IsS0FBTSxFQUFDO0FBQUEsUUFDeEQ7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNILFFBQVE7QUFDTlosWUFBTThCLE1BQU0sb0NBQW9DO0FBQUEsSUFDbEQ7QUFBQSxFQUNGO0FBRUEsU0FDRSxtQ0FDRTtBQUFBLDJCQUFDLFVBQU8sT0FBTSxjQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0I7QUFBQSxJQUN4Qix1QkFBQyxTQUFJLFdBQVUsT0FDYjtBQUFBLDZCQUFDLFVBQU8sU0FBUSxTQUFRLFNBQU8sTUFBQyxXQUFVLDBCQUN4QyxpQ0FBQyxRQUFLLElBQUcsWUFBVywyQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErQixLQURqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxnREFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxtQ0FDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSx5Q0FBdUMsa0NBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSxpQ0FBK0Isc0RBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBQ0EsdUJBQUMsVUFBSyxVQUFVYixhQUFhTyxZQUFZLEdBQUcsV0FBVSxhQUNwRDtBQUFBLGlDQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsbUNBQUMsU0FBTSxTQUFRLGtCQUFpQix1Q0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUQ7QUFBQSxZQUN2RDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLElBQUc7QUFBQSxnQkFDSCxNQUFLO0FBQUEsZ0JBQ0wsR0FBSVIsU0FBUyxnQkFBZ0I7QUFBQTtBQUFBLGNBSC9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUdpQztBQUFBLGVBTG5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsbUNBQUMsU0FBTSxTQUFRLGVBQWMsd0JBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFDO0FBQUEsWUFDckM7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxJQUFHO0FBQUEsZ0JBQ0gsTUFBSztBQUFBLGdCQUNMLEdBQUlBLFNBQVMsYUFBYTtBQUFBO0FBQUEsY0FINUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRzhCO0FBQUEsZUFMaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxtQ0FBQyxTQUFNLFNBQVEsU0FBUSwwQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUM7QUFBQSxZQUNqQyx1QkFBQyxTQUFNLElBQUcsU0FBUSxNQUFLLFNBQVEsR0FBSUEsU0FBUyxPQUFPLEtBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFEO0FBQUEsZUFGdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxtQ0FBQyxTQUFNLFNBQVEsU0FBUSwyQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0M7QUFBQSxZQUNsQyx1QkFBQyxTQUFNLElBQUcsU0FBUSxNQUFLLE9BQU0sR0FBSUEsU0FBUyxPQUFPLEtBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1EO0FBQUEsZUFGckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBRUEsdUJBQUMsVUFBTyxVQUFVRyxjQUFjLE1BQUssVUFBUyxXQUFVLFVBQVEsa0NBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUVBLHVCQUFDLE9BQUUsV0FBVSxrRUFBZ0U7QUFBQTtBQUFBLFlBQ2hDO0FBQUEsWUFDM0MsdUJBQUMsT0FBRSxNQUFLLElBQUcsV0FBVSxnQ0FBOEIsaUNBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUFLO0FBQUEsWUFBRztBQUFBLFlBQ047QUFBQSxZQUNGLHVCQUFDLE9BQUUsTUFBSyxJQUFHLFdBQVUsZ0NBQThCLHdDQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFBRztBQUFBLGVBUkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLGFBM0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0Q0E7QUFBQSxXQXJERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBc0RBO0FBQUEsU0ExREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJEQTtBQUFBLE9BN0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E4REE7QUFFSjtBQUFDTCxHQWxHZUQsUUFBTTtBQUFBLFVBQ0hkLGFBTWJGLFNBRTBDeUIsV0FBVztBQUFBO0FBQUFTLEtBVDNDbEI7QUFBTSxJQUFBa0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkhlbG1ldCIsInVzZUZvcm0iLCJMaW5rIiwidXNlTmF2aWdhdGUiLCJ0b2FzdCIsInoiLCJyZWdpc3RlclJlc3RhdXJhbnQiLCJCdXR0b24iLCJJbnB1dCIsIkxhYmVsIiwic2lnblVwRm9ybSIsIm9iamVjdCIsInJlc3RhdXJhbnROYW1lIiwic3RyaW5nIiwibWFuYWdlck5hbWUiLCJwaG9uZSIsImVtYWlsIiwiU2lnblVwIiwiX3MiLCJuYXZpZ2F0ZSIsInJlZ2lzdGVyIiwiaGFuZGxlU3VibWl0IiwiZm9ybVN0YXRlIiwiaXNTdWJtaXR0aW5nIiwibXV0YXRlQXN5bmMiLCJyZWdpc3RlclJlc3RhdXJhbnRGbiIsInVzZU11dGF0aW9uIiwibXV0YXRpb25GbiIsImhhbmRsZVNpZ25VcCIsImRhdGEiLCJzdWNjZXNzIiwiYWN0aW9uIiwibGFiZWwiLCJvbkNsaWNrIiwiZXJyb3IiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbInNpZ24tdXAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZU11dGF0aW9uIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuaW1wb3J0IHsgSGVsbWV0IH0gZnJvbSAncmVhY3QtaGVsbWV0LWFzeW5jJ1xuaW1wb3J0IHsgdXNlRm9ybSB9IGZyb20gJ3JlYWN0LWhvb2stZm9ybSdcbmltcG9ydCB7IExpbmssIHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSAnc29ubmVyJ1xuaW1wb3J0IHsgeiB9IGZyb20gJ3pvZCdcblxuaW1wb3J0IHsgcmVnaXN0ZXJSZXN0YXVyYW50IH0gZnJvbSAnQC9hcGkvcmVnaXN0ZXItcmVzdGF1cmFudCdcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9idXR0b24nXG5pbXBvcnQgeyBJbnB1dCB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9pbnB1dCdcbmltcG9ydCB7IExhYmVsIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2xhYmVsJ1xuXG5jb25zdCBzaWduVXBGb3JtID0gei5vYmplY3Qoe1xuICByZXN0YXVyYW50TmFtZTogei5zdHJpbmcoKSxcbiAgbWFuYWdlck5hbWU6IHouc3RyaW5nKCksXG4gIHBob25lOiB6LnN0cmluZygpLFxuICBlbWFpbDogei5zdHJpbmcoKS5lbWFpbCgpLFxufSlcblxudHlwZSBTaWduVXBGb3JtID0gei5pbmZlcjx0eXBlb2Ygc2lnblVwRm9ybT5cblxuZXhwb3J0IGZ1bmN0aW9uIFNpZ25VcCgpIHtcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpXG5cbiAgY29uc3Qge1xuICAgIHJlZ2lzdGVyLFxuICAgIGhhbmRsZVN1Ym1pdCxcbiAgICBmb3JtU3RhdGU6IHsgaXNTdWJtaXR0aW5nIH0sXG4gIH0gPSB1c2VGb3JtPFNpZ25VcEZvcm0+KClcblxuICBjb25zdCB7IG11dGF0ZUFzeW5jOiByZWdpc3RlclJlc3RhdXJhbnRGbiB9ID0gdXNlTXV0YXRpb24oe1xuICAgIG11dGF0aW9uRm46IHJlZ2lzdGVyUmVzdGF1cmFudCxcbiAgfSlcblxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVTaWduVXAoZGF0YTogU2lnblVwRm9ybSkge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCByZWdpc3RlclJlc3RhdXJhbnRGbih7XG4gICAgICAgIHJlc3RhdXJhbnROYW1lOiBkYXRhLnJlc3RhdXJhbnROYW1lLFxuICAgICAgICBtYW5hZ2VyTmFtZTogZGF0YS5tYW5hZ2VyTmFtZSxcbiAgICAgICAgZW1haWw6IGRhdGEuZW1haWwsXG4gICAgICAgIHBob25lOiBkYXRhLnBob25lLFxuICAgICAgfSlcblxuICAgICAgdG9hc3Quc3VjY2VzcygnUmVzdGF1cmFudGUgY2FkYXN0cmFkbyBjb20gc3VjZXNzby4nLCB7XG4gICAgICAgIGFjdGlvbjoge1xuICAgICAgICAgIGxhYmVsOiAnTG9naW4nLFxuICAgICAgICAgIG9uQ2xpY2s6ICgpID0+IG5hdmlnYXRlKGAvc2lnbi1pbj9lbWFpbD0ke2RhdGEuZW1haWx9YCksXG4gICAgICAgIH0sXG4gICAgICB9KVxuICAgIH0gY2F0Y2gge1xuICAgICAgdG9hc3QuZXJyb3IoJ0Vycm8gYW8gY2FkYXN0cmFyIGVzdGFiZWxlY2ltZW50by4nKVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxIZWxtZXQgdGl0bGU9XCJDYWRhc3Ryb1wiIC8+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtOFwiPlxuICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIGFzQ2hpbGQgY2xhc3NOYW1lPVwiYWJzb2x1dGUgcmlnaHQtOCB0b3AtOFwiPlxuICAgICAgICAgIDxMaW5rIHRvPVwiL3NpZ24taW5cIj5GYXplciBsb2dpbjwvTGluaz5cbiAgICAgICAgPC9CdXR0b24+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCB3LVszNTBweF0gZmxleC1jb2wganVzdGlmeS1jZW50ZXIgZ2FwLTZcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTIgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0XCI+XG4gICAgICAgICAgICAgIENyaWFyIGNvbnRhIGdyw6F0aXNcbiAgICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICBTZWphIHVtIHBhcmNlaXJvIGUgY29tZWNlIHN1YXMgdmVuZGFzIVxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXQoaGFuZGxlU2lnblVwKX0gY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICA8TGFiZWwgaHRtbEZvcj1cInJlc3RhdXJhbnROYW1lXCI+Tm9tZSBkbyBlc3RhYmVsZWNpbWVudG88L0xhYmVsPlxuICAgICAgICAgICAgICA8SW5wdXRcbiAgICAgICAgICAgICAgICBpZD1cInJlc3RhdXJhbnROYW1lXCJcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyKCdyZXN0YXVyYW50TmFtZScpfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgIDxMYWJlbCBodG1sRm9yPVwibWFuYWdlck5hbWVcIj5TZXUgbm9tZTwvTGFiZWw+XG4gICAgICAgICAgICAgIDxJbnB1dFxuICAgICAgICAgICAgICAgIGlkPVwibWFuYWdlck5hbWVcIlxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoJ21hbmFnZXJOYW1lJyl9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgPExhYmVsIGh0bWxGb3I9XCJlbWFpbFwiPlNldSBlLW1haWw8L0xhYmVsPlxuICAgICAgICAgICAgICA8SW5wdXQgaWQ9XCJlbWFpbFwiIHR5cGU9XCJlbWFpbFwiIHsuLi5yZWdpc3RlcignZW1haWwnKX0gLz5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICA8TGFiZWwgaHRtbEZvcj1cInBob25lXCI+U2V1IGNlbHVsYXI8L0xhYmVsPlxuICAgICAgICAgICAgICA8SW5wdXQgaWQ9XCJwaG9uZVwiIHR5cGU9XCJ0ZWxcIiB7Li4ucmVnaXN0ZXIoJ3Bob25lJyl9IC8+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPEJ1dHRvbiBkaXNhYmxlZD17aXNTdWJtaXR0aW5nfSB0eXBlPVwic3VibWl0XCIgY2xhc3NOYW1lPVwidy1mdWxsXCI+XG4gICAgICAgICAgICAgIEZpbmFsaXphciBjYWRhc3Ryb1xuICAgICAgICAgICAgPC9CdXR0b24+XG5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInB4LTYgdGV4dC1jZW50ZXIgdGV4dC1zbSBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgIEFvIGNvbnRpbnVhciwgdm9jw6ogY29uY29yZGFyIGNvbSBvcyBub3Nzb3N7JyAnfVxuICAgICAgICAgICAgICA8YSBocmVmPVwiXCIgY2xhc3NOYW1lPVwidW5kZXJsaW5lIHVuZGVybGluZS1vZmZzZXQtNFwiPlxuICAgICAgICAgICAgICAgIFRlcm1vcyBkZSBzZXJ2acOnb1xuICAgICAgICAgICAgICA8L2E+eycgJ31cbiAgICAgICAgICAgICAgZXsnICd9XG4gICAgICAgICAgICAgIDxhIGhyZWY9XCJcIiBjbGFzc05hbWU9XCJ1bmRlcmxpbmUgdW5kZXJsaW5lLW9mZnNldC00XCI+XG4gICAgICAgICAgICAgICAgUG9sw610aWNhcyBkZSBwcml2YWNpZGFkZVxuICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgIC5cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC8+XG4gIClcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2FycnVkYXkvRG93bmxvYWRzL3Bpenphc2hvcC9zcmMvcGFnZXMvYXV0aC9zaWduLXVwLnRzeCJ9