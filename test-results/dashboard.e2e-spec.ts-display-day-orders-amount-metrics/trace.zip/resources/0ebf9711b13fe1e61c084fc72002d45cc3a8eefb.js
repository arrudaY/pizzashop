import { http, HttpResponse } from "/node_modules/.vite/deps/msw.js?v=efc33bbd";
export const getPopularProductsMock = http.get("/metrics/popular-products", () => {
  return HttpResponse.json([
    { product: "Pizza 01", amount: 5 },
    { product: "Pizza 02", amount: 3 },
    { product: "Pizza 03", amount: 2 },
    { product: "Pizza 04", amount: 7 },
    { product: "Pizza 05", amount: 4 }
  ]);
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImdldC1wb3B1bGFyLXByb2R1Y3RzLW1vY2sudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgaHR0cCwgSHR0cFJlc3BvbnNlIH0gZnJvbSAnbXN3J1xuXG5pbXBvcnQgeyBHZXRQb3B1bGFyUHJvZHVjdHNSZXNwb25zZSB9IGZyb20gJy4uL2dldC1wb3B1bGFyLXByb2R1Y3RzJ1xuXG5leHBvcnQgY29uc3QgZ2V0UG9wdWxhclByb2R1Y3RzTW9jayA9IGh0dHAuZ2V0PFxuICBuZXZlcixcbiAgbmV2ZXIsXG4gIEdldFBvcHVsYXJQcm9kdWN0c1Jlc3BvbnNlXG4+KCcvbWV0cmljcy9wb3B1bGFyLXByb2R1Y3RzJywgKCkgPT4ge1xuICByZXR1cm4gSHR0cFJlc3BvbnNlLmpzb24oW1xuICAgIHsgcHJvZHVjdDogJ1BpenphIDAxJywgYW1vdW50OiA1IH0sXG4gICAgeyBwcm9kdWN0OiAnUGl6emEgMDInLCBhbW91bnQ6IDMgfSxcbiAgICB7IHByb2R1Y3Q6ICdQaXp6YSAwMycsIGFtb3VudDogMiB9LFxuICAgIHsgcHJvZHVjdDogJ1BpenphIDA0JywgYW1vdW50OiA3IH0sXG4gICAgeyBwcm9kdWN0OiAnUGl6emEgMDUnLCBhbW91bnQ6IDQgfSxcbiAgXSlcbn0pXG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsTUFBTSxvQkFBb0I7QUFJNUIsYUFBTSx5QkFBeUIsS0FBSyxJQUl6Qyw2QkFBNkIsTUFBTTtBQUNuQyxTQUFPLGFBQWEsS0FBSztBQUFBLElBQ3ZCLEVBQUUsU0FBUyxZQUFZLFFBQVEsRUFBRTtBQUFBLElBQ2pDLEVBQUUsU0FBUyxZQUFZLFFBQVEsRUFBRTtBQUFBLElBQ2pDLEVBQUUsU0FBUyxZQUFZLFFBQVEsRUFBRTtBQUFBLElBQ2pDLEVBQUUsU0FBUyxZQUFZLFFBQVEsRUFBRTtBQUFBLElBQ2pDLEVBQUUsU0FBUyxZQUFZLFFBQVEsRUFBRTtBQUFBLEVBQ25DLENBQUM7QUFDSCxDQUFDOyIsIm5hbWVzIjpbXX0=