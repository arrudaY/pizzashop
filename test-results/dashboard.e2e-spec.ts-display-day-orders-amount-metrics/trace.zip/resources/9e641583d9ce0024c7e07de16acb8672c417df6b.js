import { http, HttpResponse } from "/node_modules/.vite/deps/msw.js?v=7d79b549";
export const signInMock = http.post(
  "/authenticate",
  async ({ request }) => {
    const { email } = await request.json();
    if (email === "johndoe@example.com") {
      return new HttpResponse(null, {
        status: 200,
        headers: { "Set-Cookie": "auth=sample-jwt" }
      });
    }
    return new HttpResponse(null, { status: 401 });
  }
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNpZ24taW4tbW9jay50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBodHRwLCBIdHRwUmVzcG9uc2UgfSBmcm9tICdtc3cnXG5cbmltcG9ydCB7IFNpZ25JbkJvZHkgfSBmcm9tICcuLi9zaWduLWluJ1xuXG5leHBvcnQgY29uc3Qgc2lnbkluTW9jayA9IGh0dHAucG9zdDxuZXZlciwgU2lnbkluQm9keT4oXG4gICcvYXV0aGVudGljYXRlJyxcbiAgYXN5bmMgKHsgcmVxdWVzdCB9KSA9PiB7XG4gICAgY29uc3QgeyBlbWFpbCB9ID0gYXdhaXQgcmVxdWVzdC5qc29uKClcblxuICAgIGlmIChlbWFpbCA9PT0gJ2pvaG5kb2VAZXhhbXBsZS5jb20nKSB7XG4gICAgICByZXR1cm4gbmV3IEh0dHBSZXNwb25zZShudWxsLCB7XG4gICAgICAgIHN0YXR1czogMjAwLFxuICAgICAgICBoZWFkZXJzOiB7ICdTZXQtQ29va2llJzogJ2F1dGg9c2FtcGxlLWp3dCcgfSxcbiAgICAgIH0pXG4gICAgfVxuXG4gICAgcmV0dXJuIG5ldyBIdHRwUmVzcG9uc2UobnVsbCwgeyBzdGF0dXM6IDQwMSB9KVxuICB9LFxuKVxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLE1BQU0sb0JBQW9CO0FBSTVCLGFBQU0sYUFBYSxLQUFLO0FBQUEsRUFDN0I7QUFBQSxFQUNBLE9BQU8sRUFBRSxRQUFRLE1BQU07QUFDckIsVUFBTSxFQUFFLE1BQU0sSUFBSSxNQUFNLFFBQVEsS0FBSztBQUVyQyxRQUFJLFVBQVUsdUJBQXVCO0FBQ25DLGFBQU8sSUFBSSxhQUFhLE1BQU07QUFBQSxRQUM1QixRQUFRO0FBQUEsUUFDUixTQUFTLEVBQUUsY0FBYyxrQkFBa0I7QUFBQSxNQUM3QyxDQUFDO0FBQUEsSUFDSDtBQUVBLFdBQU8sSUFBSSxhQUFhLE1BQU0sRUFBRSxRQUFRLElBQUksQ0FBQztBQUFBLEVBQy9DO0FBQ0Y7IiwibmFtZXMiOltdfQ==