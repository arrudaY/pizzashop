import {
  require_react
} from "/node_modules/.vite/deps/chunk-BOFYMYUE.js?v=7d79b549";
import "/node_modules/.vite/deps/chunk-TXPGJST7.js?v=7d79b549";
export default require_react();
//# sourceMappingURL=react.js.map
