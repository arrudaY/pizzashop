import {
  clsx,
  clsx_default
} from "/node_modules/.vite/deps/chunk-ZHRGLJTE.js?v=7d79b549";
import "/node_modules/.vite/deps/chunk-TXPGJST7.js?v=7d79b549";
export {
  clsx,
  clsx_default as default
};
//# sourceMappingURL=clsx.js.map
