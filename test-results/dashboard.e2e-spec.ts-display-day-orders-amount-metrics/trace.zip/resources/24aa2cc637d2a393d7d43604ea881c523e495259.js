import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/app/dashboard/month-revenue-card.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7d79b549"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/arruday/Downloads/pizzashop/src/pages/app/dashboard/month-revenue-card.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=7d79b549";
import { DollarSign } from "/node_modules/.vite/deps/lucide-react.js?v=7d79b549";
import { getMonthRevenue } from "/src/api/get-month-revenue.ts";
import { Card, CardContent, CardHeader, CardTitle } from "/src/components/ui/card.tsx";
import { MetricCardSkeleton } from "/src/pages/app/dashboard/metric-card-skeleton.tsx";
export function MonthRevenueCard() {
  _s();
  const { data: monthRevenue } = useQuery({
    queryKey: ["metrics", "month-revenue"],
    queryFn: getMonthRevenue
  });
  return /* @__PURE__ */ jsxDEV(Card, { children: [
    /* @__PURE__ */ jsxDEV(CardHeader, { className: "flex-row items-center justify-between space-y-0 pb-2", children: [
      /* @__PURE__ */ jsxDEV(CardTitle, { className: "text-base font-semibold", children: "Receita total (mês)" }, void 0, false, {
        fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/dashboard/month-revenue-card.tsx",
        lineNumber: 17,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DollarSign, { className: "h-4 w-4 text-muted-foreground" }, void 0, false, {
        fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/dashboard/month-revenue-card.tsx",
        lineNumber: 20,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/dashboard/month-revenue-card.tsx",
      lineNumber: 16,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(CardContent, { className: "space-y-1", children: monthRevenue ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("span", { className: "racking-tight font-mono text-2xl font-bold", children: (monthRevenue.receipt / 100).toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL"
      }) }, void 0, false, {
        fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/dashboard/month-revenue-card.tsx",
        lineNumber: 25,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-muted-foreground", children: monthRevenue.diffFromLastMonth >= 0 ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-emerald-500 dark:text-emerald-400", children: [
          "+",
          monthRevenue.diffFromLastMonth,
          "%"
        ] }, void 0, true, {
          fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/dashboard/month-revenue-card.tsx",
          lineNumber: 34,
          columnNumber: 19
        }, this),
        " ",
        "em relação ao mês anterior"
      ] }, void 0, true, {
        fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/dashboard/month-revenue-card.tsx",
        lineNumber: 33,
        columnNumber: 13
      }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-rose-500 dark:text-rose-400", children: [
          monthRevenue.diffFromLastMonth,
          "%"
        ] }, void 0, true, {
          fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/dashboard/month-revenue-card.tsx",
          lineNumber: 41,
          columnNumber: 19
        }, this),
        " ",
        "em relação ao mês anterior"
      ] }, void 0, true, {
        fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/dashboard/month-revenue-card.tsx",
        lineNumber: 40,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/dashboard/month-revenue-card.tsx",
        lineNumber: 31,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/dashboard/month-revenue-card.tsx",
      lineNumber: 24,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV(MetricCardSkeleton, {}, void 0, false, {
      fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/dashboard/month-revenue-card.tsx",
      lineNumber: 50,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/dashboard/month-revenue-card.tsx",
      lineNumber: 22,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/arruday/Downloads/pizzashop/src/pages/app/dashboard/month-revenue-card.tsx",
    lineNumber: 15,
    columnNumber: 5
  }, this);
}
_s(MonthRevenueCard, "vHFdS1Bl/vEHA2FAT0QNigAEQXc=", false, function() {
  return [useQuery];
});
_c = MonthRevenueCard;
var _c;
$RefreshReg$(_c, "MonthRevenueCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arruday/Downloads/pizzashop/src/pages/app/dashboard/month-revenue-card.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JRLFNBZ0JRLFVBaEJSOzJCQWhCUjtBQUFpQixNQUFRLHFCQUF1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNoRCxTQUFTQSxrQkFBa0I7QUFFM0IsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLE1BQU1DLGFBQWFDLFlBQVlDLGlCQUFpQjtBQUV6RCxTQUFTQywwQkFBMEI7QUFFNUIsZ0JBQVNDLG1CQUFtQjtBQUFBQyxLQUFBO0FBQ2pDLFFBQU0sRUFBRUMsTUFBTUMsYUFBYSxJQUFJQyxTQUFTO0FBQUEsSUFDdENDLFVBQVUsQ0FBQyxXQUFXLGVBQWU7QUFBQSxJQUNyQ0MsU0FBU1o7QUFBQUEsRUFDWCxDQUFDO0FBQ0QsU0FDRSx1QkFBQyxRQUNDO0FBQUEsMkJBQUMsY0FBVyxXQUFVLHdEQUNwQjtBQUFBLDZCQUFDLGFBQVUsV0FBVSwyQkFBeUIsbUNBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsY0FBVyxXQUFVLG1DQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFEO0FBQUEsU0FKdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBO0FBQUEsSUFDQSx1QkFBQyxlQUFZLFdBQVUsYUFDcEJTLHlCQUNDLG1DQUNFO0FBQUEsNkJBQUMsVUFBSyxXQUFVLDhDQUNaQSx3QkFBYUksVUFBVSxLQUFLQyxlQUFlLFNBQVM7QUFBQSxRQUNwREMsT0FBTztBQUFBLFFBQ1BDLFVBQVU7QUFBQSxNQUNaLENBQUMsS0FKSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLE9BQUUsV0FBVSxpQ0FDVlAsdUJBQWFRLHFCQUFxQixJQUNqQyxtQ0FDRTtBQUFBLCtCQUFDLFVBQUssV0FBVSxvREFBa0Q7QUFBQTtBQUFBLFVBQzlEUixhQUFhUTtBQUFBQSxVQUFrQjtBQUFBLGFBRG5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQVE7QUFBQSxRQUFHO0FBQUEsV0FIYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0EsSUFFQSxtQ0FDRTtBQUFBLCtCQUFDLFVBQUssV0FBVSw4Q0FDYlI7QUFBQUEsdUJBQWFRO0FBQUFBLFVBQWtCO0FBQUEsYUFEbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFBUTtBQUFBLFFBQUc7QUFBQSxXQUhiO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQSxLQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnQkE7QUFBQSxTQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBd0JBLElBRUEsdUJBQUMsd0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtQixLQTVCdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThCQTtBQUFBLE9BckNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzQ0E7QUFFSjtBQUFDVixHQTlDZUQsa0JBQWdCO0FBQUEsVUFDQ0ksUUFBUTtBQUFBO0FBQUFRLEtBRHpCWjtBQUFnQixJQUFBWTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiRG9sbGFyU2lnbiIsImdldE1vbnRoUmV2ZW51ZSIsIkNhcmQiLCJDYXJkQ29udGVudCIsIkNhcmRIZWFkZXIiLCJDYXJkVGl0bGUiLCJNZXRyaWNDYXJkU2tlbGV0b24iLCJNb250aFJldmVudWVDYXJkIiwiX3MiLCJkYXRhIiwibW9udGhSZXZlbnVlIiwidXNlUXVlcnkiLCJxdWVyeUtleSIsInF1ZXJ5Rm4iLCJyZWNlaXB0IiwidG9Mb2NhbGVTdHJpbmciLCJzdHlsZSIsImN1cnJlbmN5IiwiZGlmZkZyb21MYXN0TW9udGgiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIm1vbnRoLXJldmVudWUtY2FyZC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUXVlcnkgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG5pbXBvcnQgeyBEb2xsYXJTaWduIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuXG5pbXBvcnQgeyBnZXRNb250aFJldmVudWUgfSBmcm9tICdAL2FwaS9nZXQtbW9udGgtcmV2ZW51ZSdcbmltcG9ydCB7IENhcmQsIENhcmRDb250ZW50LCBDYXJkSGVhZGVyLCBDYXJkVGl0bGUgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvY2FyZCdcblxuaW1wb3J0IHsgTWV0cmljQ2FyZFNrZWxldG9uIH0gZnJvbSAnLi9tZXRyaWMtY2FyZC1za2VsZXRvbidcblxuZXhwb3J0IGZ1bmN0aW9uIE1vbnRoUmV2ZW51ZUNhcmQoKSB7XG4gIGNvbnN0IHsgZGF0YTogbW9udGhSZXZlbnVlIH0gPSB1c2VRdWVyeSh7XG4gICAgcXVlcnlLZXk6IFsnbWV0cmljcycsICdtb250aC1yZXZlbnVlJ10sXG4gICAgcXVlcnlGbjogZ2V0TW9udGhSZXZlbnVlLFxuICB9KVxuICByZXR1cm4gKFxuICAgIDxDYXJkPlxuICAgICAgPENhcmRIZWFkZXIgY2xhc3NOYW1lPVwiZmxleC1yb3cgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBzcGFjZS15LTAgcGItMlwiPlxuICAgICAgICA8Q2FyZFRpdGxlIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgUmVjZWl0YSB0b3RhbCAobcOqcylcbiAgICAgICAgPC9DYXJkVGl0bGU+XG4gICAgICAgIDxEb2xsYXJTaWduIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCIgLz5cbiAgICAgIDwvQ2FyZEhlYWRlcj5cbiAgICAgIDxDYXJkQ29udGVudCBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cbiAgICAgICAge21vbnRoUmV2ZW51ZSA/IChcbiAgICAgICAgICA8PlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmFja2luZy10aWdodCBmb250LW1vbm8gdGV4dC0yeGwgZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgIHsobW9udGhSZXZlbnVlLnJlY2VpcHQgLyAxMDApLnRvTG9jYWxlU3RyaW5nKCdwdC1CUicsIHtcbiAgICAgICAgICAgICAgICBzdHlsZTogJ2N1cnJlbmN5JyxcbiAgICAgICAgICAgICAgICBjdXJyZW5jeTogJ0JSTCcsXG4gICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAge21vbnRoUmV2ZW51ZS5kaWZmRnJvbUxhc3RNb250aCA+PSAwID8gKFxuICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1lbWVyYWxkLTUwMCBkYXJrOnRleHQtZW1lcmFsZC00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgK3ttb250aFJldmVudWUuZGlmZkZyb21MYXN0TW9udGh9JVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPnsnICd9XG4gICAgICAgICAgICAgICAgICBlbSByZWxhw6fDo28gYW8gbcOqcyBhbnRlcmlvclxuICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1yb3NlLTUwMCBkYXJrOnRleHQtcm9zZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAge21vbnRoUmV2ZW51ZS5kaWZmRnJvbUxhc3RNb250aH0lXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+eycgJ31cbiAgICAgICAgICAgICAgICAgIGVtIHJlbGHDp8OjbyBhbyBtw6pzIGFudGVyaW9yXG4gICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgPC8+XG4gICAgICAgICkgOiAoXG4gICAgICAgICAgPE1ldHJpY0NhcmRTa2VsZXRvbiAvPlxuICAgICAgICApfVxuICAgICAgPC9DYXJkQ29udGVudD5cbiAgICA8L0NhcmQ+XG4gIClcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2FycnVkYXkvRG93bmxvYWRzL3Bpenphc2hvcC9zcmMvcGFnZXMvYXBwL2Rhc2hib2FyZC9tb250aC1yZXZlbnVlLWNhcmQudHN4In0=