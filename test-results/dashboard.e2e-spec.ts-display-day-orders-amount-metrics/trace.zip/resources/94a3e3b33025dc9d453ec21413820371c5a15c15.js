import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/app.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7d79b549"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/arruday/Downloads/pizzashop/src/app.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/global.css";
import { QueryClientProvider } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=7d79b549";
import { Helmet, HelmetProvider } from "/node_modules/.vite/deps/react-helmet-async.js?v=7d79b549";
import { RouterProvider } from "/node_modules/.vite/deps/react-router-dom.js?v=7d79b549";
import { Toaster } from "/node_modules/.vite/deps/sonner.js?v=7d79b549";
import { queryClient } from "/src/lib/react-query.ts";
import { ThemeProvider } from "/src/components/theme/theme-provider.tsx";
import { router } from "/src/pages/routes.tsx";
export function App() {
  return /* @__PURE__ */ jsxDEV(HelmetProvider, { children: /* @__PURE__ */ jsxDEV(ThemeProvider, { storageKey: "pizzashop-theme", defaultTheme: "system", children: [
    /* @__PURE__ */ jsxDEV(Toaster, {}, void 0, false, {
      fileName: "/Users/arruday/Downloads/pizzashop/src/app.tsx",
      lineNumber: 17,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Helmet, { titleTemplate: "%s | pizza.shop" }, void 0, false, {
      fileName: "/Users/arruday/Downloads/pizzashop/src/app.tsx",
      lineNumber: 18,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(QueryClientProvider, { client: queryClient, children: /* @__PURE__ */ jsxDEV(RouterProvider, { router }, void 0, false, {
      fileName: "/Users/arruday/Downloads/pizzashop/src/app.tsx",
      lineNumber: 20,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/arruday/Downloads/pizzashop/src/app.tsx",
      lineNumber: 19,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/arruday/Downloads/pizzashop/src/app.tsx",
    lineNumber: 16,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/arruday/Downloads/pizzashop/src/app.tsx",
    lineNumber: 15,
    columnNumber: 5
  }, this);
}
_c = App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arruday/Downloads/pizzashop/src/app.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JRO0FBaEJSLE9BQU8sb0JBQWM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFckIsU0FBU0EsMkJBQTJCO0FBQ3BDLFNBQVNDLFFBQVFDLHNCQUFzQjtBQUN2QyxTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MsZUFBZTtBQUV4QixTQUFTQyxtQkFBbUI7QUFFNUIsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLGNBQWM7QUFFaEIsZ0JBQVNDLE1BQU07QUFDcEIsU0FDRSx1QkFBQyxrQkFDQyxpQ0FBQyxpQkFBYyxZQUFXLG1CQUFrQixjQUFhLFVBQ3ZEO0FBQUEsMkJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVE7QUFBQSxJQUNSLHVCQUFDLFVBQU8sZUFBYyxxQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1QztBQUFBLElBQ3ZDLHVCQUFDLHVCQUFvQixRQUFRSCxhQUMzQixpQ0FBQyxrQkFBZSxVQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStCLEtBRGpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVFBO0FBRUo7QUFBQ0ksS0FaZUQ7QUFBRyxJQUFBQztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUXVlcnlDbGllbnRQcm92aWRlciIsIkhlbG1ldCIsIkhlbG1ldFByb3ZpZGVyIiwiUm91dGVyUHJvdmlkZXIiLCJUb2FzdGVyIiwicXVlcnlDbGllbnQiLCJUaGVtZVByb3ZpZGVyIiwicm91dGVyIiwiQXBwIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJhcHAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAnLi9nbG9iYWwuY3NzJ1xuXG5pbXBvcnQgeyBRdWVyeUNsaWVudFByb3ZpZGVyIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuaW1wb3J0IHsgSGVsbWV0LCBIZWxtZXRQcm92aWRlciB9IGZyb20gJ3JlYWN0LWhlbG1ldC1hc3luYydcbmltcG9ydCB7IFJvdXRlclByb3ZpZGVyIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcbmltcG9ydCB7IFRvYXN0ZXIgfSBmcm9tICdzb25uZXInXG5cbmltcG9ydCB7IHF1ZXJ5Q2xpZW50IH0gZnJvbSAnQC9saWIvcmVhY3QtcXVlcnkudHMnXG5cbmltcG9ydCB7IFRoZW1lUHJvdmlkZXIgfSBmcm9tICcuL2NvbXBvbmVudHMvdGhlbWUvdGhlbWUtcHJvdmlkZXInXG5pbXBvcnQgeyByb3V0ZXIgfSBmcm9tICcuL3BhZ2VzL3JvdXRlcydcblxuZXhwb3J0IGZ1bmN0aW9uIEFwcCgpIHtcbiAgcmV0dXJuIChcbiAgICA8SGVsbWV0UHJvdmlkZXI+XG4gICAgICA8VGhlbWVQcm92aWRlciBzdG9yYWdlS2V5PVwicGl6emFzaG9wLXRoZW1lXCIgZGVmYXVsdFRoZW1lPVwic3lzdGVtXCI+XG4gICAgICAgIDxUb2FzdGVyIC8+XG4gICAgICAgIDxIZWxtZXQgdGl0bGVUZW1wbGF0ZT1cIiVzIHwgcGl6emEuc2hvcFwiIC8+XG4gICAgICAgIDxRdWVyeUNsaWVudFByb3ZpZGVyIGNsaWVudD17cXVlcnlDbGllbnR9PlxuICAgICAgICAgIDxSb3V0ZXJQcm92aWRlciByb3V0ZXI9e3JvdXRlcn0gLz5cbiAgICAgICAgPC9RdWVyeUNsaWVudFByb3ZpZGVyPlxuICAgICAgPC9UaGVtZVByb3ZpZGVyPlxuICAgIDwvSGVsbWV0UHJvdmlkZXI+XG4gIClcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2FycnVkYXkvRG93bmxvYWRzL3Bpenphc2hvcC9zcmMvYXBwLnRzeCJ9