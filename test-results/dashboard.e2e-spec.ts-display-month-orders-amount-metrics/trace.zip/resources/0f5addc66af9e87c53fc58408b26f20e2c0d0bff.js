import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/skeleton.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=efc33bbd"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/arruday/GitHub/pizzashop/src/components/ui/skeleton.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { cn } from "/src/lib/utils.ts";
function Skeleton({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: cn("animate-pulse rounded-md bg-muted", className),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/arruday/GitHub/pizzashop/src/components/ui/skeleton.tsx",
      lineNumber: 8,
      columnNumber: 5
    },
    this
  );
}
_c = Skeleton;
export { Skeleton };
var _c;
$RefreshReg$(_c, "Skeleton");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arruday/GitHub/pizzashop/src/components/ui/skeleton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT0k7QUFQSiwyQkFBbUI7QUFBYTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFaEMsU0FBU0EsU0FBUztBQUFBLEVBQ2hCQztBQUFBQSxFQUNBLEdBQUdDO0FBQ2lDLEdBQUc7QUFDdkMsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsV0FBV0MsR0FBRyxxQ0FBcUNGLFNBQVM7QUFBQSxNQUM1RCxHQUFJQztBQUFBQTtBQUFBQSxJQUZOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUVZO0FBR2hCO0FBQUNFLEtBVlFKO0FBWVQsU0FBU0E7QUFBVSxJQUFBSTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiU2tlbGV0b24iLCJjbGFzc05hbWUiLCJwcm9wcyIsImNuIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJza2VsZXRvbi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvdXRpbHNcIlxuXG5mdW5jdGlvbiBTa2VsZXRvbih7XG4gIGNsYXNzTmFtZSxcbiAgLi4ucHJvcHNcbn06IFJlYWN0LkhUTUxBdHRyaWJ1dGVzPEhUTUxEaXZFbGVtZW50Pikge1xuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGNsYXNzTmFtZT17Y24oXCJhbmltYXRlLXB1bHNlIHJvdW5kZWQtbWQgYmctbXV0ZWRcIiwgY2xhc3NOYW1lKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApXG59XG5cbmV4cG9ydCB7IFNrZWxldG9uIH1cbiJdLCJmaWxlIjoiL1VzZXJzL2FycnVkYXkvR2l0SHViL3Bpenphc2hvcC9zcmMvY29tcG9uZW50cy91aS9za2VsZXRvbi50c3gifQ==