import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/app/dashboard/month-orders-amount-card.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=efc33bbd"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/month-orders-amount-card.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=efc33bbd";
import { Utensils } from "/node_modules/.vite/deps/lucide-react.js?v=efc33bbd";
import { getMonthOrdersAmount } from "/src/api/get-month-orders-amount.ts";
import { Card, CardContent, CardHeader, CardTitle } from "/src/components/ui/card.tsx";
import { MetricCardSkeleton } from "/src/pages/app/dashboard/metric-card-skeleton.tsx";
export function MonthOrdersAmountCard() {
  _s();
  const { data: monthOrdersAmount } = useQuery({
    queryKey: ["metrics", "month-orders-amount"],
    queryFn: getMonthOrdersAmount
  });
  return /* @__PURE__ */ jsxDEV(Card, { children: [
    /* @__PURE__ */ jsxDEV(CardHeader, { className: "flex-row items-center justify-between space-y-0 pb-2", children: [
      /* @__PURE__ */ jsxDEV(CardTitle, { className: "text-base font-semibold", children: "Pedidos (mês)" }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/month-orders-amount-card.tsx",
        lineNumber: 17,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Utensils, { className: "h-4 w-4 text-muted-foreground" }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/month-orders-amount-card.tsx",
        lineNumber: 18,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/month-orders-amount-card.tsx",
      lineNumber: 16,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(CardContent, { className: "space-y-1", children: monthOrdersAmount ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("span", { className: "racking-tight font-mono text-2xl font-bold", children: monthOrdersAmount.amount }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/month-orders-amount-card.tsx",
        lineNumber: 23,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-muted-foreground", children: monthOrdersAmount.diffFromLastMonth >= 0 ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-emerald-500 dark:text-emerald-400", children: [
          "+",
          monthOrdersAmount?.diffFromLastMonth,
          "%"
        ] }, void 0, true, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/month-orders-amount-card.tsx",
          lineNumber: 29,
          columnNumber: 19
        }, this),
        " ",
        "em relação ao mês anterior"
      ] }, void 0, true, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/month-orders-amount-card.tsx",
        lineNumber: 28,
        columnNumber: 13
      }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-rose-500 dark:text-rose-400", children: [
          monthOrdersAmount?.diffFromLastMonth,
          "%"
        ] }, void 0, true, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/month-orders-amount-card.tsx",
          lineNumber: 36,
          columnNumber: 19
        }, this),
        " ",
        "em relação ao mês anterior"
      ] }, void 0, true, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/month-orders-amount-card.tsx",
        lineNumber: 35,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/month-orders-amount-card.tsx",
        lineNumber: 26,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/month-orders-amount-card.tsx",
      lineNumber: 22,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV(MetricCardSkeleton, {}, void 0, false, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/month-orders-amount-card.tsx",
      lineNumber: 45,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/month-orders-amount-card.tsx",
      lineNumber: 20,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/month-orders-amount-card.tsx",
    lineNumber: 15,
    columnNumber: 5
  }, this);
}
_s(MonthOrdersAmountCard, "eVUQBo3ayFgd2a/Lf1CXtZs2rcQ=", false, function() {
  return [useQuery];
});
_c = MonthOrdersAmountCard;
var _c;
$RefreshReg$(_c, "MonthOrdersAmountCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arruday/GitHub/pizzashop/src/pages/app/dashboard/month-orders-amount-card.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JRLFNBV1EsVUFYUjsyQkFoQlI7QUFBaUIsTUFBUSxxQkFBdUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDaEQsU0FBU0EsZ0JBQWdCO0FBRXpCLFNBQVNDLDRCQUE0QjtBQUNyQyxTQUFTQyxNQUFNQyxhQUFhQyxZQUFZQyxpQkFBaUI7QUFFekQsU0FBU0MsMEJBQTBCO0FBRTVCLGdCQUFTQyx3QkFBd0I7QUFBQUMsS0FBQTtBQUN0QyxRQUFNLEVBQUVDLE1BQU1DLGtCQUFrQixJQUFJQyxTQUFTO0FBQUEsSUFDM0NDLFVBQVUsQ0FBQyxXQUFXLHFCQUFxQjtBQUFBLElBQzNDQyxTQUFTWjtBQUFBQSxFQUNYLENBQUM7QUFDRCxTQUNFLHVCQUFDLFFBQ0M7QUFBQSwyQkFBQyxjQUFXLFdBQVUsd0RBQ3BCO0FBQUEsNkJBQUMsYUFBVSxXQUFVLDJCQUEwQiw2QkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0RDtBQUFBLE1BQzVELHVCQUFDLFlBQVMsV0FBVSxtQ0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRDtBQUFBLFNBRnJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBQ0EsdUJBQUMsZUFBWSxXQUFVLGFBQ3BCUyw4QkFDQyxtQ0FDRTtBQUFBLDZCQUFDLFVBQUssV0FBVSw4Q0FDYkEsNEJBQWtCSSxVQURyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLE9BQUUsV0FBVSxpQ0FDVkosNEJBQWtCSyxxQkFBcUIsSUFDdEMsbUNBQ0U7QUFBQSwrQkFBQyxVQUFLLFdBQVUsb0RBQWtEO0FBQUE7QUFBQSxVQUM5REwsbUJBQW1CSztBQUFBQSxVQUFrQjtBQUFBLGFBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQVE7QUFBQSxRQUFHO0FBQUEsV0FIYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0EsSUFFQSxtQ0FDRTtBQUFBLCtCQUFDLFVBQUssV0FBVSw4Q0FDYkw7QUFBQUEsNkJBQW1CSztBQUFBQSxVQUFrQjtBQUFBLGFBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQVE7QUFBQSxRQUFHO0FBQUEsV0FIYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0EsS0FkSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0JBO0FBQUEsU0FwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFCQSxJQUVBLHVCQUFDLHdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUIsS0F6QnZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyQkE7QUFBQSxPQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaUNBO0FBRUo7QUFBQ1AsR0F6Q2VELHVCQUFxQjtBQUFBLFVBQ0NJLFFBQVE7QUFBQTtBQUFBSyxLQUQ5QlQ7QUFBcUIsSUFBQVM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlV0ZW5zaWxzIiwiZ2V0TW9udGhPcmRlcnNBbW91bnQiLCJDYXJkIiwiQ2FyZENvbnRlbnQiLCJDYXJkSGVhZGVyIiwiQ2FyZFRpdGxlIiwiTWV0cmljQ2FyZFNrZWxldG9uIiwiTW9udGhPcmRlcnNBbW91bnRDYXJkIiwiX3MiLCJkYXRhIiwibW9udGhPcmRlcnNBbW91bnQiLCJ1c2VRdWVyeSIsInF1ZXJ5S2V5IiwicXVlcnlGbiIsImFtb3VudCIsImRpZmZGcm9tTGFzdE1vbnRoIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJtb250aC1vcmRlcnMtYW1vdW50LWNhcmQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVF1ZXJ5IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuaW1wb3J0IHsgVXRlbnNpbHMgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5cbmltcG9ydCB7IGdldE1vbnRoT3JkZXJzQW1vdW50IH0gZnJvbSAnQC9hcGkvZ2V0LW1vbnRoLW9yZGVycy1hbW91bnQnXG5pbXBvcnQgeyBDYXJkLCBDYXJkQ29udGVudCwgQ2FyZEhlYWRlciwgQ2FyZFRpdGxlIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2NhcmQnXG5cbmltcG9ydCB7IE1ldHJpY0NhcmRTa2VsZXRvbiB9IGZyb20gJy4vbWV0cmljLWNhcmQtc2tlbGV0b24nXG5cbmV4cG9ydCBmdW5jdGlvbiBNb250aE9yZGVyc0Ftb3VudENhcmQoKSB7XG4gIGNvbnN0IHsgZGF0YTogbW9udGhPcmRlcnNBbW91bnQgfSA9IHVzZVF1ZXJ5KHtcbiAgICBxdWVyeUtleTogWydtZXRyaWNzJywgJ21vbnRoLW9yZGVycy1hbW91bnQnXSxcbiAgICBxdWVyeUZuOiBnZXRNb250aE9yZGVyc0Ftb3VudCxcbiAgfSlcbiAgcmV0dXJuIChcbiAgICA8Q2FyZD5cbiAgICAgIDxDYXJkSGVhZGVyIGNsYXNzTmFtZT1cImZsZXgtcm93IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteS0wIHBiLTJcIj5cbiAgICAgICAgPENhcmRUaXRsZSBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1zZW1pYm9sZFwiPlBlZGlkb3MgKG3DqnMpPC9DYXJkVGl0bGU+XG4gICAgICAgIDxVdGVuc2lscyBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiIC8+XG4gICAgICA8L0NhcmRIZWFkZXI+XG4gICAgICA8Q2FyZENvbnRlbnQgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgIHttb250aE9yZGVyc0Ftb3VudCA/IChcbiAgICAgICAgICA8PlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmFja2luZy10aWdodCBmb250LW1vbm8gdGV4dC0yeGwgZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgIHttb250aE9yZGVyc0Ftb3VudC5hbW91bnR9XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICB7bW9udGhPcmRlcnNBbW91bnQuZGlmZkZyb21MYXN0TW9udGggPj0gMCA/IChcbiAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZW1lcmFsZC01MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICt7bW9udGhPcmRlcnNBbW91bnQ/LmRpZmZGcm9tTGFzdE1vbnRofSVcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj57JyAnfVxuICAgICAgICAgICAgICAgICAgZW0gcmVsYcOnw6NvIGFvIG3DqnMgYW50ZXJpb3JcbiAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtcm9zZS01MDAgZGFyazp0ZXh0LXJvc2UtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIHttb250aE9yZGVyc0Ftb3VudD8uZGlmZkZyb21MYXN0TW9udGh9JVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPnsnICd9XG4gICAgICAgICAgICAgICAgICBlbSByZWxhw6fDo28gYW8gbcOqcyBhbnRlcmlvclxuICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgIDwvPlxuICAgICAgICApIDogKFxuICAgICAgICAgIDxNZXRyaWNDYXJkU2tlbGV0b24gLz5cbiAgICAgICAgKX1cbiAgICAgIDwvQ2FyZENvbnRlbnQ+XG4gICAgPC9DYXJkPlxuICApXG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9hcnJ1ZGF5L0dpdEh1Yi9waXp6YXNob3Avc3JjL3BhZ2VzL2FwcC9kYXNoYm9hcmQvbW9udGgtb3JkZXJzLWFtb3VudC1jYXJkLnRzeCJ9