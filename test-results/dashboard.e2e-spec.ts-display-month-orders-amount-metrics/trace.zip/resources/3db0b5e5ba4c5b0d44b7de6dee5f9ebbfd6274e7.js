import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/app/orders/order-table-filters.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=efc33bbd"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-filters.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=efc33bbd";
import { Search, X } from "/node_modules/.vite/deps/lucide-react.js?v=efc33bbd";
import { Controller, useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=efc33bbd";
import { useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=efc33bbd";
import { z } from "/node_modules/.vite/deps/zod.js?v=efc33bbd";
import { Button } from "/src/components/ui/button.tsx";
import { Input } from "/src/components/ui/input.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "/src/components/ui/select.tsx";
const orderFiltersSchema = z.object({
  orderId: z.string().optional(),
  customerName: z.string().optional(),
  status: z.string().optional()
});
export function OrderTableFilters() {
  _s();
  const [searchParams, setSearchParams] = useSearchParams();
  const orderId = searchParams.get("orderId");
  const customerName = searchParams.get("customerName");
  const status = searchParams.get("status");
  const { register, handleSubmit, control, reset } = useForm({
    resolver: zodResolver(orderFiltersSchema),
    defaultValues: {
      orderId: orderId ?? "",
      customerName: customerName ?? "",
      status: status ?? "all"
    }
  });
  function handleFilter({ orderId: orderId2, customerName: customerName2, status: status2 }) {
    setSearchParams((state) => {
      if (orderId2) {
        state.set("orderId", orderId2);
      } else {
        state.delete("orderId");
      }
      if (customerName2) {
        state.set("customerName", customerName2);
      } else {
        state.delete("customerName");
      }
      if (status2) {
        state.set("status", status2);
      } else {
        state.delete("status");
      }
      state.set("page", "1");
      return state;
    });
  }
  function handleClearFilters() {
    setSearchParams((state) => {
      state.delete("orderId");
      state.delete("customerName");
      state.delete("status");
      state.set("page", "1");
      return state;
    });
    reset({
      orderId: "",
      customerName: "",
      status: "all"
    });
  }
  const hasAnyFilter = !!orderId || !!customerName || !!status;
  return /* @__PURE__ */ jsxDEV(
    "form",
    {
      onSubmit: handleSubmit(handleFilter),
      className: "flex items-center gap-2",
      children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold", children: "Filtros:" }, void 0, false, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-filters.tsx",
          lineNumber: 89,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          Input,
          {
            placeholder: "ID do pedido",
            className: "h-8 w-auto",
            ...register("orderId")
          },
          void 0,
          false,
          {
            fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-filters.tsx",
            lineNumber: 90,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Input,
          {
            placeholder: "Nome do cliente",
            className: "h-8 w-[320px]",
            ...register("customerName")
          },
          void 0,
          false,
          {
            fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-filters.tsx",
            lineNumber: 95,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Controller,
          {
            name: "status",
            control,
            render: ({ field: { name, onChange, value, disabled } }) => {
              return /* @__PURE__ */ jsxDEV(
                Select,
                {
                  defaultValue: "all",
                  name,
                  onValueChange: onChange,
                  value,
                  disabled,
                  children: [
                    /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-8 w-[180px]", children: /* @__PURE__ */ jsxDEV(SelectValue, {}, void 0, false, {
                      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-filters.tsx",
                      lineNumber: 113,
                      columnNumber: 17
                    }, this) }, void 0, false, {
                      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-filters.tsx",
                      lineNumber: 112,
                      columnNumber: 15
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                      /* @__PURE__ */ jsxDEV(SelectItem, { value: "all", children: "Todos" }, void 0, false, {
                        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-filters.tsx",
                        lineNumber: 116,
                        columnNumber: 17
                      }, this),
                      /* @__PURE__ */ jsxDEV(SelectItem, { value: "pending", children: "Pendente" }, void 0, false, {
                        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-filters.tsx",
                        lineNumber: 117,
                        columnNumber: 17
                      }, this),
                      /* @__PURE__ */ jsxDEV(SelectItem, { value: "canceled", children: "Cancelado" }, void 0, false, {
                        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-filters.tsx",
                        lineNumber: 118,
                        columnNumber: 17
                      }, this),
                      /* @__PURE__ */ jsxDEV(SelectItem, { value: "processing", children: "Em preparo" }, void 0, false, {
                        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-filters.tsx",
                        lineNumber: 119,
                        columnNumber: 17
                      }, this),
                      /* @__PURE__ */ jsxDEV(SelectItem, { value: "delivering", children: "Em entrega" }, void 0, false, {
                        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-filters.tsx",
                        lineNumber: 120,
                        columnNumber: 17
                      }, this),
                      /* @__PURE__ */ jsxDEV(SelectItem, { value: "delivered", children: "Entregue" }, void 0, false, {
                        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-filters.tsx",
                        lineNumber: 121,
                        columnNumber: 17
                      }, this)
                    ] }, void 0, true, {
                      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-filters.tsx",
                      lineNumber: 115,
                      columnNumber: 15
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-filters.tsx",
                  lineNumber: 105,
                  columnNumber: 13
                },
                this
              );
            }
          },
          void 0,
          false,
          {
            fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-filters.tsx",
            lineNumber: 100,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(Button, { type: "submit", variant: "secondary", size: "xs", children: [
          /* @__PURE__ */ jsxDEV(Search, { className: "mr-2 h-4 w-4" }, void 0, false, {
            fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-filters.tsx",
            lineNumber: 129,
            columnNumber: 9
          }, this),
          "Filtrar resultados"
        ] }, void 0, true, {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-filters.tsx",
          lineNumber: 128,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            onClick: handleClearFilters,
            type: "button",
            variant: "outline",
            size: "xs",
            disabled: !hasAnyFilter,
            children: [
              /* @__PURE__ */ jsxDEV(X, { className: "mr-2 h-4 w-4" }, void 0, false, {
                fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-filters.tsx",
                lineNumber: 140,
                columnNumber: 9
              }, this),
              "Remover filtros"
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-filters.tsx",
            lineNumber: 133,
            columnNumber: 7
          },
          this
        )
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-filters.tsx",
      lineNumber: 85,
      columnNumber: 5
    },
    this
  );
}
_s(OrderTableFilters, "feHCo+4TPh8lpkrfrpltwU9U2Mo=", false, function() {
  return [useSearchParams, useForm];
});
_c = OrderTableFilters;
var _c;
$RefreshReg$(_c, "OrderTableFilters");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-filters.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0ZNOzJCQXhGTjtBQUFvQixvQkFBUSw2QkFBeUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDckQsU0FBU0EsUUFBUUMsU0FBUztBQUMxQixTQUFTQyxZQUFZQyxlQUFlO0FBQ3BDLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxTQUFTO0FBRWxCLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsYUFBYTtBQUN0QjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFFUCxNQUFNQyxxQkFBcUJSLEVBQUVTLE9BQU87QUFBQSxFQUNsQ0MsU0FBU1YsRUFBRVcsT0FBTyxFQUFFQyxTQUFTO0FBQUEsRUFDN0JDLGNBQWNiLEVBQUVXLE9BQU8sRUFBRUMsU0FBUztBQUFBLEVBQ2xDRSxRQUFRZCxFQUFFVyxPQUFPLEVBQUVDLFNBQVM7QUFDOUIsQ0FBQztBQUlNLGdCQUFTRyxvQkFBb0I7QUFBQUMsS0FBQTtBQUNsQyxRQUFNLENBQUNDLGNBQWNDLGVBQWUsSUFBSW5CLGdCQUFnQjtBQUV4RCxRQUFNVyxVQUFVTyxhQUFhRSxJQUFJLFNBQVM7QUFDMUMsUUFBTU4sZUFBZUksYUFBYUUsSUFBSSxjQUFjO0FBQ3BELFFBQU1MLFNBQVNHLGFBQWFFLElBQUksUUFBUTtBQUV4QyxRQUFNLEVBQUVDLFVBQVVDLGNBQWNDLFNBQVNDLE1BQU0sSUFDN0N6QixRQUE0QjtBQUFBLElBQzFCMEIsVUFBVUMsWUFBWWpCLGtCQUFrQjtBQUFBLElBQ3hDa0IsZUFBZTtBQUFBLE1BQ2JoQixTQUFTQSxXQUFXO0FBQUEsTUFDcEJHLGNBQWNBLGdCQUFnQjtBQUFBLE1BQzlCQyxRQUFRQSxVQUFVO0FBQUEsSUFDcEI7QUFBQSxFQUNGLENBQUM7QUFFSCxXQUFTYSxhQUFhLEVBQUVqQixtQkFBU0csNkJBQWNDLGdCQUEyQixHQUFHO0FBQzNFSSxvQkFBZ0IsQ0FBQ1UsVUFBVTtBQUN6QixVQUFJbEIsVUFBUztBQUNYa0IsY0FBTUMsSUFBSSxXQUFXbkIsUUFBTztBQUFBLE1BQzlCLE9BQU87QUFDTGtCLGNBQU1FLE9BQU8sU0FBUztBQUFBLE1BQ3hCO0FBQ0EsVUFBSWpCLGVBQWM7QUFDaEJlLGNBQU1DLElBQUksZ0JBQWdCaEIsYUFBWTtBQUFBLE1BQ3hDLE9BQU87QUFDTGUsY0FBTUUsT0FBTyxjQUFjO0FBQUEsTUFDN0I7QUFDQSxVQUFJaEIsU0FBUTtBQUNWYyxjQUFNQyxJQUFJLFVBQVVmLE9BQU07QUFBQSxNQUM1QixPQUFPO0FBQ0xjLGNBQU1FLE9BQU8sUUFBUTtBQUFBLE1BQ3ZCO0FBQ0FGLFlBQU1DLElBQUksUUFBUSxHQUFHO0FBRXJCLGFBQU9EO0FBQUFBLElBQ1QsQ0FBQztBQUFBLEVBQ0g7QUFFQSxXQUFTRyxxQkFBcUI7QUFDNUJiLG9CQUFnQixDQUFDVSxVQUFVO0FBQ3pCQSxZQUFNRSxPQUFPLFNBQVM7QUFDdEJGLFlBQU1FLE9BQU8sY0FBYztBQUMzQkYsWUFBTUUsT0FBTyxRQUFRO0FBQ3JCRixZQUFNQyxJQUFJLFFBQVEsR0FBRztBQUVyQixhQUFPRDtBQUFBQSxJQUNULENBQUM7QUFFREwsVUFBTTtBQUFBLE1BQ0piLFNBQVM7QUFBQSxNQUNURyxjQUFjO0FBQUEsTUFDZEMsUUFBUTtBQUFBLElBQ1YsQ0FBQztBQUFBLEVBQ0g7QUFFQSxRQUFNa0IsZUFBZSxDQUFDLENBQUN0QixXQUFXLENBQUMsQ0FBQ0csZ0JBQWdCLENBQUMsQ0FBQ0M7QUFFdEQsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsVUFBVU8sYUFBYU0sWUFBWTtBQUFBLE1BQ25DLFdBQVU7QUFBQSxNQUVWO0FBQUEsK0JBQUMsVUFBSyxXQUFVLHlCQUF3Qix3QkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRDtBQUFBLFFBQ2hEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxhQUFZO0FBQUEsWUFDWixXQUFVO0FBQUEsWUFDVixHQUFJUCxTQUFTLFNBQVM7QUFBQTtBQUFBLFVBSHhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUcwQjtBQUFBLFFBRTFCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxhQUFZO0FBQUEsWUFDWixXQUFVO0FBQUEsWUFDVixHQUFJQSxTQUFTLGNBQWM7QUFBQTtBQUFBLFVBSDdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUcrQjtBQUFBLFFBRS9CO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTDtBQUFBLFlBQ0EsUUFBUSxDQUFDLEVBQUVhLE9BQU8sRUFBRUMsTUFBTUMsVUFBVUMsT0FBT0MsU0FBUyxFQUFFLE1BQU07QUFDMUQscUJBQ0U7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsY0FBYTtBQUFBLGtCQUNiO0FBQUEsa0JBQ0EsZUFBZUY7QUFBQUEsa0JBQ2Y7QUFBQSxrQkFDQTtBQUFBLGtCQUVBO0FBQUEsMkNBQUMsaUJBQWMsV0FBVSxpQkFDdkIsaUNBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBWSxLQURkO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxpQkFDQztBQUFBLDZDQUFDLGNBQVcsT0FBTSxPQUFNLHFCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE2QjtBQUFBLHNCQUM3Qix1QkFBQyxjQUFXLE9BQU0sV0FBVSx3QkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBb0M7QUFBQSxzQkFDcEMsdUJBQUMsY0FBVyxPQUFNLFlBQVcseUJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXNDO0FBQUEsc0JBQ3RDLHVCQUFDLGNBQVcsT0FBTSxjQUFhLDBCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF5QztBQUFBLHNCQUN6Qyx1QkFBQyxjQUFXLE9BQU0sY0FBYSwwQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBeUM7QUFBQSxzQkFDekMsdUJBQUMsY0FBVyxPQUFNLGFBQVksd0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXNDO0FBQUEseUJBTnhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBT0E7QUFBQTtBQUFBO0FBQUEsZ0JBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWtCQTtBQUFBLFlBRUo7QUFBQTtBQUFBLFVBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQXlCSTtBQUFBLFFBR0osdUJBQUMsVUFBTyxNQUFLLFVBQVMsU0FBUSxhQUFZLE1BQUssTUFDN0M7QUFBQSxpQ0FBQyxVQUFPLFdBQVUsa0JBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdDO0FBQUE7QUFBQSxhQURsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUVBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTSjtBQUFBQSxZQUNULE1BQUs7QUFBQSxZQUNMLFNBQVE7QUFBQSxZQUNSLE1BQUs7QUFBQSxZQUNMLFVBQVUsQ0FBQ0M7QUFBQUEsWUFFWDtBQUFBLHFDQUFDLEtBQUUsV0FBVSxrQkFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUDdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVNBO0FBQUE7QUFBQTtBQUFBLElBekRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQTBEQTtBQUVKO0FBQUNoQixHQXhIZUQsbUJBQWlCO0FBQUEsVUFDU2hCLGlCQU90Q0QsT0FBTztBQUFBO0FBQUF3QyxLQVJLdkI7QUFBaUIsSUFBQXVCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJTZWFyY2giLCJYIiwiQ29udHJvbGxlciIsInVzZUZvcm0iLCJ1c2VTZWFyY2hQYXJhbXMiLCJ6IiwiQnV0dG9uIiwiSW5wdXQiLCJTZWxlY3QiLCJTZWxlY3RDb250ZW50IiwiU2VsZWN0SXRlbSIsIlNlbGVjdFRyaWdnZXIiLCJTZWxlY3RWYWx1ZSIsIm9yZGVyRmlsdGVyc1NjaGVtYSIsIm9iamVjdCIsIm9yZGVySWQiLCJzdHJpbmciLCJvcHRpb25hbCIsImN1c3RvbWVyTmFtZSIsInN0YXR1cyIsIk9yZGVyVGFibGVGaWx0ZXJzIiwiX3MiLCJzZWFyY2hQYXJhbXMiLCJzZXRTZWFyY2hQYXJhbXMiLCJnZXQiLCJyZWdpc3RlciIsImhhbmRsZVN1Ym1pdCIsImNvbnRyb2wiLCJyZXNldCIsInJlc29sdmVyIiwiem9kUmVzb2x2ZXIiLCJkZWZhdWx0VmFsdWVzIiwiaGFuZGxlRmlsdGVyIiwic3RhdGUiLCJzZXQiLCJkZWxldGUiLCJoYW5kbGVDbGVhckZpbHRlcnMiLCJoYXNBbnlGaWx0ZXIiLCJmaWVsZCIsIm5hbWUiLCJvbkNoYW5nZSIsInZhbHVlIiwiZGlzYWJsZWQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIm9yZGVyLXRhYmxlLWZpbHRlcnMudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHpvZFJlc29sdmVyIH0gZnJvbSAnQGhvb2tmb3JtL3Jlc29sdmVycy96b2QnXG5pbXBvcnQgeyBTZWFyY2gsIFggfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgeyBDb250cm9sbGVyLCB1c2VGb3JtIH0gZnJvbSAncmVhY3QtaG9vay1mb3JtJ1xuaW1wb3J0IHsgdXNlU2VhcmNoUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcbmltcG9ydCB7IHogfSBmcm9tICd6b2QnXG5cbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9idXR0b24nXG5pbXBvcnQgeyBJbnB1dCB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9pbnB1dCdcbmltcG9ydCB7XG4gIFNlbGVjdCxcbiAgU2VsZWN0Q29udGVudCxcbiAgU2VsZWN0SXRlbSxcbiAgU2VsZWN0VHJpZ2dlcixcbiAgU2VsZWN0VmFsdWUsXG59IGZyb20gJ0AvY29tcG9uZW50cy91aS9zZWxlY3QnXG5cbmNvbnN0IG9yZGVyRmlsdGVyc1NjaGVtYSA9IHoub2JqZWN0KHtcbiAgb3JkZXJJZDogei5zdHJpbmcoKS5vcHRpb25hbCgpLFxuICBjdXN0b21lck5hbWU6IHouc3RyaW5nKCkub3B0aW9uYWwoKSxcbiAgc3RhdHVzOiB6LnN0cmluZygpLm9wdGlvbmFsKCksXG59KVxuXG50eXBlIE9yZGVyRmlsdGVyc1NjaGVtYSA9IHouaW5mZXI8dHlwZW9mIG9yZGVyRmlsdGVyc1NjaGVtYT5cblxuZXhwb3J0IGZ1bmN0aW9uIE9yZGVyVGFibGVGaWx0ZXJzKCkge1xuICBjb25zdCBbc2VhcmNoUGFyYW1zLCBzZXRTZWFyY2hQYXJhbXNdID0gdXNlU2VhcmNoUGFyYW1zKClcblxuICBjb25zdCBvcmRlcklkID0gc2VhcmNoUGFyYW1zLmdldCgnb3JkZXJJZCcpXG4gIGNvbnN0IGN1c3RvbWVyTmFtZSA9IHNlYXJjaFBhcmFtcy5nZXQoJ2N1c3RvbWVyTmFtZScpXG4gIGNvbnN0IHN0YXR1cyA9IHNlYXJjaFBhcmFtcy5nZXQoJ3N0YXR1cycpXG5cbiAgY29uc3QgeyByZWdpc3RlciwgaGFuZGxlU3VibWl0LCBjb250cm9sLCByZXNldCB9ID1cbiAgICB1c2VGb3JtPE9yZGVyRmlsdGVyc1NjaGVtYT4oe1xuICAgICAgcmVzb2x2ZXI6IHpvZFJlc29sdmVyKG9yZGVyRmlsdGVyc1NjaGVtYSksXG4gICAgICBkZWZhdWx0VmFsdWVzOiB7XG4gICAgICAgIG9yZGVySWQ6IG9yZGVySWQgPz8gJycsXG4gICAgICAgIGN1c3RvbWVyTmFtZTogY3VzdG9tZXJOYW1lID8/ICcnLFxuICAgICAgICBzdGF0dXM6IHN0YXR1cyA/PyAnYWxsJyxcbiAgICAgIH0sXG4gICAgfSlcblxuICBmdW5jdGlvbiBoYW5kbGVGaWx0ZXIoeyBvcmRlcklkLCBjdXN0b21lck5hbWUsIHN0YXR1cyB9OiBPcmRlckZpbHRlcnNTY2hlbWEpIHtcbiAgICBzZXRTZWFyY2hQYXJhbXMoKHN0YXRlKSA9PiB7XG4gICAgICBpZiAob3JkZXJJZCkge1xuICAgICAgICBzdGF0ZS5zZXQoJ29yZGVySWQnLCBvcmRlcklkKVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc3RhdGUuZGVsZXRlKCdvcmRlcklkJylcbiAgICAgIH1cbiAgICAgIGlmIChjdXN0b21lck5hbWUpIHtcbiAgICAgICAgc3RhdGUuc2V0KCdjdXN0b21lck5hbWUnLCBjdXN0b21lck5hbWUpXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzdGF0ZS5kZWxldGUoJ2N1c3RvbWVyTmFtZScpXG4gICAgICB9XG4gICAgICBpZiAoc3RhdHVzKSB7XG4gICAgICAgIHN0YXRlLnNldCgnc3RhdHVzJywgc3RhdHVzKVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc3RhdGUuZGVsZXRlKCdzdGF0dXMnKVxuICAgICAgfVxuICAgICAgc3RhdGUuc2V0KCdwYWdlJywgJzEnKVxuXG4gICAgICByZXR1cm4gc3RhdGVcbiAgICB9KVxuICB9XG5cbiAgZnVuY3Rpb24gaGFuZGxlQ2xlYXJGaWx0ZXJzKCkge1xuICAgIHNldFNlYXJjaFBhcmFtcygoc3RhdGUpID0+IHtcbiAgICAgIHN0YXRlLmRlbGV0ZSgnb3JkZXJJZCcpXG4gICAgICBzdGF0ZS5kZWxldGUoJ2N1c3RvbWVyTmFtZScpXG4gICAgICBzdGF0ZS5kZWxldGUoJ3N0YXR1cycpXG4gICAgICBzdGF0ZS5zZXQoJ3BhZ2UnLCAnMScpXG5cbiAgICAgIHJldHVybiBzdGF0ZVxuICAgIH0pXG5cbiAgICByZXNldCh7XG4gICAgICBvcmRlcklkOiAnJyxcbiAgICAgIGN1c3RvbWVyTmFtZTogJycsXG4gICAgICBzdGF0dXM6ICdhbGwnLFxuICAgIH0pXG4gIH1cblxuICBjb25zdCBoYXNBbnlGaWx0ZXIgPSAhIW9yZGVySWQgfHwgISFjdXN0b21lck5hbWUgfHwgISFzdGF0dXNcblxuICByZXR1cm4gKFxuICAgIDxmb3JtXG4gICAgICBvblN1Ym1pdD17aGFuZGxlU3VibWl0KGhhbmRsZUZpbHRlcil9XG4gICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiXG4gICAgPlxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkXCI+RmlsdHJvczo8L3NwYW4+XG4gICAgICA8SW5wdXRcbiAgICAgICAgcGxhY2Vob2xkZXI9XCJJRCBkbyBwZWRpZG9cIlxuICAgICAgICBjbGFzc05hbWU9XCJoLTggdy1hdXRvXCJcbiAgICAgICAgey4uLnJlZ2lzdGVyKCdvcmRlcklkJyl9XG4gICAgICAvPlxuICAgICAgPElucHV0XG4gICAgICAgIHBsYWNlaG9sZGVyPVwiTm9tZSBkbyBjbGllbnRlXCJcbiAgICAgICAgY2xhc3NOYW1lPVwiaC04IHctWzMyMHB4XVwiXG4gICAgICAgIHsuLi5yZWdpc3RlcignY3VzdG9tZXJOYW1lJyl9XG4gICAgICAvPlxuICAgICAgPENvbnRyb2xsZXJcbiAgICAgICAgbmFtZT1cInN0YXR1c1wiXG4gICAgICAgIGNvbnRyb2w9e2NvbnRyb2x9XG4gICAgICAgIHJlbmRlcj17KHsgZmllbGQ6IHsgbmFtZSwgb25DaGFuZ2UsIHZhbHVlLCBkaXNhYmxlZCB9IH0pID0+IHtcbiAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgPFNlbGVjdFxuICAgICAgICAgICAgICBkZWZhdWx0VmFsdWU9XCJhbGxcIlxuICAgICAgICAgICAgICBuYW1lPXtuYW1lfVxuICAgICAgICAgICAgICBvblZhbHVlQ2hhbmdlPXtvbkNoYW5nZX1cbiAgICAgICAgICAgICAgdmFsdWU9e3ZhbHVlfVxuICAgICAgICAgICAgICBkaXNhYmxlZD17ZGlzYWJsZWR9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxTZWxlY3RUcmlnZ2VyIGNsYXNzTmFtZT1cImgtOCB3LVsxODBweF1cIj5cbiAgICAgICAgICAgICAgICA8U2VsZWN0VmFsdWUgLz5cbiAgICAgICAgICAgICAgPC9TZWxlY3RUcmlnZ2VyPlxuICAgICAgICAgICAgICA8U2VsZWN0Q29udGVudD5cbiAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cImFsbFwiPlRvZG9zPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwicGVuZGluZ1wiPlBlbmRlbnRlPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiY2FuY2VsZWRcIj5DYW5jZWxhZG88L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJwcm9jZXNzaW5nXCI+RW0gcHJlcGFybzwvU2VsZWN0SXRlbT5cbiAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cImRlbGl2ZXJpbmdcIj5FbSBlbnRyZWdhPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiZGVsaXZlcmVkXCI+RW50cmVndWU8L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgIDwvU2VsZWN0Q29udGVudD5cbiAgICAgICAgICAgIDwvU2VsZWN0PlxuICAgICAgICAgIClcbiAgICAgICAgfX1cbiAgICAgIC8+XG5cbiAgICAgIDxCdXR0b24gdHlwZT1cInN1Ym1pdFwiIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIiBzaXplPVwieHNcIj5cbiAgICAgICAgPFNlYXJjaCBjbGFzc05hbWU9XCJtci0yIGgtNCB3LTRcIiAvPlxuICAgICAgICBGaWx0cmFyIHJlc3VsdGFkb3NcbiAgICAgIDwvQnV0dG9uPlxuXG4gICAgICA8QnV0dG9uXG4gICAgICAgIG9uQ2xpY2s9e2hhbmRsZUNsZWFyRmlsdGVyc31cbiAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcbiAgICAgICAgc2l6ZT1cInhzXCJcbiAgICAgICAgZGlzYWJsZWQ9eyFoYXNBbnlGaWx0ZXJ9XG4gICAgICA+XG4gICAgICAgIDxYIGNsYXNzTmFtZT1cIm1yLTIgaC00IHctNFwiIC8+XG4gICAgICAgIFJlbW92ZXIgZmlsdHJvc1xuICAgICAgPC9CdXR0b24+XG4gICAgPC9mb3JtPlxuICApXG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9hcnJ1ZGF5L0dpdEh1Yi9waXp6YXNob3Avc3JjL3BhZ2VzL2FwcC9vcmRlcnMvb3JkZXItdGFibGUtZmlsdGVycy50c3gifQ==