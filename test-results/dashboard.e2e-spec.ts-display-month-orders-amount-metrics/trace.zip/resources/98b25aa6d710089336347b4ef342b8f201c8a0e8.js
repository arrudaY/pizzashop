import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/app/orders/order-table-skeleton.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=efc33bbd"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-skeleton.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Search } from "/node_modules/.vite/deps/lucide-react.js?v=efc33bbd";
import { Button } from "/src/components/ui/button.tsx";
import { Skeleton } from "/src/components/ui/skeleton.tsx";
import { TableCell, TableRow } from "/src/components/ui/table.tsx";
export function OrderTableSkeleton() {
  return Array.from({ length: 10 }).map((_, i) => {
    return /* @__PURE__ */ jsxDEV(TableRow, { children: [
      /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(
        Button,
        {
          disabled: true,
          variant: "outline",
          size: "xs",
          title: "Detalhes do pedido",
          children: [
            /* @__PURE__ */ jsxDEV(Search, { className: "h-3 w-3" }, void 0, false, {
              fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-skeleton.tsx",
              lineNumber: 18,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: "Detalhes do pedido" }, void 0, false, {
              fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-skeleton.tsx",
              lineNumber: 19,
              columnNumber: 13
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-skeleton.tsx",
          lineNumber: 12,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 11,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-4 w-[172px]" }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 24,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 23,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-4 w-[148px]" }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 28,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 27,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-4 w-[110px]" }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 32,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 31,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-4 w-[200px]" }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 36,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 35,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-4 w-[64px]" }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 40,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 39,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-4 w-[92px]" }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 44,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 43,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-4 w-[110px]" }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 48,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 47,
        columnNumber: 9
      }, this)
    ] }, i, true, {
      fileName: "/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-skeleton.tsx",
      lineNumber: 10,
      columnNumber: 7
    }, this);
  });
}
_c = OrderTableSkeleton;
var _c;
$RefreshReg$(_c, "OrderTableSkeleton");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arruday/GitHub/pizzashop/src/pages/app/orders/order-table-skeleton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJZO0FBakJaLDJCQUF1QjtBQUFjO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVyQyxTQUFTQSxjQUFjO0FBQ3ZCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxXQUFXQyxnQkFBZ0I7QUFFN0IsZ0JBQVNDLHFCQUFxQjtBQUNuQyxTQUFPQyxNQUFNQyxLQUFLLEVBQUVDLFFBQVEsR0FBRyxDQUFDLEVBQUVDLElBQUksQ0FBQ0MsR0FBR0MsTUFBTTtBQUM5QyxXQUNFLHVCQUFDLFlBQ0M7QUFBQSw2QkFBQyxhQUNDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQztBQUFBLFVBQ0EsU0FBUTtBQUFBLFVBQ1IsTUFBSztBQUFBLFVBQ0wsT0FBTTtBQUFBLFVBRU47QUFBQSxtQ0FBQyxVQUFPLFdBQVUsYUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkI7QUFBQSxZQUMzQix1QkFBQyxVQUFLLFdBQVUsV0FBVSxrQ0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEM7QUFBQTtBQUFBO0FBQUEsUUFQOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxNQUVBLHVCQUFDLGFBQ0MsaUNBQUMsWUFBUyxXQUFVLG1CQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1DLEtBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRUEsdUJBQUMsYUFDQyxpQ0FBQyxZQUFTLFdBQVUsbUJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUMsS0FEckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFQSx1QkFBQyxhQUNDLGlDQUFDLFlBQVMsV0FBVSxtQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtQyxLQURyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUVBLHVCQUFDLGFBQ0MsaUNBQUMsWUFBUyxXQUFVLG1CQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1DLEtBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRUEsdUJBQUMsYUFDQyxpQ0FBQyxZQUFTLFdBQVUsa0JBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0MsS0FEcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFQSx1QkFBQyxhQUNDLGlDQUFDLFlBQVMsV0FBVSxrQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrQyxLQURwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUVBLHVCQUFDLGFBQ0MsaUNBQUMsWUFBUyxXQUFVLG1CQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1DLEtBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBdkNhQSxHQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3Q0E7QUFBQSxFQUVKLENBQUM7QUFDSDtBQUFDQyxLQTlDZVA7QUFBa0IsSUFBQU87QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkJ1dHRvbiIsIlNrZWxldG9uIiwiVGFibGVDZWxsIiwiVGFibGVSb3ciLCJPcmRlclRhYmxlU2tlbGV0b24iLCJBcnJheSIsImZyb20iLCJsZW5ndGgiLCJtYXAiLCJfIiwiaSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsib3JkZXItdGFibGUtc2tlbGV0b24udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFNlYXJjaCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcblxuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2J1dHRvbidcbmltcG9ydCB7IFNrZWxldG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL3NrZWxldG9uJ1xuaW1wb3J0IHsgVGFibGVDZWxsLCBUYWJsZVJvdyB9IGZyb20gJ0AvY29tcG9uZW50cy91aS90YWJsZSdcblxuZXhwb3J0IGZ1bmN0aW9uIE9yZGVyVGFibGVTa2VsZXRvbigpIHtcbiAgcmV0dXJuIEFycmF5LmZyb20oeyBsZW5ndGg6IDEwIH0pLm1hcCgoXywgaSkgPT4ge1xuICAgIHJldHVybiAoXG4gICAgICA8VGFibGVSb3cga2V5PXtpfT5cbiAgICAgICAgPFRhYmxlQ2VsbD5cbiAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICBkaXNhYmxlZFxuICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxuICAgICAgICAgICAgc2l6ZT1cInhzXCJcbiAgICAgICAgICAgIHRpdGxlPVwiRGV0YWxoZXMgZG8gcGVkaWRvXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8U2VhcmNoIGNsYXNzTmFtZT1cImgtMyB3LTNcIiAvPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3Itb25seVwiPkRldGFsaGVzIGRvIHBlZGlkbzwvc3Bhbj5cbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgPC9UYWJsZUNlbGw+XG5cbiAgICAgICAgPFRhYmxlQ2VsbD5cbiAgICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiaC00IHctWzE3MnB4XVwiIC8+XG4gICAgICAgIDwvVGFibGVDZWxsPlxuXG4gICAgICAgIDxUYWJsZUNlbGw+XG4gICAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtNCB3LVsxNDhweF1cIiAvPlxuICAgICAgICA8L1RhYmxlQ2VsbD5cblxuICAgICAgICA8VGFibGVDZWxsPlxuICAgICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJoLTQgdy1bMTEwcHhdXCIgLz5cbiAgICAgICAgPC9UYWJsZUNlbGw+XG5cbiAgICAgICAgPFRhYmxlQ2VsbD5cbiAgICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiaC00IHctWzIwMHB4XVwiIC8+XG4gICAgICAgIDwvVGFibGVDZWxsPlxuXG4gICAgICAgIDxUYWJsZUNlbGw+XG4gICAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtNCB3LVs2NHB4XVwiIC8+XG4gICAgICAgIDwvVGFibGVDZWxsPlxuXG4gICAgICAgIDxUYWJsZUNlbGw+XG4gICAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtNCB3LVs5MnB4XVwiIC8+XG4gICAgICAgIDwvVGFibGVDZWxsPlxuXG4gICAgICAgIDxUYWJsZUNlbGw+XG4gICAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtNCB3LVsxMTBweF1cIiAvPlxuICAgICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgIDwvVGFibGVSb3c+XG4gICAgKVxuICB9KVxufVxuIl0sImZpbGUiOiIvVXNlcnMvYXJydWRheS9HaXRIdWIvcGl6emFzaG9wL3NyYy9wYWdlcy9hcHAvb3JkZXJzL29yZGVyLXRhYmxlLXNrZWxldG9uLnRzeCJ9